# Bounded direct-handoff progress diagnostics

The dedicated test driver and native entry have optional progress diagnostics.
They change no transfer checks, readiness rules, protocol payloads or clocks.
The probe and exact instance-ID fixture remain untouched. All 18 Node tests pass,
including six focused progress tests; native execution is separate Root evidence.
Exact source pins and coverage are in the [receipt](reports/native-direct-handoff-progress-v1.json).

Root enables the driver with `progressDiagnostics:true` and adds the native user
argument `--direct-handoff-progress=true`. Both default off. Existing `tick()`
records progress before its test-state early returns. Root can supply actual
`rawPending`, pending serial/generation, pending command count and last command
kind through `getScope`; it may pass catalogue count/ticks or a hook phase to
`diagnostic(extra)`. The authenticated direct-only native progress message can
bypass the ordinary serialized command lane without changing other commands.

Sampling is limited to once per two seconds. A record is at most 4 KiB and atomically
replaces `direct-progress.json` inside the verified private fixture. There is one
active write and one coalesced latest pending snapshot. Session, connection,
generation and area are checked again before rename. Old-source or closed writes
cannot commit, and clock/I/O failures remain diagnostic errors rather than transfer
failures. There is no payload history, whole-world snapshot or queue traversal.

Host fields identify phase, area readiness, tile presence/count, catalogue/raw
publication and command backlog. Native fields identify initialization/world
readiness, instance/batch/raw counts, accepted serial, TCP status/available bytes,
bridge buffer bytes, output counts and frame/ticks. The native entry also stores
scalar frontiers immediately before and after the existing receive call. The
after marker means that call returned; it does not certify completion of separate
asynchronous jobs. No message dictionary or body is retained in the frontier.

`flushDiagnostics()` permits final bounded I/O to settle before capture. `close()`
drops pending work and prevents later publication. These diagnostics alone do not
explain the earlier IPC resets or loading stall, and establish no new runtime,
rendering, clock-provider or performance acceptance.
