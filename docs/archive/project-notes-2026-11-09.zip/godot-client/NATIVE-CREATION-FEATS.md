# Original creation Feats and shared feat-slot rules

Current follow-ups: the [active first-level Feats binding](NATIVE-CREATION-FEAT-ADAPTER.md)
and [class-dependent continuation/School](NATIVE-CREATION-SCHOOL.md) now bind the
staged source controls to the draft. The evidence below describes the earlier
milestones and their historical scope, not the current binding limit.
The earlier milestone corrects the shared creation/level-up slot counter.
Source creation, full level-up, original pixels and the overall UI goal remain
open. Do not treat arithmetic checks as source Feats acceptance.

The [spell-capacity composition follow-up](NATIVE-CREATION-FEAT-CAPACITY.md)
now covers memorizing and mixed-class prerequisites through the existing native
spell-gain owner, with384 unchanged-original cases and2,649 native checks.
Unavailable capacity remains explicit. This closes a prerequisite-core gap;
the complete active-table draft adapter and live CG_FEATS binding remain open.

## Active data and original counters

`systems/native_data/creation_feat_slots.gd` now owns both actual callers:
`creation_rules.gd::feat_slots` and `native_level_up.gd::feat_slots`. It follows
the current connection's physical racialtypes/classes rows and the selected
class's BonusFeatsTable. No embedded choice list is introduced. Creation uses
total/class level1; level-up uses new total level and new selected-class level.
The original server still validates and commits the proposal.

Original7ec290 returns BYTE normal/bonus counters. NormalFeatEveryNthLevel is a
signed32 period; the total level is a byte. Level1 always receives the configured
normal count plus configured first-level extras with byte wrapping. Later levels
receive that count only at a nonzero period's divisibility boundary, including
negative signed periods. Bonus counts are bytes from physical class levels1..60;
the original getter2997d0 returns0 outside that range.

LoadRaceInfo2aa460 supplies format defaults only when the corresponding columns
are absent: period3, normal count1, and extra1 only for legacy physical race6.
Present server columns own their values, including blank/zero. These historical
format defaults are original loader behavior, not a replacement race list.
LoadBonusFeatsTable29a6c0 loads the first60 physical Bonus cells. Missing physical
rows use the table's DEFAULT value, while explicit `****` cells convert to0.
The native counter preserves these distinctions. General malformed-integer
parsing beyond the existing native table scalar reader remains a separate issue.

## Scoped verification

Pinned original binary SHA256:
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.

`scripts/inspect-native-creation-feat-slots.py` executes complete original
7ec290/7f5d70/7f10a0/2997d0 instructions in the isolated CPU emulator, with
decoded race/class/stat fixtures and no substituted helper boundaries. Its288
cases include multiclass totals, byte wraps, signed/zero periods, first-level
extras and class bonus levels at/outside60. It neither reads a running process
nor uses the GPU/server. The corpus is
`../backups/animations/native-creation-feat-slots-observations-v1.json`, SHA256
`5842d021351c5a7c4b9cce7786f6b484892ef4ef3728b95023e4f62c395c7534`.

Headless debugger receipts for the current core and callers:

- `reports/native-creation-feat-slots-binding-v1.debugger.json`:1128 checks;
  original corpus, table projection, actual creation/level-up owners and parsed
  authored2DA physical rows/defaults.
- `reports/native-creation-feat-slots-package-regression-v1.debugger.json`:389.
- `reports/native-creation-feat-slots-skills-regression-v1.debugger.json`:5144.

All three passed with sourceUnchanged=true and no engine/lifetime/debugger
exceptions. These are headless CPU checks, not visual, performance, full
prerequisite, mounted-server replacement or authoritative upload acceptance.
The earlier Skills original-server admission remains scoped to its own sealed
version. No public connection was made for this milestone.

Before-wiring checkpoint: `backups/native-creation-feats-slot-before-v1.zip`,
2448 files, SHA256
`09a56a7d17a5e842c1de122af58ae0b1596ba912138401f08e47a3ac258ca6c8`.

## Staged source view and popup controls

`native_feats_chooser.gd`, `native_feat_popup.gd` and
`creation_feats_layout.gd` now prepare the original two-list frame and distinct
CG_FEATS_POPUP/CG_SPELLINFO children through shared native modal/painter services.
`reports/native-creation-feats-view-v3.debugger.json` passes31 checks with
sourceUnchanged=true and no engine/lifetime/debugger errors. The real original
GFF/model geometry is used; artwork/font upload is doubled and data models are
authored fixtures. Physical inputs check row selection, hover-only info,
add/remove physical IDs, granted-row disabling, both popup lifecycles,
one/multiple family choices, Recommended/Reset dispatch, pending/replacement
retirement, both Escape routes and scaled helper hit regions. It is not a
draft commit, authoritative server result, original-pixel, exact font/wrap or
complete rule acceptance test. Production creation does not open this view yet.

The physical test found and corrected popup Control ordering: Godot's z_index
does not change hit testing. Both child windows now move after parent controls
at placement/open, ensuring their visible buttons receive input. Failed v1
(explicit String inference) and v2 (popup input then invalid test index) evidence
is retained. Only their uniquely identified headless test processes were stopped;
user/editor/server processes were preserved. The test now has a bounded lifetime.

## Original Feats workflow still to bind

The later `creation_feat_requirements.gd` core now matches360 complete original
7ee690 executions (180 accepted/180 rejected) and eleven reached helpers with
no substituted boundaries. `reports/native-creation-feat-requirements-v1.debugger.json`
passes725 checks, sourceUnchanged=true, without engine/lifetime/debugger errors.
The independent corpus is
`../backups/animations/native-creation-feat-requirements-observations-v1.json`,
SHA256`c1d83c3a2a1bbfd6dffc607dec6ab86bc09052c7908eff069497669f8b45285c`.
Its authored driver is `scripts/inspect-native-creation-feat-requirements.py`.

This core accepts an already decoded, valid native feat/stat snapshot. The
corpus explicitly uses MINSPELLLVL0 and a resolved/non-sentinel BAB cache; it does
not accept original table-loader/default semantics, spell capacity or BAB cache
rebuilding. Positive spell requirements remain ready=false until their original
capacity result is supplied. Owned primary feats satisfy epic prerequisites;
new selected feats satisfy ordinary AND/OR prerequisites, while secondary feats
are excluded as in the original. Skill ranks are signed bytes, rank minima are
unsigned words, and Untrained/class usability and class grant levels are retained.

Before live binding, the adapter MUST enforce complete current-class/score/
cached-BAB/Fort/raw-skill/class-grant data and the connection's active tables.
The decoded core assumes those fields exist and its scalar defaults must never
turn unresolved native data into a definite UI allowed/rejected state. The root
read-only review found no mismatch inside the declared corpus scope and retained
this adapter requirement. No production creator/level-up caller has switched to
this prerequisite core yet.

`creation_feat_spell_rules.gd` adds the original non-memorizing positive
MINSPELL branch. Its288 original executions include complete known-spell/gain/
race/class helpers (127 accepted/161 rejected) without substituted helpers.
`reports/native-creation-feat-spell-requirements-v1.debugger.json` passes869
checks, including composition with the prerequisite core and pending data
states; sourceUnchanged=true, no engine/lifetime/debugger error. Corpus SHA256:
`6197ca5bb2e6937d941d536d68fcd6aa79a12fb86190a128dabb7eb57de32f46`,
at`../backups/animations/native-creation-feat-spell-requirements-observations-v1.json`.
The driver is `scripts/inspect-native-creation-feat-spell-requirements.py`.
These are decoded valid non-memorizing storage fixtures at class levels1..40;
constant physical stat gains normalize to the adapter's per-class cumulative
gain. The memorizing branch, raw table adapter and actual source draft remain
open. Missing raw/racial abilities or class spell storage stays pending.

Additional original loader evidence is retained in
`reports/native-creation-feats-research-v5.json`. Known rows use gain-table
NumSpellLevels and0 on failed cell lookup; gain cells use255 on failed lookup.
The unrestricted caller's `GetSpellGain != 0` deliberately includes that255
sentinel. Do not replace these rules with a generic remaining-uses check or an
invented extra ability gate. The existing native radial spell-gain helper is
the same original7f6b20 used for memorizing prerequisites; reuse its logic only
after the complete active creation/level-up snapshot adapter is checked.

`creation_feat_choice_rules.gd` now reproduces complete CanChooseFeat7ed040
reservation/classification/duplicate rules. The480 original cases execute all
reached prerequisite/class helpers; only malloc/memset/free are explicit ABI
service boundaries. Corpus SHA256:
`1d19d1b1f16106583689b28e44f2fbff01043ca4adaa715ebf69d126c42111b6`,
at`../backups/animations/native-creation-feat-choice-observations-v1.json`.
The driver is `scripts/inspect-native-creation-feat-choice.py`.
`reports/native-creation-feat-choice-v2.debugger.json` passes964 checks,
sourceUnchanged=true, no engine/lifetime/debugger error; all178 accepted and302
rejected original cases match. The failed v1 arithmetic receipt is retained.

The original does not apply a generic slot-bucket feasibility formula: selected
bonus-only entries with bonus0 are deferred and may consume normal slots later,
whereas a new bonus-only candidate with bonus0 fails immediately. Normal-only
entries reserve normal slots, then the candidate reserves its exclusive slot,
then deferred existing entries consume normal/bonus slots. A flexible candidate
requires a slot remaining after that sequence. Class List values wrap to bytes
and use the first matching record; duplicate owned/new physical IDs are rejected
independently of GainMultiple. This decoded valid-snapshot corpus uses
MINSPELL0/cached BAB and is not active-table/source-draft/server acceptance.

`reports/native-creation-feats-research-v6.json` retains SortFeats2adde0 and
CompareFeatName2a3810. Available entries use case-sensitive legacy-byte ordering;
groups sort by MasterFeatName concatenated directly with FeatName. Known rows
sort by plain names separately. Equal comparator keys have no explicit physical
ID tiebreaker; exact CRT qsort tie order remains unproven.

`reports/native-creation-feats-research-v2.json` retains33 original functions,
including complete paged race/feat loader pseudocode. The resource report
`reports/native-creation-feats-resources-v1.json` retains CG_FEATS and
CG_FEATS_POPUP full GFF hierarchy and84 decoded helper models. One unused
CTL_CG_HELPFE helper has ambiguous hook geometry; reader success is not a
claim that every helper or original pixel has been accepted.

CG_FEATS uses two source list controls and separate remaining-count text.
Rows attach add/remove and info buttons. Info is added to the panel only while
the parent row is hovered; child hover forwards to its parent. Granted rows are
disabled and retained by Reset. Newly selected rows are case-sensitive name
sorted after those rows; identical displayed names collapse even for distinct
physical IDs. Names/icons/descriptions use the active feat/masterfeats/TLK.

Available grouped feats open CG_FEATS_POPUP to select a physical child ID. An
exactly-one-entry popup selects it immediately. The distinct information panel
constructor9c3410 uses CG_SPELLINFO, not CG_FEATS_POPUP or an assumed CG_FEATINFO.
Removing a chosen prerequisite repeatedly removes now-invalid chosen dependents.
Recommended resets only selectable feats and uses package FeatPref2DA.
Cancel/Escape resets derived choices and returns3 in creation (2 in level-up).
OK is blocked only when both an available choice and remaining slots exist;
exhausted custom rules may permit unused slots. It commits the physical IDs and
hands ownership to coordinator9c69a0 with800e. The no-feat Skills path passes8010
and requires its own correct class-dependent continuation.

The first-level active-table/source-draft binding has now progressed beyond
these decoded cores. [NATIVE-CREATION-FEAT-ADAPTER.md](NATIVE-CREATION-FEAT-ADAPTER.md)
records515 adapter/original checks,17 actual source-control/draft checks, scoped
menu caching, remaining loader limits and the still-unported class-dependent
continuation. Keep creation staged until the whole original chain, safe saving,
mounted-server data, original pixels and authoritative localhost outcomes pass.

The user-reported missing subtype selection indicator is corrected with the
original CGuiListBox yellow selected text. Source-backed palette observations,
the retained failing reproduction and73 clean actual-control/input regression
checks are recorded in
[NATIVE-FEAT-POPUP-SELECTION.md](NATIVE-FEAT-POPUP-SELECTION.md).
