# Original-style creation flow integration

The production creation owner now enters `CG_MAIN` for the current
`[connection, draft_scope]` once the draft is editable and the source frame is
prepared. This replaces the previous staging-only integration: production
`Create` never called the frontend's `begin`, and its finished/command signals
were unbound. The generic native Godot editor remains a temporary, explicit
fallback for the Appearance/character-information leaves while their source
views are being integrated. This is not full creation or level-up acceptance.

`NativeCreation` owns the draft and native BIC worker. The frontend owns child
tickets and original control routing. `NativeSessionWorld` owns the bounded,
connection-scoped pending entry request. Cancellation retires draft/input
lifetimes. Native creation intents and host replies now include `connection`,
`draft`, and the full operation kind, such as `native-creation-submit`. The host
captures the uploading session before awaiting it. Late old-draft replies and
retired frontend callbacks must not affect a reopened creator.

The Familiar/Companion source child is now wired into the class-dependent
Package continuation. It uses active physical `HEN_FAMILIAR`/`HEN_COMPANION`
rows, the existing native asset service for UTC resources, the original private
pregame record projectors on native workers, and the native active-LTR name
service. It does not borrow the player's stats or instantiate a world entity.
The parent uses ordinary original panel activation; only its distinct
`OKSCROLLPANEL` help child is explicitly registered as modal. Raw Arcane metadata
is preserved because the original table and storage predicates differ.

Accepted standalone controls evidence before integration:
`reports/native-creation-associate-view-v2-receipt.json`: 30 checks, clean engine,
unchanged inputs, physical headless input and 11 pooled controls for a 1,024-row
table. Twelve row handlers took 0.312–0.667 ms. These are synchronous handler
samples with controlled art/fonts, not cold-load, GPU, whole-client, server,
creator-save or original-pixel measurements. The first parse rejection is
retained in `.cache/associate-view-tests/20261103-064246-f93e2f6e`.

The original private UTC import and Familiar help/OK-scroll control owners are
retained in `reports/native-creation-associate-view-static-v1.json`. Earlier
pure policy, original-instruction, resource and native name-generation evidence
remains in `NATIVE-CREATION-ASSOCIATES.md` and `NATIVE-NAME-GENERATION.md`.

`reports/native-pregame-flow-v1-receipt.json` now passes 24 composed native
navigation checks, including actual production entry without a manual `begin`,
Gender commit, Cancel/reopen, late old-draft reply/callback rejection, disconnect
and return through Browser to Main. The accepted current static closure has 571
inputs; the earlier clean engine run lost wrapper finalization to a sharing
violation and is retained as unaccepted infrastructure evidence. Timing tags
still show an 86.8 ms picker-cancel cleanup and a 40.3 ms Gender OK; these need
further diagnosis, not an instant-response claim.

`reports/native-creation-associate-binding-v4-receipt.json` passes 24 checks
through actual Package/Skills/Feats/School/Spells/Associate input, active sparse
2DA/TLK/UTC resources, real native template/name/private-stats workers, committed
draft type/name, and the actual BIC worker. The 6,695-byte output was parsed and
verified to preserve the selected physical ID and generated name. The measured
associate commit took 44.184 ms, still enough overhead to investigate. The test
never uploads to a server. Original-client visual comparison, real server admission, complete
appearance/info leaves, exact original continuation/write ordering and full
level-up parity remain separate requirements. The composed test exposed and
fixed two real integration defects: reentrant post-Feat dispatch during a draft
refresh, and a private UTC worker completing before the sheet controls existed.
The original failure logs and a later fixture-only localized-name correction
are retained. No public connection, visible
client launch, process restart, shared native rebuild or GPU benchmark is
authorized by these isolated tests.
