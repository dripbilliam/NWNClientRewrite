# First-level feat choice responsiveness

The first-level native creator now builds an operation-scoped first-match class
feat lookup. It resolves prerequisite field aliases once when the private feat
table is decoded. Neither change edits raw active 2DAs, caches gameplay outcomes,
nor changes the original eligibility/selection order.

`native_data/creation_feat_context.gd` owns these small derived views.
`creation_feat_state.gd` rebuilds the class lookup for each detached snapshot,
and rebuilds private decoded aliases only when the active table identity changes.
`creation_feat_choice_rules.gd` and `creation_feat_requirements.gd` retain their
unindexed path for callers with ordinary decoded snapshots.

The class index retains the first matching WORD feat ID and original BYTE List
and grant-level conversions. It is shared only by candidates within the same
synchronous creation action. A changed class/draft obtains another snapshot.
Case aliases retain exact-key priority, then the first case-insensitive match;
original decoded keys and raw physical columns remain available. Missing fields
stay absent. Selected and owned feats remain current inputs to every evaluation.

The actual installed Fighter workload comes from the successfully admitted
source-control character and its original-server export: 1,116 physical feat
definitions, 29 available rows and eight grants before Recommended. It evaluates
1,453 candidates and commits the exact selected IDs/order `[10, 28, 106]`.

| Isolated actual-control sample | Recommended callback |
| --- | --- |
| Original scans | 496 ms / 476 ms |
| Class index | 105 ms / 103 ms |
| Class index and private field aliases | 92 ms / 92 ms |

The original scan profile attributed about 202 ms to class flags and 178 ms to
prerequisite class-record lookup. With the index those phases cost about 6 ms and
2 ms. The source view itself costs about 14 ms. Resolving private field aliases
also reduces repeated prerequisite dictionary scans.

Receipts are under `.cache/creation-feat-profile/native-feat-profile-v2/`
(before), `native-feat-profile-v3/` (class index), and `native-feat-profile-v4/`
(index and aliases). They use unchanged source
owners wrapped with clocks, installed tables/TLK, actual pointer dispatch,
complete ordinary-policy model equality and the admitted export's exact feat
IDs. Art/font providers are controlled non-rendering doubles. These CPU timings
are not FPS, GPU, live-server latency or full original-client performance parity.

`tools/test-native-creation-feat-context.mjs feat-index-alias-v1` passes 1,695
checks, including all 840 complete original CanChooseFeat/prerequisite executions
through indexed and ordinary paths, exact result/diagnostic equality, duplicate
records, physical conversions, current-class isolation, raw-row preservation and
case-collision behavior. Its engine is clean and all 31 inputs remain unchanged.
The earlier `feat-index-v1` certificate-store sandbox rejection is retained; it
is not accepted evidence.

Dirty production bytes from before either optimization are preserved in
`../backups/native-creation-feat-index-before-20261103/`.

## Fresh publication at the Skills boundary

The actual original-server run identified another cause that the warm isolated
profile did not exercise. Skills OK discarded the current State, including its
warmed definitions and names. The frontend then presented its older, pre-Skills
context. The first Recommended click had to perform a cold decode; skill-based
eligibility could also be stale until that click.

`State.reset_selection()` now retires selected choices and their derived model
while retaining immutable data guarded by table/TLK identity. Skills OK publishes
the current post-Skills model before transferring to Feats. Feats/School Cancel
uses the same within-draft cache retirement. Opening a new draft still creates a
fresh State. This is neither a global world cache nor a cross-connection receipt.

`.cache/creation-class-flow/native-feat-entry-v2/proof.json` passes 22 actual
control checks. Purchasing a prerequisite skill exposes its feat before any
Feats action; reentry clears that rank/choice and removes the feat. State,
definition/name-array identity and decode count survive Skills transitions and
Feats Cancel/reopen. The first fixture's unusable controlled skill is retained
as a clean rejected case, not a product failure.

The later original-server Wizard run measured Skills OK at 200 ms including its
first row/model publication, first Feats Recommended at 107 ms with decode count
unchanged, and Main Play at 17 ms. Earlier real callbacks had reached 1,424 ms for
Feats Recommended and 318 ms for Play. The Play improvement separately moves
mandatory validation to the existing detached BIC worker. These are functional
run CPU callback observations, with different class/workloads; they are not a
controlled same-class benchmark or an FPS claim. That Wizard receipt's overall
HP-export assertion was rejected for legitimate server Toughness recomputation,
so these timings do not retroactively accept the whole run.

Dirty before-bytes for the boundary repair are in
`../backups/native-creation-feat-entry-before-20261103/`.

The final automatic-package dependencies were followed by fresh clean policy
(1,695 checks) and actual entry (22 checks) runs. Their exact inputs and receipts
are readback-verified in `../backups/native-creation-feat-after-v1.zip`; see
[the checkpoint manifest](reports/native-creation-feat-v1-checkpoint.json).
The archive preserves the documentation as it stood when sealed. This later
checkpoint link adds no server, pixel or full-creator acceptance claim.
