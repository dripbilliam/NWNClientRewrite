# Claimed creator Title bounds

Nine creator menus incorrectly treated the source Title rectangle as an
unbounded text anchor. With center/center alignment, the installed font put
part of the title outside the panel. Each original binder explicitly sets
the claimed Title object's bounds flag4 before importing it. The correction
keeps the actual GFF rectangle as the alignment region, following the prior
Attributes correction.

| Menus | Original binder | Local layout |
|---|---|---|
| Race |8e8fe0|creation_choice_layout.gd|
| Class |8ec4b0|creation_choice_layout.gd|
| Package |8ed900|creation_choice_layout.gd|
| Gender |8ede10|creation_gender_layout.gd|
| Alignment |8eade0|creation_alignment_layout.gd|
| Skills |9cce50|creation_skills_layout.gd|
| Portrait |8edb00|portrait_chooser_layout.gd|
| School |9ccb40|creation_school_layout.gd|
| Domains |9cc0f0|creation_domains_layout.gd|

The seven local files erase only the Title entry's `floating` and `anchor`
markers. Generic Painter/Dialog placement, text alignment, original rectangle,
fonts, choice IDs, callbacks, input and draft operations are unchanged. All
dirty before-files are preserved in
`backups/native-creation-claimed-titles-before-v1`.

`reports/native-creation-claimed-title-source-v1.json` collects the retained
original binders. The original client SHA256 is
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.

`tests/native_creation_claimed_titles_test.gd` uses actual installed GUI/MDL,
native Painter labels and real installed FontFile/bitmap-atlas glyph coverage.
It checks the bounded source rectangle, center alignment, clipping, literal
atlas ink within the frame and125% scaling. The six-menu before run had18
failures among66 checks; its corrected run passes66. The expanded nine-menu
before run had9 failures among99 checks; final99 pass with clean engine and
all171 source pins unchanged. All receipts are in
`.cache/creation-claimed-titles/`; the final label is
`native-creation-claimed-titles-nine-after-v1`.

The separate read-only12-menu geometry audit is preserved in
`.cache/creation-label-geometry/native-creation-label-geometry-v1`. It reports
later-image intersections for Feats headers/remaining labels and Familiar's
Name label. Rectangle overlap alone does not prove opaque pixel coverage;
those remain separate investigation. Familiar's actual centered Title anchor
differs from the740x30 claimed rectangles and was not changed.

No GPU/FPS benchmark, user client, public server, authoritative character
acceptance or full original-pixel comparison is part of this milestone.
