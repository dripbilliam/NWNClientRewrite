# Native chat portraits and player replies

2026-11-01. Connected to the production native chat HUD and player-list Tell
action. Extends [chat HUD](NATIVE-CHAT-HUD.md) and
[category/context behavior](NATIVE-CHAT-CATEGORIES.md). A later
[authoritative local follow-up](NATIVE-CHAT-LOCAL-ACCEPTANCE.md) confirms actual
reply mouse input, GUI27 and delivered Tell text. Full chat/UI parity remains
unproven.

## Original source and behavior

Pinned original nwmain SHA-256:
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.

[REA/Ghidra dossier](reports/native-chat-reply-research-v1.json) and
[read-only original model data](reports/native-chat-reply-source-v2.json).

77c140 passes a portrait and player ID to the global message buffer6f68d0.
Its non-server speech paths set the fifth argument to1, including NPC/unknown
speakers; server speech passes0. The retained entry stores category, portrait
resource and player identity.879080 attaches BUT_CHAT_REPLY at the first text
line and reserves at least two lines for its portrait.87a0e0 reconstructs the
same control when the original pane history is rebuilt.

The original CReplyButton callback879ba0 resolves its retained PLAYER_ID through
6ac110, then sends GUI event27, zero WORD and the player's current controlled ID
at+34. It then invokes6f9ec0 to prime `/tp "account name" `.87cb30 focuses the
entry and emits focus event1 using its current mode. The callback does not turn
every portrait into a clickable creature or select a nearby canonical object.
NPC/unknown player sentinel0xfffffffe produces no reply action when lookup fails.

The [executed dispatch/reader follow-up](NATIVE-CHAT-DISPATCH.md) corrects the
earlier reversed field interpretation:6d89c0 matches player.objectId at+34;
the separate character.id is+38. Account lookup6d8a20 compares account+10;
6d8910 instead compares full character name+40. Both `/t`/`/tell` and
`/tp`/`/tellplayer` resolve PLAYER_ID, by character and account respectively.
The separate `/o` command retains name-addressed Tell encoding. Player-list
Tell GUI28 remains distinct from portrait GUI27; its original priming is
`/t "full character name" `, while portrait replies prime the account `/tp`.

Failed account lookup queues local feedback106, whose existing original
descriptor resolves TLK61899 (“Player not found.”) as combat information.
87b0d0 clears/releases the prompt before dispatch. The native account-error path
now clears focus/draft and displays that localized feedback without sending
speech. The dispatch follow-up now also restores silent malformed-Tell
cancellation, unknown slash forwarding and unconditional prompt retirement.

The original tooltip override879f10 uses a disclosed party-member cache to show
name, current/maximum HP and location. The subsequent
[tooltip/transition follow-up](NATIVE-CHAT-TOOLTIPS.md) now connects that native
lookup/cache and checks it through the actual gameplay controller. Original
tooltip pixels and timing remain open.

## Native resources and drawing

BUT_CHAT_REPLY SHA-256:
`f45443550d53db695e0ad735908132b57b84e714602e1ee835b34e3b7ee8d503`.

- Bounds approximately(-24,-10,18,27), retaining the source fractional values.
- The tiny portrait plane is16×25px, inset1px inside the frame.
- Its V coordinates1.0–0.21875 display25 of the32 original raster rows.
- PortraitFrame uses GUI_BOXES_INGAME; the original up/hilite mesh tracks
  replace its atlas UVs. Hover does not require another raster or viewport.
- The source text starts approximately30px into the pane, placing the frame
  approximately6px from its left edge. The portrait aligns with the message's
  first text baseline and moves with its scroll content.

[chat_reply_layout.gd](systems/native_data/chat_reply_layout.gd) samples original
GUI states through the existing native pose/animated-mesh readers and compiles
their planes. [native_chat_reply_button.gd](systems/native_chat_reply_button.gd)
reuses NativeGuiBitmapPlane to draw raw rasters with those UVs in Canvas.
The portrait is not cropped twice through an additional portrait atlas and is
not stretched with chat width or font size. No per-message model-raster job,
SubViewport or JS rendering is introduced. The template loads through the
actor-model worker decoder so original mesh animation data survives loading.

The chat scroll body now includes the original left portrait margin while the
text keeps its own source origin and width. Native RichTextLabel line/character
offsets place retained buttons after wrapping; see the
[official RichTextLabel API](https://docs.godotengine.org/en/stable/classes/class_richtextlabel.html#class-richtextlabel-method-get-line-offset).
Received rows reuse their controls across rebuilding. Small custom fonts reserve
extra whole text lines when necessary to keep the unscaled portrait from
overlapping the next message. Exact original trailing pixel spacing and baseline
comparison still require graphical acceptance.

[chat_reply.gd](systems/native_data/chat_reply.gd) owns current player/account
lookup and portrait disclosure. It uses active tables, received objects/player
records and native portrait resource selection. Out-of-area unknown speech uses
the original PO_HU_M_99_T fallback; server lines have no portrait. Click resolves
the current roster, then emits the scoped raw GUI request and primes the account
while preserving the mode. Reset/close retires buttons and raster bindings;
delayed input from an old history cannot act on a new one. A held mouse press
captures the current generation, area and controlled actor, so releasing after
any of those changes cannot send a reply under a different gameplay owner.

Only protocol transport changed in JS: GUI event27 encoding, current player/
character admission and optional account-identity validation for native `/tp`
requests. The extra account identity does not go on the wire. No local echo,
canonical player mutation or substitute creature-ID Tell is introduced.

## Verification and remaining work

- `native-chat-reply-source-v2`:4 read-only original resource inspections.
- `native-chat-reply-v6`:148 strict editor-headless checks, including earlier
  chat/category/settings coverage, actual speech projection, source portrait
  dimensions/UVs/hover, control reuse, small-font spacing, actual click/Enter,
  GUI27-before-focus ordering, current-controlled lookup, NPC/departed-player
  behavior, account errors, reset retirement and held-input ownership changes.
- `native-chat-reply-release-v2`:148 packaged release-headless checks.
- `native-players-chat-v1`:39 actual player/invitation control checks in a
  headless derivative, including player-list event28 and typed account Tell.
  It skips screenshots and GPU-art readiness; no pixel acceptance is inferred.
- `native-chat-reply-phase-v1`:23 whole-HUD transition/focus checks.
- `native-chat-reply-text-v1`:35 received-text regression checks.
- Node chat GUI and network-session regressions:41 tests pass, including both
  build34/35 layouts, current controlled targeting, DM/self reply admission,
  stale identity and no authoritative state mutation.

The rejected source-test v1/compile v1 and geometry v2/v3 receipts are retained.
The geometry expectation initially demanded exactly30px even though the source
coordinate is30.0000019px; the final check preserves source coordinates with a
small comparison tolerance instead of rounding implementation geometry.

No GPU window, benchmark, public connection or original-process modification was
used. Original pixel/scroll/selection review and actual local server-script/chat
outcomes remain open. Also finish tooltip visual/timing parity, remaining command/
history behavior, source trailing-line spacing and full formatting/color policy.
The tooltip follow-up verifies retained history across actual area changes.
Continue the disconnect/server/controlled-actor history audit; this reply
milestone accepts reset/retirement, not persistence across recreation of the
gameplay UI owner. Neither milestone closes the full goal.

Baseline: `backups/native-chat-categories-v1.zip` (2262 verified files).
Checkpoint: `backups/native-chat-replies-v1.zip`.
