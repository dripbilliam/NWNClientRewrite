# Original Package controls and live native draft

2026-11-01. CG_PACKAGE now has a source-resource screen and real native draft
bindings. This is a scoped checkpoint, not full Package/creator acceptance. The
source creator remains staged: Configure's remaining Feats/Spells child chain,
associate name generation, complete helper instruction parity, safe saving and
original-client pixels remain unfinished.

## Original behavior and ownership

`native_package_chooser.gd` reuses `native_creation_choice.gd`, the source modal,
original painter, readonly help and scrollbars. The original eight-entry GUI
contains the shared class-style list, help, title and four action buttons.
Pregame artwork stays independent; entries, text, referenced preferences and
starting equipment come from the active catalog, including server replacements.
No stock class/package/feat/spell lists are embedded in this screen.

Creation and level-up must use base or active-server2DA data and their referenced
rules. The source Package changes do not replace the separate level-up workflow
or claim its UI is complete. All final uploads remain server-authoritative.

Original Package8e5770/constructor8dc6d0 resets derived choices on opening,
including a later Cancel. Allocation and portrait/appearance choices survive.
The port applies that reset through the real draft. A prototype rendering
side-effect previously repopulated Wizard cantrips immediately; source creation
now keeps that provisional behavior out of the original Package path.

Population8e96b0 reads physical packages.2da order, requires readable ClassID
and PlayerClass, filters to the active class, and excludes physical row255.
There is no alphabetical sorting or substitution of a class default. The first
listed row is selected while general help483/487 remains displayed. Recommended
selects that same first row and explicitly updates help; title restores general
help without changing selection. Missing selected TLK entries retain the prior
title/description independently. A native `TalkText.fetch_reference` exposes
found status without confusing a valid empty string with an absent entry.

Cancel/Escape returns3, preserves entry reset and invalidates Package completion
and later customization according to CG_MAIN's original result handler. It does
not return the generic chooser's result2. Automatic OK requires a listed row;
Configure remains available without one and uses the raw active class Package
field as its fallback, rather than searching for another package.

Automatic OK writes the real package ID and active School/Domain/Associate data,
uses only the listed skill/feat/spell preference resources, stores starting gold
and queues referenced equipment. It does not redo ability allocation, portrait,
head or voice. Skills are filled in preference order without filling unlisted
skills. Feat slot feasibility preserves preference order and distinguishes
normal/bonus/both choices. The native BIC writer consumes the source callback's
gold and queued equipment. The old broad prototype recommendation path remains
separate until full source creation is ready.

The coordinator loads referenced tables natively on demand, suspends duplicate
controls while pending and scopes completion to the draft, live child ticket
and active text revision. Text replacement, cancellation and reentrant owner
retirement cannot apply a late recommendation to another draft. No JS creation
or rendering preparation is introduced.

Configure8e1ec0 writes its package ID, gold and queued equipment, then transfers
CG_MAIN's callback to Skills9c3040 in creation mode0. It does not automatically
apply those package preference choices, mark Package complete or jump directly
to Appearance. The coordinator now binds `package-configuration` to the
[original Skills child](NATIVE-CREATION-SKILLS.md), which edits the real draft,
supports original recommendation/reset/input semantics and commits its skill
mask. Skills then transfers to the still-staged Feats/class-dependent sequence;
the full source configuration chain remains unfinished.

## Evidence and checks

Pinned nwmain.exe SHA256:
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.
CG_PACKAGE SHA256:
`7447e9ba4f6dd37177bc4de40bdcd9220b6cd240d517ab9f81e3bfc3155bdc4b`.
Vtable140e64918: bind8ed900, Escape8e3420. The
[Package dossier](reports/native-creation-package-research-v1.json) retains
population, row help8e69d0, Recommend8e66f0, title8e7d90, Cancel8e11d0,
automatic OK8e4620, Configure8e1ec0, preference helpers7eb040/7eb300/7eb630,
CanChooseFeat7ed040, original SelectTab and CG_MAIN's result handler. The
[configuration constructor](reports/native-creation-package-configuration-research-v1.json)
proves that Configure continues to CG_SKILLS rather than a generic appearance
screen. Original class loader maps Arcane to500 and MinAssociateLevel to524.

`scripts/inspect-native-creation-package.py` executes unchanged original
population, selection, general help, Recommended, Cancel/Escape, scalar OK and
Configure/callback-transfer instructions for72 fixtures and252 operations.
Actual SelectTab/SetChecked execute. Table lookup, text/UI delivery, allocation,
preference helper bodies, skill summary and customization activation are explicit
providers. The corpus proves the coordinator boundaries, not those helper
bodies, the resource parser, complete creation or pixels. Corpus:
`../backups/animations/native-creation-package-observations-v1.json`, SHA256
`8da744cb9f61d94b529bf429ebf03c47a36222c7901bf32fd8bbddca65181b26`.

- `native-creation-package-binding-v8` and `...-release-v3`:389 each. Original
  state/metadata observations plus actual physical source input, scoped draft
  actions, BIC gold/items, title/help, scroll/scaling, empty-list class fallback,
  held/pending/text replacement, cancellation and reentrant retirement. Artwork
  and fonts are nonrendering doubles. The pending-job barrier isolates lifetime;
  real dependency loading is exercised by the mounted-server check.
- `...-overrides-v1`:34 checks with actual authored server2DA/custom-TLK files
  mounted above the base install. Source Package displays the custom name and
  applies custom gold77, only listed skill0 rank4, specified bonus/general feats
  and custom spell/preparation, preserving the selected abilities. Prior Class,
  Alignment, Attributes and catalog-replacement checks also pass.
- `...-attributes-regression-v1`:2719; Class regression1108; draft-reset237.
  All runs are headless with unchanged sources and no engine/lifetime error or
  debugger exception.
- `...-local-v1`:37 checks on the preserved original Prelude server at
  127.0.0.1:5121. Actual source Gender/Race/Class/Alignment/Abilities/Package
  controls edit one draft; prototype appearance/name pages finish unported
  steps. The server admits/exports Wizard10 level1 with exact selected abilities
  `[9,14,14,16,13,10]`, all28 skill ranks and expected feats/spells, alignment
  and identity. Clean native exit0, acknowledged shutdown, zero workers/public
  connections. This is authoritative acceptance of this local character, not
  proof of every server's data or every original preference branch.

Failed evidence is retained: binding-v1 collided with RefCounted.reference;
the helper was renamed fetch_reference. Binding-v2/v3 exposed the prototype
cantrip mutation and attempted clicks on clipped rows; production isolates the
mutation and tests scroll rows into view. Binding-v6/release-v1 initialized a
pending-action fixture from an already-completed parent, then expected it to be
incomplete. Later tests explicitly initialize that fixture's completion gate.
No original corpus was edited to make these tests pass.

## Remaining acceptance

The automatic path delegates prerequisites and rule arithmetic to existing
native providers. Their full original instruction behavior, unusual byte-width
skill/spell cases, all custom class combinations, missing/default/malformed2DA
cells and exact memorization/domain variants require wider parity work. The
metadata oracle explicitly substitutes those helpers; its green checks must
not be used to declare them proved.

Original automatic Package calls CNWNameGen for a fresh associate name. The new
path currently keeps the existing draft name and records
`packageAssociateNamePending`; the name generator is still unported. Complete
the native generator and the original Skills/Feats/Spells configuration chain,
then remaining creation children, safe existing-BIC save and graphical/input/
sound acceptance. Keep full source creation staged until those gates pass.

Before-change verified checkpoint:
`backups/native-creation-package-before-v1.zip`,2418 files, SHA256
`ef92cb849961fd9c945501b8bc91e733d25728a669cabef6acdfa44498b3ec85`.
No public join, visible/GPU benchmark or user/editor restart was performed.

Verified final checkpoint: `backups/native-creation-package-bound-v1.zip`,
2425 files, SHA256
`4a36384b752d243bdaa5f9909d05c02787355df10a0dd35312c392719b173e8e`.
The [acceptance receipt](reports/native-creation-package-bound-v1.acceptance.json)
checks current production hashes against six headless receipts and the local
server run, pins the original corpus and verifies the backup digest. Full
Package, configuration children, associate names, preference-helper instruction
parity, graphical, level-up and full-goal acceptance explicitly remain false.
