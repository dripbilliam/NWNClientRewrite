# Original Gender creation child

2026-11-01. CG_MAIN's original Gender button now opens CG_SEX through the
connection-owned native draft controller. The source creator is still staged
while its remaining children are ported; the shipping creator remains available.
This step does not activate an incomplete source workflow for normal players.

## Original behavior and integration

The original opener `1408e71d0` creates CCharacterSexPanel using CG_SEX and the
parent callback `1408e9be0`. Its initializer `1408ede10` imports MaleButton,
FemaleButton, OkButton, CancelButton, Title and HelpBox. Initial gender0/1
selects the corresponding radio; another byte value leaves no selected tab.
Source help starts at title203/body447 and switches to445/199 for male or
446/200 for female. Clicking a radio updates that local selection and help.

OK `1408e56e0` reads the then-current draft gender, commits a valid selected
radio, and returns800d when unchanged or8017 when changed. An invalid selected
slot or absent object does not invent a gender. Cancel `1408e1290` returns2
without writing the draft. The existing original parent policy uses8017 to
reopen a previously completed portrait selection. It does not clear the stored
portrait ResRef merely because gender changed.

`native_gender_chooser.gd` uses the shared source painter/menu builder, original
models and radio animation poses. `creation_gender_layout.gd` derives geometry
from the actual resource and help model's text0/text1/title0/title1/scroll hooks;
its native scrollbar retains the original animated rail/arrows. Artwork and
captions remain pregame-owned while the actual draft and portrait choices stay
active-catalog-owned. No server resource replaces this pregame frame.

`native_creation_frontend.gd` binds that child to
`NativeCreation.commit_source_gender`. The commit reads the actual current
draft, refreshes the real owner and then advances the original parent result.
Its own refresh cannot invalidate its in-flight OK ticket; a separate scope
replacement or reentrant retirement still invalidates it. Cancel, held mouse
input and late child/owner callbacks cannot write a reopened draft. Selecting a
radio or committing this local choice sends no standalone game-server packet;
the eventual native character BIC carries the committed gender.

## Evidence

`../scripts/inspect-native-creation-gender.py` executes unchanged original
prepare/select/OK/Cancel instructions. Layout import, text/update delivery,
object lookup, modal deactivation/destruction and tab service calls are explicit
providers. Corrected V2 also executes original SelectTab/SetChecked: programmatic
selection does not invoke the click callback, so initial help stays203/447 until
a real click. V1's contrary provider assumption and corresponding initial-help
claim are superseded. Its64-case corpus covers current byte0/1/2/255, selected slot-1/0/1/2,
present/absent object and OK/Cancel. Corpus:
`../backups/animations/native-creation-gender-observations-v2.json`, SHA-256
`b4492bcc017e5cf435c289bd448737a4d5dcfdd7edd88ebea6a3798b44d88601`.
Static dossiers: `reports/native-creation-gender-research-v1.json`.

- `native-creation-gender-geometry-v1`:four original GUI model metadata checks,
  including a323×317 help body. This is metadata inspection, not pixel proof.
- `native-creation-gender-v2` and `native-creation-gender-release-v2`:208 strict
  editor/release headless checks each. They compare that original instruction
  corpus and exercise actual source parent/radio/OK/Cancel mouse input through
  the real creator. They also cover original-parent portrait reopening, retained
  ResRef, cancellation/reopen, held/stale callbacks and reentrant retirement.
  The already-completed portrait progress in this initial Gender test is a
  parent-state fixture. The later [Race/Subrace port](NATIVE-CREATION-RACE.md)
  supplies the preceding source child and its own real-owner/local proof.
  Artwork is a non-rendering
  double; these checks do not establish original pixels or the whole sequence.
- `native-creation-gender-parent-v1`:35 existing parent/portrait/reset/input
  checks still pass.
- `native-creation-gender-local-v2`:20 actual local creation checks. The source
  Gender radio and OK signals commit gender1 to the real draft before its
  native Wizard BIC is submitted. The original Prelude server admits it and
  exports gender1; all28 skill ranks match as well. Both native and server
  movement reach1.50003m. Shutdown is acknowledged, workers reach zero, exit0,
  source unchanged, no native exception and zero public connections.

The local proof now explicitly checks exported gender. The former live-probe
assertion that armor class must remain unavailable was superseded by the
verified [creation-vitals provider](NATIVE-CREATION-VITALS.md); actual session
summary HP/AC readiness is checked before upload.

Existing user/original/editor/server processes remained open. No GPU benchmark,
visible autonomous launch or public-server connection was made. Original
help hover/edit/keyboard behavior, graphical/font/scale review, remaining source
children/helper commands, complete CG_MAIN activation, preservation-safe
existing-BIC customization/save and full UI parity remain required.
