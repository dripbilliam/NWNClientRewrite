# Runtime Customize Appearance and Information tail

The shipping creator now delegates the original Customize child to
`native_creation_tail.gd`. Appearance and Character Information are real source
Controls. The generic fifteen-page presentation remains available to its old
entry path; the verified source Customize route does not enter that fallback.

The frontend remains the main draft/flow owner and is unchanged by this slice.
Its current `[connection,draft,serial,child]` ticket stays current across
Appearance acceptance8002 and Information. Only Information8007 is delivered to
`accept_child`; it marks Customize complete and enables Play. Cancel2 returns
to Main. Appearance commits its accepted appearance state; Information keeps
its name/age/biography/deity/voice edits private until its own accepted result.

The Tail owner rechecks the exact parent ticket, creator connection/draft,
race/gender/class/alignment/package signature and active text revision. It also
checks accepted results against the current pane's private value. Retirement
dismisses only its own panes, stops audio/model work, restores the preview
surface and invalidates asynchronous name/results. A pending resource job is
drained before the latest replacement request starts, bounding work on reopen.

Active outfit restrictions, typed UTI fields, palettes and full model resource
index run on a private catalog fork and worker. No main-thread full-index scan
was added. The existing sealed `creation_tail_provider.gd` supplies physical
rows and original initialization rules, including phenotypeFF initialization,
head WORD values, non-P control disable semantics, skin19 and actual garment19
parts, six materials and the package's filtered voice index. Pending data keeps
source OK disabled and Cancel available; unknown fields do not become defaults.

Only the existing preview's `SubViewportContainer.surface` moves into the
source model slot. Models are stopped before either reparent. The preview
signature contains the complete accepted source value and typed source outfit;
its native creature object keeps raw skin body fields separate from actual
equipped garment parts/materials. The ordinary preview path is preserved.

Information supplies an explicit voice sample to `play_sample`, so the old
generic player's independent counter cannot advance it twice. Exact admitted
soundset IDs/resources and the current ticket gate the request. Random names
use the sealed scoped `native_character_names.gd` owner, worker LTR generator
and optional NameFilter contract. Worker IDs map to the view's own pending ID;
late readiness does not reset typed fields, and old replies cannot commit.

The first-level BIC writer opts into `creation_tail_bic.gd` only for a completed
`sourceTailChoices` transaction. It revalidates context and accepted values,
writes root body fields from raw skin, preserves BYTE+extended WORD fields,
and writes a type2 equipped row containing only the selected `EquippedRes`.
The private UTI overlay remains a separate typed source-preserving service.
Missing tail/wings remain omitted. Source Information keeps its exact native
CP1252 limits, whitespace, signed atoi age and physical voice WORD.

`Builder.validation_errors` substitutes only those accepted Tail-owned field
checks for the older generic limits. All unrelated class, abilities, skill,
feat, spell, portrait, package and associate validation remains. The first
version identifies the exact existing generic messages locally; it does not
change `creation_rules.gd` or introduce a second rules owner. Changed accepted
head/voice/name/context or incomplete Tail metadata rejects the transaction.

The dedicated current-source compile and composed source/control/BIC runner is
`tools/test-native-creation-tail-binding.mjs`. Rejected receipts are retained:
v1 produced40 functional checks/BIC but actual Gameplay import exposed new
LevelUp parser errors; v2 had a clean engine and53 checks with one authored
mixed-case CResRef expectation failure, plus a root comment-only ClassState
source change during the pin. Those copies are not accepted feature receipts.
The final receipt/checkpoint records the clean current-source result separately.

Final functional v4 accepts67 checks: strict actual Gameplay compile1, composed
source/control/worker/BIC59 and independent copied JavaScript GFF parsing7.
All440 source and copied inputs match. Native preview admission produced16
meshes from the actual installed resources. Main's real summary name/current
portrait refresh and explicit existing-character mode1 rejection pass. This
owner supports only first-level mode0; existing vault BIC save semantics remain
unsupported rather than using this writer.

The functional checkpoint's observed callback samples exposed responsiveness work. First
and repeated Tail open callbacks take134–148ms detaching full active table
graphs. Most preview requests take0.7–1.2ms, but replacing an in-flight native
stream synchronously drains its workers and reached369.6ms. The32,832-name
resource index itself took33.56ms on worker35. These are labeled copied-source
CPU observations with normal filesystem/cache state, not FPS or general cold
cache benchmarks. The functional checkpoint explicitly has
`responsiveAcceptance:false`; it remains immutable before the follow-up below.

## Accepted bounded preparation and preview retirement

The follow-up imports `creation_tail_snapshot.gd`. It preserves table presence,
column/default metadata, physical orderedRows/orderedCells lengths, complete
selected racial/appearance rows, both gender rows, all clothing/ruleset rows and
the one consumed resolved ruleset scalar. No mutable live table/lease crosses a
worker. The1,694-check differential compares whole Provider outputs, native
getter/default/case/physical-cell behavior, non-P/missing data and mutation
isolation before runtime use. Installed full detach150.827ms versus exact
projection4.105ms is a descriptive same-fixture observation.

Preview now hides/disables and epoch-retires one old native stream, clears
`view.model` immediately, and holds only the latest replacement snapshot. Its
captured private worker tasks finish before close/free. Surface movement waits
for that drain and occurs before a replacement installs. Close joins remaining
owned work. No generic AssetService, Stream, renderer or frontend code changes.
Cancellation discard is distinguished from replacement coalescing.

The final `runtime-tail-perf-v1` copy accepts176 checks: actual Gameplay compile1,
one-worker rapid retirement stress107, composed source/control/model/BIC61 and
independent BIC parser7. All442 source/copied inputs match. Together with the
projection test this is1,870 scoped checks. The actual native stream still
admits16 meshes and all Main/Info/typed BIC/private/stale/mode1 checks pass.

Observed opens were3.867–4.382ms. Actual preview callbacks were0.221–0.934ms;
twelve rapid source requests took3.918ms total and coalesced12 replacements.
The actual maximum drain was26.301ms and maximum coordinator process26.550ms,
recorded explicitly rather than hidden after the input callback. One retired
stream and one pending snapshot were the observed maxima. The separate100
request worker stress coalesced99 and discarded one cancellation without an
early close/join. Remaining roughly27ms cleanup is a future local optimization.

The final checkpoint marks responsive acceptance for this local functional
source scope. These are copied-source CPU observations with normal cache state,
not FPS, a GPU benchmark, public-world timing or server admission acceptance.

This is native source navigation, active resource/worker admission and parsed
BIC validation. Controlled UI artwork/fonts in the composed fixture do not
establish full original pixels or audible playback. No server upload/admission,
client restart, public connection, native build or FPS benchmark is performed.
Global modal/NUI coverage remains incomplete; no new modal membership was
inferred from these Controls' class or visual layer.
