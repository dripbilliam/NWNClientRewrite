# Render submission and visibility investigation

Workstream for [the 140 FPS goal](NATIVE-140FPS-PERFORMANCE-GOAL.md), 2026-11-05.
The original executable's reported 140 FPS remains the user's observation.
Neither candidate below has a matched graphical FPS improvement acceptance yet.
Both are private, reversible candidates; ordinary source and native outputs are
unchanged.

## Concrete redundant work: light publication

`ModelPointLight.configure()` currently publishes raw lamp parameters, then
overwrites them with enhanced parameters. It also writes `shadow_enabled=false`
unconditionally. Animated/admission callers immediately restore the separately
selected shadow value. This produces actual engine work even when the final
support radius and shadow selection do not change.

The exact installed Godot commit is
`ed1daf0bf001b61586d9930840f2f1394092c079`. Its
[Light3D setters](https://github.com/godotengine/godot/blob/ed1daf0bf001b61586d9930840f2f1394092c079/scene/3d/light_3d.cpp#L37)
forward each shadow/parameter assignment. Its
[renderer light storage](https://github.com/godotengine/godot/blob/ed1daf0bf001b61586d9930840f2f1394092c079/servers/rendering/renderer_rd/storage_rd/light_storage.cpp#L205)
increments the shadow version and sends a light dependency notification on every
shadow setter call, including unchanged values. Changed support range also
increments that version. This establishes invalidation work, not its eventual
GPU cost in a room containing moving shadow casters.

The private [lamp publication candidate](tools/perf140/render/model_point_light_candidate.gd)
computes the same final parameters once and writes only changed engine inputs.
Direct `configure()` retains its existing shadow-reset semantics. Admission and
animation preserve the existing selected shadow without a transient reset.
Authored properties/revisions, light history inputs, palette fields, animation
cache, radius/color policy, shadow mode, and quality are retained.

The isolated headless [test](tests/native_perf140_render_light_publication_test.gd)
passes **1,319 checks across 807 boundaries**. It compares the unmodified
production facade against the candidate in actual Godot Nodes, including final
physical properties, metadata, property revisions, palette pixels, raw fallback,
HDR/support changes, ambient/shadow flags, admission/fades, hidden ancestors,
transform changes, weak owner registration, exit and re-entry. Physical slot IDs
are necessarily different between simultaneous worlds and their encoded
specular indices are normalized for comparison.

A separate explicitly instrumented source copy still invokes each native setter
and counts its calls. For 20 animated color publications and 20 fade publications:

| Work per lamp | Current facade | Candidate |
| --- | ---: | ---: |
| Shadow-version increments from shadow setters | 80 | 0 |
| Changed range publications | 80 | 0 |
| Color setter calls | 80 | 40 |
| Energy / attenuation / specular calls | 200 | 0 |
| Visibility setter calls | 120 | 0 |

The result holds both with and without a selected shadow. These are authored
component inputs and observed native property calls, not a measured GPU atlas
reuse rate. Color, range and shadow changes still publish when actually needed.

Receipt:
`.cache/native-140fps/render-agent/light-publication-1793871275816/receipt.json`.
Production oracle SHA-256:
`e803135ef951ea13d3d83267f0d671d2072e2df4d676bdf320a98fd9b4d1b9f6`.

## Concrete redundant work: palette uploads

`NativeLightPalette.update()` stores position, support radius, falloff constants
and the ambient-only bit. Animated RGB and fade are carried by the actual light
color; they are absent from this texture. Nevertheless every current update marks
the entire `2 × 2016` RGBAF image dirty, including color/fade-only publications
whose palette pixels are unchanged. The following flush uploads that image.

The separate [palette candidate](tools/perf140/render/native_light_palette_candidate.gd)
retains the two published Color values per slot and changes image pixels and
dirty/revision state only when their contents change. This uses roughly 64 KiB of
additional packed storage. Release clears the cached active-policy row so a new
lifetime with the same position/range is correctly re-enabled. Membership,
allocation order, palette capacity, global parameters and shader source remain
the same. Revision/upload diagnostics now count actual value changes/uploads.

The [palette test](tests/native_perf140_render_light_palette_test.gd) passes
**107 checks across 50 boundaries**, comparing every byte of the complete image
and exact membership/free-slot order. It covers position/support/falloff/ambient
changes, stale writes, repeated release and same-value slot reuse. For 40
color/fade-only frames the baseline uploads the unchanged image 40 times; the
candidate uploads it zero times. These are headless implementation counters, not
GPU transfer timings.

Receipt:
`.cache/native-140fps/render-agent/light-publication-1793871590744/receipt.json`.
Production palette SHA-256:
`2485df8c97d8ede450aa85ca8407812d35ecf5fd456c47d524b8921a22d3eb21`.

Both receipts pin the engine, copied dependency closure and current source
before/after. There are no changed inputs or script/leak errors. The engine emits
the existing Windows root-certificate-store startup warning; its exact text is
retained as a permitted environment warning. There is no network use in these
tests. No graphical correctness or live-client validation is claimed.

Reproduce in a fresh private directory:

```powershell
node godot-client/tools/perf140/render/test-light-publication.mjs --run
node godot-client/tools/perf140/render/test-light-publication.mjs --palette --run
```

The runner refuses a changed production oracle and records the exact private
engine command. It does not import the shared project, load its autoloads, build
a native library, stop other processes, or launch a graphical renderer.

## Native rendering and culling evidence

The original executable is opened read-only through REA/Ghidra 12.1.4. SHA-256:
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.
Retained provider profile digest:
`ab1af6a0e002de5d4940f7e3d2cfd844cfe45f918fcd3678b343002640413374`.
The project already retains the full relevant dossiers in
`reports/native-140fps-investigation-v1/`; see also
[the visibility audit](NATIVE-VISIBILITY-WORK-AUDIT.md).

The established sequence is retained BSP membership, volume traversal against
camera planes, object/emitter bounds tests, then individual Part bounds tests and
texture-indexed mesh buckets. Dirty geometry flags control repeated Gob work.
An empty symbol search does not prove absence of another method. Map exploration
bits and server object-delivery tests do not establish a client room-only PVS.
No guessed current-room or player-line-of-sight hiding is accepted here.

Fresh `Scene::RenderShadows` evidence at `0x1400d0ab0` is retained in
[this projection](tools/perf140/render/evidence/native-render-shadows.json),
provider evidence
`ev_47e2aeb0ea92d7931ef94d265dc95ec12067c7248082aaae6d4710883520568d`.
It explicitly sets stencil/depth/color masks and iterates selected lights with
separate static/dynamic geometry gates and shadow-plane composition. Therefore
the native method is not equivalent to rendering six cubemap faces for each
point shadow. It does not establish a drop-in Godot replacement, exact pass cost,
or permission to remove shadows. The immediate candidates remove redundant work
inside the established Godot shadow owner without changing shadow quality.

## Draw count and next gates

The heavy capture has roughly 6,600 draw calls and 450,000 triangles in one
instrumented observation, about 68 triangles per submitted draw. The average is
descriptive, not proof that every draw can be merged. Blended ordering, animation,
materials, lights and shadows can create real boundaries.

Godot Forward+ automatically instances opaque/alpha-tested instances only when
mesh and material Resources are shared. Blended surfaces require different
treatment. See the official
[performance documentation](https://docs.godotengine.org/en/4.6/tutorials/performance/optimizing_3d_performance.html)
and [renderer architecture](https://docs.godotengine.org/en/4.4/contributing/development/core_and_modules/internal_rendering_architecture.html).
The loading agent owns the evicted-but-still-live resource identity correction
and material initialization candidate; their draw-count impact must be measured
before duplicating that work with manual batching.

The existing experimental terrain MultiMesh path is disabled and rejects active
model lights/animated parts. Enabling it wholesale would lose required lighting
or animated behavior. Manual spatial batches also share one culling AABB, unlike
individually culled automatic instances. A future batch candidate must preserve
the physical light/emitter/interaction owners and exact opaque geometry/material
identity, and must show a benefit after the resource identity fix.

Central acceptance remains pending: same sealed capture generation, viewport,
camera, player focus, animation/control sequence, complete asset closure and
graphics settings; independently test lamp, palette and combined variants.
Retain enhanced 32-light history/surface output, pooled particles, gamma 1.2 and
postprocess `(28, .4, .15, .7)`. Check actual room pixels, shadow behavior, draw
counts, render CPU/GPU time and frame distribution after driver replay fidelity
is accepted. No FPS gain is claimed from the component receipts alone.

The coordinating agent's first quiet matched unprofiled lamp comparison
completed cleanly: baseline **18.635 ms**, lamp candidate **18.890 ms**, with the
same 5,968 draws, 353,308 triangles and 44,057 Nodes. This is **no demonstrated
FPS improvement**. One pair does not establish either a regression or a benefit.
Palette and combined candidates and detailed attribution remain with the
coordinator; component correctness/work-count results are separate from total
frame performance.

Fresh [static-light/draw-bucket evidence](tools/perf140/render/evidence/native-static-light-and-draw-buckets.json)
also rules out a tempting unsupported shortcut. `DoStaticLightBuckets`
(`0x1400d9330`) drains its retained dirty tile bucket and reloads bin colors.
`LightPartTriMesh` (`0x1400da970`) bakes per-vertex color pools only when
`g_bFullDynamicLighting==0`; full-dynamic mode removes those pools. The original
contains and binds the fragment-lighting option, and both local profiles use
enhanced 32-light rendering. Static baking is therefore not established as the
active matched native reference. `Scene::RenderDrawBucket` (`0x1400cd210`)
retains per-Part virtual draw calls within cull/state groups; texture buckets
alone do not prove merged batches.

## Shadow caster admission audit

The current normal paths do not accidentally leave every MeshInstance at its
default shadow setting. `model_instance.gd:95` and `actor_instance.gd:137`
explicitly set casting from authored `data.shadow`. Terrain batches preserve
that setting. Sky, weather, particles, transition helpers and character-preview
platforms explicitly disable casting. The binary model parser obtains mesh
shadow/render flags separately; the ASCII reader retains authored `shadow`.
This source audit is not a runtime census of the heavy capture.

Fresh original functions inspected before the quiet GPU window:

| Original function | Address | Observed boundary |
| --- | --- | --- |
| `Scene::DoGobShadows` | `0x1400c7f90` | Enabled Gob flags, optional selected-Gob ancestry, focus-distance gate, optional noncharacter policy, then light shadow-support test before volume projection |
| `Scene::RenderDynamicShadows` | `0x1400ce3a0` | Dedicated prepared volume data and draw-bucket classes; separate front/back stencil operations; consumes submitted element count |
| `Scene::RenderStaticShadows` | `0x1400d2ca0` | Dedicated static shadow parts/buckets, gated by the first selected scene light |

`DoGobShadows` tests the Gob origin inside authored `shadowradius` (fallback
`radius`) and inside `maxshadowdist` around the scene focus. When
`g_bNonCharacterDynamicShadows` is zero it applies additional model-classification
and attachment checks. Shipped initialized bytes establish `maxshadowdist=25.0`,
`g_bNonCharacterDynamicShadows=1` and `g_fShadowAlphaCutoff≈0.6667000`.
`maxshadowdist` is also registered as a console variable, so initialized bytes
alone do not establish a running client's value. `Scene::SetSceneFocus`
(`0x1400d3580`) directly writes the position used by the distance test.
`Gob::TurnOffShadows`/`TurnOnShadows` explicitly write Gob `+0xf4` to zero/one.

Both known original `Documents/Neverwinter Nights[.0]/settings.tml` profiles
currently configure `graphics.shadows.all-types-can-cast-dynamic=true`,
`max-casting-lights=3`, `creatures.mode=2` and `environment.enabled=true`.
The shipped binary contains those setting paths and a bool setter for the
noncharacter global. Thus disabling noncharacter/environment casters would not
match the recorded original configuration. No settings were changed or private
login fields read into the evidence.

`PartTriMesh::GetProjectsShadows` (`0x14008f5f0`) additionally applies an
alpha-cutoff rule for certain noncharacter/unattached model classifications;
its exact class/attachment policy must be retained rather than generalized to
every mesh. `PartTriMesh::Project` (`0x1400a3770`) evaluates retained face planes
against the light, reads face adjacency to form silhouette edges, and publishes
six indices per admitted edge using retained VertexDataObject storage. The
dynamic stream is flushed only when available element capacity is insufficient.
The non-null projection path retains an existing VertexDataObject token while
replacing its geometry item. These are topology/stream reuse facts; they do not
prove that projection work is cached across unchanged frames.

Selected [native defaults/projection evidence](tools/perf140/render/evidence/native-shadow-defaults-and-projection.json)
and [original local shadow settings](tools/perf140/render/evidence/original-shadow-settings.json)
are retained separately from the candidate tests.

The remaining unknowns include live console overrides, source model flags,
selected-Gob callers and complete static/dynamic classification. Therefore these
observations do **not** authorize guessing a distance, hiding
noncharacter casters, or treating all current static meshes as unnecessary.
Godot's cubemap caster intersection policy is a different policy; matching it to
native gates requires fixtures and runtime evidence.

A separate unresolved parity question is hidden shadow proxies. Both current
model/actor builders skip GPU mesh creation for `render=false`, even if the
authored shadow bit is set. The original Part projection walk is distinct from
ordinary drawing, but it also has virtual type exclusions that remain unresolved.
No census yet establishes hidden non-AABB shadow proxies in the heavy closure.
Do not turn walkmeshes into casters or claim a performance gain from this finding.

## Private stencil research path, if simpler candidates are insufficient

This is a feasibility outline, not implemented code or an accepted replacement.
The original generates/projects dedicated shadow volumes and composes them with
stencil tests, whereas the current engine renders point-shadow cubemaps. Matching
that ownership could avoid repeatedly drawing the ordinary world into six light
views, but adds silhouette construction, volume rasterization and composition.

Godot's [spatial stencil interface](https://docs.godotengine.org/en/4.6/tutorials/shaders/shader_reference/spatial_shader.html#stencil-modes)
provides reference writes/comparisons, restricts reads to the transparent pass,
and does not expose copying its main stencil buffer. It is insufficient by
itself for the original's separate face-count operations and per-light opaque
composition. A plain dark screen overlay would incorrectly dim ambient and
unrelated lights.

An isolated native RenderingDevice prototype could instead own its depth/stencil
target and a screen mask per selected shadow light. First copy/reconstruct scene
depth into the private target; rasterize capped extruded shadow volumes with
separate front/back operations; then expose per-light visibility masks to the
existing enhanced light response. The
[depth/stencil pipeline state](https://docs.godotengine.org/en/4.6/classes/class_rdpipelinedepthstencilstate.html)
provides independent front/back depth-fail/pass operations. A
[CompositorEffect callback](https://docs.godotengine.org/en/4.6/classes/class_compositoreffect.html)
can run after the depth prepass and before opaque shading, on the render thread,
with explicit resolved-depth access. These documented capabilities establish a
possible research route, not that the required framebuffer bindings and lifetime
are already proven in this project.

The first gate should be a single authored closed mesh and one point light,
comparing masks/pixels with camera inside/outside the volume and light movement.
Only then recover/reproduce the original projection and caster gates. Retain
immutable topology/edge adjacency by source hash, updating dynamic/skinned data
only at changed pose/light boundaries. Avoid a second per-frame world scan.

Material risks must be resolved before a heavy-room trial: reverse-Z, winding and
near/far caps; nonmanifold or open authored geometry; alpha-tested receivers and
casters; transparent receiver depths; MSAA coverage; particles and glow;
occlusion beyond the camera frustum; camera changes; and 32-light admission/fades.
Screen masks also add viewport-sized bandwidth and memory, so fewer cubemap
draws may still lose overall. Keep the normal engine path as the exact comparison
and retain full geometry/effects. A foundational promotion requires the user's
approval after measured isolated correctness and performance evidence.

## Owner-published light inputs

The coordinating agent's detailed common-scene attribution measured approximately
1.54 ms in the native light registry across 576 lamps, inside a 1.86 ms light
history callback. The registry still obtains authored properties, native state
and property revision through three reflected `Object.get` calls per eligible
lamp per frame, despite their existing owner knowing when it replaces them.

The new private input candidate keeps these data in `ModelPointLight` and pushes
references to its existing authored/state dictionaries to the existing native
registry. Property setters support direct dictionary reassignment/revision
changes; a configure guard coalesces intermediate writes until configure is
complete. Separate monotonic publication numbers reject stale publications.
Dictionary aliases preserve the existing direct in-place radius/range behavior.
The native history solver, rows, physical registration order and admission/fade
publication remain separate owners.

`pushed-inputs-v2` compiled with `/O2 /fp:strict /W4 /WX` and passed 536 exact
headless comparisons, preserving its 2,600 source pins, six shared native-output
guards and retained history map identity. Its receipt is
`.cache/native-140fps/render-agent/pushed-inputs-v2/oracle-1793875639880/receipt.json`.
That gate **did not cover reentrant polling from an earlier ancestor visibility
listener**. The coordinating/particle agents identified that Node3D emits the
ancestor signal before descendant signals, allowing a poll to observe changed
live ancestor visibility before the candidate's parent watcher runs. Therefore
v2 is frozen as **failed visibility scope**, regardless of its earlier checks;
it is not eligible for graphical acceptance or promotion.

The v3 variant removes the parent watcher completely and retains the
original live parent/inside/visibility queries, transform query and enhanced/
priority metadata queries. Only the authored/state/revision reflection reads
are replaced. A dedicated
[ancestor callback oracle](tests/native_perf140_render_visibility_reentrancy_test.gd)
reenters the history owner during that earlier signal and compares full rows,
native history/fades and physical lamp state. The frozen v2 fails both hide/show
cases in its clean-engine `visibility-reentrancy/receipt.json`, with unchanged
private runtime pins; that report also notes that the separate main test tool
subsequently changed for v3, although it is not the external reproducer script.

v3 passes **539 full exact comparisons plus 5 reentrancy checks**, with no
unexpected engine/script/leak errors, all 2,600 runtime pins unchanged, all six
shared native outputs unchanged, and zero history-map detaches. A native counter
confirms zero reflected properties/state/revision reads for every real pushed
lamp in that oracle; its legacy facade case proves the three original reflected
reads, then zero additional reads after publication.

Accepted component receipts:
`.cache/native-140fps/render-agent/pushed-inputs-v3/oracle-1793876689841/receipt.json`
and `pushed-inputs-v3/visibility-reentrancy/receipt.json` in that same parent.
The private DLL SHA-256 is
`1e452017f5c471e4d1ca22139370e428a9def1b453556e6cc1cd37257fe3e25a`.
Graphical FPS acceptance remains pending with the coordinator. No universal
correctness claim is made for leaf/parent visibility notification caching.

## Model controllers versus particle simulation

[Fresh native evidence](tools/perf140/render/evidence/native-emitter-controller-and-simulation.json)
retains the next particle investigation boundaries. The observed BSP collector
(`0x1400dc140`) tests each retained emitter's transformed sphere against camera
planes before appending it. That loop has no birth/lifetime/active-particle-count
filter. This does not rule out other earlier registration policies.
`Scene::DoEmitterBucket` (`0x1400c7ae0`) conditionally invokes `AnimateParticles`
first; only afterward does the active particle count control draw-list inclusion,
sorting and rendering. Zero active particles therefore does not by itself prove
the preceding simulation/control work was skipped.

`PartEmitter::AnimateParticles` (`0x140061210`) caps its time step at 0.5, applies
owner/tile fade early returns, initializes/updates transform history, and invokes
its virtual simulation method. Its wrapper has no zero-birth/empty shortcut.
`Gob::Animate` (`0x14004dbd0`) separately advances AnimRun time by speed × delta,
then passes previous/current times and blend weight into `AnimateHierarchy`.
`MdlNodeEmitter::InternalControl` (`0x140052400`) delegates to the generic typed
controller writer and recalculates emitter radius. The generic controller writes
scalar/vector/quaternion values into Part offsets with weight blending.

This supports a typed-state handoff from model animation to particle simulation.
It does not yet establish complete clock equivalence with this client's actor,
static/default, paused or offscreen paths. Scene/Gob virtual eligibility gates,
animation membership and paused/default behavior still need recovery. The
particle agent is checking whether existing `Entry.source_key` paths already
consume part of that shared state before choosing a reuse candidate.

### Chunk emitter radius

[Fresh bounded evidence](tools/perf140/render/evidence/native-chunk-emitter-radius.json)
for `PartEmitter::CalculateRadius` (`0x140061710`) confirms that chunk emission
is not bounded only by an authored mesh. After the source-classification/target
gates and base ballistic/lifetime/sprite calculation, the native loop expands
the sphere using every current active particle's child object: distance from
the emitter to the child's world position, plus that child's current radius.
A null particle view terminates the loop; a missing child skips that entry.
The existing `particle_bounds.gd.calculate` helper already includes this branch,
but live adapters conservatively decline chunks. Enabling it requires the
actual child-object positions/radii and correct update order; this evidence
does not justify substituting a static mesh box or a zero-active shortcut.

## Object visibility hook resolution (partial)

Further bounded visibility research is retained separately in
[`native-object-visibility-hooks-partial.json`](tools/perf140/render/evidence/native-object-visibility-hooks-partial.json).
It resolves the CNWCObject type descriptor, complete-object locator and actual
base vtable. The old +0x1f8/+0x200/+0x210/+0x218 calls forward through the
object's bound render owner at +0x78 to its +0x118/+0x120/+0x130/+0x138 slots.
The final render-owner slot semantics remain unresolved. A tile-position helper
checks current tile state, including a neighboring tile near a boundary, and
bypasses that check when the area flags disable it. These are presentation
inputs, not proof of portal/PVS room culling; no gate is enabled from this work.

[The next bounded trace](tools/perf140/render/evidence/native-object-render-adapter-disambiguation.json)
verified the primary Gob vtable through its own type descriptor/complete-object
locator. Its corresponding slots are hit-check and part-position operations,
whose signatures do not match CNWCObject's calls. Therefore the bound +0x78
object must not be treated as a primary Gob pointer. An initial shadow-offset
hypothesis was disproved and retained as such: actual primary Gob shadow
methods occupy +0x190/+0x198. The object update separately publishes alpha
through the bound adapter's +0xe8 slot and calls +0x8 with zero after a timed
fade ends. The graphics-adapter binding must still be recovered before naming
its control slots or enabling suppression.

## Pose publication setter contract

The coordinator owns a separate private pose-publication experiment. This agent
has not changed `native/model_pose_storage.hpp`. Inspection of the exact
[pinned Node3D implementation](https://github.com/godotengine/godot/blob/ed1daf0bf001b61586d9930840f2f1394092c079/scene/3d/node_3d.cpp)
found that its existing quaternion-then-scale publication goes through a cached
Euler representation. Building a fresh quaternion basis and assigning a single
transform is therefore not automatically an exact replacement. The coordinator
has instead retained the existing setter path for changed inputs and is
investigating skipping only unchanged, stabilized republication.

Additional retained work is documented in
[`NATIVE-EMITTER-COLLECTION-AND-CLOCKS.md`](tools/perf140/render/NATIVE-EMITTER-COLLECTION-AND-CLOCKS.md)
and
[`FONT-ATLAS-UPLOAD-OWNERSHIP.md`](tools/perf140/render/FONT-ATLAS-UPLOAD-OWNERSHIP.md).
The first separates native BSP collection, current-delta simulation and gated
model clocks, with exact model-classification byte provenance recovered. The
second pins an isolated ce2d-based font upload ownership candidate: root's
Safe/Separate pixel controls pass and the old Separate control reproduces the
fault; production empty-image causation and performance acceptance remain open.

The dedicated
[`native_perf140_render_transform_setter_contract_test.gd`](tests/native_perf140_render_transform_setter_contract_test.gd)
oracle observes 32 repeated
publications per case and external mutation boundaries, including assignments
that preserve the visible matrix but can reset internal rotation/scale caches.
It also distinguishes changing Euler order/edit mode from changing the matrix.
The runner is `node tools/perf140/render/run-transform-contract.mjs --run` from
`godot-client`; it uses an existing isolated, pinned headless project and builds
no native output.

Two clean isolated runs each passed 5,797 checks across 1,764 input cases, with
unchanged private runtime/source pins, no unexpected engine/script/leak errors,
and no server or graphical work. The first receipt is
`.cache/native-140fps/render-agent/transform-contract-1793878820311/receipt.json`.
Direct quaternion-basis construction was exact in only 252 cases; reproducing
the old-scale, normalized-Euler path matched all cases. Every case was stable
across original publications 2 through 33. Singular previous bases and repeated
zero-scale decomposition are explicitly outside this clean-engine gate.

The oracle also demonstrated a real hidden-cache boundary: assigning an
identical transform or basis preserved the visible matrix in all 252 boundary
cases, but changed the next original setter output in 49 cases. Comparing only
the live matrix cannot establish that republication is redundant. The second
receipt, `transform-contract-1793878920775/receipt.json`, added a live scale
query. It exposed a different scale in 119 identical-matrix cases, including
all 49 output changes. Requiring unchanged source values, live matrix, live
scale and Euler order produced no incorrect skips in those tested boundaries.
The coordinator subsequently transferred the isolated pose prototype to this
agent. Its native header is
[`model_pose_storage_publication_candidate.hpp`](tools/perf140/render/model_pose_storage_publication_candidate.hpp).
It retains the original position/quaternion/scale setters for every changed or
unsupported state. Two consecutive identical actual publications are required
before reuse; live transform bytes, live scale and Euler order must still agree.
The exact eight source words are retained, including signed zero. Manual
ownership invalidates reuse. Nonfinite/nonpositive source scales and singular
outputs retain the original path; a changed external matrix falls back before
any cache-only scale decomposition. Material/light publication is unchanged.

The first private build's dedicated test fixture omitted two required API
fields, so that receipt is retained as failed fixture scope with zero actual
publications. The corrected fixture and identical implementation are sealed as
`pose-publication-v2`. It passes **286 dedicated checks** and **60,141 original
resource checks** across eleven original models, covering changed source data,
warm stability, external/manual edits, identical-matrix cache resets, Euler
order/edit mode, negative/zero scale, nonfinite position, retirement and closure
from each original setter callback. Both original-resource paths retain the
same compiled controller arithmetic and compare exact Part bytes, local
transforms, clip events and lifetimes.

Accepted component receipts are
`.cache/native-140fps/render-agent/pose-publication-v2/oracle-1793881083660/receipt.json`
and `resources-1793881124870/receipt.json`. All 2,600 private runtime/source pins
and all six shared native-output guards remain unchanged; no unexpected engine,
script or leak errors occurred. The private DLL SHA-256 is
`fa9e49f173d5a753c616e457681eee22463be2a1f316046343bd495e4cf1b2ee`.
There is no graphical FPS acceptance or main promotion at this stage.

A separate delayed-observation header is prepared source-only alongside v2.
It avoids cache getters on changing inputs, captures two actual output
witnesses once the same source repeats, and can reuse from the fourth
publication. This preserves the original setter math and trades one additional
warm publication for less work on perpetually animated Parts. Its dedicated
fixture also asserts zero cache getter calls for always-changing inputs.
`prepare-pose-publication.mjs <fresh-id> --delayed` seals that variant; at this
checkpoint it has not been built or run and has no performance claim.

The coordinator requested a further guarded source variant before any
promotion. The pinned GDExtension ABI exposes `object_has_script_method`; this
variant checks `_notification` directly before reuse without invoking script.
Parts with script notification handlers always keep the original setters,
including handlers attached after a plain Part was warmed. Unknown external
GDExtension Part constructors are outside the managed-constructor scope.
`prepare-pose-publication.mjs <fresh-id> --guarded` combines that guard with
delayed observation and adds unchanged-publication closure/late-attachment
fixtures. Its only additional private bootstrap change binds that ABI query.
The sealed `pose-publication-guarded-v3` now passes **400 focused checks** and
**60,141 checks across eleven original models and their clips**, with all 2,600
private pins, source inputs and six shared native-output guards unchanged.
The DLL SHA-256 is
`d5492a880920bc458a87b4e558dd8249d295235eab10d15b34377db8f25e1f37`.
Receipts are `oracle-1793891541039/receipt.json` and
`resources-1793891558987/receipt.json` in that stage. These are correctness
checks conducted during the unrelated engine build, not CPU timing or FPS
evidence. No graphical acceptance or main promotion has occurred; sealed v2
is intact.

The direct script-method guard does not promise arbitrary descendant callback
count parity. Managed ModelPointLight children already use transform
notifications to republish their position; skipping identical Part setters
intentionally removes duplicate notifications while explicit final light
publication remains. Arbitrary externally attached child scripts and unknown
GDExtension Part constructors are outside this managed-tree/read-only API scope.

### Separate material publication lead

`NativeMaterial.publish_native_pose` still unconditionally invokes its color,
emission and enabled setters. The exact pinned
[ShaderMaterial implementation](https://github.com/godotengine/godot/blob/ed1daf0bf001b61586d9930840f2f1394092c079/scene/resources/material.cpp)
updates its parameter cache and calls RenderingServer without a value-equality
guard. Its shader-parameter getter reads that local cache, so an isolated future
publication candidate could compare both owner fields and actual cached
uniforms, preserving direct external parameter repairs without a renderer
readback. Backend update coalescing and a whole-room benefit remain unverified.
No material-publication change has been implemented here; the separate loading
agent owns private material initialization changes.

### Separate render thread and engine shutdown

The coordinator's same-workload experiment reached about **91 FPS versus
54 FPS** with Godot's separate render thread, but its normal shutdown failed
the lifecycle gate (`RenderingDevice::finalize` wrong thread, two leaked
objects). A minimal blank-window probe reproduced the same failure without
client extensions or network. The separate thread remains a private experiment,
not an accepted launch default.

The pinned engine source transfers the main RenderingDevice owner to its render
task at startup, waits for that task at shutdown, but does not transfer ownership
back before DisplayServer deletes that device on main. A small proper-source
fix, retained evidence, release packed probe and isolated build plan are in
[`RD-LIFECYCLE-ENGINE-FIX.md`](tools/perf140/render/RD-LIFECYCLE-ENGINE-FIX.md).
No guard is suppressed and no application engine file has been replaced.

The coordinator's four same-build lifecycle controls now show clean Safe on
both engines, the original error/two leaks on pristine Separate, and clean
Separate with the seven-line source patch. The first clean full-room pair is
about 61 FPS Safe versus 105 FPS Separate. Those engine artifacts and exact source/
binary hashes are documented in the linked dossier; the official installed
engines remain unchanged.

Parallel rendering also exposed an existing UI offscreen-readback assumption:
global deferred post-draw notifications could consume a different newly queued
GUI raster job. Matched old-kernel images confirmed the problem. The private
per-camera render epoch/completion fence restores party buttons/chat bars in
the coordinator's matched captures. Frozen V2 has that graphical evidence; V3
additionally binds its Resource into the queued arm invocation to guarantee
lifetime on immediate close, and passes 15 focused headless checks. Its original
GUI GPU fixture compares raw RGBA hashes/bounds, mixed dimensions and close/
cancel cycles against a Safe reference. Fixture chat cases now use the actual
production crops rather than rasterizing the layout-only `pnl_chat` model; each
job records its own failure so an invalid resource cannot mask later results.
The coordinator's focused original-art V4 controls now pass 113 Safe checks and
162 Separate checks: all 24 actual raster RGBA hashes and bounds match exactly,
including the production chat crops and cancellation/retirement cycles, with
clean exits. No rendering or UI default has been promoted here.

### Combined particle and pose candidates

`clock-pose-guarded-v1` derives the sealed native-clock/RNG parent and exact
guarded/delayed pose V3. Its sole overlapping kernel merge adds the pose ABI
binding while retaining every clock/RNG registration. It passes 61,969 component
checks and has private DLL
`bd48a5671900cac52a661af7b4f2cabc4e308592d928fb03e5210ef3d2ec6a89`.

The further `lease-clock-pose-guarded-v1` derives the particle agent's sealed
managed lease parent SHA
`20fab7baae2500eb4e45a95e77da68a2f4f913b52fe252666e1f2fa81a1afd14`.
It preserves its exact original pose-header baseline before substituting the
same guarded header and one bootstrap line. The private DLL is
`42897ce781a8f865ed86f062b5b7bc478e5d2c5f8cddf946be803cfb77110286`.
It passes 400 pose checks, 60,141 original-model/all-clip checks, 29,669 lease/
clock/RNG/pose/lifetime checks and 45 pure actual-header policy checks: 90,255
total. Frozen parent/source/copy and six shared native-output guards are intact;
no unexpected engine errors or leaks occurred. These remain functional gates,
not whole-room FPS evidence. The root coordinator owns graphical composition
and acceptance; no shared source or DLL was replaced by these experiments.

The first clean full-room guarded-pose composition did not improve throughput:
about 105.9 FPS versus 109.2 FPS for the lease-only parent, with equal submitted
world counts. The coordinator is retaining the functional evidence without
promoting guarded pose publication. There is no claim that lower setter counts
automatically improve this workload.

### Static submission and process census

[`STATIC-LEAF-CENSUS.md`](tools/perf140/render/STATIC-LEAF-CENSUS.md) documents a
new read-only, post-measurement census and exact integration hook. Its synthetic
headless fixture passes 17 checks. The clean room census found 2,351 candidate
tile leaves of 2,479, 1,092 global exact tuples and 1,935 spatial 4x4 groups.
The spatial grouping could remove at most 416 render-instance slots; that is
not 416 demonstrated saved draw calls. Only 126 of 41,669 nodes had process flags,
including 56 rig owners. The measured main callback envelope was about 9.535 ms
versus render CPU 3.694 ms/GPU 3.512 ms, so drawing was not the current throughput
limit. No batching path was promoted from this census.
It records exact Mesh/Material/render-state tuples, global versus spatial
repeats, unsupported qualifications, and process/rig-owner counts. It neither
changes visibility nor creates any batch. Godot Forward+ already hardware
instances matching surface sort keys, so candidate leaf counts are not saved
draw calls. A future exact-resource MultiMesh prototype must demonstrate gains
in scene-instance/cull work and preserve lights, collision, picking, shadows,
retirement and conservative spatial visibility.

### Builtin light loop and constructor correction

The optional native engine light registry retains the original registry's
rows/getter order/arithmetic with public engine getters. Its strengthened
functional receipt `render-agent/builtin-light-check-v3/receipt.json` passes
171 direct byte-exact checks and 463 inherited Focus checks in each of builtin
and default extension modes: 1,097 clean checks, unchanged source/output guards.

The first full runtime exposed a missing explicit base `_init` call in the
GDScript selector. Builtin mode had concealed that default extension mode left
the inherited registry null. A map-only relink had identical `.text` content
and RVA layout to the archived ce2d engine and resolved the null receiver AV
to `Object::_call_bind+0xb1`. The exact constructor/configure/history/register/
remove/close oracle passes 17 checks with the corrected `super()` call. The
failed sources and crash/map evidence are retained separately; no engine
guard was suppressed to address this GDScript defect.

The coordinator's corrected clean same-engine room comparison reports
9.185 ms/108.87 FPS for the old extension registry versus 8.921 ms/112.09 FPS for
the optional builtin loop, equal view/world counts and no >50 ms frames. That
is a small gain requiring repetition before promotion, not the 140 FPS goal.

The next private experiment is
[`pushed_fields_v4/PLAN.md`](tools/perf140/render/pushed_fields_v4/PLAN.md).
It uses canonical writer-owned field aliases with per-claim lifetime
tokens and revoke-before-configure semantics. It keeps all physical getters
and both metadata polls live. Exact source/Script guards provide fallback;
unknown facades keep reflection. The fresh V4 release engine compiles cleanly
and 1,632 isolated headless checks pass, including actual canonical cache hits,
mid-configure/nested visibility callbacks and same-Script instance replacement.
It still reads one reserved scalar to validate the live binding. No V4 whole-
room performance result is claimed yet. Larger metadata publisher APIs remain
a separate unpromoted proposal.
