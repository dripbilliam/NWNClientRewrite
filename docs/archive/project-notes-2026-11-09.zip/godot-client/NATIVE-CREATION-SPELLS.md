# Native creation: spell-selection policy

The original spell-selection policy now has a native data-only implementation
in `systems/native_data/creation_spells_state.gd`, with an independently tested
first-level active-table adapter in `creation_spells_snapshot.gd`. The source
creator now binds that policy to its real draft, original CG_SPELLS controls,
Package preferences, Reset/Cancel/OK and the actual BIC save worker. The complete
source creator remains staged: the shipping generic creator is still separate,
and remaining creation children, level-up, original pixels and authoritative
upload/admission are not accepted by this milestone.

## Original behavior

The original initializer9ce190 branches on **LearnScroll** for its initial
budget and tab selection. The level-display callback9caae0 and OK admission
9c6e70 separately branch on **MemorizesSpells**. Those flags are not aliases,
including in custom class data. The first native attempt conflated them and
failed168 unchanged-original cases; that failure is retained. The corrected
policy preserves both gates.

Scroll learners receive a shared first-level budget3 plus a positive signed
Intelligence modifier; later class levels use2. Previously known spells are
snapshotted for Reset. When the original first-level/raw-Intelligence condition
holds and the cantrip book was empty, all class-level0 spells are added before
selection. The automatic cantrip step does not apply the opposition filter.
The native policy takes explicit getter results rather than guessing counts
from missing server properties.

Other casters use known-spell capacity per level. Tabs depend on the original
gain/known-capacity tests; unfinished flags also require ability eligibility,
available choices and remaining budget. Source byte/word widths are preserved.
If no usable choices remain, OK may be permitted with an unused budget. That
differs from simply requiring an exact generic count at every level.

The policy retains initial known ownership and original list semantics: sorted
rebuilds use the existing bytewise `_stricmp` lower-bound ordering, adding a spell
appends to the visible selected list, and removal reinserts it in sorted order.
Known lists can be rebuilt on a tab change. Scroll-learning cantrip removal is
disabled. Filling a non-memorizing level can advance to the immediate next level
with remaining capacity. Reset restores the initial known book and repeats the
original initialization behavior. Consumers receive detached view arrays.

No Nodes, Resources, network commands, rendered models or world store are owned
here. `configure` requires a complete declared native getter snapshot; missing
flags/scalars/arrays fail explicitly. The active-table adapter must preserve
the current connection's class, spell, racial, stat-gain, ability and known-table
ownership and distinguish missing data from zero. The currently verified known
index traversal is bounded to255 entries per level.

## Active-table adapter

`creation_spells_snapshot.compose(rules, active_text)` reads the active physical
class/spell/race/gain/known tables and the owned draft. It composes the existing
native ability and spell-gain owners rather than introducing a second rule
store. The class's actual `SpellTableColumn` selects spell levels. `UserType`,
`Master` and a missing name do not silently remove physical choices from this
original chooser. Names/descriptions use the current text owner; icons retain
native resource-reference width. Race adjustments, raw Intelligence's automatic
cantrip gate, effective scores, school opposition and optional known-table
constructor defaults remain distinct.

The original school loader only writes recognized letters. An unavailable
school byte is therefore represented as null; it is not invented as General.
If an eligible spell requires that byte for opposition filtering, the policy
remains unavailable. Unused rows can retain explicitly unknown school/icon
metadata. A memorizing, non-scroll-learning class requires an as-yet unbound
prior chooser counter, so this adapter does not fabricate one.

`reports/native-creation-spells-snapshot-v3-receipt.json` passes18 focused native
checks, including a custom class and spell column, both school choices, missing
known tables, ability thresholds, unknown metadata, physical-column precedence
and borrowed-data isolation. The engine log is clean, exit0 and the copied input
hashes are unchanged. The initial v1 three1024-row snapshot samples took24.406,
28.990 and27.391ms; the current v2 rerun recorded23.940,25.382 and46.276ms while
other isolated CPU tests were also running. This is boundary-time adapter work, not a claim
of cold GUI readiness, live FPS, complete original getter execution or current
whole-flow readiness. The bound session now retains table-publication identities,
replays only when those publications change and refreshes text without resetting
the selection budget. Ordinary add/remove handlers do not rebuild other menus.

## Evidence and next bindings

Original client SHA256:
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.
`reports/native-creation-spells-static-v1.json` retains the original constructor,
prepare, tab, add/remove, Reset/Recommended, OK/Cancel/Escape, getter and loader
dossiers. Static decompilation is not full execution acceptance.

`scripts/inspect-native-creation-spell-selection.py` in the workspace executes
complete original9ce190 and9c6e70 instructions in the isolated CPU emulator.
Current-class, known-count, gain, minimum and known-capacity getters plus GUI
services are explicitly captured boundaries. Its480 cases vary class flags,
levels, signed modifier/word counters, known books, opposing schools and spell
metadata. Corpus: `reports/native-creation-spell-selection-original-v1.json`,
SHA256 `3a9c8c080d9d988206ca5ed26bab193a66bee853b947fd3fbde657ec37756532`.

`reports/native-creation-spells-state-v5-receipt.json` passes1,939 native checks
against that pinned corpus and detached/order/add/remove/reset/advance cases.
The engine log is clean, exit0 and copied input hashes remained unchanged.
Add/remove behavior has static original evidence and native tests; the480
executed comparisons cover initialization and OK, not those complete callbacks.
The first rejected fixture/conditional-policy snapshots remain in reports/cache.
The current rerun covers the explicit-null school representation and cached
legacy-byte ordering used by the active-table adapter. Its480-case
initialization/OK corpus is unchanged. A separate single-row return regression
checks that existing equal-name groups keep their order. Returning one spell
now uses the original lower-bound insertion rather than sorting the whole list,
which previously reversed those existing ties as well as wasting CPU work.
The byte comparator's NUL boundary is tested with bytes; a rejected earlier
fixture attempted an invalid Godot NUL string and is retained without claiming
it as a production failure or a clean accepted run.

`reports/native-creation-spells-resources-v2-receipt.json` reads the installed
CG_SPELLS hierarchy and model hooks without changing the installation. The source
GFF digest is `5ecd6d81abc022bf42ea3ed9bbe49156b5859e4fceb310e38e1651cf82149929`.
The first resource probe's guessed row name and generic blank-label assumption
failed and are retained. Original9caae0/9c74c0/9ca3e0 use `CTL_CG_BTN_FEAT` for
spell rows. The claimed EmptySpellListLabel and CannotLearn controls attach to
the original blank model's text hook; the new layout adapter handles these two
specific labels without changing generic control interpretation.

The separate static information dossier retains CSpellInfoPanel's constructor,
explicit modal opening, preparation, Close/Escape and the row enable helper.
The artwork is shared with the feat information pane, but spell Close is9c8080
and the owner is distinct. The new `native_spell_information.gd` preserves that
callback. `native_spells_chooser.gd` uses a bounded visible row pool rather than
one control subtree for every physical spell.

`reports/native-creation-spells-view-v8-receipt.json` passes41 installed-source
checks with20 total pooled row controls for a1024-spell definition fixture.
Physical tabs, select/add/remove, source information Close, OK with an exhausted
pool, Escape, scaled input, stale held-row rebinding, replaced scopes, unavailable
data and final painter/icon cleanup are exercised. The information request has
its own bounded identity; retiring parent held input does not invalidate the
current child result. The actual creator controller, original GUI-manager
membership of this parent, full Recommended operation, level-up, server upload
and original pixels are not accepted by this fixture.

The first functional pass's large-table add/remove pairs took42–50ms. Phase
timings isolated a full policy re-sort (24–31ms for a remove) and repeated
control-tree input retirement. The current view retires input once per owner
update or scroll-rebind boundary and retains the same controls. After the
single-row insertion correction, two headless runs measured pair ranges
9.204–13.256ms and5.636–9.770ms. The latest policy remove samples are about0.04ms;
remaining cost is primarily detached projection and visible control updates.
These are synchronous feature timings with controlled art/fonts, not a GPU/FPS
benchmark, a controlled whole-client A/B comparison or cold resource readiness.
The current engine logs are clean and all copied preload-closure hashes remained
unchanged. Parse/helper-preparation failures and the earlier slower snapshots
are preserved. The controls are now imported by the staged source creator; this
independent view fixture still does not accept that controller or a full creator.

## Draft, Recommended and save integration

`creation_spell_selection.gd` binds a weak rules owner and connection/draft scope
to the existing spell books. It keeps the original chooser's private counters
and a small edit transcript; it does not create another character or rule store.
`creation_spells_validation.gd` replays that transcript against the current
active metadata at commit and save. Retired scopes, incompatible table changes,
unrecorded book changes and incomplete metadata cannot silently save. Missing
prior counters for memorizing/non-scroll-learning variants remain unavailable.

`creation_spell_preferences.gd` has 1,449 focused checks against 480 complete
original `7eb630` helper executions and additional native boundaries. Its oracle
is `native-creation-spell-recommendations-original-v1.json`, SHA256
`571d3644f9227ee6444a63d9f44e06e48f99f01065d80f1b7b2c732d4a5f7102`.
`creation_spell_recommendations.gd` composes the helper with the original
`9c9df0` reset/descending-level fallback sequence; the complete coordinator was
not CPU-executed. Its active Package preference plan and failure distinctions
pass 20 checks. Missing package lookup, actual resource-load failure and an
empty successfully loaded preference table remain distinct.

The real creator requests missing preference resources through its existing
native asset service. Recommended resets choices before awaiting the resource.
Cancel/Escape stays available during preparation, retires the exact request and
prevents late completion from reopening or changing a retired transaction.
Only the explicitly proven spell information leaf receives a modal-owner
registration here; the parent is not classified from RTTI alone.

`native-creation-spell-selection-v1-receipt.json` passes 22 owner/commit/replay,
scope, mutation and detached-worker-data checks. The actual source-control
integration passes 47 checks in `native-creation-spells-binding-v3-receipt.json`:
physical Package→Skills→Feats→School→Spells, active custom rules/text, information
Close, held-input reticketing, asynchronous preference loading and cancellation,
the original `8011` continuation, and the real BIC worker/submit intent. Eight
warm add/remove handler pairs took 0.436–1.164 ms. An earlier rejected run took
75–89 ms because the handler refreshed every creation menu; the bound edit now
updates only its active spell projection. These are CPU handler samples with
controlled artwork, not FPS, cold readiness or original-client pixels.

The save worker receives copied draft/slot/transcript owners and a detached
spell-name map captured on the owner thread, rather than live TLK/file handles.
Its 6,772-byte fixture BIC preserves exact known order and the earlier
school-owned memorization-slot cache, including unused slots marked unready.
A separate actual-control/real-worker case passes 15 checks for a custom
non-memorizing class and verifies parsed known lists with no memorized lists or
`SpellsPerDayList`. The original first-level writer `807950` supplies the latter
contract; the older generic path remains separate. Neither authored custom-class
fixture was sent to a server. The latest School regression passes 25 checks.

`native-creation-spells-save-static-v1.json` retains complete static school-byte,
preference-string lookup and first-level writer dossiers. The v2 checkpoint
records exact tested inputs, original evidence, dirty-before copies, scoped
changes and rejected earlier fixtures. Test counts overlap across cases; they
are not a count of unique game features. Full creator/level-up, authoritative
upload/admission and visual parity remain open.

The runner uses the existing pinned runtime and an isolated hidden headless
project, with no server connection, GPU benchmark, shared native build or user
process restart:

```powershell
./godot-client/tests/run-native-creation-spells-state-tests.ps1 -Name unique-state-receipt
```

Next work is the remaining class-dependent associate/familiar continuation and
the rest of the source creator, followed by full native-client visual and
authoritative save acceptance. The completed spell slice does not establish
those broader requirements or every rule variant.
