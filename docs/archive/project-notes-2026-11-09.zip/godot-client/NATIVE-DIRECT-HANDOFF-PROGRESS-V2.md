# Direct-handoff framing diagnostics follow-up

The v2 opt-in diagnostics preserve all transfer checks and add only sender/socket
and receiver framing scalars. All 20 Node tests pass: the previous 18 plus two
framing/projection cases. Exact sources and the dirty-before manifest are pinned
in [the new receipt](reports/native-direct-handoff-progress-v2.json). The earlier
receipt and v7 runtime rejection remain unchanged.

The native test entry publishes pending first/last byte, JSON newline index and
searched length, and binary declared u32 length when the first byte is `0x89` and
eight header bytes exist. JSON newline search is capped by the existing 1 MiB
JSON limit. Binary buffers can reach 8 MiB; they are neither scanned nor copied
for diagnostics, and explicitly report a null newline index with zero searched
bytes. No packet payload is retained.

Existing `protocol_read_error` fields are named as read-error code/bytes/expected
bytes/ticks. They do not stand for successful or cumulative native reads. Root's
Host hook separately supplies actual socket written/read/writable/destroyed
values and snapshot-scoped header/chunk/end counts, total bytes and newline
presence. Counters are diagnostic observations, not delivery or admission proof.

The default remains off, at most one sample per two seconds, at most 4 KiB per
atomic latest-only record, with one active and one latest pending write. New
native helper execution and any explanation of the IPC failure require separate
runtime evidence. This preparation launched no engine or server and changed no
shared Host, core parser, clocks, probe or acceptance assertions.
