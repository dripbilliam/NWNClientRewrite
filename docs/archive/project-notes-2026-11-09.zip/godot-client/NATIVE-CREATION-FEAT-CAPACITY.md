# Creation and level-up feat spell capacity

This is a prerequisite component for the still-staged original Feats workflow.
It does not activate CG_FEATS or complete character creation/level-up. Continue
[the full Feats work](NATIVE-CREATION-FEATS.md) and the active UI parity goal.

`systems/native_data/creation_feat_spell_capacity.gd` composes the original
7ee690 class traversal with the existing non-memorizing prerequisite core and a
caller-owned memorizing spell-gain getter. Any class with known positive capacity
satisfies the requirement. Unknown capacity remains unavailable when no other
class definitely satisfies it; it is never converted to zero. Requirement0
does not manufacture a spell-storage dependency. Queries do not mutate the
decoded source, actor, selected feats, scores or spell uses.

The getter contract is `Callable(class_index, required_level)` returning
`{"ready": true, "gain": <BYTE>}` or an unavailable result. The active draft
adapter must validate its complete current rules/stat snapshot before setting
ready=true. The existing native `spell_radial.gd::spell_gain` was exercised here
with complete fixtures; that getter also reports missing-data errors in normal
use, so a future adapter must not blindly wrap every returned0 as ready=true.
The helper owns no second actor store, spell table cache or per-frame work.

## Original evidence and native composition

`scripts/inspect-native-creation-feat-memorizing.py` executes unchanged original
FeatRequirementsMet7ee690, memorizing GetSpellGain7f6b20, and the reached
class/race/stat/ability/prestige helpers. The ruleset key/integer lookup is an
explicit fixture service boundary; no prerequisite, gain or ability algorithm
is replaced. Native decoded storage and cached BAB/Fortitude are authored
fixtures, not proof of their table loaders or live draft construction.

The current corpus is
`reports/native-creation-feat-memorizing-original-v2.json`:384 cases,84 accepted
and300 rejected. It covers mixed memorizing/non-memorizing classes, signed
base/racial/class/bonus abilities, dexterity adjustment, specialization,
prestige divisors and custom ruleset modifier settings. Required levels are
0/1/2/3/5/9/10/255; decoded class levels are1/2/3/8/20/40. Physical class IDs
are valid for the authored loaded-class count. This is not universal malformed
table or out-of-capacity native storage acceptance.

The native test builds corresponding active physical class/race/stat/spell/
ruleset tables, uses the real native spell-gain owner, compares each memorizing
getter, and composes capacity through the existing full prerequisite core.
It also checks cumulative class gains, mutation isolation, unavailable callbacks,
missing array elements, invalid gain values and definite later-class success.

Current receipt:
`reports/native-creation-feat-memorizing-v4-receipt.json`.
**2,649 checks pass**, engine/script/lifetime logs are clean, and the entry's
entire static preload/extends dependency closure remains unchanged. Two hundred
warm capacity queries measured0.252ms p95 and0.425ms maximum. These are scoped
CPU measurements, not whole-game FPS or original-client graphical acceptance.

The runner retains an isolated complete native-library snapshot for parsing,
while current-source acceptance pins only the actual static dependency closure.
Unrelated agents may change other modules without silently changing the tested
closure. Every copied source hash is retained separately in the receipt.
No game server connection, GPU test or native output build is used.

Reproduce with unique output names:

```powershell
py -3 scripts/inspect-native-creation-feat-memorizing.py --report godot-client/reports/new-capacity-original.json
.\godot-client\tests\run-native-creation-feat-memorizing-tests.ps1 -Name native-feat-capacity-repeat
```

The native runner uses the sealed original-v2 corpus. Changing that source
requires a separate reviewed runner/corpus receipt, not overwriting old evidence.

Verified checkpoint: `backups/native-creation-feat-capacity-v1.zip`,47 entries,
SHA-256 `e309f6e3270907640d0449945b662b27a0083079e76796c1cb30ff055ce1152b`.
It contains the exact tested dependency snapshot and reconstructed, hash-checked
rejected-v1 driver, without original binaries, user profiles or private keys.
Shared-file snapshots contain other uncommitted work; never restore them over
newer files wholesale. The later integration receipt is
`reports/native-creation-feat-capacity-integration-v1.json`.

## Rejected evidence and remaining integration

Original-v1 omitted the loaded native class/race counts from its authored
fixture. Reached GetClass7f0f60 therefore redirected class gains to class0;
the first comparison failed. That corpus and both failed copied native runs
remain preserved. Original-v2 sets those required loader counts and executes
the same original instruction bodies. No expected results, algorithm branches,
assertions or execution deadlines were weakened to obtain acceptance.

The full active-table draft adapter still needs complete cached BAB/saves,
effective and raw abilities, class grants, skill usability/ranks, feat loader
defaults and all referenced resource availability. Then bind the original
available/known lists, families, recommendations, dependency removal and commit
to the real draft and finish Package's class-dependent continuation. Existing
BIC preservation, original pixels, full source creation/level-up and actual
original-server admission/export remain required.
