# Stored actor-name owner: independent source review

This read-only review supports a narrow constructor/name publication owner, conditional on Root's actual accepted canonical history. It is not integration, runtime or full local-name parity acceptance. [The compact report](reports/native-actor-name-owner-independent-review-v1.json) contains the new missing proof, source pins and required actual NetworkWorld cases; the larger existing constructor/header dossiers remain referenced rather than duplicated.

## Constructor defaults are all empty

Fresh exact assembly for stats constructor `7ea230` establishes pointer/length zero for first name `+20/+28`, last name `+30/+38` and override `+40/+48`. The later calls to `CTlkTable::GetSimpleString` for refs68684/68685 do not assign localized default names: both use stack `RSP+48` as the return-string destination and immediately free that temporary. The complete `1994d0` lower confirms its output is only that supplied destination. Derived `7ea7a0` does not directly rewrite these name slots. The immediate full-creature `7fb140` construction path does not load BIC/GFF names; its later helper constructor `973840` only initializes itself and retains an actor pointer.

Consequently **all three known-empty strings are legitimate for a genuinely certified fresh native construction**. They are client initialization facts, not received stats. This does not justify the same initialization for an existing/generic/imported proxy, a first snapshot or a newly assigned lifetime number. A separate local-character load/clone path can have a different provenance and must not be conflated with the fresh A path.

## Appearance P400 owns stored first/last

Native `77fe10` first looks up the actual creature. Its raw P400 branch copies the literal as first and explicitly empties last. Its split branch calls `9735f0` for first, then last. Each component either copies literal bytes untouched or sets its own wire fetch gender and calls `FetchInternal(parseFlag0)`. Base TLK remains raw; runtime overrides invoke strict native ParseStr. The actual effective gender, including female-family fallback, is retained in call order. Raw components do not parse, trim, split or change the override slot.

The name setter `80a810` is conditional on successful native creature lookup and message bounds. It writes stats first/last only. P decoding can consume/resolve strings even when no actor exists, without creating an actor-name owner. U10000 sends its name to party/portrait UI; it is not an actor stored-name update. Later `7f3f00` chooses a nonempty stored override or joins actual stored first/last. Empty success is a valid name, not ref5189, and there is no chat-time re-fetch.

The P lookup target is **not** token context. The complete immediate P/object-update/message dispatchers introduce no direct TLK-global context/B8/BC reset. A localized reference sets its own gender; other parser globals retain the real preceding native history. Do not borrow the speaker, controlled actor or ordinary chat body frame. An explicit certified NULL context may be represented to the current TalkText parser as `{}`; an omitted context remains unknown. Context-independent literal/base/CUSTOM-only cases need not wait for unrelated unavailable context.

At P arrival, retain the descriptor/version, selected override presence/value (including absence), complete CUSTOM byte snapshot and actual available retained parser/provider state. Resolve first before last, then store resolved values once. Later tokens, overrides, actor fields or chat parser state cannot silently supply a missing historical dependency. A completed native fetch failure stores empty; genuine pending data/provenance must remain distinct from a known completed miss.

## Complete history must be explicit

Current `NetworkWorld.apply` forwards only `message.records`. The decoder can return a parsed prefix with `complete:false`, and the Session applies it before diagnosing the unsupported record. Thus merely having called `applyObjectUpdates` does not establish complete native history. Root must retain/taint that fact before authorizing fresh construction; a later complete packet does not erase a prior gap.

Private canonical-object correspondence and provisional transaction ownership are needed. Serialized name metadata is a detached publication, not proof that an imported or clone-copied proxy owns a native constructor. Same-packet A→P must see the staged typed owner, but only validated commit may publish the owner/name metadata. A late conflicting record must not leak the staged constructor, name or certainty onto the canonical object.

Repeated A and D+A retain bytes and lineage and must never manufacture empty strings or a new constructor. Native D schedules disposal; current JS tombstones do not prove whether the native object was retained or reconstructed later. Ambiguous reuse may therefore make historical nonempty values unavailable while preserving their bytes; known-empty defaults remain invariant. A disclosure token change is not destruction. Reset/reconnect or same-ID canonical replacement cannot borrow an old private owner or plausible copied metadata.

Root's minimal actual NetworkWorld checks should cover fresh complete A→P→U; same-transaction A→P versus P→A; generic P/U/I/inventory/area/imported proxies; repeated A and D+A; incomplete prefixes; transaction rollback; reset/reconnect/ID reuse and canonical replacement; and input/DTO/CUSTOM/parser-context mutation isolation. API's separate Godot tests must cover exact current row/lifetimes, delayed component resolution and no historical-context rebinding. Picker's helper pure tests remain a separate scope; this review ran none.

No production, existing test, engine/server/client, GPU, user process, profile/key or native-build action was performed. Remaining controlled-PC entry/BIC/clone provenance is explicitly separate from the certified fresh-A constructor fact.
