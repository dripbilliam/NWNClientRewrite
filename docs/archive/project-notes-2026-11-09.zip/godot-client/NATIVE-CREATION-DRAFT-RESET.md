# Native creation draft resets and class-file parity

2026-11-01. Connected to the shipping connection-owned creator and first-level
BIC builder. This fixes draft behavior and character serialization; it does not
activate the unfinished original CG_MAIN parent, replace its child panes, enable
existing-character Customize or establish original-window pixel parity.

## Corrected behavior

Changing race, class, abilities or alignment retires selected skills, feats,
known/prepared spells and cleric domains. Previously domains survived every
upstream reset, and alignment did not reset derived choices at all. A Cleric
draft now requires new domains before Play. Racial/class grants and budgets
continue to derive from the active server rules. Names, biography, portrait,
appearance, school and associate choices are not blanket-reset by this helper.

The native first-level BIC writer now follows the original client's optional
class fields: write School only for an active PickSchool class, and Domain1/2
only for an active PickDomains class. Other classes omit those fields. A
first-level ClassList element uses original client struct type0, instead of
copying the server's type2. This is a first-level creation correction, not an
existing-BIC rewrite. Existing-character editing remains disabled.

An unset in-memory domain is BYTE255 in the original and an empty selection in
the native draft. It is not domain0. The first draft of this correction wrote
255 fields for non-domain classes; an actual server export and further client
writer research showed that omission is the correct final file behavior.

## Original evidence

Pinned nwmain.exe SHA256:
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.
The retained [REA/Ghidra dossier](reports/native-creation-derived-research-v1.json)
includes complete functions, body provenance and evidence identities.

- CG_MAIN callback8e9be0 invokes draft reset7edcc0 after the relevant completed
  upstream child, when Package was already available. The prototype creator has
  no original completion gates, so it clears the same derived choices when its
  corresponding edit commits. Full parent/child gating remains pending.
- Complete7edcc0 zeroes skill-choice arrays, recalculates skill budget/modifiers,
  clears selected feat lists, regrants eligible racial/class feats, empties spell
  resources/known lists/prepared slots, and writes `ffff` to both domains for
  each supported class. It does not clear School at the adjacent byte.
- Helpers7ed6d0,7edbf0 and7ed920 perform feat-list clearing, prepared-slot clearing
  and known-list clearing respectively.7ec0c0 computes skill points;7fadc0
  recomputes skill modifiers. Earlier investigation variable names were misleading:
  these are not familiar/companion reset routines.
- Original class loader2a4a90 maps PickDomains to boolean INT at class+4f4 and
  PickSchool to class+4f8. The dynamically assembled strings are present as
  little-endian constants in the source; the active table columns remain the
  native decision inputs.
- Original client writer807950 conditionally writes those fields and adds the
  first-level ClassList element with type0. Client loader7f7e20 reads them only
  for corresponding active classes. Server SaveClassInfo413880 independently
  uses the same conditional fields and its own type2 export records.

`scripts/inspect-native-creation-derived-reset.py` executes complete7edcc0 plus
the three original list-clearing helpers unchanged in an isolated CPU emulator.
The160-case corpus covers empty/one/two/eight classes, the synthetic over-limit
class-count9 guard, first-level/racial-adjustment/feat regrant branches and skill
budget inputs. Class-count9 is a boundary probe, not a supported character.
Skill-budget/modifier calculations, feat-rule queries, memmove/memset and frees
are explicit providers; this does not prove their complete internal parity.

Corpus: `backups/animations/native-creation-derived-reset-v1.json`, SHA256
`a5abe6c710fd231733a15b698890661d085e960eaa2649a66d932c5303fc0820`.

## Accepted checks

- `native-creation-derived-reset-v6`:237 editor-headless checks, using the pinned
  corpus and the actual shipping gameplay UI/creator. Real sidebar/button mouse
  input and embedded-popup keyboard input select domains and change upstream
  choices; the test checks preservation, required fresh choices, cancellation/
  reopen, and parsed Fighter/Cleric/Wizard BIC fields and record types.
- `native-creation-derived-reset-release-v2`:237 packaged release-headless checks
  of the same final source and input path.
- `native-creation-derived-overrides-v1`:15 existing authored server class,
  spell/feat/package/custom-TLK and replacement-catalog regression checks.
- `native-creation-derived-local-v2`, `native-creation-derived-cleric-local-v1`
  and `native-creation-derived-wizard-local-v1`:11 creator checks each, followed
  by actual admission, authoritative movement and server BIC export on the
  already-running original Prelude server at127.0.0.1:5121. Each starts with a
  genuinely recommended Cleric draft, changes class via the live controller,
  uploads its native BIC and checks exported class/level/domain/school/feat/spell
  values. The fixture uses live control callbacks; physical mouse/popup input
  is covered separately by the237-check test.

All final receipts have unchanged source, no native/engine/lifetime error and
zero public connections. Local sessions close with protocol acknowledgment and
zero remaining workers. They preserve the existing editor and Prelude server.
No visible window, GPU test, public login or Arelith chat was used.

Failed receipts remain: resetV1 had a test-only localized-string lookup error;
V2 compared JSON float arrays as typed integer arrays and incompletely exercised
popup selection; V3 pushed keys directly into PopupMenu, bypassing Window's
internal menu dispatch. V4 corrected embedded-viewport forwarding. V5 then
verified the source-correct optional fields/type; V6 adds Wizard/Cleric fields
and feat regrant observations. LocalV1 admitted/moved/exported correctly but
failed the overly literal255-versus-omitted export expectation. It is not accepted
as a complete passing receipt. No failed evidence was overwritten.

## Next creation work

[CG_MAIN](NATIVE-CREATION-PARENT.md) still needs its original creation-mode
summary, all child owners and the live adapter. The original fixed summary uses
PNL_CHRSHT2, CTL_CHRSHT_NOSIZ and tab5/6/7/8, with four tabs: Character Sheet
(TLK10560), Skills327, Feats326 and **Spells5215**. Character page factory88a830
selects PNL_CHRSHT_CHAR2; Skills88a970, Feats88a8e0 and Spells88aa00 select
PNL_CHRSHT_SKIL2. This is not the resizable three-tab in-game sheet.

Keep pregame frame artwork independent of active server resources; use the
active draft catalog for choices/descriptions/portraits. Reuse the corrected
draft reset in the eventual parent adapter. Original summary content/mask/title,
remaining source children, server-vault-only creation, preservation-safe existing
BIC editing/saving and original-client visual review remain incomplete. The
[whole UI goal](NATIVE-UI-PARITY-GOAL.md) stays active.

Checkpoint: `backups/native-creation-derived-reset-v1.zip`, with adjacent verified
manifest. This includes authored sources and the reproducing research script;
reports/corpora are separately retained at the paths above.
