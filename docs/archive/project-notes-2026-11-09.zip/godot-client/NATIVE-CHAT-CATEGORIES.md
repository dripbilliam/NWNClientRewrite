# Original chat categories and context radial

2026-11-01. Connected to the production native chat HUD. Extends
[NATIVE-CHAT-HUD.md](NATIVE-CHAT-HUD.md); full chat/HUD parity remains open.

## Source evidence

[REA/Ghidra function and instruction observations](reports/native-chat-categories-research-v1.json)
use the pinned original nwmain SHA-256
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.
This is static original evidence, not a claim of original runtime/pixel review.

77c140 maps received speech channels to categories; the pane's inclusion mask
is not `1 << speechChannel`. The DM variants17/18/19/20/22 override ordinary
category selection with0x400. Ordinary DM chat14/30 uses the Shout category4.
Server speech5/15 is0x20; Talk1/8/11/12 is1; Tell4 is2; Shout2/9 is4;
Whisper3/10 is8; Party6 is0x40. Script sound7 is not a chat row.

6f68d0 retains category/portrait/player metadata in the global message buffer
and appends the message to both chat windows.879080 admits it only when the
row category intersects that pane's mask.87a0e0 reconstructs a window using
the retained messages and current mask. Combined8793c0 uses0xffffffff;
split879560 uses left0x74f and right0x100000b0. Feedback presentation
6cb2e0/6d54a0/6d56d0 appends with0x80;770640 player/barter notices use0x20.
6e4ab0's AurPostString mirroring uses0x10000000.

The original context constructor9b3040 and builder9b30c0 reuse CRadialMenu.
879ec0 is installed on the chat drag bar's right-click callback. Its center is
IR_CHAT and its seven entries are:

| Slot | Icon | Category / operation | Include / exclude TLK refs |
| --- | --- | --- | --- |
|0|IR_CHATCOMBINE when combined; IR_CHATSPLIT when split|Split / combine|1405 /1406|
|1|IR_PARTYCHAT|0x40|1399 /1400|
|2|IR_SERVERMSG|0x20|1397 /1398|
|3|IR_DMCHAT|0x400|67572 /67573|
|4|IR_CHAT|1|67574 /67575|
|5|IR_CMBTINFO|0x80|1407 /1408|
|6|IR_SHOUTS|4|1394 /1395|

The first entry's icon names describe the current state, while its TLK label
describes the action. Actual installed TLK records confirm1405 is “Split Chat
Window” and1406 is “Combine Chat Windows”.9b33ae jumps to8793c0 (combine),
while9b33ee jumps to879560 (split).9b338a calls879030, OR-ing the category;
9b33ca targets87a0a0, whose decoded NOT/AND instructions clear it. These small
callbacks lack Ghidra function boundaries; instruction evidence is retained
instead of treating failed decompilation as a different operation.

Those category changes only update the mask: existing displayed rows remain.
Later rows use the changed mask. A source-style rebuild (including combine or
split) re-evaluates retained history. This explains why exclusive “ordinary
versus system” routing was incorrect and why one row can appear in both panes.

## Native implementation

[chat_categories.gd](systems/native_data/chat_categories.gd) owns the original
category/mask/slot/TLK policy. ServerChat gives received rows a local monotonic
sequence; this is UI history identity and is never sent to the server.
NativeChatHud keeps admitted sequence sets for each pane, bounded by retained
history. Arrival, category toggles and explicit history rebuilds remain separate.
The MMO display filters are an additional client setting over those admitted
rows; they do not alter server delivery.

Right-click the top bar or log for the original filter radial. Shift-right-click
the bar, right-click its unique width grip, or use Client Options → Interface
to open adjustable Chat settings. Selected text supports Godot's native copy
shortcuts; the generic Godot right-click popup is disabled in the log.

The chat menu reuses ServerRadial, original GUI_RA_MENU hooks, shared artwork,
native fonts and layer100. The canvas is parented to the actual chat panel's
viewport; the first input test exposed and corrected a misplaced root-viewport
owner. Menu actions are local filters/layout changes and issue no game request.
Independent canvas/input is retired immediately when gameplay is hidden, reset
or closed. Stale selections cannot change the next chat session's preferences.

The global settings file stores combined/left/right masks, preserving unrelated
preferences. Combine/split restores the source default masks and rebuilds the
visible history; source filtering stays independent from outgoing chat mode.

## Evidence and next work

- `native-chat-categories-v3`:126 strict headless checks, including source
  category cases, actual source radial layout and real right-click/selection,
  include/exclude state, duplicate pane admission, old-versus-new history,
  combine/split rebuilding, persistence and stale ownership.
- `native-chat-categories-release-v1`:126 packaged release headless checks.
- `native-chat-categories-phase-v1`:23 whole-HUD visibility/input checks,
  including chat's independent radial during a transition.
- `native-chat-categories-text-v1`:35 received-text regression checks.
- The failed v1 receipt is retained: the menu was on the wrong viewport;
  unchanged source masks alone did not establish functioning input.

No GPU window, benchmark, public server connection or native-client visual
acceptance was used. [Portrait reply controls and their PLAYER_ID `/tp` workflow](NATIVE-CHAT-REPLIES.md)
now have a scoped native source/input milestone. Complete formatting/speaker
metadata, remaining commands/history, sound/tooltips and graphical/local-server
acceptance remain open. Text selection is enabled;
physical clipboard interaction has not been accepted headlessly. The shared
radial's general visual/scale acceptance is also still separate.

Baseline: `backups/native-chat-hud-adjustable-v1.zip` (2259 verified files).
Checkpoint: `backups/native-chat-categories-v1.zip`.
