# Optional BASE draw-leaf merging

`--base-scenery-draw=merged` is a disabled-by-default experiment. It expands the
terrain material/cell merger to positively identified received BASE placeables.
It preserves original Placement/Part nodes, collision/picking, references,
emitters/lights, entity IDs and authoritative state. Only supported mesh draws
are substituted. There is no second world registry or per-frame entity scan.

## Native evidence and admission

The retained original `CreatePartBuckets1400c6a50` excludes non-TriMesh,
AsPartAABB/AsPartDanglyMesh and owning models with a positive own animation count.
It compares texture/material, tilefade, shadow/render and vertex-channel state,
and limits combined vertices below 65,535. `CombineParts1400c5f30` merges draw
geometry while retaining secondary physical Part records. Exact witnesses:
`.cache/native-presentation-parity/shared-animation-agent/base-placeable-batching-audit-v1/native-static-batching-evidence.json`.

The new worker-side `base_static_draw_proof.gd` uses already-read original source
bytes to establish the own animation count and supermodel declaration. It is
more conservative than native: inheritance is refused, as are unsupported mesh
ancestry/features. A zero-animation mesh beside an emitter can qualify while
the emitter's original owner continues operating. Unknown source data stays
unavailable. No stationary-transform, model-name, white-texture or table-only
heuristic establishes BASE eligibility.

Runtime admission additionally requires `BaseScenery.classify` positive received
staticState provenance; an actual Template.Placement; exact World identity,
area generation, desired/installed signature and received lifetime; supported
material/pass, alpha=1, original render/tilefade proof; immutable CPU draw arrays;
uniform positive transforms and supported vertex channels. Blended/private alpha
materials, dynamic GI, UV2/baked channels, custom bounds, references/skinning/
animation/dangly/AABB ancestry and unknown context keep the ordinary path.

The default Godot static GI mode is copied, as in the terrain subset. The current
native World does not construct VoxelGI volumes or baked lightmaps. Those broader
contexts are unproven; adding them requires new admission evidence and withdrawal
hooks rather than assuming the merged bounds select equivalent probes.

## Grouping and native fog

Groups use actual material identity, draw properties/layers/shadow mode, channel
layout and a bounded 20 m spatial cell. Jobs are bounded to 50,000 vertices,
150,000 indices, 128 sources and two data-only workers. Spatial cells provide
culling bounds; they are not rooms, native TileData or permission to hide content.

Materials without instance fog share an explicit no-instance-fog context. When
native per-instance fog is active, the caller must provide an authentic context
through World's `native_static_draw_context_provider` Callable metadata before
open. The callback receives `(placement, mesh)` and returns:

```gdscript
{
    "available": true,
    "identity": [/* original physical TileData lease/scope identity */],
    "factor": current_native_factor,
}
```

The identity must be detached primitive data and the factor must exactly match
the original mesh's `nwn_tile_fog_factor`. Different identities/factors cannot
share a draw. The replacement gets that factor before suppressing originals.
No provider is installed by this experiment; such meshes **fall back** until an
authentic existing physical-fog owner supplies one. It never guesses a TileData
association from coordinates, cell membership or nearby terrain.

## Integration and lifetime

AssetService attaches the source proof on successful original static-model
publication only under the flag. ResourcePool retains existing CPU draw arrays
under the same flag. ModelTemplate carries immutable proof to its Placement.
World admits after final pose/show and all instance_ready listeners, polls only
pending work under its existing publication gate, exposes worker IDs to normal
retirement, and reports `snapshot().base_draw_merge` counts/rejections.

`static_draw_invalidation.gd` is a weak draw-owner endpoint called **before**
existing state mutation. Hooks cover received full/delta state, changed pose,
World removal/retirement, first alpha-owner enrollment and alpha/vector/draw
setters, reference reattachment, native shadow changes and physical fog writes.
Material/Node visibility/lifetime callbacks also withdraw. Withdrawal immediately
hides the replacement and restores original RenderingServer draw visibility,
then schedules bounded work. Node visibility and layer masks remain unchanged;
the earlier layer-zero renderer/light lifetime fault is not reintroduced.

Inactive source rows and their CPU streams are removed on withdrawal. Workers
carry epochs/revisions and cannot publish stale scope/lifetime results. Actual
task IDs remain exposed until joined. Final close joins remaining jobs before
freeing the helper. New writers of mesh/material/layer/transform/instance state
must use the same synchronous invalidation seam before changing it.

## Validation and remaining gates

The isolated headless fixture passed **43 checks**, diagnostics zero and source
pins unchanged. A short actual Vulkan Forward+ fixture passed **48 checks**, clean
exit, diagnostics zero and source pins unchanged. Original/merged image bytes
were equal, actual draw submissions decreased for distinct meshes, and a layer-1
shadow light retired safely through 20 render frames while sources were hidden.
I inspected the merged image: both expected original triangles are visible.
The tests cover proof/inheritance/unsupported ancestry, BASE/usable/missing
records, private alpha material enrollment, exact lifetime, preserved original
Part/emitter/light identities, authentic fog identity/factor and pre-write
withdrawal, repeated bounded re-entry and pending-worker retirement.

Receipts: `.cache/native-presentation-parity/static-scenery-agent/terrain-instancing-base-{check-v4,graphics-v1}/`.
Earlier failed parser/metadata/prototype receipts remain preserved. Reproduce
with a fresh `terrain-instancing-...` label and `--base`, adding `--graphics` for
the authored pixel/draw/light-lifetime fixture.

This does **not** establish full-room BASE eligibility, native visual parity,
better loading or higher FPS. Root's separate terrain V2 full scene completed
1,918 entities / 225 tiles and reduced approximately 5,940 draws to 5,576, but
its roughly 89 FPS did not improve over streaming-only. BASE must be assessed
on the real recording, including actual accepted/rejected counts, same-camera
visuals, cold/warm loading, draw/submission costs, state updates and shutdown.
Keep the default ordinary route until those gates justify promotion.
