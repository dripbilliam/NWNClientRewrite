# Live creation Skills summary and cache lifecycle

2026-11-01. All three source summary list pages now read the real native
creation draft. This follow-up completes the previously pending Skills data
binding. It does not finish the original Skills allocation child, the source
creator workflow, vitals/details or original-client visual acceptance. The
source creator remains staged; the shipping fifteen-page owner stays active.

## Original evidence

Pinned nwmain.exe SHA256:
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.
[REA/Ghidra dossier](reports/native-creation-skill-summary-research-v1.json).

- Base stats constructor7ea230 and derived reset7edcc0 clear the live eligibility
  mask at+E0. Initialized ranks/abilities do not imply confirmed skill choices.
- `CG_SKILLS` constructor9c3040 owns the skill allocation panel.9cce50 binds
  its actual OkButton to9c8d10. That complete OK callback rebuilds the mask from
  signed positive trained ranks or untrained class usability and then enters
  the feat/spell continuation. Package acceptance8e4620 independently builds
  the same mask after applying recommendations.
- Rank write7fa8b0 updates ranks+D8 and cached values+D0 without rebuilding
  eligibility. Trained rank0 has value0; other values include the original
  ability modifier and dexterity adjustment, using signed-byte arithmetic.
- Live display9bfda0 reads the cache through7f0bf0/7f6ae0. Original skill count
  is BYTE, admission storage is DWORD and shifts alias IDs modulo32. The native
  projection preserves those observed semantics rather than inventing a wider
  mask. Class-loss getter7f6630 reads class stride150+297 and controls the row's
  lost-abilities value style.

The Capstone write scans were discovery only, not complete ownership or boundary
proof. REA subsequently confirms writes9c8e5e and8e530a in the actual Skills OK
and package acceptance functions. The dossier retains both full functions,
constructor/control bindings and lower getters/writer.

`scripts/inspect-native-creation-skill-summary.py` executes original live
SetData9bfda0, complete OK9c8d10 and rank writer7fa8b0 unchanged, including class
usability, rank/value getters and cache reads. Raw stat/table fixtures, object
lookup, GUI/TLK/string formatting, allocation and the subsequent child chain
are explicit boundaries. Effective scores are supplied by the existing pinned
skill arithmetic fixture. This is not a complete live original-client creator
or visual oracle. Invalid imported class IDs in the seed cases are explicitly
remapped before live execution; the live path does not normalize those IDs.

Accepted corpus: `backups/animations/native-creation-skill-summary-observations-v2.json`,
72 cases, SHA256
`fdc72beff874b721c56affbd8fc3c842041196bfed5df37f9a8a141821254a60`.
Cases include initial/committed/edited/recommitted rows, count0/255/256,
32-bit aliasing, varied class/ability/race rules and both class-loss flags.
V1 is preserved but rejected: the fixture wrote its intended loss flag at+294
instead of the provider-confirmed+297, so its declared source and observed
flags disagreed. Numeric/mask comparisons exposed no implementation mismatch.

## Native lifecycle

`native_data/creation_skill_summary.gd` shares the existing verified arithmetic
and eligibility calculation for representable unbuffed draft input. Its read
projection uses an explicitly committed mask rather than the calculated import
mask. Raw ranks, modifiers, table dependencies and unavailable states remain
separate from that eligibility cache. This is not authoritative in-world skill
evaluation or existing-character customization.

`creation_rules.gd` owns `skill_summary_mask`. New initialization and all
`reset_choices` paths clear it. Completed recommendations commit it, matching
the original package acceptance. Rank edits retain it. The shipping sidebar
commits when leaving Skills only after a finished allocation; the future
original Skills child must call the same native commit on its real OK route.
This temporary sidebar hook does not claim original child/Cancel parity.
The cache is not an extra serialized BIC field.

`creation_summary_lists.gd` projects active server skill names, icons, help and
integer values into the already shared source row view. Before acceptance it
is a valid empty list, not an invented list of default skills. Missing rule
dependencies remain pending. Original source artwork/TLK and active server
data ownership remain separate. Tab/row input, help, scoped replacement and
retirement use the same native view as Feats and Spells.

## Accepted checks

- `native-creation-skill-summary-v2` and
  `native-creation-skill-summary-release-v1`:482 strict editor/release-headless
  checks each. They compare original initial/accepted/edited/reaccepted masks
  and values, then exercise real recommendations, Skills tab/row/help/integer
  controls, active TLK, physical rank allocation and Next, upstream class and
  ability reset, cancellation/reopen and retired draft reads. Source artwork is
  an explicit non-rendering double; no original pixels are claimed.
- `native-creation-skill-summary-lists-v1`:334 existing original Feats/Spells
  instruction and source-list input/ownership regressions pass with Skills live.
- `native-creation-skill-summary-reset-v1`:237 original reset, real native input
  and first-level BIC serialization regressions pass.
- `native-creation-skill-summary-local-v1`:17 real native/session checks plus
  original localhost Prelude admission, movement and export. The host compares
  every skill-rank entry with the original server's export; all28 match.
  Wizard class, School, feats and known spells also pass. Protocol finish is
  acknowledged, cleanup is clean and zero workers remain.

Final receipts have unchanged sources, no native/script/lifetime error and zero
public connections. No GPU benchmark or visible game launch was used. Editor
and original server were preserved. Failed testV1 remains retained: its33
nonempty class-loss cases exposed the rejected fixture offset, and its UI case
incorrectly expected a decrement from an already minimum base ability. V2 fixes
those fixture/input assumptions without weakening the assertions.

Remaining: HP/AC and complete details/XP, completion-mask/parent-helper wiring,
original allocation and other child screens, preservation-safe existing-BIC
saves and original-client visual review. The [whole UI goal](NATIVE-UI-PARITY-GOAL.md)
remains active. Verified checkpoint: `backups/native-creation-skill-summary-v1.zip`.
