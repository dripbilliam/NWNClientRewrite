# Owned-associate context and displayed character record

The owned current-creature policy is integrated in Desktop for normal world
and current owned portrait contexts. The target Character Record owner is
also integrated; it preserves a private actor/target disclosure lease and
uses the canonical panel8 admission/Session contract. The earlier normal
other-creature and self milestones remain separate. Complete associate,
remote portrait, possession and DM parity is not claimed.

The current copied native suite passed1,070 checks:969 original-derived
policy checks,45 actual Desktop/radial/sheet pointer and lifecycle checks,
and56 prior world/other-creature input regressions. All four engine logs
were clean and input hashes unchanged. This reused separately captured
original-server NPC data with authored IDs/text/tokens. It did not prove
installed sheet pixels or a composed server/UI outcome. The separate
original5127 NPC data probe passed14 checks. The subsequent composed
original5127 test passed63 checks using an authored selective GUI3/4/TLK/token
module and the real installed native controls. It covers current owned
world/portrait hierarchy to Record, received NPC abilities/skills/feats,
six exact target GUI3/4 callbacks, selective updates, X and ownership-loss
retirement. It is not complete world/DM/remote-portrait or pixel acceptance.

The subsequent current-source gate passed1,105 checks: the same1,070,
one new composed-probe compile check,33 typed-packet witness cases and one
test-only host syntax check. Five native engine logs were clean and copied
inputs unchanged. Its exact237 inputs/results are sealed in
`backups/native-associate-record-source-after-v1.zip` (265 verified entries,
SHA256 `6ef55b29a052044b6efdc0b5b0c332ee34b7a89890fd37610604db0a6d9b71f9`).
The manifest explicitly keeps composed-server/UI acceptance false. The
optional `-AssociateRecordCheck` launcher mode and dedicated hidden5127
driver exist only for that finite local proof; ordinary launch and older
WorldRadial/CombatPresentation modes keep their existing behavior.

The composed63 result and exact1,553 runtime pins are archived separately in
`backups/native-associate-record-authoritative-after-v3-sealed.zip` (1,567
readback-verified entries, SHA256
`6873b318a442ce658f3857e257686a8b8173ce6672cf6242323b27c6fa3c1d35`).
The first ZIP verifier rejected Windows separator indexing; that artifact is
retained and is not the accepted archive. Six local row selections took at
most0.08ms CPU, while the original-server callback barriers took233–2,317ms
including transport/chat/TLK delivery. These measurements do not establish
FPS, GPU performance or instant server response. Explicit protected test
credentials, default/MAIN preservation, strict current-server cryptographic
identity, source hashes, native outputs, original processes and cleanup all
passed. No public world was joined or user client restarted.

The original98e340 root and inline normal branch98e550 use the clicked
creature's received `master` and `field908` (a WORD associate type) after
comparing master with the current controlled actor. Their sectors are5 Guard,
4 Stand Ground,3 Follow,6 Special Abilities,2 Attack Nearest,0 Heal Me,
1 Cast and7 Associate Actions. The five commands send signed identifiers
-7/-2/-5/-3/-4 to the clicked associate. Cast appears only when controlled
creature+408 is zero: the separately proved received playerFlags bit10 owner.

Associate Actions98f8e0 starts with Examine0, then preserves these exact sectors:

| Associate type | Additional actions |
| --- | --- |
| 1 | Kick3, Unlock1, Inventory2, Disarm Trap4, Search7, Spellcasting5, Stealth6 |
| 2 | Unsummon3 (-9), Talk7 |
| 3 | Unsummon3 (-8), Possess2 |
| 4 | Unsummon3 (-10) |
| 5 | Release Domination3 (-12) |
| Other known WORD | Examine only |

Command callback995f10 sends the exact clicked ID and signed command. Its
assignment branch writes type39/associateType1 with the same clicked ID and
low SHORT command. Type1 Kick997f30 instead sends -17 and suppresses the
player-party operation for this associate type; it has no assignment branch.
The policy therefore does not invent a draggable Kick shortcut. Other command
quickbar caption/icon fallback coverage remains separate from command metadata
and activation; the prior bound39 milestone proved only five recognized captions.

Unknown playerFlags/master/type does not mean zero, NPC or unowned. The new
projection refuses unknown normal admission and returns detached rows. It has
no registry, visual-node dependency, per-frame scan or copied world. Its trusted
row builders exist for source-oracle comparison; runtime binding must use
`project` after a current private input/lifetime check.

## Original execution evidence

`reports/native-owned-associate-radial-original-v1.json` executes unchanged
original machine code:48 root cases,8 actions pages and68 command callbacks.
The binary and fixture scripts are hash-pinned. Sector/icon/TLK/callback/argument
observations are actual original execution, with UI/actor/party/network services
explicitly authored at call boundaries. These124 cases are not native-client
input, server outcomes or pixels. The follow-up44 unchanged-original
Examine/Talk/Possess/Kick callback cases are in
`reports/native-owned-associate-callbacks-original-v1.json`. The native detached
policy suite passed969 checks with clean engine logs and unchanged23 copied
inputs. Root plus action projection took74µs median,101µs p95 and384µs maximum
for authored text; these timings do not measure actual UI, artwork, server
response or FPS.

Its first891-check run rejected the fixture's qword transport conversion.
Original negative callback arguments are unsigned64 observations that exceed
Godot JSON's exact floating point range. The original oracle/script remain
untouched. `scripts/normalize-native-associate-oracle.py` derives a separately
hash-linked signed low-DWORD column before the Godot boundary. This matches
995f10's native ESI-to-writer DWORD and low-SHORT-to-type39 assignment operations;
the high32 bits are not used by these callbacks. No policy or native expected
value was changed to pass. Exact raw qword integers remain in the original file.

## Why Examine needs a displayed-target owner

Normal997e00 opens Character Record for owned associate types1..4. It does not
send ordinary network Examine and does not open the controlled player's sheet
as a substitute. Both6ac1c0 and6ac1a0 use client+48, the current controlled ID;
the former returns the ID and the latter resolves its creature.

Explicit target-open6fb330 gates panel8 against the requested target. Same-target
reuse preserves the current page. A different target resets to page0 and
updates sheet+8e0. Self-toggle6fc400 is different: an already displayed controlled
record closes, while a different displayed target retargets to controlled after
the self gate. Forced panel8 also needs its reviewed self-retarget behavior.
An open foreign sheet must not bypass disabled membership for a retarget.

Page subscription sender7bddd0 emits21/1 with signed page and the displayed
target ID; close6f7e10 uses pageFF and that same displayed ID. Skills9bf640 and
Feats9c04b0 send GUI3/4 with the page's displayed target at+a18 and preserve the
existing fresh-description resolver. InventoryStats7b2740 begins with an object
ID and resolves that exact creature/stat owner. Receiving associate statistics
must not change controlled identity or move them into the player's record.

The retained original character-sheet corpus has1353 cases: receiver976,
permission324, target16, constructor5, clear16 and destructor16. It proves normal
server permission for controlled self or a direct associate. It is at
`backups/animations/native-character-sheet-observations.json`; its old research
script writes that path, so do not casually rerun it over historical evidence.
The new static caller dossier is
`reports/native-associate-record-owners-research-v1.json`.

The data-only owned original-server diagnostic passed14 checks on loopback5127:
real AddHenchman disclosed type1/master ownership; exact typed21/1 pages0/1/2
returned NPC-owned statistics without changing controlled identity. Page0 gave
six ability BYTEs `[12,12,12,10,10,10]` and received AC field8c11; page1 gave28
indexed CHAR skill ranks/BOOL flags; page2 gave primary feat45 and an explicit
empty bonus list. Page-1 was sent to the same displayed NPC, without inventing a
server close acknowledgement. The association was removed and session/server
cleaned. Protected processes and six native outputs stayed unchanged. Evidence
is `reports/native-associate-record-server-v1-receipt.json` and its private test
directory's `probe.json`. This verifies a data prerequisite, not a native target
record, GUI3/4 response, actual radial input or rendering.

Runtime integration now supplies the scalar actor/target disclosure-lifetime
lease, canonical API-owned panel8 admission, target-aware close/forced-self
and self-toggle behavior, exact target21/1 and GUI3/4 intents, nonself
level-up/drag suppression, and target-owned portrait/row projection. It never
falls back from a stale foreign lease to the controlled actor. Master, type,
permission, lifetime, area and control changes retire stale presentation.
The copied input tests cover these contracts; the standalone protocol
companion separately proves actual NPC-target GUI3/4 and selective TLK/token
updates; composed63 adds the installed-control acceptance described above.
Missing raw fields remain unknown; final NPC AC still needs
its target expertise-mode owner proof rather than borrowing controlled AC.

DM modes, hostile/unowned target branches, other object hierarchies, and full
native font/pixel acceptance remain outside this staged associate milestone.
