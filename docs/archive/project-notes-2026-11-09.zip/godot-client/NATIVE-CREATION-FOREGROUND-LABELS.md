# Creator foreground text

The installed-geometry audit found Feats headers/counter and Familiar's Name
label intersecting background artwork created later in their Godot parents.
The two-menu raster diagnostic then tested actual visibility rather than
inferring opacity from rectangles.

Each bounded owned case uses actual installed fonts and native model/raster
publication. It captures the normal pane, hides the target labels and compares
pixels, then moves those same labels to the foreground in the fixture only.
The original Feats render had zero changed text pixels for all four targets;
the fixture foreground placement revealed332,319,386 and36 pixels. Familiar
Name likewise had zero normal text pixels and137 after foreground placement.
Both failing cases exited cleanly with unchanged source inputs.

The production correction only moves the existing labels above background
siblings after assembly:

- `native_feats_chooser.gd`: Title, list headers and remaining count/caption,
  followed by the existing popup-order restoration.
- `native_associate_chooser.gd`: Title and Name above list/edit artwork inside
  its existing content owner; the separate information-popup order remains.

No text, active data, physical ID, choice, event, draft, model or shared Painter
behavior changes. Dirty before-files are preserved at
`backups/native-creation-foreground-before-v1`.

Final real-raster receipts pass22 checks with clean engine, no timeout and
unchanged current source closures:

- `reports/native-creation-feats-foreground-after-v1-receipt.json`:14 checks;
  `.cache/creation-foreground-raster/20261103-085550-2d606e32/result-original.png`.
- `reports/native-creation-associate-foreground-after-v1-receipt.json`:8 checks;
  `.cache/creation-foreground-raster/20261103-085614-f702bc1f/result-original.png`.

Clean rejected before-runs remain in `20261103-085344-928acdbd` and
`20261103-085443-3014aa69`. The first parse-only fixture rejection is preserved
separately; its sole correction was an explicit Variant annotation for the
two different pane signatures.

The final PNGs were viewed. Name and the restored Feats text are visible.
Available Feats still truncates in its existing83-pixel label rectangle; that
separate header-bounds/default-flags issue remains open until its original
owner is verified. This repair establishes restored text ink, not complete
caption/pixel parity or the entire Familiar preview's visual acceptance.

The diagnostic window is non-activating, parked at(-32000,-32000),16x16 at the
OS surface and renders only its private850x650 UI viewport. There is no FPS
benchmark, user-window interaction, server connection, native rebuild or
authoritative draft/character acceptance. The harness never changes normal
client launch behavior.
