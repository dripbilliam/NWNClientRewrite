# Connection-owned creation summary and portrait binding

2026-11-01. The real session entry now binds the native creator to the shared
source summary and original portrait pane. This is a partial data/ownership
milestone. The source presentation remains **staged and hidden** until its
remaining original children/helper workflow can replace the shipping fifteen
pages. Do not enable or advertise a completed original creator from these tests.

## Native flow and ownership

`native_session_world.gd` configures the creator from the independently owned
pregame painter/TLK/catalog, retrying if those sources arrive after New Character.
`native_creation.gd` owns the exact(connection,draft counter) identity, real
rule draft, summary provider and validated portrait commit. No imported BIC,
fabricated actor, JS presentation or server acknowledgment supplies this model.

The original completion mask starts at0: initialized default fields do not
count as confirmed choices. The parent will own that mask through its original
child-result policy. Tests explicitly supply completed mask31 to inspect data;
that is not proof that unported child screens already work.

Actual native edits/recommendations update the provider revision. Active server
text refreshes data without another edit while pregame frame/text ownership
stays separate. The projection supplies localized race/subrace, alignment,
first-level class, authored full name and current native rule draft ability
values/modifiers. Lookups use active tables/TLK rather than stock class names.

Original portrait OK now validates the current owner/scope and writes the real
portrait field. Normal render refresh retains the committing child ticket;
gender/race/filter changes replace the binding and retire old input. Other
original parent/child commands remain unbound. Cancel/close clears values,
callback and scope and unbinds borrowed portrait targets. New drafts get new
identities. Old reads/commits, late hidden-draft bindings and reentrant replies
cannot publish into the replacement. Source workers/views close with their
creator; shared pregame/data art remains borrowed.

## Original evidence

Pinned nwmain.exe SHA256:
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.
[REA/Ghidra dossier](reports/native-creation-summary-binding-research-v1.json).
`scripts/inspect-native-creation-summary-mask.py` executes original instructions
from9b6380 to the verified9b72a5 join, plus complete title routine88b180.
String formatting/allocation, GUI, name/TLK queries, ability modifiers and
HP/AC getters are explicit lower providers. This is a bounded Character region,
not its complete data/calculation engine, renderer, live process or save path.

The39 cases cover all32 combinations of five completion bits and empty names/
headings with a substituted prefix. Native `creation_summary_values.gd` matches
the exact whitespace, leading punctuation and numeric visibility:

- bit1 appends the full name to `Character Record, `.
- bit2 includes race/subrace; bit16 appends comma/space and alignment.
- bit4 appends newline, class text and trailing newline.
- bit8 exposes **fourteen** fields: six score/modifier pairs plus HP and AC.
  Earlier notes mentioned only the twelve ability fields; constructor hooks and
  executed code confirm that HP/AC are gated too.

Ability modifiers reuse the verified active-rules helper.7f3f00 preserves
authored name contents when joining nonempty fields;7f67c0 prefers nonempty
subrace;7f1a40 formats a fresh single class as Name (1). Native draft lookups
remain distinct from the oracle's supplied getter strings. This does not prove
all fresh-draft initialization or effective-stat/color derivation against the
original. Corpus: `backups/animations/native-creation-summary-mask-v1.json`, SHA
`d00dcf18d5c3844d335d55c8707388e1a515ca02c0433e4dfa36a749d8bcf9a8`.

The [live-list follow-up](NATIVE-CREATION-SUMMARY-LISTS.md) now connects Feats
and Spells to the real draft with original live-callback evidence and source
input tests. It preserves the different imported-BIC Spells behavior.

The [Skills-cache follow-up](NATIVE-CREATION-SKILL-SUMMARY.md) also connects
the live Skills list with original initialization/acceptance/edit/reset behavior.

**Remaining content:** the real source keeps HP/AC and XP/details
pending instead of substituting the picker's imported-BIC projection.
The isolated formatter comparison supplies HP/AC getter values; the real draft
does not until their original initialization/calculation is ported. Mask routing,
remaining child actions, preserved existing-BIC saves and original pixels stay
required. Full summary/creator parity flags remain false.

## Accepted checks

- `native-creation-summary-binding-v3` and
  `native-creation-summary-binding-release-v1`:74 editor/release headless checks
  each. They compare39 original observations, actual native text/ability input,
  portrait OK into the shipping draft, active text, independent source catalogs,
  cancellation/reopen, stale/reentrant results and late source readiness. The
  active catalog has different CG_MAIN bytes; only the pregame catalog supplies
  the valid frame. Source artwork is a non-rendering double; geometry and native
  draft/data services are real.
- `native-creation-summary-binding-frontend-v1`:35 original parent/portrait/
  reset/cancel/input regressions pass.
- `native-creation-summary-binding-local-v2`:15 actual session/creation checks,
  original localhost Prelude admission/movement and Wizard class/School/feat/
  learned-spell export. It confirms real entry binding/revision before upload;
  the source presentation remains staged, not a complete visible workflow.

Final receipts retain unchanged source, no engine/lifetime/native error and zero
public connections. Local shutdown acknowledges the protocol with zero workers.
Existing editor/server processes remain open. No GPU test or public join was
used while the user's other game is running. BindingV1's test-only inferred-
type error is retained and unaccepted; V2 passed69 checks before the additional
late-readiness/portrait cases. LocalV1 passed the earlier source, V2 the final one.

Checkpoint: `backups/native-creation-summary-binding-v1.zip`, with verified
read-back manifest and reproducing script. The [full UI goal](NATIVE-UI-PARITY-GOAL.md)
remains active. Continue with original draft initialization/vitals and live
child/helper workflow before replacing the shipping creator; all three list
bindings now have their separately documented scoped acceptance.
