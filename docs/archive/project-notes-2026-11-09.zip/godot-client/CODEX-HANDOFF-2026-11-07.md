# Native client handoff — production performance parity

Written 2026-11-07, at the user's request before moving to a new chat.

## Read this first

The immediate job is to finish integrating and **measuring** the useful performance paths in the client the user actually launches. Do not restart the entire rendering investigation or repeat months of migration work. The important recent discovery was configuration/source drift: a fast private benchmark used a different engine, rendering thread, lighting-input owner and private particle integrations from the ordinary playable client.
                      
The normal launcher can now select the supported current-source candidate. Configuration, capability and several headless functionality checks pass. **No matched graphics/FPS comparison of this newly integrated candidate has run. No performance defaults were promoted. The 140 FPS/native-parity goal remains unfinished.**

At handoff there is no replacement client or original NWN client running. Two owned local servers remain open. The last two native processes were headless startup checks and exited cleanly. No graphics or authoritative local-server test batch was started after the user's request to make a handoff. The user subsequently explicitly requested pausing this chat's goal; it is being paused for transfer.

The user's latest instruction is to write this handoff rather than begin the larger test batch. They had just permitted some tests, but then asked to switch chats first. Reconfirm PC availability when the new chat is ready to run GPU tests; availability changes frequently because the user plays other games.

## Workspace, preservation and permissions

- Repository/workspace: `C:\Users\Niflheim\Desktop\Tools\Local Tools\EntireDecomp`.
- Main client: `godot-client/`. PowerShell is the normal shell.
- The tree contains a large amount of valuable uncommitted work from multiple agents/chats. Inspect before editing. **Do not reset, clean, revert, overwrite unrelated changes or commit automatically.**
- No applicable `AGENTS.md` was found during this work. Check again in case that changes.
- Back up exact bytes before substantial changes. Preserve failed receipts and old stages; create fresh run names instead of overwriting.
- Do not rebuild or replace shared native DLLs casually. The current engine and DLL are already available and pinned below.
- No automated Arelith/public-server connection or movement is part of this task. Offline captured replays and the owned local server are sufficient. A manual user Arelith test can follow acceptance.
- New windows must open unfocused on a nonprimary monitor, with a visible mouse. Do not steal mouse/focus when starting or closing a client.
- Never print/private-copy credentials into command lines, notes or reports. Authentication belongs to the existing protected Electron broker. Historical CD keys in chat are intentionally omitted here.
- Do not stop/reconfigure the original NWN client or an unrelated game. Check the exact process/run identity before closing an authorized replacement instance.
- GPU/FPS tests require a free PC. Pure/light checks can often proceed while the user plays; do not claim FPS from competing GPU workloads.
- The user has repeatedly authorized using subagents. Keep file ownership disjoint. The just-finished agents are described below; their identities need not carry into a new chat.

## Goal and latest decisions

Canonical current plan: [NATIVE-PRODUCTION-PARITY-GOAL.md](NATIVE-PRODUCTION-PARITY-GOAL.md).

The old thread's goal tracker is **unfinished** and the user explicitly requested pausing it for transfer. Goals are thread-scoped; a new chat must inspect its own goal state and establish/resume the intended goal rather than assume the old tracker transferred. Do not resume the old chat in parallel.

Working objective:

> Resolve benchmark-versus-playable-client drift. Audit exact source, engine, loaded native capabilities, rendering thread, lighting-input owner, collision route, preferences and flags. Make genuinely useful paths selectable through the normal launcher. Establish one discoverable flag registry, no-launch listing and requested-versus-effective startup manifests. Reject ignored/unknown options and unsupported capabilities. Run matched correctness, movement, visual and FPS comparisons using current source and isolated common settings. Promote defaults only after evidence. Continue toward native parity/140 FPS without inventing gains. Preserve dirty work, backups and native compatibility.

The user permits substantial/foundational changes with backups, but expects explanations and actual measurements. The latest work is deliberately a minimal integration of already prepared paths, rather than another engine migration.

## What the client is, and where work belongs

Godot owns resource selection/decoding, meshes/materials, actors/animation, lighting, particles, presentation and native UI. JavaScript/Electron still handles the original network protocol, protected login brokerage and recorded transport. **This does not mean JS renders the world.** Do not accidentally restore old JS rendering/prepared-scene paths.

Useful entry points:

| Owner | Responsibility |
| --- | --- |
| `join-native.ps1` | User-facing launch parameters; invokes existing preparation helpers before normal launch. |
| `tools/native-session-bootstrap.cjs` | Original protected Electron broker and child-host launch. |
| `tools/native-session-host.cjs` | Original protocol/session handling, native process and private loopback transport, startup manifest. |
| `native_live_world.gd` | Native SceneTree, assets/world/camera/frame lifecycle, final report and startup capability observation. |
| `native_session_world.gd` | Browser/menu/session integration, raw world acceptance and scoped connection reset, settings, native UI and replay-view application. |
| `systems/native_render/live_world.gd` | Actual world/entity construction and movement collision owner. |
| `systems/native_render/focus_lighting.gd` | Actual lighting input collection and unchanged existing solver/publication. |
| `systems/native_render/native_feature_report.gd` | Actual loaded capabilities, parsed native choices and asynchronous render-thread observation. |
| `systems/native_render_settings.gd` | Saved client render/UI settings owner. |
| `systems/client_api/` | Read-only entity API work; do not turn it into a second world store. Secondary priority. |

Resource/session/movement authority stays in its current owner. Server state is authoritative; presentation prediction/interpolation must remain distinguishable. Rendering/collision optimizations must not invent unavailable state or change received entity lifetimes.

Research/navigation: [NATIVE-OWNERSHIP.md](NATIVE-OWNERSHIP.md), [README.md](README.md), `../wiki/README.md`, `../evidence/`. Native binary inspection is available through the REA/Ghidra-related tools; discover relevant tool metadata when needed. Do not assume every old document is the current acceptance state.

## Confirmed performance/configuration problem

The private V4 captured-room benchmark used:

- A custom release-template Godot engine.
- Explicit separate render thread.
- A built-in native light-input registry.
- Private particle clock/random/pose-related integrations and, in some cases, a different particle DLL.

The normal client used the official editor engine, default/safe rendering thread behavior, script light collection and the legacy movement collision loop. Simply enabling newer loading/cache options did not carry the older benchmark runtime and source changes into production.

In the preceding live comparison, approximately 46 FPS was observed in the quiet windows of both the all-four loading experiment run and ordinary control. Walking remained slow. Logged movement medians differed, but camera/path/population/timing were not matched. **Those logs do not establish that all four loading changes caused a causal regression, or that the ordinary run won.**

Evidence: `.cache/native-presentation-parity/root/live-all-four-regression-v1/ordinary-comparison-a.json`.

The heavy area was ID `2147618622`. Representative steady CPU work included particles around 5 ms, lighting around 3.4 ms and rigs around 2 ms; GPU time was around 4 ms in those samples. The legacy movement query could iterate about 1,960 entities per preview, resolve descriptors/poses repeatedly, and execute up to 38 clearance checks for a blocked path. The native indexed query existed but production had no supported route to actually select it. That routing gap is now fixed, pending matched live performance acceptance.

## Implemented in the ordinary client

### Central flag registry and listing

- `systems/native_data/client_feature_registry.json`: authoritative supported performance schema, 26 managed entries at this checkpoint.
- `tools/native-client-flags.cjs`: pure parser/catalogue/validation, no game decoding or Electron launch.
- [CLIENT-FLAGS.md](CLIENT-FLAGS.md): generated human reference.

Run from `godot-client`:

```powershell
.\join-native.ps1 -ListFlags
node .\tools\native-client-flags.cjs --list-flags --json
```

The listing exits before builders/launch. It distinguishes supported choices from parser/native-source inventories and research-only options. Source literals are **not** proof that a feature is forwarded, supported by the loaded binary, or actually used.

Validation now rejects unknown inputs, duplicate managed choices, ignored scalar switch forms, unsupported research-only normal-launch inputs, and invalid cache budget/dependencies. A former scalar-overhead flag consumption problem was corrected. Bare `--native-profile` is distinct from rejected `--native-profile=true|false`; use the central detailed-profiling option for explicit policy.

### Current-source candidate selection

From `godot-client`:

```powershell
.\join-native.ps1 -PerformanceRuntime verified-native -RenderThread separate -DriveCollision indexed -LightInputRegistry builtin -DetailedProfiling on
```

For final clean performance comparison use explicit profiling `off` in separately staged matched cases. `saved` is the default and must not be treated as a known measurement state.

Independent choices/defaults:

| Choice | Current normal default | Candidate |
| --- | --- | --- |
| Performance runtime | `standard` (existing ordinary runtime selector) | `verified-native` |
| Render thread | `default` (preserve existing engine policy) | `separate` |
| Movement collision | `legacy` | `indexed` |
| Light-input registry | `script` | `builtin` |
| Detailed profiling | `saved` | explicit `on` or `off` |

No defaults have been promoted. Loading/cache/shared-rig options remain independently selectable; they are not silently enabled by this candidate.

`tools/native-performance-runtime.cjs` verifies exact existing engine size/SHA, current `project.godot` and script-class cache. It runs **current project scripts via `--path`/`--script`**, not an old frozen PCK. Ordinary editor/release selection is preserved. The verified-native route rejects an incompatible packaged-release combination.

### Actual owners and startup evidence

`tools/native-feature-manifest.cjs` writes `reports/<run>.startup.json` containing selected executable, source/file hashes, exact engine/native arguments (private ticket redacted), declared/requested choices, actual native capabilities and observed world owners.

Native startup rejects an explicit unsupported built-in light request before world preparation; it does not silently fall back. Render-thread observation is asynchronous: initial hello can legitimately say pending, but the final graphical observation must establish the requested thread. Headless observations explicitly say they cannot prove GPU-thread behavior.

The indexed collision owner is selected before World construction and frozen for its lifetime. Detached diagnostics report requested/effective route, actual owner script and world/generation/area scope. Existing algorithms, server authority and retirement semantics are retained.

The built-in lighting adapter connects `NwnBuiltinLightInputRegistry` directly to the existing Focus input path. The lighting equations, ranking, fades and renderer-publication tail are unchanged. Actual registry class/capability/owner/counts/fallback reason are reported. Explicit unavailable capability rejects.

### Last source changes before handoff

`native_live_world.gd`: startup monitor fallback now changes screen only if the initial screen is primary. It no longer overwrites a valid secondary selected by engine `--screen`. The last known topology was secondary0=1920 wide, secondary1=3440 wide, primary2; re-enumerate, do not hardcode.

`native_session_world.gd`: runtime snapshots now separate settings-owner state from effective presentation:

```text
runtime_features.presentation.settings:
  preference_path, menu_layout_path, gamma, particles_enabled,
  particle_collision_enabled, compact_scenery_enabled, fov_degrees
runtime_features.presentation.gamma: actual gamma_controller.snapshot()
runtime_features.presentation.particle_visibility: enabled, collision_enabled, registered
```

Base presentation also includes viewport, MSAA, maximum FPS, VSync, profiling, screen/primary screen and focus flags. These snapshots run at startup/report/protocol boundaries, not a per-frame world scan. Final replay-view particle/collision/viewport overrides can differ from saved settings; the verifier distinguishes them.

## Frozen production identity and native inputs

Last verified current-source identity, 919 files:

```text
7ddd9b73b94535322c11aa2928f0c3d2216cd0b10bc2622c0b279b6dca74333c
```

This is an application subset signature, not the entire dirty repository. Complete staged preload/library closures have separate pins. Markdown additions do not change this identity; code changes generally do.

| Input | SHA256 |
| --- | --- |
| `native_live_world.gd` | `df8415c6d500f0243cf1be973c0bb1d21e1d2734ab861f7a53947b69921bc448` |
| `native_session_world.gd` | `57c636adf7cb13fd5c8ee8ea9120b49891fb25b2ccda8205b599798afb180f25` |
| Central registry | `d2659abb178784cb1b9ca615048e72e5002b12e0faa33f0f04520ebfc65da3f1` |
| Official `.tools/Godot_v4.7.2-stable_win64.exe` | `ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424` |
| Verified custom engine | `62f54a7f7ff4638987730a246833cea4054779e7cb2a333bb5921fd5b0aea6dc` |
| Current `.cache/native-kernel/nwn-particle-kernel.dll` | `b3f591291516e64321dee870c3cb5ff14a72d40092062ec36813c70cc40ffbfb` |
| Current `.cache/native-resource-index/nwn-resource-index.dll` | `a2450c9f86c4f6dd9d9dfdb7a388218777746cc8311c7458c775bc3dd1255a11` |

Verified engine path relative to `godot-client`:

```text
.cache/native-140fps/render-agent/engine-font-atlas-ownership-v1/build-1793998835313/binaries/godot.windows.template_release.x86_64.exe
```

It is 90,787,840 bytes. Current particle DLL is 800,256 bytes.

The private V4 particle DLL SHA was `672bd24ae23f0be06bb209bc40ec5083fbe8ac14e92b2dd6b10f836255a840ea`. **Do not replace current DLL with it.** Current main source/DLL lacks V4 native particle clock/random/managed pose/eligibility lease integration. Research flags alone do not activate missing code or capabilities. An animation `_native_clock()` helper in current rigs is not proof that the V4 particle-clock path exists.

## Evidence already obtained — do not overstate it

| Check | Result / limitation |
| --- | --- |
| Root flags/manifest Node tests | 14 passed; combined with 35 existing loading tests, 49 passed. |
| PowerShell binding/forwarding | 10 passed; existing loading PS tests also passed (18). |
| Native feature report schema | 272 current-schema checks passed. |
| Collision route/oracles | 48,905 native checks passed; no FPS claim. |
| Light-input selection/behavior | 1,435 native checks passed across ordinary/custom engines and unavailable capability. |
| Runtime selector | 8 config tests plus 43 native assertions/4 cases passed. |
| Production selection/integration | 17 tests passed again after final V2 edits, together with the11 preference tests. |
| V2 preference tests | 11 passed after the final gamma-key adjustment; combined final28/28 tests passed without native/GPU processes or server connections. |
| Actual protected bootstrap startup D | Both ordinary and candidate passed 13 gates each, current frozen source, clean shutdown, zero server connections. |
| Actual unavailable-capability startup | Explicit built-in light on ordinary engine rejected clearly before menu/world; negative acceptance passed. |
| Current-source full captured replay V1 | 1,918 entities, 225 tiles, all 360 recorded movement prediction operations accepted; clean retirement/exit. Headless and inherited preferences: functionality only. |
| V2 captured replay / graphics / authoritative local batch | **Not run yet.** |

Latest current-source startup receipt:

```text
.cache/native-presentation-parity/root/production-features-host-d/summary.json
reports/production-features-host-d-ordinary.{json,startup.json,native.json,engine.log}
reports/production-features-host-d-candidate.{json,startup.json,native.json,engine.log}
```

D used the real normal protected broker, current scripts, explicit profiling off and no server connection. Final observations actually contain the newly added settings/particle/gamma fields. Both had clean native exit and zero workers. It inherited live preferences and is **startup functionality evidence**, not a matched render-settings benchmark. Headless focus flags are not graphical focus proof.

Earlier startup A and B failed because test fixtures respectively required graphical visibility and accidentally invoked an unrelated graphical browser/preload test. Those receipts remain preserved. C and latest D use explicit headless logical startup plus ordinary finish/ACK; do not erase failures or relabel them as application crashes.

Two direct check-only parse attempts around the final metadata edits returned exit0 but printed log-path errors caused by the restricted user-log location / relative log-file path handling. Do not call those attempts diagnostic-clean. Actual startup D subsequently parsed and ran the same final source cleanly with valid report paths.

Exact root integration backups:

```text
.cache/native-presentation-parity/root/production-feature-manifest-v1/before/
.cache/native-presentation-parity/root/production-feature-manifest-v1/native_live_world.before-monitor-guard.gd
.cache/native-presentation-parity/root/production-feature-manifest-v1/native_session_world.before-settings-observation.gd
```

`checkpoint-current.json` in that directory predates the final screen/settings changes and records source `edc6820f…`. Preserve it as an earlier checkpoint. This handoff and startup D identify the later freeze; do not silently rewrite old receipts.

## The captured workload and accepted V1 replay

Sealed capture:

```text
C:\Users\Niflheim\AppData\Roaming\nwn-model-viewer-research\native-loading-recordings\capture-YaH3xf
```

- Use generation2 for the dense area/movement case.
- `timeline.jsonl` SHA256: `6ce44bfe52a7bd8c3b08e936206360847cd3bb1ec1713bd1d21c7304882d3920`.
- Offline transport has no game-server connection; only private loopback to its owned Godot child. Captured resources remain local originals.
- Receipt `reports/production-headless-current-gen2-a.json` plus native/log siblings.
- That V1 run used source `edc6820f…`, current b3f particle DLL and verified engine62f. Do not claim it ran the later metadata freeze.
- 1,918/1,918 desired entities, 225 tiles, ready true, no rejected prediction inputs, zero workers and clean protocol finish/exit.
- Actual inputs: 349 drive, six stop, five turn =360. Roughly 9.402–48.421 seconds are the input section; the later quiet window is distinct. The replay is not merely positions pretending to test input.
- Actual collision owner was indexed with correct generation2/area scope. Actual light owner was builtin/history enabled, registered576, zero reported registry errors.
- Thread observation was present, but a headless run does not establish GPU-thread performance.
- Driver clock retained lateness: maximum about1,906ms, 635 events beyond25ms. Do not claim exact original network-delay fidelity when the replay falls behind.
- V1 inherited live preference files; it cannot establish fair FPS even if run graphically. New production replays now require V2 isolated preference seeds.
- Exact V1 driver bytes were preserved in the agent's V1 evidence directory; the driver was later changed to permit early pending thread evidence and require final completed evidence.

## Ready for the next chat: V2 matched captured replay matrix

Documentation: [NATIVE-PRODUCTION-REPLAY.md](NATIVE-PRODUCTION-REPLAY.md). Some historical sections intentionally still describe V1. The agent's [final V2 handoff](.cache/native-presentation-parity/continuous-streaming-agent/production-selection-v2/HANDOFF.md) contains exact latest commands; prefer its V2 matrix/manifest over old examples missing seed inputs. That handoff SHA256 is `e6f72570ec31d8f99fcef2ad90cf18d9a9a98f08ef7c8cd37c6ba3f1d0586ad2`.

Helper/driver ownership:

- `tools/native-production-selection.cjs`
- `tools/replay-native-loading.mjs`
- `tools/native_parity/performance/replay_client_capsule.mjs`
- Dedicated tests `tests/native_production_selection.test.cjs` and `tests/native_production_preferences.test.cjs`.

V2 matrix:

```text
.cache/native-presentation-parity/continuous-streaming-agent/production-selection-v2/matrix-a.json
SHA256 e0dd9b3a7a7c93c8b11fb741c9b4432756e4a3859246d79d909da5e2039262d1
```

All five cases have source `7ddd9b73…`, 2,117 complete code/preload/current-library pins each, ordinary loading, gameplay render profile and explicit profiling on. Stepwise cases:

| ID | Engine | Thread | Lighting | Collision |
| --- | --- | --- | --- | --- |
| `editor-safe-script-legacy` | Official | safe | script | legacy |
| `editor-separate-script-legacy` | Official | separate | script | legacy |
| `native-separate-script-legacy` | Verified | separate | script | legacy |
| `native-separate-builtin-legacy` | Verified | separate | builtin | legacy |
| `native-separate-builtin-indexed` | Verified | separate | builtin | indexed |

This matrix isolates one change per step rather than attributing an all-on result to threading alone.

Each selection lives at:

```text
.cache/native-presentation-parity/production-replay/production-v2-<ID>/production-selection.json
```

Fully indexed candidate manifest SHA:

```text
05f55e2c8f3f80089380d18ffaa6a1d2d6ea67a84cc6f1cd19b74ff27f03c721
```

V2 common seed manifest is `production-selection-v2/preference-seeds-b.json`, SHA `b2e6250e75816e61fe13c84976f0c4811e68c778f75e2d70183445bfea7a2c73`. Do not use the earlier seed manifest merely because it has a similar name.

- Immutable render seed SHA `86b14987edc38ab177436df5c159cb9c68402b8ea72d0defbafc88b08fd87c9f` (273 bytes).
- Immutable layout seed SHA `4c696a5b4ae9a152790b9cc383e790f1a18c9a15924a2f64ac70b4f65de1f491`.
- Shared seed settings: gamma1.2, particles on, collision on, UI scale1, compact scenery true, FOV45. Compact scenery is explicitly common, not newly promoted by production defaults.
- Each replay copies seeds into **new per-run working preference files** and forwards existing native `--render-preferences`/`--menu-layout` paths. Runtime saves may change working files; seeds and live preferences must remain untouched.
- Final verifier requires actual bound paths and actual effective gamma/particle/collision/viewport. Final recorded replay views, not seed assumptions, determine expected particle/viewport overrides.
- Actual gamma field is `presentation.gamma.gamma`, not `gamma_effect`.
- Graphical missing gamma effect is rejected. Headless has an explicit no-GPU-pass limitation.
- Selection `accepted:true` means staged/pins verified, **not** replay/visual/FPS acceptance.

A later authorized replay invocation, from workspace root, should load the row and its SHA from the matrix instead of transcribing filenames by hand:

```powershell
$clientRoot = Join-Path (Get-Location) 'godot-client'
$matrixPath = Join-Path $clientRoot '.cache/native-presentation-parity/continuous-streaming-agent/production-selection-v2/matrix-a.json'
$matrix = Get-Content -LiteralPath $matrixPath -Raw | ConvertFrom-Json
$case = $matrix.rows | Where-Object id -eq 'native-separate-builtin-indexed'
$capturePath = 'C:\Users\Niflheim\AppData\Roaming\nwn-model-viewer-research\native-loading-recordings\capture-YaH3xf'
$env:NWN_ENTITY_API_REST = 'false'
node .\godot-client\tools\replay-native-loading.mjs "--capture=$capturePath" --generation=2 --paced --movement-timing "--production-selection=$($case.file)" "--production-selection-sha256=$($case.sha256)" --observe-profile=true --steady-ms=1000 --run=production-v2-candidate-headless-a --headless
```

For the graphical version omit `--headless`, use a new run name, confirm display selection and inspect the final actual engine/thread/settings/owner evidence. Do not launch graphics while another game runs. Run the baseline plus candidate first; then intermediate rows as needed. Do not compare menu-capped FPS or later quiet observations to movement frames. Keep first/cold setup separate from steady-state samples and retain pop-in/loading/missing-asset failures.

The old goal's automatic continuation after the handoff ran the final pure checks: `node --test godot-client/tests/native_production_preferences.test.cjs godot-client/tests/native_production_selection.test.cjs`,28/28 passed in about7.3seconds on unchanged source `7ddd9b73…`. This supersedes the child handoff's pending pure-test note. No native/GPU process or server connection was involved. No V2 native or GPU replay has run yet. If sources change, stage a fresh cohort; **never patch old pins to pass**.

Final V2 tooling hashes: selection helper `e44c7ba2d9f4d20324d55f14a0d2311b623c8299336f18c9c4c81dabca67956b`; replay driver `4fe10a88500f74feb38689053e2df9ef0ccc9c82c552cdb1811f53581c539816`. These tools are outside the919-file renderer signature but are still pinned by the broader local harness and must not be assumed unchanged solely from that signature.

## Ready for the next chat: authoritative owned-local functionality batch

Documentation/contract: `tools/native_parity/performance/check_production_local.md`.

Prepared harness:

- `check_production_local.cjs`: prepare/verify/analyze only, no launch command.
- `check_production_local.ps1`: explicit bounded execution and before/after fences.
- Final prepared plan `prepared-g`, not earlier A–F. Final verify-only of F correctly rejected the later changed `native-production-selection.cjs`; no process launched. Root then regenerated G against the final helper bytes. G preparation succeeded; execution and a fresh verify remain pending.

```text
.cache/native-presentation-parity/static-scenery-agent/production-local-v1/prepared-g/plan.json
SHA256 360467661964942c143093b950b6bdf732e1a253cba8d5d84808bdb7df15ff67
Source 7ddd9b73b94535322c11aa2928f0c3d2216cd0b10bc2622c0b279b6dca74333c
```

The plan copies 955 renderer/resource files and pins1,622 protocol/harness inputs. Both variants share the same current renderer copy/DLL. Current host/bootstrap are used through exactly reversible private adapters for loopback5122, isolated paths/userdata/cache and pinned Node child. Two accepted test-only scoped pending-abort telemetry hunks exist only in the copied native session; they do not fake data or alter main gameplay.

Both variants explicitly share merged loading, shared animation preparation, prepared native draw cache25GiB, gameplay/shared/pooled rendering, profiling **off**. Only engine/thread/light-input/collision differ. This is functionality coverage of the integrated families, not a claim that merged/cache options improve FPS.

It uses original server full/delta delivery and actual native movement, two completed joins plus a real pending-stream abort, stale scopes and retirement. It must compare actual native/server movement. A reconnect is not proof that the server sent destroyed-object messages; absent removals must be reported unexercised.

Future verify-only:

```powershell
$localPlan = Join-Path (Get-Location) 'godot-client/.cache/native-presentation-parity/static-scenery-agent/production-local-v1/prepared-g/plan.json'
$localPlanSha = '360467661964942c143093b950b6bdf732e1a253cba8d5d84808bdb7df15ff67'
node .\godot-client\tools\native_parity\performance\check_production_local.cjs verify "--plan=$localPlan" "--plan-sha=$localPlanSha"
```

After checking current availability and the fences, execute one variant at a time:

```powershell
.\godot-client\tools\native_parity\performance\check_production_local.ps1 -Plan $localPlan -ReviewedPlanSha $localPlanSha -Variant control -Run native-production-local-control-a -Execute
.\godot-client\tools\native_parity\performance\check_production_local.ps1 -Plan $localPlan -ReviewedPlanSha $localPlanSha -Variant candidate -Run native-production-local-candidate-a -Execute
```

The launcher refuses without `-Execute`. Do not use these names if already present. Before/after checks bind source/preload/init metadata, protocols, native libraries, Node/Electron/engines, server PID/creation/home/nonpublic command line/UDP ownership/module/settings. Code changes after preparation can invalidate the broader protocol pins even if the919-file source identity stays the same. Re-prepare/review if any input changed; never bypass a fence.

No authoritative local batch has run for this candidate. No current GPU or online acceptance follows from preparing this harness.

## Local server identities — historical pins, verify at execution

At final process inventory only the following `nwserver.exe` processes were open; neither was stopped or reconfigured:

| Fixture | PID | Port | Home |
| --- | --- | --- | --- |
| BaseReuse1 |19768|5121|`runtime-logs/local-multiplayer-server`|
| BaseReuse2 |20872|5122|`runtime-logs/local-multiplayer-base-reuse2`|

Executable:

```text
C:\Users\Niflheim\Desktop\Tools\Local Tools\FullDecomp\NwnRootInstall\bin\win32\nwserver.exe
SHA256 98951511ae7d06a251355f12d4f3e4b96269a2414fa3058e641afd70098690f6
```

BaseReuse2 identity:

- UTC creation ticks `639296483436795190`.
- Descriptor `.cache/native-presentation-parity/root/pipeline-family-v4-a/local-server.json`, SHA `e7ede9d32f37346dcd17010c4a56490c4460d08f5291ab3dde6c4b1e81ff082f`.
- Module SHA `b8802b74139b896fef05e47042786ae3fdbb36e92991f3d8742c7ef28661a6f9`.
- Settings SHA at stage `4f236aef384674c2e8557d775a985b8ee2d75d5ed59788299340fdb3deebac4a`.
- Publicserver0, NAT punch disabled. Fixture has two areas,132 authored props and verified animated emitters/loot bags.

If the same process no longer exists after a reboot, **do not treat an unrelated PID as the owner**. Review/re-establish the owned fixture and fresh identity rather than forcing the stale plan.

## What is still not solved

1. Matched graphical measurement of the integrated current-source engine/thread/light/collision routes.
2. Actual authoritative local movement/abort/reconnect batch for both current configurations.
3. Visual parity of lighting, particles, highlighting, visibility and UI after runtime/thread changes.
4. Default promotion decision backed by repeatable measurements; no140FPS claim yet.
5. Private V4 particle-native clock/random/managed-pose integrations are not ported simply by selecting the custom engine. Treat as separate scoped work if evidence warrants.
6. The earlier requested format conversion/preparation is only partially implemented. A25GiB on-demand converted-model/draw cache is not the same thing as a complete ahead-of-time source-format conversion/preparation pipeline.
7. Broader game/UI parity remains a separate unfinished program. Do not claim it all complete from this performance task.

Earlier first versions of loading1–4 include immutable shared rig preparation, continuous player-centric base scenery admission, terrain/base batching and an on-demand native prepared draw cache. Some narrow publication spikes improved in tests, but they did not establish an overall FPS win. The user already called out the distinction between caching and converting files. Keep that distinction explicit.

The user's seven presentation requirements (blocker visibility, elevated bridge surfaces, native reveal/LOS/translucency, correct FOV convention, open doorway picking, eligible player lifetime/presentation, readable wrapped NPC dialogue) have their own detailed history in [NATIVE-WORLD-PRESENTATION-PARITY-GOAL.md](NATIVE-WORLD-PRESENTATION-PARITY-GOAL.md). Highlighting should be a whole-body glow rather than independent per-part artifacts. Persistent black scenery was a real regression with Tab released; do not dismiss future black surfaces as merely highlighting. Consult scoped evidence before making new visibility policy guesses.

UI/level-up/creation must use the active base/server2DA data, and HP/rules remain server owned in multiplayer. Menus should preserve WASD/camera/world-click behavior where appropriate. Client game numbers should be whole numbers; diagnostic precision stays. These are standing project constraints, not tasks to redesign during this batch.

## Subagent handoff and safe parallelism

All current agents were told to stop edits and not launch tests for this transfer.

| Previous lane | Owned files / result |
| --- | --- |
| continuous_streaming | Runtime selector; production-selection/replay tooling; V2 preference isolation and five-case matrix; final owned handoff under its V2 directory. |
| static_scenery_path | `live_world.gd` collision route, focused tests/report fixture; current local prepare/verify/analyze harness. Its prepared-f was superseded by Root's prepared-g after final helper edits. |
| shared_animation_preparation | `focus_lighting.gd`, new light-input registry adapter, tests/docs; frozen completion under light-registry-production-v1. |
| root | Central schema/options/manifest, normal host/launcher and native entry/session hooks, integration and acceptance. |

Do not concurrently edit the same entry/host/manifest files. A useful next split is root running the serialized GPU matrix, one agent reviewing functional local receipts, and one doing read-only profiler/binary analysis. Additional changes should wait until the source cohort is measured, or be staged separately.

## Recommended next actions

1. Read this handoff, current parity goal and the final agent V2 handoff. Inspect dirty files and verify hashes/source identity. Do not re-run broad discovery.
2. Confirm the old chat will not continue its active goal in parallel; establish the unfinished objective in this chat.
3. Check PC/client availability. The final28 pure selection/preference tests have now passed; repeat only if those inputs change. Verify/stage fresh only if input hashes changed.
4. Run the V2 headless candidate once to exercise isolated bound preferences and final effective metadata; retain result and do not call it FPS proof.
5. Execute the prepared local control/candidate functionality batch sequentially, preserving its server/source fences.
6. Run matched graphical baseline/candidate at the same capture generation, native settings, resolution, MSAA, particles and recorded camera path. Inspect the actual render-thread observation and visual result. Do not count menu-capped frames or headless timings.
7. Attribute gains using intermediate matrix cases; split quiet, input, loading and first-use hitches. Repeat only to resolve a concrete uncertainty. Then decide keep/promote/reject, back up changes and tell the user what is ready for manual Arelith testing.

The user is frustrated by excessive preparation without a visible result. The validation infrastructure is now largely ready: **run the prepared relevant checks next rather than building another elaborate testing framework.** Be candid about what was actually measured and keep updates focused on findings.

## Suggested opening prompt for the new chat

> Continue the native NWN client's performance-parity work. Read `godot-client/CODEX-HANDOFF-2026-11-07.md`, the current parity goal, and the V2 agent handoff before editing. Preserve all dirty work. The current-source candidate and flag/effective-capability reporting are integrated, but matched GPU and authoritative local movement acceptance remain unfinished. Verify the current source/plan hashes and current PC availability, then run the prepared tests rather than restarting discovery. Use disjoint subagents as useful. Do not connect to Arelith automatically, change native libraries, or promote defaults without evidence. New windows must remain unfocused on a nonprimary monitor.

