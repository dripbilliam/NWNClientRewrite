# Bounded continuous base-scenery streaming

The optional `--base-scenery-stream=continuous` mode keeps an existing base
ObjectStream working as its completed rows are admitted. It refills freed
reservations without waiting for the slowest member of the original wave.
The default remains the previous `waves` behavior until comparative acceptance.

## Ownership and bounds

`live_world.gd` remains the authoritative desired/installed/lifetime owner.
`object_stream.gd` owns actual model requests, prepared packets, scene instances
awaiting adoption, and its current placement groups. The new
`base_stream_schedule.gd` stores only sparse pending ID/signature/position
metadata. It contains no canonical world rows, model bundles or live Nodes.

The reservation limit is the minimum of 64 and the existing configured base and
static limits. A successful, hidden or independently failed row retires its
active reservation. A stale prepared result must also retire its old reservation
before a current same-ID lifetime can enter. Existing source/service epochs,
appearance signatures, worker limits, nearest-ready ordering, publication clock
and ResourcePool budget remain required.

Before control is ready, the owner retains the existing single base worker.
After readiness it can use the existing fresh-owner four-worker policy without
waiting for the original wave to finish. The controlled-character request still
owns the next request. The background owner limit remains unchanged.

The queue is updated at canonical full/delta/removal boundaries. It is sorted
when pending metadata or the priority origin changes, then consumed through its
cursor. Refilling base rows does not scan the whole World registry or rebuild
that ordering on every frame. Live non-base planning retains the existing
revision-based scan and separate actor/static lanes.

An active row/group is released after adoption. An already prepared group can
share its existing result with newly reserved placements. Empty groups release
their result/template handles; later repeats use the existing pool/directory.
The queue does not retain one model graph per world placement. A newly animated
row is deferred to an ordinary correctly typed wave rather than being inserted
into a potentially differently decoded active group. A source remount that
invalidates the active scope likewise waits for ordinary owner retirement.

## Separate scheduling experiments

The previously checked `--base-scenery-template-probe=ready` and
`--base-scenery-admission=timed` paths are now present in MAIN source but remain
separate opt-ins. The former can queue ready template hits despite saturated
cold job capacity. The latter preserves the original first eight successful
adoptions and permits further currently verified base-only admissions within
the same existing three-millisecond clock, bounded to 64 base successes.
Continuous refill does not itself enable either experiment.

`World.snapshot().continuous_base_stream` reports the mode, reservation limit,
World-lifetime refill count and detached sparse-scheduler counters. Existing
base-admission counters keep their cumulative/high-water semantics. ObjectStream
model-job/probe counters cover that owner's current park/resume wave; a
continuous wave can include multiple refills. Directory counters remain
owner-lifetime cumulative. These differently scoped counters must not be added
as if all represented per-frame or per-world totals.

## Validation performed

Exact before bytes and source mappings are retained under
`.cache/native-presentation-parity/continuous-streaming-agent/refill-v1/`.
`backup.json` identifies the pre-integration MAIN World, ObjectStream and
directory. `capsule-port.json` records guarded narrow ports onto the existing
V8/V10 replay sources; reversing those hunks produces their exact predecessors,
preserving unrelated capsule-specific managed-pose code.

The dedicated `tests/native_continuous_base_stream_test.gd` executes an actual
production World, ObjectStream, ResourceCatalog, AssetService, ResourcePool and
ModelTemplate using tiny authored meshes. A ResourceCatalog subclass only gates
one authored model resource read; it retains real source forks/stores/workers.
No World/readiness override or fake render pool is used.

- Fresh `run-d`: **41 checks passed**, zero native diagnostics, clean exit.
- The actual owner installs more than its initial 64 reservations while one
  original-wave model read remains genuinely held. Every observed active key
  and owner-row set remains at or below 64. Initial shared model work consists
  of two model jobs, and the same actual owner performs the refills.
- Covered sparse nearest/tie ordering, installed/inflight/failed exclusions,
  stale signatures, canonical same-ID removal/reuse, independent failure and
  retry, complete park/worker drain, and unfinished old-world retirement while
  the next generation loads the same IDs.
- `run-c` executes the prior real-World retained-owner/remount suite with
  continuous mode off: **99 checks passed**, zero native diagnostics, clean exit.
  It includes actual override winner/geometry, worker retirement and direct close.
- The first `run-a` is preserved as failed: one assertion detected unnecessary
  sorting caused by transient pre-install removal. The fix confines enqueue to
  canonical change/removal boundaries; fresh `run-b` and final `run-d` pass.

These are isolated headless correctness checks. They do not invoke World.open,
load real terrain/player content, connect to any server, exercise gameplay input
or establish a GPU/FPS/loading speedup. Root owns serial captured-room Vulkan
comparisons and local-server acceptance. All normal defaults remain unchanged.

## Moving-priority review and final source revision

Root's review caught a raw-interpolated-position call that could bypass the
existing two-metre stream-priority refresh threshold. The final World uses the
existing quantized `priority_origin` in the continuous planner. It does not
dirty the pending order for every tiny movement.

`run-e` passes **45 checks**, zero diagnostics, with the prior real refill cases
and an additional isolated priority-method contract: 199 movement/planner calls
below two metres cause no extra sort, then crossing 2.01 metres causes one.
That additional case uses a point-only controlled presentation stand-in and
calls the actual World priority methods; it is explicitly not actor readiness
or gameplay validation. The actual worker/refill/lifetime cases are unchanged.
`run-f` reruns the old full-World retirement/remount suite with continuous mode
enabled: **99 checks passed**, zero diagnostics, clean exit.

The fresh exact port `capsule-port-v2.json` and `capsule-v2/` preserve the earlier
port rather than modifying it. World MAIN is `cbcb29c8...`, capsule is
`d5749781...`; ObjectStream and the sparse helper are unchanged. Source/default
promotion and captured-room performance acceptance still belong to root.

In continuous mode `base_scenery_batches`/`base_scenery_objects` describe planning
reservations/refill attempts, not distinct owner creations. Use
`base_owner_creations`, `base_stream_refills`, successful installed keys and
`continuous_refilled_rows` for those comparisons. A refused animated-row refill
can repeat until its existing reservation finishes; it does not submit a model
job or consume the pending row. This conservative fallback remains a potential
future refinement, not a throughput claim.
