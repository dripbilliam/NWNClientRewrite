# Staged creature clock lifecycle facts

`src/network_client_clock_lifecycle.js` owns private metadata, not clock values or a second world. Its source basis is [Client creature construction boundary](NATIVE-CLIENT-CREATURE-CONSTRUCTION-BOUNDARY.md): original external A/type5 reader `77f870` performs typed lookup, constructs `7fb140` and adds to AI `7675d0` only on the successful fresh path. Existing typed A reuses its owner. Constructor birth samples base T0; this JavaScript helper neither samples nor simulates that clock. D does not establish native hard destruction.

## Exact API

```js
const lifecycle = new NativeClientClockLifecycle({
  owner: world,
  connection: null, // May be explicitly bound once before/after transactions.
  recordHistoryComplete: false,
  externalRegistryHistoryComplete: false
});
lifecycle.bindConnection(world, acceptedConnection);
lifecycle.begin(staged, {complete: decoded.complete, recordCount: records.length});
lifecycle.observe(staged, record, recordIndex, {
  canonicalBefore, stagedProxy,
  externalOwner: 'absent' | 'live' | 'retained' | 'unknown',
  areaId: knownAreaIdOrNull
});
// Validate expected old??staged identities BEFORE canonical row assignment:
const boundaries = lifecycle.commit(staged, id => oldOrStagedFor(id));
// Root now performs its already-validated canonical assignments.
lifecycle.publish(staged);
// On any rejected/rolled-back World transaction:
lifecycle.abort(staged);
// Private accepted-boundary reader; forged DTOs cannot satisfy this lookup:
lifecycle.acceptedBoundary(world, boundary);
lifecycle.acceptedBatch(world, staged); // Null until publish; detached opaque list.
lifecycle.stateFor(world, actualCanonicalProxy);
lifecycle.history(world);
```

Root owns all integration. Create a new helper on each actual `NetworkWorld` registry reset and discard the previous helper. Each helper receives a private monotonically assigned epoch; tokens contain that epoch, the connection label at token allocation (possibly `unbound`) and a private physical serial. Explicit later connection binding does not reconstruct or retoken an existing physical owner. A different connection requires a new registry epoch. Neither a new Host session nor a new helper instance certifies native external-registry history by itself; `externalRegistryHistoryComplete` defaults false and may be true only from the separately established native registry-history boundary.

`externalOwner` is a trusted pre-record fact. It must not come from injected DTO fields, display lifetimes, a raw first snapshot, the numeric ID alone or a generic JavaScript proxy. `absent` permits fresh certification only with complete external history, no canonical proxy, no earlier staged metadata for that ID, and a valid native external-tagged ID. `live` establishes an existing typed physical owner; it never certifies construction. Private previously live metadata may also prove ordinary A reuse while its history remains complete. After D, only a separately justified `retained` fact can prove physical reuse. Without it, A is unknown even if the same JavaScript proxy remains.

All ordered records must pass through `observe`, including irrelevant records, so the index is contiguous and the declared count is checked before commit. Non-creature records allocate no owner metadata or lifecycle event. Area is an explicit allowlisted pre-record value, never reconstructed from the coalesced final row.

Record coverage, external-registry history and per-ID physical-construction certainty are separate. `recordHistoryComplete` also defaults false; Root may certify it only at its actual fully tracked observer boundary. A fully observed generic type5 P/I/U/stat record or unknown-owner A leaves that ID's constructor uncertified. It does not lower the external-registry history of unrelated IDs, disable pause/rate/GUI timing transport, or invalidate another continuously tracked physical owner. A later A for the same uncertain ID stays unknown; a separately never-seen, explicitly absent ID can still certify its fresh constructor under complete history.

An actual decoder-incomplete packet, malformed/untracked transaction, rollback, missing ordered record or actual unsupported external-registry insertion gap remains globally conservative. `history().complete` aliases global record coverage, with `recordReason`; `history().constructionHistoryComplete` is the global external-registry certification flag. Neither false global flag is repaired by a later complete packet. Event/state construction certainty is the narrower per-ID result, combined with those global prerequisites.

A D with complete construction history, explicit external absence and no current/canonical/staged owner is a certified no-op. Its removal fact preserves the numeric raw bit and `ownerAbsentCertified:true`, with null token and no ctor flags. It does not create removed-owner metadata or taint either history. That specific path may move from a null staged proxy to its first actual fresh A proxy in the same packet; a second/different allocated proxy still rejects as an alias. Unknown absence remains conservative and does not receive this certification.

## Proposed Root hook locations (not installed)

In `NetworkWorld.applyObjectUpdates`:

1. Call `begin(staged, ...)` beside the actual transaction-private staged `Map`. Pass actual decoded completeness; do not supply true for direct/imported calls.
2. Observe each record at its actual index. For type5, capture the pre-record canonical/physical proof, obtain the actual staged proxy through the existing `object()` owner, then observe before applying record mutations. The absent-D early-continue needs an observation with both proxies null; otherwise its removal would disappear from the lifecycle record stream. Generic work/inventory/non-creature branches still advance the index before their existing early continues.
3. After existing full validation but **before canonical row assignment**, call `commit` with the expected `old??staged` resolver for touched IDs only. Commit checks actual canonical identity: an existing owner must remain the same old proxy, and a newly installed owner must be the actual staged proxy. It prepares boundaries but installs no private owners/tokens or accepted facts. No registry scan is performed.
4. After successful canonical assignment, call `publish(staged)`. This installs the already validated private metadata without resolving/rereading rows or performing new token arithmetic. `acceptedBoundary`/`acceptedBatch` remain null before this step. Root can keep a private WeakMap from the actual accepted records array to this opaque list; no raw DTO property authorizes it. Deliver in original record order. On rejection before publication call `abort`; no staged clock facts may be delivered.

The helper validates every resolver result before publication. Failed or aborted preparation consumes no physical token, retains prior canonical metadata and taints future coverage/construction history. Publication returns null for stale/untracked requests; Root must not reinterpret that as a successful clock publication. Root must not interleave another transaction/connection mutation between synchronous prepare and publish. JavaScript memory exhaustion is outside this semantic contract.

## Accepted output

`commit` returns a frozen list of empty frozen boundary objects. Only this helper's private WeakMap can resolve them, and only after `publish`. `acceptedBoundary(owner, boundary)` returns a detached record:

```js
{ version: 1, source: 'native_client_clock_lifecycle_v1',
  epoch, connection: safeIntegerOrNull, transaction: positiveSafeInteger,
  complete: boolean, recordHistoryComplete: boolean, recordReason: stringOrNull,
  constructionHistoryComplete: boolean, constructionReason: stringOrNull,
  fact: { operation: 'create' | 'remove', recordIndex, objectId, objectType: 5,
    ownership: 'new' | 'retained' | 'unknown', deletionFlag: 0 | 1 | null,
    areaId: uint32OrNull, physicalToken: opaqueStringOrNull,
    ownerAbsentCertified: boolean,
    constructionCertified: boolean, aiRegistrationCertified: boolean } }
```

The construction and AI booleans are true only on a certified fresh accepted A path. False does not assert absence of existing AI membership. `ownerAbsentCertified` is explicitly Boolean on every event (false on other paths). Removal retains the original numeric wire BOOL bit, not JavaScript truthiness. A/D/A in one packet retains all three independent facts, even though only one final canonical row remains. Each event snapshots that ID's ordered record/construction certainty; later ambiguity never overwrites earlier facts. `[A1,P2,A2,A3]` can therefore produce constructor certainty `[true,false,true]` for the three A events without certifying ID2.

`stateFor` exposes only detached allowlisted scalar metadata. After D, presence is `removed-ambiguous` and `physicalCurrent:false`; an old token may remain as historical identity, never as proof of destruction or current reuse. After ambiguous A, that old token remains noncurrent privately while the new create event reports `physicalToken:null`. There are no invented nativeLifetime/knownLifetime values, dates, previous-time pairs, model/scene data or user labels.

If a later trusted `live` fact proves a current typed owner after its own physical ambiguity or a record-history gap, it receives a distinct opaque handle rather than inheriting the historical token. This does **not** certify construction on that A: constructor/AI flags remain false and construction history stays incomplete. Only an explicit `retained` witness or uninterrupted private live history may reuse a historical physical token. Unknown construction of a different object does not revoke this owner's uninterrupted private continuity. An actual coverage gap makes `stateFor().physicalCurrent` false without scanning weak owners.

The private stores contain weak canonical-proxy metadata, weak transaction state and weak opaque accepted boundaries. A sparse private ID-local negative record also preserves an unknown no-proxy D across packets; otherwise a missing WeakMap key could falsely make its next A fresh. This stores scalar provenance only, adds nothing for certified-absent no-op D, and is removed when the ID binds to an actual canonical proxy or the helper epoch ends. It has no model/row payload, second world copy, capacity guess or per-frame scan. Transaction maps hold touched IDs and ordered scalar facts only, are cleared after publish/abort, and never clone or scan world rows. All negative-record changes use the same prepare/publish/abort boundary. Current/old readers reject another helper epoch's boundaries and proxy clones. The owning integration must use its current helper rather than retain an old reader across a registry reset.

## Focused authored-record gate

```text
node --test --test-timeout=5000 test/native-client-clock-lifecycle.test.js
```

These tests exercise protocol provenance and transaction contracts using authored records and explicit trusted-context fixtures. They do not execute the original game, prove a real server lifecycle, initialize a runtime clock owner, or claim frame-time/native timer equivalence. Root's actual World transaction and ingress integration remains separate.
