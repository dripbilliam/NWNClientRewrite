# Receipt-time stored actor names

The current isolated component gate passes **65 checks**: the previous 43 stored-name checks are unchanged, and 22 new checks cover historical chat capture, snapshot coalescing, pending resource ownership and detached receipts. [The current receipt](reports/native-actor-name-state-v2.json) pins the exact current helper, fixture, TalkText and protocol inputs. [The earlier component document](NATIVE-ACTOR-NAME-STATE.md) remains the historical 43-check scope.

## Integration contract

```gdscript
capture_received(row: Dictionary, metadata_state: Variant, text, current: Dictionary) -> Dictionary
resolve_received(receipt: Dictionary, text, current: Dictionary) -> Dictionary
```

Root's Host event metadata is `nativeTextEvent.actorName={version:1,historyComplete:bool,state:<private state snapshot|null>}`. Root owns that wrapper's validation, private canonical capture and Header/Gameplay hooks. Pass its `state` explicitly to `capture_received`, with the event's certified history in `current.actorNameHistoryComplete` and the authoritative accepted connection/generation/area. Do not substitute a later raw row's name declaration or latest private metadata. The row supplies only the matching creature identity/lifetimes/current-area membership required to bind the receipt. If authoritative scope or source is still unavailable, capture returns unavailable; the Header retains the raw event metadata and retries admission rather than inventing an area or lifetime.

A captured receipt contains version1, source `native_actor_name_received_v1`, captured `historyComplete:true`, exact scope and witness, a detached plain name record, and `result:null` until ready. `resolve_received` returns the same ready/name/slot structure as `name`, or an explicit unavailable/pending result. The only lookup-owner reference is a scalar Text instance ID; there are no live Nodes, Resources, canonical actor references or world copies in the receipt. Once ready, a detached result is frozen and copied on reads.

Current accepted connection, generation and area must still match at every resolve. Captured historical history is independent of a later unrelated live-history taint. Removal or ID reuse in that same scope cannot supply another name, row, CUSTOM map or context. A different scope or a closed name owner rejects the receipt. Pending references must finish on their captured Text owner; already-ready strings need no reader.

## Coalescing and deferred resolution

When metadata, scope and dual lifetime match a current cached publication, capture copies its resolved slots without refetching. When the chat event's private P state is older or newer than the coalesced raw snapshot/cache, capture constructs an isolated record from that exact detached state. It never calls global `observe`, overwrites a global name record, or reads a later actor name to complete the event.

First and last still resolve in order, and a completed first component stays stored while the second waits. Only the captured P parser context, selected direct override states and CUSTOM bytes can participate. Pending nested selections remain subject to the existing snapshot gate. Readiness can supply the actual missing TLK/named-table resource on the same Text owner; it cannot fill missing historical actor/parser context from live rows. Integer scope validation also accepts the equivalent integral numbers produced by actual JSON serialization, then compares normalized exact scope tuples.

The existing global cache/data-publication path remains required. This receipt API closes the chat-versus-200ms-snapshot timing gap; it does not replace state-boundary name caching with a speech-only adapter.

## Current evidence

`.cache/overhead-settings/native-actor-name-state-v7/proof.json` is accepted: 65 checks, 15 immutable source/copy pins, clean engine exit, unchanged six native outputs. The actual JS helper generates the metadata, which crosses JSON into the actual Godot TalkText snapshot fetch/parser with controlled TLK bytes. All accepted-boundary construction facts remain authored fixture inputs, not original constructor/server execution.

v4 preserves a fixture-only static type rejection. v5 preserves an error at the new JSON round-trip assertion; scope normalization was then corrected without weakening scope checks. v6 completed all65 checks with clean engine and three new fixture setup failures: a native direct override correctly bypassed missing files, so the intended wait was already ready, and the detached-value checker omitted StringName scalar keys. v7 uses an actual captured override waiting for named-table readiness, with frozen context/CUSTOM, and retains the original assertions. Prior accepted v2/v3 and all rejected evidence remain untouched.

No shared Gameplay/Header/Host integration, original-server reception, controlled-PC BIC/clone provenance or pixels are accepted here. No server, key/profile read, GPU, native build, OS input or user-process action occurred.
