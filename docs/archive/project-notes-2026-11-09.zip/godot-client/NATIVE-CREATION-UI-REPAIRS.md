# Character-creation presentation repairs

This pass addresses the reported portrait, Attributes, feat-subtype, title and
spell-screen defects. It does not finish the Appearance/character-information
leaves or the complete level-up flow.

| Report | Cause and correction |
| --- | --- |
| Portrait sections remain blank after fast scrollbar jumps | A temporarily full asset queue was recorded as a permanent image failure. `NativeUIArt` now retains a bounded, deduplicated admission backlog only for current bindings, retries admission at completion boundaries and drops obsolete deferred work. Already admitted requests stay coalesced across cell recycling. Actual missing or invalid resources still fail explicitly. |
| Attributes values disappear and names are misplaced | Later opaque row artwork covered the numeric labels. Numbers now draw above the row; names use the original model text hooks. The allocation and ability-rule owners are unchanged. |
| Feat subtype selection has no visible highlight | The logical selection worked, but empty button styles did not distinguish it. The selected text now uses the original list's yellow selection palette, including after a late bitmap-font rebuild. Physical feat IDs and commit logic are unchanged. |
| Some creator titles are outside their frames | Their original binders set claimed-text flag 4. These owners now retain their bounded, centered Title rectangles instead of treating them as floating text anchors. Changes are local to the verified menu layouts, not the general painter. |
| Spell-list headings and remaining count are invisible | Their labels were created below later list artwork. These claimed labels now draw in the foreground without intercepting mouse input. |
| Feat-list headings/count and Familiar Name label are invisible | Actual normal-versus-hidden text raster comparisons confirmed opaque coverage. These labels now draw above the list/edit artwork; popup owners retain their foreground priority. |

## Warlock spell tabs

The two locally cached Arelith manifests inspected here use identical Warlock
gain/known progression resources. Physical class 92 is Warlock; its first-level
spell tables have no capacity, and its casting progression begins at level 2.
The actual native Snapshot/State replay therefore produces ten disabled tabs,
zero remaining choices and `canAccept=true` at level 1. Its ten eligible
level-zero rows are visible but disabled. The original disabled-tab model pose
does not draw a level icon. This is distinct from missing icon resources.

This result is derived from manifest-selected, hash-verified active tables;
there is no hardcoded Warlock exception in production. The exact manifest of
the user's earlier session was not persisted, so this offline comparison does
not establish current-server equivalence. See
`reports/native-cached-warlock-spells-v1-receipt.json` and
`scripts/probe-cached-warlock-spells.mjs` in the workspace root.

## Validation and limits

The portrait suite passes 40 checks, including actual installed portrait
loading after large jumps and revisits. Attributes passes 42 actual-font/input
checks and 2,690 original-rule comparisons. The feat popup passes 42 selection
checks plus its existing 31-check lifecycle/group regression. Their dedicated
documents and immutable checkpoints retain the before-fix failures and exact
test inputs:

- `NATIVE-CREATION-ATTRIBUTES.md`
- `NATIVE-FEAT-POPUP-SELECTION.md`
- `reports/native-portrait-queue-fix-v1.json`

The full spell pane is also tested with real installed bitmap fonts and native
model artwork in a private offscreen, non-activating viewport. The final image
must contain the headings/count pixels, a completed row bitmap and enabled
level icons. This is a drawing-correctness check, not a GPU performance test.

The actual Package, Skills, Feats, School, Spells and Associate control chain
passes a composed 24-check headless test through a parsed BIC submit intent.
Main/Browser/Picker/Creator navigation separately passes 24 checks. These cases
use authored inputs and local installed resources; they do not upload a new
character or prove live-server admission. No user process was restarted and no
shared native output was rebuilt for these repairs.

The root spell/header and preview-equipment changes, their exact accepted
test snapshots and before-change files are preserved in
`../backups/native-creation-ui-repairs-v1.zip`; its readback-verified receipt is
`reports/native-creation-ui-repairs-v1-checkpoint.json`. The final source-title
proof is
`.cache/creation-claimed-titles/native-creation-claimed-titles-nine-after-v1/proof.json`
(99 actual-font/geometry checks). The final spell drawing receipt is
`reports/native-creation-spells-raster-v6-receipt.json` (12 checks, including
actual header/count pixels). Creator control-chain validation is
`reports/native-creation-urgent-ui-binding-v2-receipt.json` (24 checks).
The final Feats/Familiar foreground cases pass 22 actual-raster checks in
`reports/native-creation-feats-foreground-after-v1-receipt.json` and
`reports/native-creation-associate-foreground-after-v1-receipt.json`. The Feats
Available header still truncates within its current claimed width; this is a
separate source-label bounds investigation, not claimed complete visual parity.
After both foreground-label repairs, the composed creator chain was rerun:
`reports/native-creation-urgent-ui-binding-v3-receipt.json` passes all 24 checks
with a clean engine and unchanged tested inputs.

Customize and character information still use the explicit temporary native
Godot fallback. Their original-style source views are being prepared separately
and are not presented as integrated. Full creation and level-up parity remain
open requirements.
