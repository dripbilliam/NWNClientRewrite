# Resume complete client parity — UI first

The 2026-11-03 immediate priority is [complete native level-up UI
parity](NATIVE-LEVEL-UP-PARITY-GOAL.md). Finish its original appearance, complete
actions and authoritative local-server gates while preserving every other
unfinished migration/playability requirement below.

Reaffirmed requirement: character creation and level-up must use the base or
current server's resolved `.2da` data and referenced resources. Pregame artwork
ownership must never replace gameplay rule ownership. Test distinct mounted
server tables/TLK and connection changes; preserve physical IDs and original
server authority. See [native skill allocation](NATIVE-CREATION-SKILLS.md).

Current first-level acceptance is consolidated in
[NATIVE-CREATION.md](NATIVE-CREATION.md): native Customize is integrated,
installed/cached custom-class control/BIC paths pass, and Fighter/Wizard have
scoped original-local-server create/reconnect evidence. Earlier unfinished
creator descriptions below are historical only within those superseded scopes.
Level-up's [private class publication](NATIVE-LEVEL-UP-CLASS-PUBLICATION.md)
passes its input/lifecycle gates, while Recommended actions, broader class/server
coverage, intermittent connection/loading reliability, original pixels and all
remaining UI/HUD/gameplay requirements stay active.

The [quickbar-context milestone](NATIVE-QUICKBAR-CONTEXT.md) now has scoped native
input, original protocol-cache comparisons and58 owned original-server checks,
including actual closed-inventory item results and canonical macro persistence.
Complete context/role menus, all bound types, original pixels and all remaining
UI-first creation/level-up/HUD work remain required before general migration.

The [nameplate text-fitting milestone](NATIVE-NAMEPLATE-TEXT.md) passes2119
original width/wrap/bubble-policy and actual-control checks, plus573 real
installed-font/shared-mesh/HUD input checks. Original font raster metrics,
pixels and full HUD acceptance remain open; all outstanding UI-first work and
later client-parity priorities are unchanged.

The latest [source Skills milestone](NATIVE-CREATION-SKILLS.md) binds original
models/input to the actual draft and passes scoped original-server rank export.
The complete UI-first objective is unchanged: finish CG_FEATS and the remaining
configuration/creation chain, safe saving and original visual/input acceptance,
then all other outstanding menus/HUD before general migration resumes.

Requested by the user on 2026-10-31 after the live lighting comparison.
Status: **active UI-first goal**, created successfully on2026-11-01 after the
goal service reported no existing goal. Earlier activation attempts were rejected
by an unfinished lighting objective; that service state is no longer current.
The user has now deferred lighting in favor of UI/HUD/nameplates. Preserve its
unfinished requirements/evidence without calling lighting universally complete.

The first scoped UI correction is documented in `NATIVE-MENU-EXIT-LIFECYCLE.md`;
the subsequent settings-to-renderer audit is in `NATIVE-GAMMA-SETTINGS.md`. The
current [native nameplate milestone](NATIVE-WORLD-NAMEPLATES.md) connects creature
portraits/names/injury and hover/Tab behavior to the native live HUD with67 scoped
release-headless checks. Original-client visual acceptance and remaining HUD/UI
surfaces stay open.

The later [highlight-key/instant-tooltip correction](NATIVE-HIGHLIGHT-TOOLTIPS.md)
connects active keymap action97 to world highlighting and shared GUI hints, with
the source double-tap latch and persistent threshold. Original execution,
actual native headless input and scoped original-server checks are recorded
there; this does not complete any full HUD/menu/graphical acceptance gate.

The [HUD tooltip/queue follow-up](NATIVE-HUD-TOOLTIPS.md) now adds borrowed native
hint ownership, safe control handoff and original-server mouse cancellation/
effect expiry. The178-check owned local receipt is scoped acceptance; complete
HUD/menu, creation/CG_MAIN, original input/graphics and all later priorities
remain part of this active objective.

Later source-backed [creature overrides](NATIVE-NAMEPLATE-OVERRIDES.md) and
[world object captions](NATIVE-OBJECT-CAPTIONS.md) now have573 strict native
editor/release checks and108 actual local-server HUD/player/chat checks,
including original meshes/anchors, real hover, received custom captions and
hide/clear restoration. Inventory24/5, full font/display/pixels and all remaining
HUD/menu acceptance stay open; the whole objective is unchanged.

The current [party indicators](NATIVE-PARTY-INDICATORS.md) and
[direction locator](NATIVE-PARTY-LOCATOR.md) connect the original member-state/
leader artwork and camera-relative source arrow to native received state.
Scoped headless source/input/lifecycle receipts pass; original pixel and local
server acceptance remain open, along with the rest of the HUD/menu inventory.

The [action queue](NATIVE-ACTION-QUEUE.md) now derives40px slots and icon placement
from original models, preserves widgets through received changes and guards
cancel/removal ownership. Scoped native input tests pass; original pixels,
authoritative local queue use and remaining HUD surfaces stay open.

The [effect/status bar](NATIVE-EFFECT-BAR.md) now connects original layout,
flashing, raw addition order, effect GUI-event clicks and controlled portrait
poison/disease states. Native source/input/worker and protocol checks pass;
graphical review and authoritative local script outcomes remain open.

The [native chat HUD and adjustable settings](NATIVE-CHAT-HUD.md) now use source
pane/prompt/mode resources with real input, persistence and reconnect tests.
The latest user request adds resizable/movable chat and common MMO preferences;
these stay native and available through Client Options → Interface. Complete
portrait tooltips, command/history behavior, pixels and authoritative local chat
acceptance remain open. [Original category filtering and the context radial](NATIVE-CHAT-CATEGORIES.md)
now have a separate native input/history milestone, including immediate canvas
retirement on world hiding. The [portrait/account reply follow-up](NATIVE-CHAT-REPLIES.md)
adds source UVs/hover, GUI27, `/tp` and the corrected player-list Tell path.
The [tooltip/transition follow-up](NATIVE-CHAT-TOOLTIPS.md) adds retained member
details and verifies chat through actual area changes. Tooltip pixels/timing,
commands/history, disconnect/server retention and graphical/local acceptance
remain open. Continue the full
HUD/menu work; lighting stays deferred and GPU tests stay off for the other game.
The [chat dispatch/transport follow-up](NATIVE-CHAT-DISPATCH.md) corrects original
name/object-ID mappings and a host branch that discarded resolved Tell IDs.
Executed original comparisons and actual native input-to-packet checks pass;
console/global history, original pixels and authoritative chat remain open.

Resume the full native Godot migration and original-client parity work in the
order below. Preserve the existing UI, base-gameplay, migration, performance and
unfinished lighting requirements; this document does not narrow their scope.

Current steering: start with HUD/nameplates. The user has a heavier game running. Optimization is useful
but not the priority; suspend GPU benchmarks and resume UI/feature work and
read-only/native headless checks that do not compete for the GPU. Recent
performance receipts are exploratory under that contention, not acceptance.

## 1. Complete original-style UI and action parity

Start with `NATIVE-UI-PARITY-GOAL.md`, `NATIVE-UI-RESOURCE-INVENTORY.md` and
`NATIVE-UI-FRAMEWORK.md`. Enumerate each surface, original resource/function,
control, state, input and actual server action/outcome. Complete replicated
original screens in both appearance and behavior; unique client screens must
follow the original game's style. Keep the reusable native UI framework.

Cover character sheets, spellbooks/preparation/families, inventory/equipment and
containers, stores/barter/acceptance states, quickbars/rebinding, nested radial
menus and item actions, party/player controls, examination, dialogue, map,
journal, connection/character selection/creation/customization, settings and
server NUI. Audit disabled/selected/pending/error states, cancellation, keyboard,
mouse, scrolling, drag/drop, scaling/fullscreen, focus, front ordering and sound.
Remove remaining placeholders. Original art must preserve its intended aspect
ratio and sampling. Verify all available actions reach the original server and
display its confirmed result; a correctly drawn button is insufficient.

Preserve simultaneous movable windows, saved positions, WASD and middle-mouse
camera control with windows open, and click movement outside menus. Use active
server-selected tables/text/content rather than hardcoded vanilla rules. UI
parity requires complete surface/control coverage and original-client comparison;
widget counts or isolated passing tests do not establish completion. General
feature porting follows this UI audit.

## 2. Finish combat, casting and animation behavior

Use `BASE-GAMEPLAY-GOAL.md`, `NATIVE-COMBAT.md`, `NATIVE-CAST-VISUALS.md` and
their current follow-ups. Complete facing, gait/blending, action/event timing,
multi-attacks, shapes, reactions, death/recovery, specialized projectiles,
weapon/shield/impact effects and combat/voice/footstep audio. Verify prolonged
fights, latency, model replacement, transitions and custom server content.
Original servers decide rules, damage, uses, inventory and outcomes.

## 3. Finish connection and travel reliability

Cover canceled joins, disconnect/reconnect, clean exits, portals and zone edges,
cross-server handoffs, resource/vault changes, pending work and failure recovery.
Investigate `native-lighting-live-full-scene-v1`: recording sealed, final protocol
acknowledgment arrived and workers reached zero, but exiting after returning to
menu produced native exit1 without a native failure field. Distinguish status
classification defects from actual transport, rendering or lifetime failures.
Prove repeated mixed-client behavior on unchanged original local servers.

## 4. Improve loading, effects and frame consistency

Use authoritative local-server scenarios and sealed recordings, including the
new `capture-C3eAC7` (3,719 events; one complete catalog; timeline SHA-256
`95dd834af211b59361f1602b88056ee403f46f7569e46ca8ff61103c358942a3`).
Retain original assets and intended effects. Target sustained smooth gameplay
at least60 FPS in representative dense moving scenes, with effects enabled,
while reducing first-load, first-effect, publication and retirement hitches.
Measure CPU/GPU distributions, resource readiness, memory and cleanup; sparse
or background scenes and isolated kernels are not acceptance.

Investigate the live light-history overhead and the30 emitters unable to find
`fxpa_cloud02`. Compare original resource selection/fallback before changing it;
do not guess replacement assets or silently drop intended visuals. Complete
specialized emitters, ordering/transparency, weather and remaining audio gaps.

## 5. Preserve unfinished lighting requirements

Carry forward `NATIVE-LIGHTING-CORRECTION.md` and its full acceptance scope.
The user reported the tested live room's lighting looked similar/good. This is
not universal material/shadow/vision or clean performance acceptance. Preserve
original-compatible area/time, material, finite/infinite/attached/effect lighting,
admission/fades, vision/darkness, fog and output behavior, generic overrides and
streaming/lifetime requirements. Keep the full-scene candidate opt-in and its
tested rollback until promotion is reviewed. Do not boost global brightness or
remove lights/effects to conceal an unresolved defect.

## 6. Complete native ownership, then offline campaigns

After multiplayer presentation/behavior acceptance, replace remaining Node/
Electron authentication, encrypted UDP/protocol/replication, downloads and
Windows-protected credential/settings services with native Godot/C++ ownership.
Rendering and model preparation stay native throughout; JS is existing
transitional services or reference only. Then complete offline campaign rules,
scripts/VM/scheduling, simulation and save/load. Complete the requested reference
wiki for the project's Markdown documentation after migration.

## Acceptance and preserved constraints

Original binary behavior and interoperability with unmodified clients on
unchanged servers are top requirements. Use current source and original binary/
Ghidra evidence, meaningful CPU/GPU/input/lifetime tests, authoritative local
scenarios, paired original/replacement clients and explicitly authorized real
server acceptance. Record remaining limitations and failed receipts honestly.

Autonomous tests use localhost and sealed offline captures. Do not automatically
join Arelith/public servers or send public chat without fresh explicit authority.
Preserve user sessions; avoid competing GPU benchmarks while another game runs.
Launch on a secondary monitor without stealing focus or capturing/warping the
mouse. Protect private CD keys and keep them out of logs/checkpoints. Back up
substantial changes and ask before promoting drastic foundational/rendering
changes as the default. No feature may be declared complete without evidence at
its required scope. No token budget was requested.
