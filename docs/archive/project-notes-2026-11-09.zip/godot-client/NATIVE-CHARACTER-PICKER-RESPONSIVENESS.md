# Native character-picker responsiveness

The original-style Godot picker now prepares the selected character's numeric
record, Skills and Spells projections on a native worker. It uses the currently
bound server tables and existing typed BIC extraction; no JavaScript rendering,
new world store, gameplay calculation, UI style replacement or server command
was introduced.

## Measured cause

The authorized pregame-only capture on `game.nwnarelith.com:5124` used the saved
protected Main profile without changing its active selection or saved settings.
The server returned nine characters. Six preview requests for three characters
completed in **136.6–138.6 ms**, including storage of the exact received BIC bytes.
The diagnostic disconnected and exited; it did not enter the world, create a
character, send chat, launch a visible window or retain a key lease.

Replaying those three records and exact resolved server 2DAs through the actual
original-style native picker exposed **75.6–83.6 ms** blocked inside each
`apply_state`, including warm switches. Even unchanged `sync` calls cost
**8.4–9.9 ms**. These are CPU timings, not FPS or GPU measurements.

Most selection work was repeated ruleset lookup: every ability modifier/spell
minimum compiled a regex and scanned the full ruleset table. Record, Skills and
Spells repeated those lookups independently. The source-faithful projections
alone consumed approximately **70–72 ms** for the captured server records.
Whole-preview JSON signature generation was only **0.12–0.15 ms**, so it was
not the main selection bottleneck. Hidden Server/Players pages also serialized
full class/portrait tables on every character-page synchronization.

Read-only REA inspection of original `nwmain.exe`, SHA256
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`, confirms:

- `CNWRules::LoadRulesetInfo` (`1402ac0c0`) builds an unordered cache once, parses
  integer values with `atoi`, and overwrites duplicate entries.
- `CNWRules::GetRulesetIntEntry` (`1402a4130`) performs a cached lookup and returns
  the supplied default on absence; it does not scan the source 2DA per query.
- Character row construction (`14070cd20`) reads already loaded class data;
  `CNWClass::GetNameText` (`140299c30`) fetches its stored TLK reference.

The retained dossiers are in
`reports/native-picker-original-cache-research-v1.json`. These observations do
not establish complete original-client timing or all resource-cache parity.

## Implementation and lifecycle

`native_data/character_picker_work.gd` owns one running task and one latest
replaceable pending selection. Its identity includes the connection, data-bind
generation, selected character, source input and text/table publication revision.
Sources and required table rows are detached before work begins. Only tables
needed by the selected classes are copied, once per active publication revision;
the complete gameplay table set is not copied per frame or per character switch.
Physical row order and dynamically named class tables are preserved.

The worker builds an integer ruleset lookup for its detached projection only.
`character_record_values.gd` has an explicit opt-in fast path; ordinary callers
retain the existing fallback. Exact-case labels, nonempty last duplicates,
signed wrapping, `atoi`-prefix behavior, default values and invalid-divisor
unknown results remain unchanged.

Superseded tasks finish privately and cannot publish old details. Removal of
preview input clears projected fields. A new connection, resource bind or
publication revision invalidates retained snapshots. The chooser verifies its
current owner again before accepting a completed result, including cancellation
while its panel is hidden. Missing dependency tables remain pending and are
requested through the existing native asset owner. Original selection nonces,
acknowledgments, double-click/Play and Cancel commands are unchanged.

Server/Players page formatting is deferred until that page is shown. Visible
Players updates still follow received rows and text/table publication revisions,
including replacement class labels and removals. Hidden updates are reflected
when the page is next opened.

## Current results and validation

With the same captured records and tables, the source-equivalence run measured:

| CPU work | Before | After |
| --- | ---: | ---: |
| Warm selection `apply_state` | 75.6–83.6 ms | 0.61–1.25 ms |
| Unchanged chooser `sync` | 8.4–9.9 ms | 0.32–0.43 ms |
| First cold selection `apply_state` | 82.9 ms | 20.08 ms |

Worker computation took **3.3–6.3 ms**. The three detail projections became ready
roughly **13–20 ms** after dispatch in this headless test's frame schedule. The
first cold copy still costs about 19 ms; the worker no longer blocks every
subsequent character switch. This does not claim zero startup cost.

The final sealed run (`native-picker-selection-final-v1`) measured **21.048 ms
for the whole first `apply_state`**, of which **17.34 ms was the detached table
snapshot**. Its warm switches were **0.58–0.909 ms** and repeat synchronization
was **0.278–0.360 ms**. Snapshot time and whole-call time are distinct measurements;
the small variation from the preceding run is retained rather than rounded into
one claim. The final four-test receipt covers **1,416 checks** with unchanged
sources and clean engine logs.

Retained checks include:

- `native-picker-work-v3`: **1,343 checks**, including all **1,295** unchanged
  original modifier-oracle cases, rapid selection coalescing, stale results,
  reconnect/data-generation changes, source/table mutation isolation, publication
  invalidation, missing preview and worker retirement.
- `native-picker-selection-equivalence-v1`: all three worker projections exactly
  equal the previous source-faithful fallback for **12 selections / 36 projection
  comparisons**, using captured server records and tables.
- `native-picker-automatic-regression-v1`: **18 checks** for automatic first-row
  selection, deferred/hidden catalogs, acknowledgments, replacement connections,
  empty rosters and safe retirement.
- `native-picker-interaction-v2`: **19 actual headless GUI-input checks** covering
  row selection, exact acknowledgments, Play, Cancel, original Server/Players tabs,
  hidden-page deferral and active class/removal updates.

These runs had no engine/lifetime diagnostics. The coordinated first suite's
source hashes were unchanged; its `success:false` receipt is deliberately kept
because the first interaction test had a test-only type-inference parse error.
That failed log and corrected later receipt remain separate.

The pregame transport capture, active-data replay and headless GUI actions are
distinct evidence. No running user client was replaced and no live graphical
picker validation, world entry, FPS acceptance or full UI/multiplayer completion
is claimed. Cold original artwork preparation, large custom rosters and all
other menus remain separate performance/coverage work.

## Complete spell-column snapshot follow-up

The sealed spells-only snapshot projection is now imported by
`native_data/character_picker_work.gd`. It retains all physical spell rows and
all active-class spell columns, including future book entries. The historical
staged proof is `reports/native-picker-switch-staged-v1.json`; it covers
26,643 policy, worker and actual source-input checks. The integrated worker
lifecycle regression passes48 clean checks with19 unchanged inputs:
`.cache/picker-work-integrated/native-picker-work-integrated-v1/proof.json`.
Historical copied-source cold callback measurements improved from35.568ms to
13.934–17.884ms, with warm callbacks0.788–1.297ms. These are CPU phase
observations, not a fresh live-server or FPS measurement.

## Reproduction and rollback

`tools/profile-native-picker-pregame.cjs` is an explicit, hidden, pregame-only
diagnostic using an existing Windows-protected profile. Its output contains
received character bytes and resolved table fixtures, never plaintext keys.
Do not use it as a general gameplay launcher or broaden its admission scope.

`tests/native_picker_cpu_profile.gd` separates parse/source/projection costs.
`tests/native_picker_selection_profile.gd` drives the actual native picker with
an offline capture; `--verify=true` compares every output with the fallback.
`tests/native_picker_work_test.gd` and `native_picker_interaction_test.gd` provide
focused lifecycle/rules/input coverage. These tools do not rebuild native DLLs.

The four dirty source inputs were copied and SHA256-verified before modification
in `backups/native-picker-responsiveness-before-v1/`. That checkpoint preserves
pre-existing uncommitted work, including the earlier native-summary changes.
Restore only this feature's changes deliberately; do not overwrite unrelated
later edits from another agent.
