# Active first-level Feats binding

The staged original-style creation flow now transfers Skills into `CG_FEATS`
and binds its real controls to the current character draft. This does **not**
replace the shipping fifteen-page creator or complete the original creation
chain. The [class-dependent coordinator and School child](NATIVE-CREATION-SCHOOL.md)
are now bound separately. [Domain controls](NATIVE-CREATION-DOMAINS.md) have a
further source-input/draft milestone. Spells/Associate source controls, the level-up
adapter, original pixels and authoritative character-upload acceptance remain open.

## Owners and rules

`systems/native_data/creation_feat_tables.gd` decodes physical active feat rows
using the constructor and loader semantics retained in
`reports/native-creation-feat-table-binding-original-v1.json` and
`native-creation-feats-research-v2.json`. Conditional failed reads preserve the
constructor sentinel; unconditional reads consume the actual failed-lookup
output. A missing column with DEFAULT is distinct from an explicit empty cell.
Column lookup uses the first case-insensitive physical header, not whichever
duplicate spelling happens to win a dictionary lookup. Invalid physical rows,
BYTE/WORD wrapping, signed conversion, master groups and action defaults remain
distinct. Malformed hexadecimal conversion or undefined native class-table
storage stays explicitly unavailable rather than inventing a rule.

`creation_feat_snapshot.gd` reads the existing connection-owned creation rules
and draft. It supplies the verified choice/prerequisite cores with current class
grants, primary granted ownership, effective ability scores, signed raw skill
ranks, original class/skill usability, BAB and first-level Fort cache. The latter
starts from native base0 plus Constitution; it does not import the class saving
throw table. Positive spell prerequisites compose the existing original-backed
memorizing getter and non-memorizing capacity core. An error0 is not published
as a known capacity0.

`creation_feat_state.gd` owns only the temporary selectable physical IDs and
detached chooser models. It handles add/remove, prerequisite-removal cascades,
Reset, ordered package FeatPref2DA recommendations, name grouping and original
normal/bonus reservation rules. Granted rows remain disabled. Missing data is
pending. This is a first-level draft adapter, not received in-world statistics
or a new world store.

Active resource publication must replace its immutable table object. The draft
owner, relevant table identities, class/race metadata, raw abilities, ranks,
domains, school, selected IDs and text revision scope cached projections. No
whole-world or per-frame scan is added. Callers receive detached models;
mutating one cannot alter the cached model. In-place mutation of published
resource rows is outside that publication contract.

## Coordinator behavior

`native_creation_frontend.gd` now owns the source Feats child, including family
and information popups. Its draft owner is `native_creation.gd`:

- Skills OK prepares a fresh temporary Feats owner and transfers the existing
  Package callback without marking Package complete.
- Source arrow clicks change temporary choices. OK commits the visible known
  physical IDs to the draft and returns the original800e continuation. Original
  panel deactivation delivers that parent callback even when transferring to
  a later class-dependent child, so Package may be complete behind School.
- Cancel returns3 and resets derived choices through the existing draft owner.
- Recommended loads the selected package's active preference table. Pending
  work checks connection/draft identity, request serial, child ticket and text
  revision before writing. Replacement text or a retired child rejects its
  late result.
- `sourceFeatChoices` selects the native choice validator at final validation;
  the old generic first-saving-throw requirement path is not used for this
  source-created selection. Reset removes that provenance marker.

The transferred next stage now enters original9c69a0's data-driven coordinator.
School and Domain have bound source views; unported Spell/Associate children remain
explicit requests and missing metadata remains pending. This replaces the earlier
conservative `package-post-skills` hold. SchoolCancel3 reverses Package progress;
later800f/8010 callbacks do not fabricate800e completion. Automatic package
recommendations and the older generic creator remain separate migration work.

## Evidence and responsiveness

`reports/native-creation-feat-adapter-v6-receipt.json` passes515 checks, including
480 immutable complete original CanChooseFeat cases composed through raw active
feat rows. It covers custom rule changes, grant levels, skill/Fort/epic/spell
prerequisites, dependencies, grouping, recommendation, reset, mutation isolation
and publication invalidation.

The1024-definition CPU fixture built its static and model projections once.
Cold model construction measured197.357ms. Twenty-four unchanged reads had
p95 0.066ms and maximum0.113ms. The earlier uncached model measured p95 26.493ms.
These are headless CPU model measurements, not live rendering/FPS, changed-choice
latency at that size, or the entire initial creator resource load.

`reports/native-creation-feat-binding-v6-receipt.json` passes17 actual creator/
frontend/source-control checks with original GUI resources and headless artwork
doubles: physical add/dependent/OK/Cancel, real draft commits and callback
handoffs, pending recommendation retirement, held input and stale draft guards.
Engine/lifetime logs are clean, exit0 and all347 static inputs remained unchanged.
Its approximately150ms click samples include deliberately awaited test frames;
they must not be presented as synchronous handler timings.
The nested result scope is authoritative: the binding runner initially copied
an overly broad outer scope string from the adapter runner. Its retained
correction is `reports/native-creation-feat-binding-scope-clarification-v1.json`;
the480 original comparisons belong to the515-check adapter case, not the17
physical binding checks.

The earlier rejected copies/logs remain in `.cache/feat-adapter-tests` and
`.cache/feat-binding-tests`. In particular, the real Gameplay.configure test
caught premature chat-wheel binding before asynchronous chat assembly. The
owning agent fixed that boundary and separately verified it; assertion-only
receipts with engine errors were not accepted.

Run the focused checks without a server or visible client:

```powershell
./godot-client/tests/run-native-creation-feat-adapter-tests.ps1 -Name unique-adapter-receipt
./godot-client/tests/run-native-creation-feat-binding-tests.ps1 -Name unique-binding-receipt
```

The runners use the existing pinned Godot runtime, isolated copied projects,
finite owned-process deadlines and unchanged-input checks. They build no shared
native library and make no server connection. Normal Windows certificate-store
access is required for a clean engine log.

The accepted checkpoint is `backups/native-creation-feat-adapter-v1.zip`,
SHA256 `d7a6a3056588e61167d5d00a2c18934ddfb3b401d424b875265ad7a765e29959`
(371 entries,1,134,144 bytes; every entry verified). It contains the exact
accepted copied closure and dirty before-files. Later optional modal hooks are
separate work; this archive is not a blanket claim about subsequent shared edits.

Remaining gates include full original table-loader execution coverage for
malformed input, exact CRT qsort order for equal keys, all installed/server rule
variants, graphical comparison, remaining class-dependent source children, complete original
source-creator saving/admission and the separate level-up adapter.
