# Original Alignment chooser and active class restrictions

2026-11-01. CG_ALIGNMENT now commits through the real native draft and scoped
CG_MAIN coordinator. Creation remains staged until the other source children,
save/customization lifecycle and visual acceptance are finished. This does not
claim the entire source creator or level-up UI is ready.

## Source behavior and data ownership

`native_alignment_chooser.gd` uses the original frame, twelve buttons, title,
radio models, authored placement, caption fonts and animated scrollbar through
the shared native source-modal/painter framework. `native_source_help.gd` now
shares the original readonly help region with Race and Class; it retains their
source bounds, selection descriptions and scoped input retirement. No JS menu
or rendering service is introduced. The protocol host change only compares
alignment fields from the original server's exported character.

Pregame GUI/model/font resources remain independently owned. The active draft's
classes.2da supplies AlignRestrict, AlignRstrctType and InvertRestrict; its
CHARGEN_ENABLE_RECOMMENDED_BUTTON ruleset value and active text provider apply.
There is no embedded stock class-availability list. The nine alignment categories
and fixed source help references are original engine/UI definitions, not a
replacement for server class restrictions. Base tables apply when no active
server override replaces them. Catalog/TLK, class, draft and connection changes
retire held input/results rather than accepting an earlier screen's choice.

`native_data/alignment_rules.gd` ports CNWClass::GetIsAlignmentAllowed with
BYTE mask/axis fields, independent good/law matches and boolean inversion.
`creation_alignment_state.gd` keeps the original tab order:
LG,LN,LE,NG,TN,NE,CG,CN,CE. Initial signed-WORD axis values classify at30/31 and
69/70; selected help follows that current alignment. Title help restores260/458
without changing selection. Clicking another permitted radio previews only;
Cancel/Escape returns2 without a draft write. OK writes canonical85/50/15 axes,
returns8001 and enables the parent's Abilities step. If Package was already
enabled, the parent clears derived skills/feats/spells/domains and invalidates
later completion, even for the same accepted alignment.

The original Recommended callback uses a class-specific physical-ID default;
custom classes outside0–10 default to LG. It does not search for a permitted
alignment. Programmatic selection can check a disabled radio, and source OK
still accepts that selection. The port preserves that behavior rather than
silently choosing another alignment. Direct clicks on disabled radios are
blocked; final active-table validation still rejects an illegal completed draft,
and the original server decides admission. This original quirk is not proof of
complete final writer/validation parity.

## Evidence and checks

Pinned nwmain.exe SHA256:
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.
The [REA dossiers](reports/native-creation-alignment-research-v1.json) retain
GetIsAlignmentAllowed299900, bind8eade0, recommendation8e5e20, selection8e1310,
OK8e3560, Cancel8e1040, title8e2b20 and constructor8db960. Vtable140e64018
slot140 resolves Escape8e32c0. The two computed OK jump tables are incompletely
recovered in decompiler pseudocode; the unchanged original instructions for
both axis writes execute in the separate CPU oracle.

CG_ALIGNMENT resource SHA256:
`8d6863d2b4e22c790695fe9b3ded7555e6b8522a7b6e25ce1d1aa6237242a4ad`.
Original help table1412985d0 supplies the general pair260/458 and all nine
selection pairs, recorded in the dossier and production state.

`scripts/inspect-native-creation-alignment.py` executes2,304 original class
restriction combinations and180 original bind/title/selection/recommendation/
OK/Cancel sequences. Original SelectTab/SetChecked also execute. Layout import,
text/color/update delivery, enabled-state delivery, tab insertion, ruleset/object
lookup and modal lifetime are explicit providers; raw class/stat fixtures are
not a catalog loader, pixels or full creator oracle. Corpus:
`../backups/animations/native-creation-alignment-observations-v1.json`, SHA256
`12f5b05687adb787ef7c6e591b4b18d99699300edc546159b5e1675a7be04355`.

- `native-creation-alignment-binding-v2` and
  `native-creation-alignment-release-v1` each pass3,231 headless checks against
  the original corpus and actual source controls: mouse, title help, disabled
  selection/recommendation, Cancel/Escape, live draft commits, conditional
  reset, scaled pointer input, table/text replacement and stale/reentrant
  retirement. Artwork and fonts are nonrendering doubles for these checks.
- `native-creation-alignment-class-regression-v1` passes1,108 and
  `native-creation-alignment-race-regression-v1` passes1,131 original-corpus and
  actual input checks after sharing their help component.
- `native-creation-alignment-overrides-v1` passes23 checks using actual authored
  server2DA/custom-TLK files mounted above the original install. A custom class
  at physical0 permits only LG through its active restriction columns; the
  source UI disables every other button, retains the native disabled-CN
  recommendation, then commits the explicit LG choice. Custom class gains,
  spells/feats/packages and replacement-catalog checks also pass.
- `native-creation-alignment-local-v1` passes29 creation checks on the preserved
  original Prelude server127.0.0.1:5121. Source Gender/Race/Subrace/Class and
  Alignment controls edit one real native draft. Remaining prototype pages
  finish the character. The original server admits/exports Wizard10 level1 and
  selected Neutral Good axes85/50; alignment, race/identity and all28 skill
  ranks match. Existing class/school/feat/spell checks pass. Native and
  authoritative movement are1.500033m. Native exit0, no exception, unchanged
  source, acknowledged clean shutdown, zero workers/public connections.

Retained failed checks: initial CPU attempts omitted the final instructions of
title/selection/recommendation from manually entered allowed ranges. The ranges
were corrected to the provider's complete inclusive bounds before any corpus
was written. Binding-v1 failed on two test-local inferred types; v2 adds explicit
integer annotations. No failed receipt was erased or counted as accepted.

## Remaining work

The original-style creator is still staged. [Abilities/Attributes now has a
scoped checkpoint](NATIVE-CREATION-ATTRIBUTES.md), including allocation costs,
limits and the Class remaining-point cache for custom racial/class gains.
Package and the remaining children are next. Exact
original-client pixels, radio poses, sounds, all inherited key routes, wider
role/content variants, level-up routes and preservation-safe existing-BIC save
remain unaccepted. The complete UI and client goal remains active.

Before-change checkpoint: `backups/native-creation-alignment-before-v1.zip`,
SHA256 `b04d2a81dbf46e7cde7c754972365956c7b16896f70654cd9605bf293b1659f9`.
No public join, visible/GPU benchmark or user/editor restart was performed.

Verified final checkpoint: `backups/native-creation-alignment-bound-v1.zip`,
2,411 files, SHA256
`8c2f8be3d09a7c6b399220acb29c72dff793c19b9bc23fd2904325ed5f14ab46`.
The [acceptance receipt](reports/native-creation-alignment-bound-v1.acceptance.json)
checks current production hashes against all five headless receipts, verifies
the backup digest and records authoritative exported axes and clean retirement.
Graphical, level-up and full-goal acceptance explicitly remain false.
