# First-level source creation flow

This work uses the current connection's physical 2DA rows, TLK and catalog.
First-level source callbacks stay separate from received level-up state and
from the older generic wizard. It does not establish full visual or server
admission parity by running authored rules in a headless fixture.

## Current repairs

`native_creation_frontend.gd` now accepts `set_phase(phase, status)` and emits
`status_dismissed(status, scope)`. The creator owns the status and authoritative
phase. Its source Main retains its choices after rejection. Preparing disables
all actions except Cancel; waiting disables Cancel as well. The new embedded
notice reuses installed `okscrollpanel` art, fonts and scroll attachments within
the existing summary footprint. It does not register another modal above Cancel.
Acknowledgements carry draft/generation/status identity, and repeated renders
do not reticket a held OK press. The source Main's editing Escape remains the
original no-op; preparing Escape follows cancellation and waiting Escape cannot
cancel an uploaded submission.

Accepted proof: `.cache/creation-phase/native-creation-phase-v3/proof.json`,
27 actual installed-control pointer/keyboard checks, clean engine, 203 unchanged
inputs. Non-rendering art/font doubles; no raster or server admission claim.
Earlier fixture-inference and malformed-helper parser rejections are retained.
The original Main controls themselves were not restyled.

`creation_spells_snapshot.gd` no longer rejects every memorizing class which
cannot learn scrolls. Original `9ce190` assigns the shared remaining counter
inside each enabled, minimum-eligible non-scroll level. This includes a full
book whose remaining count is zero. The constructor `9c3250` does not initialize
the prior counter when no such level is visited, so that narrower case remains
explicitly unavailable. Missing known-table dependencies are now reported before
the counter gate. MemorizesSpells and LearnScroll remain separate flags.

Accepted proof: `.cache/creation-class-flow/native-mem-no-scroll-after-v1/proof.json`,
13 checks/47 unchanged inputs, clean engine. The preserved before fixture has
six checks and three functional failures, with a clean engine. This is an active
adapter/private-state proof; actual source controls/BIC for the new combination
are still to be composed. Prior cached Warlock data with zero known capacity
remains a valid non-memorizing empty selection, not an invented higher level.

`native_creation_package_name.gd` uses the existing asynchronous native familiar
LTR/NameFilter service. Original package OK `8e4620` calls GetRandomName with
source `0xfe`, writes the proper familiar/companion name and selected type, then
returns `8008`. The source package callback now waits for that real name before
applying its automatic package. Configure does not run automatic name generation.
Identity, ticket, request, class/package rows, catalog/layers and TLK revision are
revalidated after awaits. No default name is substituted for a missing resource.

The Package's existing help scroll presents preparation progress or a failure.
Cancel/Escape stays available while other Package controls are busy. Cancellation
retires the request and restores editing before the frontend accepts result 3.
Automatic naming has its own small owner; the manual Associate chooser's request
and preview owners are unchanged.

Accepted first proof: `.cache/creation-class-flow/native-package-name-after-v1/proof.json`,
15 installed-control checks/436 unchanged inputs, clean engine. Recommended
familiar/companion naming uses an actual worker, Configure reaches native Skills,
and pending data preparation can be cancelled. Clean before-v2 has 14 checks and
five functional failures. Expanded after-v2 reached 28 checks, clean engine, with
one retained compound assertion rejected: it assumed a previously completed
Package flag becomes false upon reopening. Source Main retains that prior flag
behind its child. Final `native-package-name-after-v3/proof.json` passes 29 checks
with 437 unchanged inputs, comparing the captured parent completion state and
independently requiring the stale name sentinel unchanged, current Package open
and editing phase. Actual name-await Escape, real missing-LTR visible failure,
catalog correction/reopen and late text retirement are accepted in that scope.

## Original class initialization and private publication

The ordinary installed Fighter exposed a wider blocker: its optional class cells
are `****`, because the original `LoadClassInfo` calls
`InitLegacyClassDefaults(physical BYTE class ID)` **before** conditional active
column writes. Using the failed cells alone left the source post-Skills/Feats
coordinator waiting for PickDomains forever. Constructor-only defaults were not
enough to explain this sequence.

`creation_class_metadata.gd` now compiles that initialized class record, then
applies successful active overrides. `reports/native-legacy-class-defaults-original-v1.json`
contains 512 executions of the unchanged complete original function `2a4350`:
all 256 class IDs, each over two different nonzero dirty heap fills. Allocation,
free and CExoString storage are explicit captured boundaries; numeric branches,
widths and float writes execute original bytes. This is the compatibility
fallback actually used by the native loader, rather than a substitute class list.
Active custom metadata always wins. Arcane, like the other native boolean fields,
normalizes nonzero INT values to one; downstream policy tests over arbitrary raw
values remain separate.

The compiler retains physical row IDs, label/header order/case and the first
case-insensitive physical column. Private row aliases also expose that first
resolved value to generic exact-key getters; later physical duplicate cells stay
raw. Malformed native hex writes remain unresolved, not silently zero/default.
Unknown floating conversions remain explicit. The raw input table is untouched.

`NativeCreation` now owns a shallow private rule-table map, retaining the original
active class table separately as `source_classes_raw`. Only its private class view
is compiled. Accepted table publication updates changed identities; a TLK-only
revision does not rebuild classes. Canonical `ui.text.tables`, resources/world
data, level-up rules and the server catalog are not modified. Private dependency
tables survive unrelated text publication.

Accepted compiler proof: `.cache/creation-class-flow/native-class-metadata-v2/proof.json`,
7,660 checks/56 unchanged inputs. It compares the complete native default oracle,
every numeric field of all 43 installed rows, custom overrides, BYTE/INT/BOOL/FLOAT,
normal and reverse-case duplicate headers, generic and physical getters, malformed
fields, and raw graph isolation. The first compiler proof had 7,658 checks before
the reviewed reverse-case aliases correction.

Accepted actual-owner proof: `.cache/creation-class-flow/native-class-publication-v2/proof.json`,
28 checks/435 unchanged inputs, clean engine. Actual Gameplay/Creator initialization,
real class commit callbacks, installed Fighter completion, Wizard primary/vitals/
Spell Snapshot/School, and Cleric/Druid/Sorcerer/Bard/Ranger continuation branches
pass. Custom publication overrides and raw isolation also pass. This tests actual
owners/getters and routing, not every physical choice or server admission. The
clean rejected v1 assumed the Wizard raw Arcane cell matched Fighter's `****`;
v2 compares its actual captured value and complete original raw graph instead.

The new first-level draft also uses the actual temporary-stats constructor
`7ea7a0`: both associate types begin at signed -1 and both names are empty. The
old generic zero and literal `Familiar`/`Companion` values could bypass automatic
manual-chooser name generation and were incorrect when Package.Associate failed
its lookup. `.cache/creation-class-flow/native-new-stats-v1/proof.json` passes
eight checks/55 unchanged inputs using real installed initialization and the
source chooser's unset-name admission. Proper accepted associate choices survive
derived-choice reset. BIC field gating/type and authoritative acceptance are
separate checks owned by the full source-flow driver.

Dirty-before copies are under `.cache/creation-phase/before-phase-v1` and
`.cache/creation-class-flow/before-{mem-no-scroll,package-name}-v1`.

## Composed validation matrix

| Branch | Existing composed proof | Current remaining gate |
| --- | --- | --- |
| Memorizing scroll class + School | `native-creation-spells-binding-v3-receipt.json`: 47 actual source controls, preference worker, cancel/reset, parsed BIC | Rerun current repairs and compose ordinary full creation/admission |
| Cleric-style Domains | `native-creation-domains-binding-v1-receipt.json`: active class/domain/package IDs, actual controls and grants | Current full Domains-to-tail/BIC/admission |
| Non-memorizing custom class | Prior actual source controls/real BIC: 15, including separate LearnScroll flag | Current ordinary spontaneous/non-scroll source case and admission |
| Cached custom Warlock | `native-cached-warlock-spells-v1-receipt.json`: 35 actual Snapshot/State checks from seven SHA-verified cached resources | Source controls and full source save for the current active descriptor |
| Memorizing non-scroll class | Adapter/private state13; complete manual132 and Recommended137 controls/typed BIC, with distinct original budgets | Authoritative custom-data admission remains separate |
| Manual Familiar/Companion | Prior Package-to-associate/UTC/name/private summary/BIC: 30; current lazy entry/real worker/input: 24 | Ordinary full Druid/familiar authoritative admission |
| Automatic Recommended associate | Name/worker/error/reopen/stale: 29; failed-cell source validation through actual Tail/full BIC: 42 | Authoritative associate admission across current custom packages |
| Skills/Feats families, zero choices | Existing original-backed models and native controls | Current composed zero/recommend/reset/back/family branches across class data |

Current complete offline source-control cases are under
`.cache/creation-class-controls`:

| Installed active branch | Accepted native controls / BIC proof | Scope |
| --- | --- | --- |
| Wizard | `native-class-controls-wizard-v1/proof.json`, 131 checks / 437 unchanged inputs | Actual Main, Configure Skills/Feats, School, Spells, Familiar, real name worker, Tail, physical Play and typed BIC worker; exact parsed books/IDs/order |
| Cleric | `native-class-controls-cleric-v1/proof.json`, 114 checks / 437 unchanged inputs | Actual Domains and its two physical choices, Skills/Feats, Tail/Play/typed BIC; unrelated School/pet fields omitted |
| Druid | `native-class-controls-druid-v1/proof.json`, 110 checks / 437 unchanged inputs | Actual Companion selection/name worker, full Tail and physical Play/typed BIC; exact class-owned companion fields |
| Sorcerer | `native-class-controls-sorcerer-v1/proof.json`, 124 checks / 437 unchanged inputs | Non-memorizing Spells, Familiar/name, full Tail/Play/typed BIC, exact active books/feats/skills |
| Bard | `native-class-controls-bard-v1/proof.json`, 118 checks / 437 unchanged inputs | Non-memorizing Spells, full Tail/Play/typed BIC, exact books/feats/skills and omitted unused pet fields |
| Custom Mem1/Learn0, manual | `native-class-controls-mem-manual-v2/proof.json`, 132 checks / 439 unchanged inputs | Actual spell level/row arrows use active known capacity1; no cantrip injection; full typed BIC |
| Custom Mem1/Learn0, Recommended | `native-class-controls-mem-recommended-v2/proof.json`, 137 checks / 439 unchanged inputs | Actual Recommended/Reset retains original memorizing preference budget3+INT (six here), independent of LearnScroll; no cantrip injection; full typed BIC |

These cases use ordinary Creator entry and real controls rather than manually
advancing coordinator stages. Feats/Spells Recommendations are repeated after
actual Reset, preserving exact choices. A child without Recommended uses actual
row/arrow or School-tab input. Rendering is disabled with controlled art/fonts;
model/name/typed BIC workers are real. They establish neither pixels nor server
admission. The custom combination uses private active class/known table resource
overrides on the real installed Wizard row; it is not presented as a captured
server class. Each receipt retains its exact historical
Creator source, including the later independent performance edits' boundary.

The first composed custom run (`native-class-controls-mem-non-scroll-v1`) reached
the full BIC and passed all ordinary control/file assertions but retained two
incorrect final fixture expectations. It clicked Recommended while expecting
the manual capacity1. Original initializer9ce190 branches on LearnScroll;
preference helper7eb630 branches on MemorizesSpells instead. The accepted two
variants preserve both behaviors; no producer quota was rewritten to satisfy
the fixture.

Wizard/Cleric v1 recommend before accepting Feats, so they do not prove that
the first pre-click view used current Skills. That stale-view/cold-cache defect
was subsequently fixed by root: Skills OK retains immutable Feats definitions
and names, clears private choices/model, and binds the current model before
presenting the child. Within-draft Feats/School Cancel also reuse those immutable
caches; draft open still creates a fresh State.

`.cache/creation-class-flow/native-feat-entry-v2/proof.json` passes 22 checks with
439 unchanged inputs and a clean engine. Real Package/Skills up0/OK exposes the
rank-dependent physical feat3 before any Feats action; actual selection commits
[0,3]. Reentry removes the old rank/eligibility/choices. State, definitions and
name-array identities/build count persist through Skills and Feats Cancel/Main/
reopen. Its controlled skill is explicitly usable by the controlled class; the
clean rejected v1 had accidentally retained installed Animal Empathy's unrelated
class restriction. This is a functional current-input/cache regression, not a
new live callback timing acceptance. Druid v1 includes the resulting entry fix.

Counts overlap and are not a count of unique features. Older receipts describe
their exact historical inputs. The API worker owns a new full source-only live
driver, separate from the historical mixed source/generic probe. Its admission
and exported BIC evidence must be attached to the final full-flow result; a local
submit intent or accepted send is not admission.

An earlier local source-only baseline reached 66 actual input checks through
Skills and Feats before a driver misclassified the internal post-Skills stage.
After the real class metadata repair, v3 passed 91 source-control checks, was
actually admitted by the original server, entered playing, moved 1.5 metres and
matched a fresh original-server export for stats and typed tail/outfit choices.
Its **overall receipt remained rejected**: the final visual preparation had not
completed when the host finished. That completion gate is owned by the API
worker, and this result does not establish all-class or visual completion.

The original measured Feats Recommended dispatch was 1.059 s. A copied-only clock
fixture reconstructs the installed Fighter workload from detached inputs of the
actual admitted source/export proof, with table/TLK hashes and complete policy
and committed-output equality. The uncontended pre-index run
`.cache/creation-feat-profile/native-feat-profile-v2/proof.json` passed 13 checks
with 439 unchanged inputs. Recommended took 496.126/475.895 ms; repeated class
feat flags and prerequisite class-record scans accounted for most of that work.
View rebuild was 14.071/17.957 ms. No view optimization was justified by this
attribution.

Root's operation-scoped first-record index retains native duplicate/WORD/BYTE
semantics. The after-index v3 proof passed the same 13 checks with 441 unchanged
inputs and exact unindexed reference/model equality. Recommended took
104.742/103.444 ms and Reset 104.986 ms. Class flags fell to 5.935/6.195 ms and
prerequisite class-record lookup to 1.543/1.569 ms. Remaining candidate work was
65.025/67.015 ms. These are instrumented headless callback diagnostics with
controlled art/fonts, not live FPS, real raster queue or complete interaction
latency acceptance. Root's subsequent private decoded-field aliases preserve
exact-key/first-case lookup behavior. The final v4 diagnostic passes 13 checks
with 442 unchanged inputs and exact unindexed reference/model equality:
Recommended 91.847/91.648 ms, Reset 95.788 ms; candidate 52.512/50.187 ms,
prerequisite evaluation 19.101/18.025 ms, snapshot 12.145/14.776 ms and view rebuild
16.682/15.267 ms. This accepts the demonstrated policy CPU improvement while
keeping real-art and authoritative interaction latency separate.

The actual lazy Associate entry repair is accepted in
`.cache/creation-class-flow/native-associate-entry-v1/proof.json`: 24 checks,
436 unchanged inputs, clean engine. Original binder9cc4f0 changes the private
raw type -1 to 0 only on entry and starts real generation for an empty name.
SelectTab uses visible index0; preview/OK map the panel's physical-ID array, so
a sparse first row can correctly be physical2. The raw preparation value stays
separate until OK stores that mapped ID. Tests cover delayed first assembly,
real native LTR/filter workers, reentrant refresh without duplicate generation,
Cancel's observed private preparation effects, OK, pending-name Escape/reopen
and familiar/companion namespaces. This receipt does not claim full save or
authoritative associate admission.

Native Package-source validation now follows original8e4620/807950 instead of
the generic familiar/companion granted-feat gate. Failed Associate lookup keeps
the constructor's -1/empty or earlier prepared values and still completes8008.
The source validator reads the compiled class BYTE minimum and, only when it
equals one, the known Arcane field and signed-INT/String pair in that class's
owned namespace. Missing/malformed reached metadata remains explicit. An
unreached Arcane field is not a dependency; no row, zero type or name is invented.
Other generic draft validation remains intact. The manual child still requires
a real mapped row and a nonempty/generated name before OK.

Clean preserved before proof:
`.cache/creation-class-flow/native-associate-validation-before-v4/proof.json`,
41 checks with exactly two expected failures: source Recommended was rejected
by the generic pet-name rule, including full Builder admission. Accepted after:
`native-associate-validation-after-v1/proof.json`, 42 checks/441 unchanged inputs.
It physically completes Recommended, Appearance and Info, then builds and parses
the complete native BIC with only the class-owned FamiliarType(INT5)=-1 and empty
FamiliarName; the unused companion pair is absent. It also checks generic/manual
rejection, other class-owned namespaces, native signed range and malformed
metadata. Active class overrides and art/fonts are controlled test inputs, so this
is not authoritative server or pixel acceptance.

The earlier before-v3 run retained the same two functional failures but was
rejected for engine errors during immediate fixture shutdown. It exposed a real
Preview forced-retirement double wait, reported to its owner. The clean before/
after cases explicitly wait for ordinary asynchronous retirement before teardown;
they do not claim that shutdown defect fixed. Its owner subsequently repaired
the forced drain's duplicate wait and accepted 109 separate actual-worker checks.
That later repair is included in final profile-v4's pins, not retroactively in the
earlier Recommended receipt. Initial authored fixture parse/key rejections are
also retained separately.

## Automatic feat preference completion

The captured Warlock automatic package exposed a different completion contract
from manual CG_FEATS. Original Package8e4620 calls preference-only7eb040 before
recommended Skills, inserts its returned feat IDs, and ignores its remaining
CHAR. It does not choose arbitrary fillers when the preference list ends.
The complete source dossier is
`reports/native-package-feat-recommendation-source-v1.json`.

The captured-data differential passed 297 checks: generic and original-backed
State selected the same IDs for all six raw package rows. Playable310–314 choose
[408,945], using two normal slots and leaving the one Pact bonus unfilled. Pact1
is not in any preference list; Pact2 is present but correctly level-ineligible.
Thus changing recommendations or weakening manual completeness would be wrong.

`creation_feat_automatic.gd` now validates a distinct completed source-automatic
receipt. It stores only scope provenance, core character scalars, small pre/post
skill maps, selected IDs and BYTE budgets/preferences. It stores no definitions,
tables, world graph or stale eligibility verdict. The existing mandatory BIC
worker reconstructs from active tables, replays exact preference order with
the original wrapped combined CHAR and separate candidate budgets, then verifies
all chosen prerequisites/duplicates/reservations in the current context. Only
the original ignored remainder is permitted. Actual connection/draft publication
and result fences remain Creator-owned.

Reset/manual Configure retires this receipt. Manual source selections still use
their complete original validator; generic drafts keep generic validation.
Conflicting automatic/manual markers reject. The input callback captures compact
data only and does not run the replay.

Focused proof `.cache/creation-class-flow/native-auto-feats-v2/proof.json` passes
50 checks/48 unchanged inputs, including actual caster RuleView spell resolution,
compact payload, malformed/empty/unloaded/known-failed preferences, changed
context/tables, manual/reset isolation and CHAR256→0/257→1 behavior. The initial
v1 retained only new-fixture Dictionary inference errors. Peer cached automatic310
then passed 340 actual control/BIC checks, including real Configure/Cancel marker
retirement and fresh automatic replay; remaining package variants have their own
receipts. These are client/BIC proofs, not custom server admission.

## Automatic spell preference completion

Package8e4620 ignores7eb630's returned remainder/highest output. Two actual Wizard
control reproductions confirmed that generic exact-known-count validation blocked
this supported path: a missing SpellPref2DA and a valid zero-row preference table.
Both preserved before receipts pass66 checks by observing the exact visible
`Choose level 1 spells.` rejection after physical Package/Tail/Play:
`.cache/creation-automatic-spell-repro/native-auto-spells-missing-v1/proof.json`
and `native-auto-spells-empty-v1/proof.json`. Source is retained in
`reports/native-package-spell-recommendation-followup-v1.json`.

`creation_spell_automatic.gd` now captures a separate compact completed-operation
receipt and replays it only in the existing mandatory BIC worker. It holds scope,
class/race/package/ability/domain/school/alignment context and ten small known/
prepared ID arrays. It contains no table graphs, definitions, names or prior
eligibility verdict. Current active tables are consulted again at build time;
changed context, preference source, IDs/order, malformed metadata or results
reject. Manual sourceSpellChoices and generic strict validation remain separate.
Reset, real Package reopening and manual Configure retire the automatic receipt.

The original gates stay distinct. Missing preference lookup skips the helper and
cantrip injection. A successful preference-name lookup on a restricted memorizing
class injects class cantrips before the helper, even if the table subsequently
fails to load or is empty. This caller does not use the manual chooser's
LearnScroll/raw-Intelligence cantrip gate or its shared selection counter. The
Snapshot optional counter requirement defaults true; only this automatic data
projection opts out. Spontaneous classes replay native known capacities.

Private preparation assigns each known spell once to the matching slot index,
stopping at min(known count, native BYTE slot count). It never cycles or fabricates
domain spells. The original first-level writer separately serializes all native
slots, using WORD FFFF for unset entries. Source807950 writes Known/Memorized
struct0 with only WORD Spell; Ready, metamagic and domain tags belong to another
writer. The exact caller/setter/getter/writer assembly is retained in
`reports/native-first-level-spell-save-source-v1.json`; the API owner's separate
14-check parsed writer proof covers source and generic schema separation.

Focused current replay proof
`.cache/creation-class-flow/native-auto-spells-v2/proof.json` passes80 checks/53
unchanged inputs. Actual controls after proofs pass120 checks for missing prefs
(`native-auto-spells-missing-after-v2/proof.json`) and127 for empty prefs
(`native-auto-spells-empty-after-v1/proof.json`), each with441 unchanged inputs.
They physically reopen Package, switch to manual Configure, Cancel Skills,
reapply Recommended, complete Appearance/Info, press Play and parse the native
BIC, including the known prefix and unbound FFFF slots. No network or server
admission is claimed by these controlled-art/headless cases.

## Original automatic feat candidate selection

The new Wizard case also exposed a producer error that the mandatory original
replay correctly rejected. Generic Package recommendation selected future class
grants Brew Potion944 and Craft Wand946; original7ee690 rejects those grant levels
and the exact preference-only replay selects Combat Casting7 and Toughness40.
The preserved engine-clean80 rejection and candidate details are at
`.cache/creation-automatic-spell-repro/native-auto-spells-missing-diagnostic-v1/`.

Source Package recommendation and receipt replay now share the original-backed
candidate computation in `creation_feat_automatic.gd`. First matching class
records own grant levels, combined CHAR wrap and separate reservations remain,
and the producer adds no fillers. Unrelated generic direct recommendation retains
its old branch. This changes the producer rather than relaxing mandatory replay.
Focused `native-package-feat-grants-v1/proof.json` passes7 checks and the existing
automatic receipt corpus `native-auto-feats-v3/proof.json` passes50.

Ordinary unmodified installed Wizard automatic controls and BIC pass132 checks
at `native-auto-spells-stock-after-v1/proof.json`. A documented copied-only clock
around the recommendation computation observed125.947 ms on its first call and
122.244 ms after reset/reapply. Controlled art/fonts, asynchronous name work,
worker execution, GPU and network are outside that measurement; physical OK
dispatch alone cannot measure its later asynchronous continuation.

One exact captured Arelith automatic310 regression passes340 checks at
`.cache/cached-warlock-complete/cached-warlock-recommended-310-v3/runner.json`,
with441 source/512 captured-data/six native output pins unchanged. It preserves
[408,945] and the original unused bonus slot, verifies physical receipt retirement
and replay, and completes Tail/native BIC. The earlier311–314 receipts retain
their historical source scopes; they were not relabeled as current reruns.

Follow-up, deliberately outside the current full-flow patch: Package scalar
conversion still uses generic `Game.number`. Original `C2DA::GetINTEntry1a7010`
accepts both `0x` and `0X`, and uses `atoi` for a non-hex cell. Thus an active
Associate cell `0X2` or `2tail` resolves to 2 originally while the current generic
getter resolves to its fallback 0. The exact two-assertion reproducer, retained
source body and evidence ID are in
`reports/native-package-integer-followup-v1.json`. It is source-backed but not
executed yet; producers remain unchanged until current full-flow acceptance.
