# Synthetic dense offline fixture

`tools/native-dense-benchmark-fixture.mjs` builds raw replay input from an existing sealed recording. It performs no JS model selection, decoding, geometry/light preparation, simulation, rendering, connection or engine launch. The current implementation has13 passing Node tests over the actual sealed source. Catalog bulk materialization and native scene validation have not been run by this task.

## Source and scope

Source: `.cache/loading-benchmark-worlds/arelith-archive-v1`, the existing synthetic-ERF storage clone of the original capture. Its timeline SHA is `d955e6fef37015dc189ab480a76bb03b0cc2f44482bdee5a55b45561a23715ee`,106,332,491 bytes/4,019 events. Catalog manifest SHA is `47068e372f33bbc0f21c1b5c23834ce63a4df2cf8522883083cdac8c7b25195e`; exact packed resource archive SHA is `30cb0d53bfdcec63f94581ae6e149d1757dfcb41d47f704719cbdb7da90ff074`,289,933,869 bytes. Inspection verifies these seals and the captured base TLK bytes.

The initial generation1 full snapshot contains704 rows but no controlled PC (`controlledId=OBJECT_INVALID`). Its current-area cohort is703 rows:681 static placeables, four light-only placeables, five map pins and13 sounds. That is685 static/light rows, not685 `staticState` rows. The static/light payloads remain identical through the last complete generation1 snapshot, serial258. That later snapshot supplies the real stationary controlled creature4294965485, with an empty path and no dropped companion/master/facing links. This is a declared composite of captured static topology and a later captured PC, not an assertion that all inputs originally arrived in one packet.

The historical completed generation4 control has roughly630 entities. The recent manual room has roughly1,983 entities,579 lamps and1,970 shared particle members. This fixture does not reconstruct that room: the manual compact reports lack required static state and creature appearance data.

The existing `arelith-fog-particles-v1` is an authored particle-on timeline variant with the same catalog seal. Its catalog directory lacks the `objects` subdirectory containing the manifest-declared base TLK. The generator therefore uses archive-v1's verified resource/TLK source and declares particle/collision flags explicitly; it does not silently borrow installation/profile data to repair the variant.

## Generated layout

The default2×2 fixture expands the captured8×6 tile rectangle to16×12,192 tiles, in native physical row-major order. Four copies use native XY translations `[0,0,0]`, `[80,0,0]`, `[0,60,0]`, `[80,60,0]`. Every original tile descriptor, height/orientation and underlying asset reference stays unchanged. Raw static/light/sound/pin positions receive only those translations; Z and orientation remain exact. No transform matrices, scene nodes, collision geometry or texture data are prepared in JS.

The raw world contains2,813 current-area rows:2,740 static/light placeables,52 sounds,20 pins and one captured PC. The area arrays agree exactly with their raw owners:2,724 `staticPlaceables`,32 `placeableLights`,52 sounds and20 pins. Empty captured player-map pins remain empty; nonempty ones require a new explicit policy and are rejected.

Base-copy IDs and the PC/equipped item IDs remain captured. Other copies receive unique external tagged IDs allocated from `0x90000000`, excluding known captured IDs/links. Only declared object/embedded identities are remapped. Arbitrary numeric values, TLK/appearance/class/resource indices and sound fields are never treated as object IDs. Unsupported extra fields on cloned raw records—including current physical clock ownership metadata—are rejected rather than copied as invented provenance. NativeLifetime values remain captured transport metadata, not a claim of new native timer construction.

Relative order within each captured cohort is retained; copies are emitted in tile-copy row-major order, followed by the single PC. Only persistent captured CUSTOM/TLK-override inputs are seeded, in received order. No NPCs, script/UI actions, movement frames, speech or extra controlled characters are generated. Captured player/global inventory/UI data and entry remain source data rather than cloned NPC entities. One captured camera/view is retained, with explicit particle/collision flags. No new endpoint is installed or contacted; the setup label says `OFFLINE SYNTHETIC DENSE`.

The timeline uses the existing replay contract: reset/setup, catalog-ready fence, persistent text declarations/view, one fresh full world with at most64 objects per chunk, raw-world end and the normal accepted/area-ready fences. Serials start at1 with no old delta base. Frame size and ordering bounds are checked; the generated recording manifest seals the exact new timeline. A complete recording container is explicitly distinct from complete resources or rendering.

## Resource and workload limitations

The original complete presence namespace has348,244 entries but only2,927 captured resource descriptors. Packed storage reports345,320 absent-capture/failed entries; those are not silently zero-byte assets. Three recorded model errors remain: `alc_chunk_s01`, `alc_chunk_s02`, `plc_chunk_m02`. Missing emitter bitmaps and transitive dependencies are still subject to native preparation and failure reporting. Neither Node tests nor unchanged raw references certify the active native asset closure. `nativeActiveClosureValidated` and `nativeValidated` remain false; no missing dependency counts as completed.

The layout duplicates original perimeter tiles too. Seams can contain opposing walls; it is not a navigable redesigned area or a multiplayer-authoritative world. The PC stays at a real captured position in the base copy. No guaranteed cross-copy pathfinding/walkability claim is made.

Adjacent translated copies increase loaded owners, total geometry, tile/light/particle registration and clone work. A single captured camera near one quadrant does **not** automatically produce4× visible geometry/particles or recreate live-area overdraw. Existing fog/frustum culling still applies. Root should compare source variants with the same materialized fixture, prepared-cache policy, camera, library bytes and render settings. A1×1 variant isolates the same raw source layout for scaling, but it is not a full historical replay with its original NPC/event population. Loading, native completion and steady performance must be reported separately; the fixture is not evidence of a speedup.

## API and commands

```js
const source = await inspectDenseBenchmarkSource(sealedDirectory);
const fixture = buildDenseBenchmarkFixture(source, {
  copiesX:2, copiesY:2, particles:true, particleCollision:true,
});
// fixture: {recording,records,timeline,summary}; detached raw protocol data.
// File-only optional materialization into a fresh separate directory:
await writeDenseBenchmarkFixture(source,fixture,newDirectory);
```

Inspection verifies recording/catalog/timeline/packed archive/TLK seals, extracts the initial cohort and completed PC, checks immutable static/light records and their matching area arrays, and refuses a nonstationary/dropped-link PC. Scale is bounded1×1 through2×2. File materialization copies exact archived resources and TLK into a fresh directory, checks copied bytes and original source seals, and writes the new recording/timeline. It never rewrites the source. Existing failed output directories are retained and cannot be overwritten.

Read-only CLI summary:

```text
node godot-client/tools/native-dense-benchmark-fixture.mjs --source=godot-client/.cache/loading-benchmark-worlds/arelith-archive-v1
```

Proposed file-only materialization, not executed here:

```text
node godot-client/tools/native-dense-benchmark-fixture.mjs --source=godot-client/.cache/loading-benchmark-worlds/arelith-archive-v1 --output=godot-client/.cache/loading-benchmark-worlds/arelith-dense-hubint-2x2-v1
```

The shared `replay-native-loading.mjs` remains unchanged. Root owns review/materialization and any later copied engine/GPU tests. No engine or replay command was run by this task.

## Executed Node evidence

`node --test --test-timeout=5000 godot-client/tools/native-dense-benchmark-fixture.test.mjs` passes13 tests in4.43s (4.50s wrapper). Four before/after text inputs remain identical. Actual input timeline/archive/TLK hashes are verified during inspection. Tests cover actual cohort/PC selection, row/area/tile counts, unique/remapped IDs, native XY versus Z/orientation, matching embedded area lists, source ordering/chunk/byte seals, one camera/PC, explicit resource gaps, exact1×1 source variant, unsupported schemas/scales/IDs, detached mutation isolation and original metadata preservation. They construct real raw timelines in memory; no bulk archive copy or native preparation occurs.

Evidence: `.cache/native-dense-benchmark/unit-v1/`; receipt: `reports/native-dense-benchmark-fixture-v1.json`. No claim of full-scene completion, original binary parity, matched live density, GPU performance or process/server acceptance is attached to this Node gate.
