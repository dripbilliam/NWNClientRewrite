# Native client performance parity

Goal requested 2026-11-05. The user resumed the goal controls and the tracker
confirms active. The latest user message asks about test readiness but explicitly
says not to run tests now. All new test/build/graphics execution is on hold;
source inspection and private implementation continue. This supersedes
the earlier 60 FPS performance target; reaching 60 FPS is a checkpoint, not
completion. Earlier implementation evidence and unfinished checks are preserved
in [the dense-area goal](NATIVE-DENSE-AREA-PERFORMANCE-GOAL.md).

## Outcome

The user renewed this goal after inspecting the successful offline movement
preview on 2026-11-05. The tracker now explicitly targets sustained **140 FPS**,
resource loading and streaming as well as rendering. Progressively more drastic
foundational experiments are authorized when ordinary approaches and suitable
native methods are exhausted; keep verified backups, isolate candidates and
promote only after correctness, visual and matched performance evidence. The
original source/worktree and all earlier evidence remain preserved.

All four available concurrency slots are in use:

| Owner | Exclusive work area |
| --- | --- |
| Root | Integration, capture/replay fidelity, diagnostic/transport overhead, GPU/local test scheduling |
| `perf_particles` | Particle CPU/presentation private candidates and dedicated tests |
| `perf_loading` | Resource loading/cache work and private movement collision candidates/fixtures |
| `perf_render_culling` | Render/light/font publication, collection research and the shared read-only REA session |

Agents write only their own tools/docs/tests and private candidate trees under
`.cache/native-140fps/`. Root owns shared-file integration and every graphical
acceptance run; CPU-heavy work is coordinated around those windows. The existing
editor 25060 and original server 7568 remain protected. No automated public login,
movement or gameplay is authorized.

The new immutable baseline is the user's sealed `capture-YaH3xf` (5,704 events,
76,971,381 timeline bytes, 360 movement decisions/replies, 201 authoritative
movement envelopes, 2,971 native frame projections, two area generations). Its
generation-2 offline preview accepted all 360 input decisions and the user
confirmed it looked correct. It is not benchmark acceptance: the preview also
reported accumulated delivery lateness and failed its final protocol-ack gate.
Root is fixing/characterizing those harness issues before performance claims.
The packet sidecar captured outgoing movement but zero raw incoming packets due
to an incorrect server-envelope filter; the original capture remains untouched,
and its authoritative presentation envelopes are still available. A future raw
transport-emulation claim must not be made from this capture.

Optimize this native Godot client toward the original client's reported roughly
140 FPS in the same heavy room: about 7.14 ms mean frame time. Establish a matched
native reference where practical; 140 FPS is currently the user's observation,
not an independently captured benchmark. Report any remaining gap plainly.

Also shorten the approximately 21-second entity publication/pop-in period and
reduce loading, incoming-entity and movement hitches. Preserve the player-first
camera/control and tile admission policy while allowing nearby entities to
stream without freezing gameplay.

Preserve geometry, textures, established lighting, required particle effects,
resource precedence, collision correctness, server authority and interoperability
with original NWN clients and servers. Changing resolution, view, required
scenery, effects or lighting is not an accepted optimization. Diagnostic
ablations can locate a cost, but their FPS is not a passing result.

## Current evidence

### Current source-only hold and light-publication work

The readiness/status reply itself made no implementation progress; this
continuation revalidated current source and continues available implementation.
The test hold is an execution constraint, not an explicit pause of the goal.
Do not treat an automatic continuation or elapsed time as permission to test.
All check counts below predate that latest hold unless a future explicit user
clearance and new receipt say otherwise.

The source-only header audit distinguishes several costs: same-generation raw
deltas do not reopen terrain/model resources; full headers are still parsed,
and some UI projections/signatures run again. Atmosphere and wind already have
equality gates. The concrete placeable-light dirty/planning path is being
addressed with a separate private plan-cache class and unexecuted oracle source.
Its typed numeric witness preserves signed zero/int64-vs-float distinctions,
uses original fallback for unsupported/nonfinite shapes, catches raw Dictionary
alias changes and invalidates through the existing table/configure/close owner.
All original live wakes, install budget, dynamic anchors and apply boundaries
remain in that control candidate. Cold counters are added to its existing
snapshot; no new per-frame observation loop is introduced. It has not been
parsed, executed, integrated or measured.

The [attachment audit](tools/perf140/loading/PLACEABLE-LIGHT-ATTACHMENT-AUDIT.md)
identifies late model/table readiness, removal-before-retirement, same-ID
replacement, hidden results and install-budget continuation as required wakes.
Missing lightOn/deletion can restore an authored area light; missing dynamic
anchor does not mean erasing it. A stronger independent static-outer-pose
candidate is being prepared without changing the dynamic attach path.

[Pinned setter source](tools/perf140/render/GODOT-SAME-VALUE-TRANSFORM-SETTERS.md)
shows equal transform setters still propagate dirty state/notifications. In
this client a descendant ModelPointLight transform notification reaches
Palette.update, which unconditionally writes two pixels and marks upload dirty.
Therefore internal duplicate publication is a concrete lead, not proof that
all notifications are required gameplay semantics or that suppression is safe.
Separate source variants isolate pure plans, static setter suppression and
byte-identical palette-write suppression; none has been enabled or tested.
The palette variant must retain the corrected immutable-upload parent and its
changed-callback lost-write handling. Its proposed logical revision remains
per call while a separate actual-pixel revision governs upload dirtiness.
Getter/key/copy overhead remains part of the eventual measurement.

### Native height integration: light-only work while the user plays

The user reinstated **light non-FPS tests, research and base implementation
only**, then explicitly asked to keep going. This does not reopen graphics or
heavy-build permission. The V5 light-control window had already exited when
root attempted to close its uniquely owned window. Its raw report remains, but
`native-perf140-source-guard-pull-a1.exclusion.json` excludes the entire timing
run because the contention interval is unknown. There is no counterpart run.
The comparison helper now rejects an excluded run or baseline without publishing
FPS/frame statistics; the small exclusion check passed. Do not reuse this as
performance evidence. No user game/server process was stopped.

Base implementation is now prepared as a separate `NwnTerrainHeight` class and
bounded, per immutable mesh/table cache, without changing physical/clear APIs.
The five-file source overlay is
`loading-agent/terrain-height-integration-v1/source-overlay.json`, SHA256
`a89f2889d7288c3225d9fff963bc6d5c9358be56e38044567f158663ba21d5a1`.
It retains the already verified1f38c101… numeric kernel and7a4a6a27… clear parent.
Creator-thread ownership, terminal retirement, publication invalidation and
old-function fallback remain explicit. Integer-authored XY coordinates are
conservatively rejected to preserve original int64 subtraction semantics;
ordinary decoded WOK float coordinates use the numeric path. Script is default.

The granted small checks passed without a full project copy: selected Node
syntax/source generation, installed packed-array ABI sizes(16bytes each), a
headless parse of the cache, and a two-GDS process-only pack smoke gate with29
checks. The smoke gate exercises original readiness/previous-Z/area/quarter-turn
and elevation rules, unavailable-native memoization/fallback, detach and close.
Its new native class is explicitly absent, so it does **not** validate the C++
adapter at runtime. A separate single-TU MSVC `/Zs` check passed strict syntax
and generated no object/DLL. These engine checks took under a second each;
the syntax-only compiler call about2.3seconds, with no world/FPS measurement.

The extended selected-source smoke now passes52 assertions. Its preserved V2
failure was caused by two fixture assumptions: a literal negative zero was not
shown to retain its sign, and the token `nan` was assumed to be a valid float.
V3 constructs the input from exact negative-zero bits and asks the original
`Surface.walkable` for token classification. Input/packed negative-zero bits
match, and `nan` remains the original nonnumeric/nonwalkable token. No candidate
implementation byte changed to make these checks pass.

V4 additionally compiled the expanded actual-native integration fixture without
instantiating or executing it:54 assertions, clean logs, exit0, under one second.
The fixture source now covers publication, array/table identity, off-thread
rejection, explicit unsupported coordinates and missing-versus-zero behavior.
Those native runtime cases are still pending.52/54 include the earlier29 smoke
checks; do not sum these overlapping revisions as independent coverage.

Consolidated light evidence:
`reports/native-perf140-height-integration-light-evidence-v2.json` and
`root/height-caller-light-v4/process.json` under the private cache.
All five selected source hashes remained unchanged. Linking/loading the real
new class, complete caller/native corpus/lifetime tests, original-local movement
and performance remain pending for a suitable execution window. The existing
main sources and native outputs were not replaced.

The existing replay driver has explicit terrain-height selection and a cold
activation witness, described in
[the height replay contract](tools/perf140/driver/HEIGHT-REPLAY-ACCEPTANCE.md).
It defaults to script, rejects an explicit native request without actual class
configuration/query hits, preserves deliberate fallback counts and does no new
per-frame polling.26 small Node tests, Node syntax and PowerShell parsing pass;
an actual older clear-only report passes only as legacy script. No replay or
FPS test was launched for this plumbing.

The particle lifecycle test recipe also has a pure90-check evidence parser
gate. It rejects reversed/duplicate generated module calls, incomplete output
lines and malformed phase/status records. This found two parser defects, now
corrected, but proves neither the C ABI nor real engine lifecycle execution.
Frozen module bytes remain unchanged. Its engine build and runtime test remain
deferred, along with GPU/FPS work, while the user is gaming.

The separate particle ConsumerV2 source tightens malformed fallback responses:
INACTIVE must precede ObjectDB (stage0), and non-success transform replies must
retain the producer's zero-initialized payload. Valid successful raw transform
bits, including signed zero/nonfinite words, are unchanged. A tiny standalone
stub-producer C++ gate passed983 checks (MSVC strict compile0/run0, about1.5s),
with unchanged selected sources. It launched no engine and built no native DLL.
This is defensive ABI correctness, not native runtime or FPS acceptance. Frozen
V1 overlay8af556f… is preserved; reviewed successor package d569ec0a… changes
only its consumer header to5042fa0e…. The root stager requires explicit approval
of that exact successor plus matching prebuild/built receipt lineage, and keeps
its output separate as `engine-reads-fenced-v2`.12 small composition checks pass;
the stager itself has not copied or built anything. Runtime fixtures also add
real provider mutation/hide/reparent/free cases, still unexecuted.

The terrain-height isolated stage/build/finalize runner is source-complete. Node
syntax and PowerShell AST checks passed; source-check receipt052ea836…. It will
validate both16-byte packed-array references, exact five-output overlay, complete
native source inventory, strict compiler flags and actual compile/DLL/root
correlation. It copies raw build evidence and replaces inherited metadata rather
than claiming the old clear DLL proves a new height class. No stage, build or
native runtime gate has run. Existing fixed clear-only acceptance remains intact.

All current changes are private implementation or test/driver plumbing; no new
renderer or experimental native binary has been promoted to normal gameplay.
Consolidated light checkpoint:
`reports/native-perf140-light-progress-v1.json`. It preserves the discarded
wrong-checker Node command against a `.gd` file separately from the successful
Godot compile proof; no failed command is relabelled as a passing gate.

### Continued light work after the goal was resumed

The prior turn made concrete implementation/correctness progress; it was not a
wait or a performance acceptance. Current execution remains light non-FPS only.
The V2 particle composition/build wrappers are now frozen separately as
`particles-agent/synchronous-engine-read-compose-v2/source-manifest.json`,
SHA a5d8cc9c…. They retain the unchanged8af/d569 source lineage and carry exact
`consumerSuccessor` through prebuild/finalized receipts. A separate builder
c9cc13f9… rejects implicit `CL`/`_CL_` flags and records the actual argument array,
compiler/builder hashes and working directory. Root's V2-only staging gate now
requires those fields and the reviewed tool bytes.29 small Node contract checks
pass with unchanged sources, including the earlier12 composition cases; do not
add those overlapping counts. Actual staging/build/native execution is unrun.
Proof: `root/engine-read-build-guard-test-v1` under the private cache.

The bounded [height query audit](tools/perf140/loading/TERRAIN-HEIGHT-QUERY-REUSE-AUDIT.md)
found exact repeated start calculations: every synchronous path probe has the
same start, with at most38 probes per search. The retained compact peak has
10collections/380clears and760 logical height invocations, not proof of760
in-bounds triangle scans. One lazy start-inner result per valid synchronous
search could reduce380 start evaluations to at most10 while preserving logical
counts, readiness, previous-height fallback and final arithmetic. No memo has
been enabled; native-height timing comes first, followed by exact scope/binding/
bit/lifetime and stateful-provider oracles before another candidate is composed.

The [native bucket re-audit](tools/perf140/render/NATIVE-BUCKET-IDENTITY-AND-REPEATED-WALKS.md)
confirms retained spatial Part identity plus pass-specific lists, rather than a
universal model-resource deduplication set. Appending to color and shadow arrays
serves different passes. Emitter centers are read during membership upkeep and
fine camera admission; that is not evidence of duplicate simulation. No new
room/PVS/line-of-sight hiding rule is established. The separate bounded cold-only
ancestor census now passes37 checks in a tiny isolated plain-Node hierarchy
(clean exit0, about0.4s, source unchanged). It returns detached structural counts,
explicit role identities and bounded/unavailable status; it proves no real-room
getter frequency or cost. Its V2 extension now passes52 overlapping checks,
adding a separate contiguous-Node3D potential chain, plain-Node barriers and
detached endpoints.37/52 are successive revisions, not additive suites. It is
not wired into ordinary frames or the renderer. Its eventual real-cohort use
comes after measuring the fused-read candidate. Proofs:
`root/ancestor-census-light-v1` and `root/ancestor-census-light-v2`.

[Pinned Godot getter source](tools/perf140/render/GODOT-VISIBILITY-GETTER-CONTRACT.md)
confirms the public visibility getter walks only direct contiguous Node3D
parents. `is_inside_tree` is a pointer check and `can_process` reads live pause/
suspend plus retained process-owner data. The private visual-instance cache is
not a general replacement: parent visibility writes can notify/reenter before a
child's render cache updates. No cached-visibility shortcut has been introduced.

Root also corrected a real diagnostic wiring mistake before any fused native
build was run: shutdown writes the new engine readback under
`perf140_particle_modes.engine_reads`, while replay had looked under the separate
`perf140_cold_particles` census. The corrected report reader uses the actual
written field. Five small Node tests pass, including the old expression rejecting
an otherwise valid modes witness, wrong-section negative controls and unchanged
legacy ordinary behavior. This fixes future activation evidence, not a gameplay
or FPS problem. Proof: `root/engine-read-report-key-test-v1`.

The host publication source audit also separates repeated CPU work from wire
delivery: each eligible200ms tick still builds/signatures the full known registry,
but acknowledged deltas suppress unchanged static rows before sending to Godot.
Changed rows are encoded again for frame sizing and chunk serialization. A
private pending-string framing prototype now passes tiny byte-for-byte
functional comparisons; no Host runtime change or measured saving is claimed.
The new API explicitly snapshots already serialized pending values; the generic
framer keeps its mutable/toJSON semantics. No second whole-graph admission walk
was added. Both tiny gate revisions pass10 active cases with the real64MiB case
explicitly skipped; V2 extends those same cases with key-sensitive generic
serialization, exact UTF8 bounds, suspended ACKs and late-error byte prefixes.
The counts overlap. Source-only two-file overlay b7e08430… and generated Host
syntax pass; no Host was executed or shared module changed. Scope/byte/ACK
compatibility is supported, while actual full-size/local-authority/delivery and
uncontended phase/FPS acceptance remain pending. Proofs: `root/raw-plan-light-v1`
and `root/raw-plan-light-v2`. Earlier consolidated light evidence is
`reports/native-perf140-light-progress-v2.json`.

The continued header audit identified a concrete rendering-side lead:
placeable-light `receive(objects, removed)` unconditionally marks planning dirty,
including empty/unrelated deltas. The next process reconstructs all retained
area/object light plans and calls apply for every desired light. A configuration
equality gate skips some property work, but attachment and transform setters are
still visited. This is source evidence, not measured cost. Agents are tracing
all late-instance/model/attachment and scope writers before a private narrow
candidate; no dirty gate or lighting change is enabled yet.

Independent review found no functional issue under the declared immutable,
main-thread contract. One adapter comment overstates borrowed-pointer isolation:
the float64 pointer survives one **known nonmutating** packed-byte const getter
while both packed references remain owned. The pinned getter implementations
only check bounds and return their data pointer; this is not an arbitrary
callback-safe pointer retention claim. Frozen source is retained; review note is
`particles-agent/synchronous-engine-read-source-review-v1/TERRAIN-HEIGHT-REVIEW.md`.

### Compiled collision: first execution batch completed

The user explicitly reopened the test window. No other game/replacement was
running; the original local Prelude server35640 was preserved. The first six-run
batch completed: two physical/mode gates, two recorded walking replays and two
30-second unprofiled stationary windows. All runs used private copies, with zero
public or game-network connections. No new native DLL was built in this batch.

The corrected metadata successor is
`loading-agent/drive-preview-clear-provenance-v2`, manifest ae5c3fce…; its runtime
source/DLL remains the previously compiled101efc79… candidate. Root staged
`root/drive-clear-fenced-v2`, manifest7a4a6a27…. The new entry compiled cleanly.
The physical/mode gates passed5878checks/5808real-WOK rays with clean actual
activation, original physical operations and separate script/native clear routes.
The first plain-sandbox attempt retained its successful assertions but failed
on Windows certificate-store access; the fresh allowed run is the clean receipt.
No error filter was relaxed.

The recorded-walking pair accepted360/360inputs each and retained1918entities,
225tiles, the same ce2dengine/DLL, settings and enabled lighting/particles. In the
same worst-frame380clear probes, keyboard preview fell224.264→108.004ms
(51.84% lower), path194.403→81.331ms. Heights remain unchanged code and cost
67.459/63.493ms. The native calculation cache actually configured27entries,
134304payload bytes,5818queries/5791hits and zero unsupported/query/budget
fallbacks. This is one diagnostic replay pair, not exact network/trajectory
parity: its final player/camera endpoints differ about0.073world units and event
delivery remains late. Do not derive a matched FPS claim from the walking runs.

The separate unprofiled stationary pair passes the strict actual camera/view,
focus, projection, resolution, renderer and within-run stability guards. Mean
frame time9.2323/9.2916ms is108.315/107.624FPS; both have zero >50ms stalls.
It demonstrates no idle FPS gain. Small dynamic particle differences remain
(5967/5968draws,353266/353308triangles). Root viewed both pre-window images:
matching world/framing/UI/lighting with ordinary flame/smoke differences, not
pixel equivalence. The established existing missing-asset/reference warnings
are shared; effects were not disabled to improve this result.

Keep this candidate private, pending original-local authority/held-input tests
and the remaining height/collection work. It is not promoted to the ordinary
launcher. Consolidated pinned evidence is
`reports/native-perf140-drive-clear-evidence-v1.json`; the140FPS goal is unfinished.
The next granted CPU-only work validates the prepared standalone height kernel
against actual original-GDS golden results before any runtime integration.

That separate CPU validation is now complete:40053pure checks, an actual ce2d
exporter corpus of472cases/21084queries, then103304C++ golden checks with no
counterexample. The golden count includes the repeated pure cases; do not add
both counts as independent coverage. Corpus917079bytes has SHA256
`3990535cc41d46046a288aaf91e8e77536a619a9415e7734ff5ff7bed2cdb54d`.
Kernel/test source pins1f38c101…/654db6c4… match in both builds. The only defect
was the helper rejecting its documented golden label; original helper bytes and
the preflight failure were saved, then a label-only correction allowed the final
run. The height kernel still has **no runtime adapter or speed result**.
Receipts: loading-agent/drive-height-pure-v1 (d1da5e0a…),
drive-height-reference-v1 (381220aa…), drive-height-golden-v1 (78f4b8e5…).
All test clients and compiler processes finished; the local server is preserved.

### Current live retry: protocol import failure fixed

The user manually tested `live-threaded-drive-test-v1` on Arelith, then reported
a return to the menu and a failed manual retry with no message. Root gracefully
closed only that failed replacement to flush its report (native exit0). Both
connections had `network.object-import-failed: Native attack animation group
is invalid`, followed by `network.game-session-failed`. Host/native `success`
here describes clean shutdown, not successful gameplay or a passing benchmark.
The recorded FPS includes persisted detailed profiling; it is not an unprofiled
comparison. Empty-image warnings remain a separate, unproven rendering issue.

The native wire distinction is now verified against the binary: a creature's
A creation record carries an initial animation WORD, including9, but no attack
group. Only U/mask4/animation9 carries the two-bit attack count and records.
NetworkWorld incorrectly projected A/9 through the U-group validator. A valid
encoded spawn reproduced the failure before the fix; creation now retains its
initial state without inventing an attack group. Real update validation and the
0–3 bound remain unchanged. The persisted attack/object/combat regression suite
passes23 tests (`reports/native-attack-create-import-v1.json/.tap`), including
96 original native attack observations. The combined session suite passes71.

Separate Session/Lobby/host changes preserve the client import cause, expose it
to browser error state, and immediately journal terminal errors independently
of the ordinary first128 diagnostics. Those pass77 focused tests and five
syntax checks; exact pre-edit backups and source pins are retained in
`particles-agent/session-failure-v1/validation.json`. No native library changed.

The corrected manual-login trial `live-threaded-drive-test-v2` used the same
envelope renderer cce71cea… and ce2d engine. The user reported it looked much
better. It reached playing on connection1, subsequently exited cleanly (owned
parent session5101 / broker46516 terminal0), retained clean source guards and
recorded no terminal session failures. This supports the specific repair, not
complete server parity or a matched performance gain. Root made no automated
public login. The latest profiled windows still charge particles about4.6–4.8ms
and light collection about1.2–1.3ms; overlapping windows are not pooled.

Process revalidation then found Eco.exe43696 (with UnityCrashHandler43732)
running. Keep graphics benchmarks, builds and heavy CPU/headless work deferred
while it is in use. Source preparation can continue. The original local Prelude
server35640 remains protected; no running game was stopped.

### Prepared next experiments while graphics testing waits

Endpoint slots V2 passed28,302 functional checks and activated in the full-room
trial:3,658 direct hits, zero map lookups,2,782 retained indexed rows and zero
ordinary rows. It did not establish a gain: ordinary110.226FPS, indexed109.535FPS,
both zero >50ms hitches and identical draw/triangle counts, but a0.000055-unit
camera difference fails the strict view comparison. Keep it unpromoted. Root
stage is `root/endpoint-slots-fenced-v2`, manifest
`e0ce1eccc20de6defb98ebad06523c8425aa45313415656e89789e5d9824f069`.

Compiled clear V1 passed57,926 actual-engine plus10,013 pure checks; its original
physical-WOK/mode-isolation regression, recorded-walk timings and original-local
acceptance are still pending. Its actual build-proof/DLL pins are valid, but its
inherited internal kernel build manifest is stale. A separate source-prepared
metadata successor preserves the original compilation root and receipt without
claiming another build. Root's new `stage_drive_clear.mjs` consumer and explicit
`DriveClear=script|native` replay flags are prepared and syntax-checked only;
neither staging nor a gameplay test was run during Eco. Verified driver backups
are retained in `root/clear-flag-driver-before-v1`.

Authored-light source-guard V5 uses only an exact COW pointer/length fastpath with
the same value-equality fallback. Its e92fec94… engine passed1,876 positive
functional checks plus162 old-engine controls. Its first GPU pair remains
pending; use the same corrected-close runtime for both routes, without bundling
the separate font or particle experiments.

The next independent particle experiment is source-only: a synchronous engine
read ABI fuses existing eligibility/ID/type getter crossings while retaining the
same current checks, lease ordering and miss-only transform conversion. It stores
no Nodes or callbacks across calls. Producer/consumer ownership is coordinated;
the row-major Basis+origin ABI header is frozen at SHA256
`985efa740c5284506b50f2703d4d9b028d2b5b7414f883a2461000bacc7f7527`.
No fused engine/library was built or tested. Its proposed parent is the
pixel/lifetime-proved immutable-font engine, a new comparison cohort.

The source-only producer V2 now matches the original C interface's literal
`is_class_ptr` predicate at all three sites, rather than substituting the newer
`Object::cast_to` template's possible ancestry optimization. Its seven-file
manifest is32c32bcb…; the unchanged ABI is985efa…. The separate five-file
consumer integration overlay is8af556f7… (109,450 source bytes), guarded against
the original managed-pose parent. It wires the eligibility and pose seams,
ordinary-default modes, per-operation fallback, initialization/teardown and a
cold `engine_read_snapshot()` method. No full project was staged, compiled or
run. Root source review is not a functional or performance gate.

The getter audit rules out treating visibility as one cached leaf flag or
keeping an ObjectDB pointer across callbacks. Actual visibility walks the
Node3D ancestors; processing checks live pause/process-owner state; ObjectDB
validates the complete ID. Reduced interface crossings do not eliminate those
checks or imply a multi-millisecond gain. A further early-source-lookup fusion
is documented separately and is conditional on measuring the first experiment.
See `tools/perf140/render/SYNCHRONOUS-READ-NEXT-REDUCTION.md`.

The loading agent also prepared a standalone typed height kernel, a native
golden-result exporter and pure fixture source. These retain the existing
walkable-first/denied-second physical face order and explicit single-precision
expression boundaries. No runtime hook, compilation or oracle execution has
occurred. The existing physical ray operation cannot substitute for these
height semantics; do not enable the prototype from source review alone.

The stationary-camera alignment plan separately pins an exact12-f32 transform
for offline stationary windows while ordinary follow arithmetic still executes.
It rejects movement-timing mode and scope/input/player changes and retains the
strict guard. Quaternion reconstruction and a one-shot follow-state reset are
not proofs of bit-identical views. No alignment hook is implemented or measured.

Root prepared a small cold-boundary exact-view source overlay, manifest
`root/exact-view-source-v2/overlay.json`, SHA256
`475284169f6819f531a4833f7dedd6986990c107bb94d825824eb97ac06b35af`.
It adds a detached48-byte, twelve-f32 matrix witness plus projection/follow and
available scope/actor fields to the existing beginning/end observations. The
word order is explicitly **Basis columns then origin**, separate from the
particle ABI's raw C++ Basis rows. It does not reconstruct from quaternions,
change a camera, add frame callbacks or loosen the strict view comparison.
Only the small source overlay was constructed and its JavaScript preparer
syntax-checked. The prepared Godot word-order/mutation-isolation fixture has
not run. A later private stage and actual-engine gate are required before use;
this is preparation for matched measurements, not an optimization result.
The separate source review caught a live-but-outside-tree camera case: the
ordinary getter would log an error and return a default transform. V2 reports
that unavailable before reading it, and the fixture includes this negative
case. V1 and its old helper bytes are retained for audit; its overlay is
superseded. V2 freezes the helper in its own small source folder. No existing
renderer, running session or shared native output changed.

Deferred clear-geometry gates now have an isolated physical-WOK entry and a
separate script/native mode runner. Height fixtures additionally cover physical
same-pass order, signed zero, mixed material table values and unsupported math
fallback. Exact pending commands are in
`tools/perf140/loading/DEFERRED-DRIVE-REGRESSIONS.md`; none was executed while
Eco43696 remained live. This turn made source progress, not a benchmark claim.

On the next continuation, the user explicitly confirmed they were still playing
and asked to keep preparing. Heavy tests, source-tree staging/copying and engine
or native builds therefore remain deferred. Root described a first six-run,
approximately15–20minute batch (two functional clear gates, two recorded walks,
two settled graphics windows); this batch has **not started**. Longer new-engine
particle build/acceptance is separate from that first batch.

The offline drivers now have explicit ordinary/eligibility/full
`ParticleEngineReads` selection. Replay sets `NWN_PARTICLE_READS` in its child
environment even for ordinary, preventing inherited experimental settings from
leaking into a control. A post-window helper and route reducer require actual
native mode/ABI/features and operation counts before accepting a requested fused
benchmark; unsupported or missing routes cannot pass as an optimization. These
checks establish selection only, not correctness, visuals or a timing win.
Legacy projects without the helper remain explicitly ordinary controls.

The exact descriptor label `engine-synchronous-particle-reads-v2` is accepted
alongside the existing private engines. All engine/build/module/source/compiler
and runtime-feature guards remain. The source-prepared producer build tools use
a separate normal `module-source-proof.json` pointing at the actual future
compiled module, preserving the immutable source freeze's different schema.
The readback helper adds no frame callback or per-frame Variant snapshot.
Verified pre-edit driver copies are in
`root/engine-read-flag-driver-before-v1/receipt.json`. Only Node syntax and the
PowerShell AST were checked; no replay/native process or build ran.

Loading gate source review strengthened actual process/library activation,
physical ray counts, original byte pins and authenticated golden corpus receipts.
The separate actual-engine particle fixture is being prepared as test-only
source, without widening the frozen production ABI. These sources still need
real compilation and functional execution once the PC is available.

### Source preparation complete for the next execution window

The fixture/preparer package is now frozen at
`particles-agent/synchronous-engine-read-fixtures-v1/source-manifest.json`, SHA256
`67f74d565e598fe25a90ccace8c4b8d9e34bf39783fab0da727d09f1c40fd38b`.
It contains executable actual-engine oracle source and a separate test-only
bridge, plus distinct production and fixture source preparers. Normal and
exactly declared outside-tree error cases are separate invocations. Full-ID
reuse, live visibility/processing, raw matrix words, worker-domain rejection,
callback/RNG/state/geometry order, and consumer clear/reinitialization are covered
in the **unexecuted source**. Actual module hot-unload remains explicitly unproved.

Root's `stage_engine_reads.mjs` is also source-prepared and Node-syntax-checked,
not executed. It requires a reviewed future production build receipt, the exact
five frozen native overrides, matching prebuild/compiled source roots, strict
compiler flags, and no test-only access. It composes onto the existing builtin
renderer parent and adds only the cold readback. Relocated metadata preserves
the true original compile root/receipt and does not pretend a new compilation
occurred in the renderer copy. Independent loading review caught the need for
the explicit prebuild-project and binary-location guards; both are now present.
No production or test DLL for this interface exists yet.

Eco43696 subsequently disappeared, but the user answered **Keep waiting** to the
new availability check. Therefore process disappearance is not permission to
start testing: keep all builds, heavy staging, headless tests and GPU runs off
until the user explicitly makes the PC available. The local Prelude server35640
remains preserved. All scoped agents finished their source tasks and are quiet;
no test process was started during this hold.

A read-only byte/report audit corrected an old fixture limitation. The sealed
current `capture-YaH3xf/catalog-1` really contains `inc_common:2069`,10332bytes,
SHA256 `20ecd0437d31e26ee797c83422c83870d62c7f910ca3bffc2473553401575337`.
Its actual captured blob was read and verified; no installed-resource substitute,
copy or capture repair was used. The existing endpoint ordinary A1 report uses
this same capture/timeline and records configured native output, no error and
an empty unsupported-material list. This establishes the current capture has
the bytes and that saved run bound the requested contract, not complete original
shader parity. Audit: `reports/native-perf140-current-postprocess-byte-audit-v1.json`.
The older synthetic-fixture shader gap below must not be applied to this cohort.

Execution hold audit: the same unavailable test window has persisted across
three consecutive goal continuations. All three agents have now returned their
source-only handoffs, and the next evidence-dependent work is actual compile,
functional and matched replay execution. The user explicitly asked to keep
waiting even after Eco exited. Do not use more speculative candidates or status
restatements as substitutes for these gates. The goal is unfinished and needs
the user's availability change before this prepared batch can proceed. No
agent/compiler/test handle remains active; original local server35640 is kept.

### Latest checkpoint: private threaded renderer and loading candidates

The user-driven `live-threaded-test-v2` ran the measured private ce2d engine,
DLL672 and corrected builtin registry with the launcher parent retained
(owned shell session 22093). The user subsequently authorized closing the
replacement for local tests. It had already exited cleanly with host success
true and shell exit zero; the editor 25060 and original server 7568 were
reverified running. The isolated launch leaves normal defaults unpromoted.
The first Electron attempt inherited command-line
mode and exited before startup; the next detached attempt reached character
selection but ended on a local TCP reset during world admission. Both failures
are preserved. The parent-retained attempt has entered the world successfully;
the reset cause is not proven by that observation alone. No automatic public
login or movement was performed.

Live walking exposes a distinct bottleneck: fully admitted frames of 301.612,
193.287 and 161.678 ms contain respectively 267.997, 178.116 and 144.810 ms
inside `keyboard_preview`. Their exact worst-frame GPU spans are about 4 ms;
asset workers/queue and new shader deltas are zero in those frames. The timer
contains collision query construction, path planning and prediction publication;
their individual costs still need separation. This frozen renderer uses
`drive_spatial_enabled=false`, so the active flat collision query scans every
known entity and constructs obstacle lists for each prediction. An existing
experimental indexed implementation is present but not selected in this run.
The loading agent is source-auditing that actual path. Preserve collision
semantics and authoritative movement, rather than bypassing collision checks.
The private indexed derivative now passes fresh ce2d checks: 48,898 broad
checks plus 184 supplementary CLI/subphase assertions. Its root replay stage is
`drive-replay-fenced-v1`, manifest
`d7a9c7871d7dfe896ee8077370c57e39efd2ecc6b395bb443dfb2ba22f35046f`;
entry compile is clean. The existing default remains legacy; select
`--drive-collision=indexed` before world creation. Query/path/shape/tile/height
and full/delta/motion publication spans are present in both routes. The first
indexed walking trial is rejected for promotion: query setup fell from a
219.363 ms peak to 0.117 ms, but repeated model-group enumeration during slide
probes increased the path peak from 209.551 to 1,239.960 ms. The worst indexed
frame performed 495 clear calls and 220,275 model-group inputs (about 445 per
call). These are frame aggregates that can contain multiple captured inputs,
not the cost of one input. Both diagnostic runs accepted all 360 recorded
inputs, retained 1,918 entities, and exited cleanly. See
`reports/native-perf140-drive-comparison-v1.jsonl` and runs
`native-perf140-drive-legacy-movement-a2` / `native-perf140-drive-index-movement-b1`.
The successor collects a conservative geometry neighborhood once per input
and reuses its exact narrow-phase data across slide probes. It passed 49,315
headless checks and a same-project paired recorded-walk trial, all 360 inputs
accepted in both runs with 1,918 entities / 225 tiles complete. Peak keyboard
prediction fell from 396.044 to 217.352 ms; query 189.307 to 29.623 ms, path
206.466 to 187.588 ms. The representative 380-clear / ten-input frame now does
ten collections and 4,450 model-group inputs, with 2,280 obstacle inputs versus
442,320 on the legacy route. The reduction is useful but 217 ms remains an
unacceptable stall; height checks alone still reach 63.474 ms. These diagnostic
frame aggregates can batch multiple recorded inputs and are not single-input
costs or unprofiled FPS acceptance. Root retains the successor privately at
`root/drive-envelope-fenced-v1`, manifest
`cce71cea6e3ae8116d4747c97f1e161eed9350cd85386dc372578d9f6d4cdfc1`.
See `reports/native-perf140-drive-envelope-comparison-v1.jsonl`; both underlying
runs are clean and retain original loading/timing lateness rather than hiding it.
Next isolate compiled narrow-phase work while retaining the original height
callable, then test a separately exact height implementation. The existing
nearest-ray kernel has different first-face/material semantics and cannot be
substituted. Root's
offline replay now supports a
bounded detailed-profile observation log, written after child-exit handling,
and recorded movement input forwarding, for the matched legacy/indexed trial.
The first diagnostic run, `native-perf140-drive-legacy-movement-a1`, is invalid:
two log writers collided at finish. Its artifacts are preserved; the clean A2
repeat uses one bounded serialized writer and refuses any existing run artifact.
Sealed complete log prefix and exact-frame extracts are
`reports/native-perf140-live-walk-v1.performance.jsonl` (SHA256
`3d2a9fb22c7bd3ee4162567825e32db62f16b5b3052146c49bae7409c436b6e8`)
and `reports/native-perf140-live-walk-v1.json`. Windows overlap; they do not
establish a unique hitch count or matched live FPS improvement.

Combined loading now passes the same 13,307 correctness checks on both the
stock and corrected custom engines. Five paired captured-eight-tile windows
measure cold request time 396.359 to 295.500 ms and worker time 318.577 to
210.451 ms. Complete-room cold runs do not demonstrate a loading improvement:
playable 4,244.991 to 4,292.899 ms and final raw publication 22,454 to 23,249 ms,
with matched steady 110.83 versus 111.25 FPS. Do not generalize the small-set
25% gain to world loading. A two-ended offline TCP_NODELAY probe also failed to
remove the roughly 95–99 ms acknowledgment spacing; keep it experimental.
The failed restricted control (shader cache/certificate access) is preserved;
its clean repeat used the ordinary Windows access context.

The separate typed particle-boundary candidate passes 49,918 native checks.
Four unprofiled full-room runs on the same copied project/engine/DLL completed
cleanly; the first control's small camera mismatch excludes its 92.72 FPS from
the matched comparison. The repeat control and both typed runs match the strict
view and retain 5,968 draws / 353,308 triangles: control 105.88 FPS, typed
108.37 and 107.49 FPS. These single-window observations suggest only a modest
1.5–2.3% difference, not a proven large gain. Typed B1 had one 55.231 ms hitch;
B2 had none over 50 ms (worst 13.514 ms). Actual post-window native readback
confirms 1,829 typed entries selected/advanced in both typed runs, zero in the
control. The captured views were inspected with no obvious lost scenery or
effects; this is not full visual parity acceptance. See
`reports/native-perf140-typed-comparison-v1.jsonl`. The candidate remains private,
unpromoted, and does not meet 140 FPS. The authored-light V4 candidate
passes 1,714 checks but has no GPU comparison. Its close-during-writer negative
control reproduced a retained-registry publication error; a separate GDScript
successor passes 15 close/reentry checks plus the original 1,714 regressions.
Use that corrected adapter before any promotion. Both remain private. The one-shot live rig join
resolves all 56 owners: all 34 manual-only rigs are generated fx_placeable01
lights (31 static plans, three dynamic); two genuinely idle rigs are BoatHack.
This identifies a separate possible publication optimization without proving
its speed or correctness. Neither it nor untested accountant changes are
included in the user's live build.

The isolated original-local headless control `native-perf140-local-control-v1`
completed successfully with the copied ce2d engine, DLL672 and builtin registry;
this is functional connection acceptance, not a visual or FPS comparison.

A separate engine font ownership correction passed actual GPU checks with the
same pinned Arial bytes: 115 in Safe mode and 128 in Separate mode, all clean.
The unchanged engine in Separate mode reproduced 24 exact atlas pixel failures
and retained the canonical Image across queued release. Receipts are
`root/native-perf140-font-upload-fixed-safe-a1/receipt.json`,
`root/native-perf140-font-upload-fixed-separate-a1/receipt.json`, and
`root/native-perf140-font-upload-old-separate-a1/receipt.json`, under the private
cache. The fix snapshots each queued atlas upload while retaining the original
canonical atlas, texture RID and dirty policy. This is a correctness result;
it does not prove the cause of live empty-image errors or a performance gain.

The corrected light-field close adapter is staged at
`root/light-fields-close-fenced-v1` (a9a15c7dbe49f8313332dc52058c8b08e476c0c9f53136541f511af4fadc8d41),
and generated-manual V5 at `root/generated-manual-fenced-v5`
(fecfdd98313ec4c4f8f1ff41ee9e48c3134f9860188ab7e920288cdca434c299).
Both entry points compile cleanly. V5 passes 12,424 functional checks and avoids
the V4 no-token revision write on ordinary actor paths; it reuses DLL672 and
has no performance acceptance yet. Explicit replay flags and end-window mode
readback are prepared, with verified driver backups in
`root/manual-flag-driver-before-v1`. Normal launch defaults remain unchanged.

The corrected light-field cohort then completed four unprofiled graphics runs,
all clean with zero >50 ms hitches and 5,968 draws / 353,308 triangles. The first
strict-view pair is a regression: pull 109.906 FPS / 9.0987 ms, published
105.737 FPS / 9.4574 ms. Repeats are 110.327 pull / 106.216 published FPS, but
small camera drift excludes them from a second strict-view comparison. Actual
readback confirms 576 cached members and zero reflected reads in published
mode; the first interval has 5,389,452 field hits and 1,796,698 capability reads.
This work-count reduction did not improve frames. **Do not promote V4.** See
`reports/native-perf140-light-fields-comparison-v1.jsonl`. A source-only successor
investigates an exact COW source-pointer/length equality fastpath with the same
value fallback and script/token invalidation; its gain remains unproven.

The current particle census also corrects an important interpretation: the
earlier 1,649 clock-domain "unbounded" rows are not evidence of unbounded
particle radii. Actual Step results show 1,829 prepared, 1,159 checked, 444
finite nonchunk rejects, 715 admitted and 670 chunk bypasses. The effect-mask1
cohort is zero. Twenty-three rejected rows contain 347 of 709 sampled channels.
This establishes a concrete cohort to investigate, not its CPU savings. Native
radius calculation follows controller publication and global wind updates;
an old radius or zero sentinel cannot safely drive earlier admission. Preserve
current bounds, pending changes, independent clocks, source history and unknown
fallbacks. Dossiers and the source-only plan retain these limits.

Process revalidation later found the previously protected editor 25060 and
server 7568 absent, and UDP5121 free. Neither was stopped by these tests.
The original local Prelude server was restarted as PID35640, non-public;
preserve this replacement server for subsequent local checks.
The copied envelope renderer then passed two headless original-local connection
and movement cycles, including movement during object streaming: native/server
walk distances 1.500033259 / 1.500033333 metres in both cycles, no world errors,
workers zero, finish acknowledged, native exit zero and source guards clean.
`reports/native-perf140-local-envelope-v1.json` and its native report retain the
proof. This exercises authoritative click movement and the unrestricted repair
query, not held-WASD against a live server; recorded inputs and the headless
oracle cover the preview route separately. No public connection was performed.

Particle collection research also narrows the remaining architectural gap.
The original camera-volume collector fills an emitter bucket before
AnimateParticles. Empty-wrapper work still occurs for collected owners, not
necessarily every registered owner in an area. Our existing admission branch
already rejects before simulation, but only after readiness, clocks, sampling,
pose and wind setup; chunk/unknown-wind owners bypass that branch. Moving a gate
earlier requires current conservative bounds, pending command/history/callback
semantics and independent model/controller clocks; no speculative collection
or room-hiding rule has been enabled. See the particle tools'
`upstream_admission_audit.md`. A separate font dirty-atlas Image snapshot engine
is in private functional validation; the live eight empty-image update errors
remain a real issue, not a proven cause of the earlier TCP reset.

The corrected private builtin-light runtime completed matched unprofiled
30-second windows at 108.87 FPS with the extension registry and 112.09 FPS
with the builtin registry (9.185 versus 8.921 ms mean frame time). Both retain
5,968 draws and 353,308 triangles, the full recorded room, the established
lighting/effects, resolution, secondary screen and unfocused window policy.
Both finish cleanly with no measured frames over 50 ms. Receipts are
`native-perf140-builtin-light-off-a2.json` and
`native-perf140-builtin-light-on-b1.json`. This is the best accepted private
checkpoint, not a normal-launcher or live-server performance claim. The target
remains 140 FPS; a repeat and original-local gameplay acceptance are pending.

The experimental adapter startup failure was a missing parent constructor call,
leaving its default registry null. The corrected adapter calls `super()` and
passes both registry-mode lifecycle checks. It is distinct from the reproduced
threaded palette upload ownership bug: retaining a mutable Image after queued
upload produced 13 pixel mismatches in the negative control; immutable upload
images pass both Safe and Separate rendering modes. The palette fix and private
engine changes are not yet promoted. The ordinary UI draw fence and compact HUD
counters are integrated independently, with verified backups.

Three independent cold eight-tile loading experiments now have clean five-pair
measurements: static emitter routing is 11.2% faster, bulk finite-float stream
decoding is 11.8% faster, and deferred raster cache writes are 13.6% faster.
These are separate experiments; their percentages must not be added. Each
preserves packet/descriptor and error behavior through focused native checks.
The combined candidate is staged against the corrected builtin-light runtime;
its 15 isolated native correctness gates pass 13,307 checks with clean logs,
exits and unchanged source/capture guards. Its frozen manifest is
`1f0fd6a94d4132ad8c14c822fefa69d7720ba7fadd7ab32a536ac709401d92f9`;
see `combined-loading-gate-v1-receipt.json`. Controlled five-pair combined
timing is next. Combined latency, complete area loading and local
authoritative gameplay remain pending. The raster-child
storage prototype stays disabled because its preparation latency regressed.

The latest managed particle eligibility V3 off/on windows also finish cleanly:
107.00 versus 108.21 FPS, with 5,960 draws and 353,292 triangles in both. The
actual route reports 1,829 attempts, 1,822 retained hits, 948 current anchor reads
and seven fallbacks. This establishes activation, not an accepted speed gain:
the off run has one 101.5 ms hitch, and cross-process camera drift fails the
strict view-comparison gate. Preserve both reports
(`native-perf140-eligibility-{off-a1,on-b1}.json`) and do not promote from this
pair. The ordinary launcher still uses its existing engine/native outputs.

### Threaded UI and follow-up component checks

The private threaded engine's offscreen icon ordering correction now passes
113 Safe-mode and 162 Separate-mode checks, including byte-exact RGBA/bounds
comparisons for 24 original button/chat rasters, model reuse, and cancellation
immediately after renderer submission. Receipts are
`native-perf140-icon-art-{safe,separate}-v4`; V3 retains the queued compositor
resource until its arm callback completes. Earlier fixture failures and the
restricted Windows certificate-store failure remain preserved. This is
original-art/lifetime acceptance, not complete gameplay acceptance.

Further 30-second Separate-mode offline windows keep 5,968 draws, 353,308
triangles, resolution, scene counts, secondary monitor and unfocused state.
The particle lease candidate's same-project/DLL off/on/off results are
106.34 / 109.20 / 107.39 FPS, with no measured frames over 50 ms. Tiny camera
float drift between some processes is explicit in the comparison receipts;
strict cross-process view matching is not claimed for those rows. The small
lease result needs confirmation and runtime mode readback before promotion.

The retained-common-input experiment gives 109.03 FPS off and 108.85 on;
guarded model-pose publication combined with leases gives 105.88 FPS;
guarded material publication gives 107.78 FPS. These private candidates do not
establish a useful full-room gain and are not promoted. Do not combine them
merely because their functional tests pass. Ordinary source now includes the
small HUD readiness/count view and the independently accepted UI draw fence.
The latter has a verified compressed before-backup and clean current-main entry
compile plus 15 focused lifetime checks. See
`reports/native-perf140-icon-fence-integration-v1.json`; engines, launch defaults
and shared native outputs are unchanged by this two-file integration.

The loading prototype preserves complete original packets and descriptors for
eight captured tiles while reducing saved artifacts from 9,234,456 to
3,828,880 bytes (58.5%). Warm readback reads 13 unique raster children and
shares 31 repeated references through the existing decoded store. The retained
graph estimate changes from 27,247,544 to 16,307,024 bytes; this is not RSS.
See `raster-child-acceptance-v1-receipt.json`. Latency must be measured
separately: a first timing set overlapped another headless gate and is rejected
for latency conclusions. The clean exclusive five-pair repeat finds prepared
fresh-process reads essentially unchanged (194.008 to 193.144 ms) and preparation
slower (558.327 to 689.736 ms). Keep raster-child storage off as a speed fix.
The next loading candidate instead avoids proven duplicate work: original eight
tiles invoke eight uncached static model preparations plus five actor-model
preparations; routing emitter models to the existing actor path invokes only
three static and five actor preparations. The 225-check oracle preserves full
calculated packets and five malformed-resource error strings. Two clean
CPU-exclusive five-pair sets now show ordinary deferred-policy cold requests
436.369 to 387.294 ms (11.2% faster) and model work 146.422 to 94.585 ms;
prepared/process-warm times are unchanged. Sync attribution independently
shows 491.054 to 422.517 ms (14.0%). These are eight-tile results, not a live
area-loading claim. Full-area/runtime adoption is still pending.

Next architectural investigations are a main-thread builtin scene-read batch
that preserves every live check and opaque-callback barrier, static leaf
submission census, and conservative occlusion from actual opaque geometry.
Forward+ already auto-instances matching adjacent surfaces, so leaf count
alone is not a saved-draw estimate. Mobile's eight-light-per-mesh limit reaches
our Godot `light()`-based enhanced surface path; an unchanged setting does not
prove equivalent lighting. No renderer switch, guessed room hiding, empty
emitter skip, or reduced-light workaround has been promoted. **140 FPS remains
unfinished.**

The post-window `lease-census-profile-v1` dump verifies managed pose reuse is
actually enabled: 3,644 managed hits, zero refreshes and 12 live transform reads
in its final frame. The instrumented main callback envelope is 9.535 ms,
including particles 4.500, light history 1.686, rigs 0.938 and world 0.745 ms;
renderer CPU 3.694 and GPU 3.512 ms overlap these. These are profile attribution,
not unprofiled throughput. There are only 126 processing nodes among 41,669
nodes, so hierarchy size is not a callback-count estimate. The static census
finds at most 416 small-spatial-group instance-slot removals, not saved draws.
The actual lighting owner is the compiled `focus_lighting_native_input_candidate`
adapter selected by `live_world`, not the retained GDScript base implementation.

The graphical front/back occlusion probe confirms a real correctness obstacle:
Godot's two-sided occluder hides a target through a rendered backface-culled
wall (green without occlusion, black with it). Front-facing and truly two-sided
controls remain red and reduce two draws to one. Preserve that failure evidence;
do not enable generic all-tile occluders. The optional builtin scene-read module
has a separate privately archived engine, preserving the corrected-RD baseline
and production engines. The first batch regresses from 107.50 to 90.60 FPS;
it adds allocating ownership ancestry walks and redundant per-use row lookups.
The corrected optional engine uses an O(1) public C++ cached-owner accessor
without new Node fields or script API, and direct slot handles validate immutable
rows once. It passes 30,331 native checks; its full-room enabled run gives
108.43 FPS with one 98.79 ms hitch, but its paired disabled baseline failed
before steady state, so no comparative gain is claimed.

That failed baseline logs 12 empty-image texture-update errors. Source audit
finds another real threaded-ownership problem: the light palette queues an
Image reference and then mutates the same Image object on the main thread.
Initial creation and updates both need independent immutable Image objects
backed by COW data; keep the GPU texture and palette values unchanged. A focused
ownership/lifetime/render stress candidate is pending. This is another reason
the private threaded engine is not yet the ordinary launch default. Do not
hide engine errors or count this failed run as benchmark acceptance.

### Clean private threaded-engine checkpoint

The private same-source engine A/B build is complete. Empty Vulkan probes in
`rd-lifecycle-probe-v2` show pristine safe clean, pristine separate with the
original finalize/leak defect, and patched safe/separate both clean. The patch
returns the main RenderingDevice's ownership after the render task has joined;
it does not remove guards. Official engine binaries remain unchanged. Exact
source/archive/build/SDK scope and receipts are in
[the engine lifecycle audit](tools/perf140/render/RD-LIFECYCLE-ENGINE-FIX.md).

Full room runs with the patched private engine, same source/view/viewport,
all 1,918 entities / 225 tiles, 5,968 draws / 353,308 triangles, MSAA2 and no
detailed profiling:

| 30-second receipt | Mode | Mean ms | FPS | P95 ms | >50ms |
| --- | --- | ---: | ---: | ---: | ---: |
| `native-perf140-custom-safe-a1` | Safe | 16.520 | 60.53 | 20.332 | 0 |
| `native-perf140-custom-separate-b1` | Separate | 9.536 | 104.87 | 13.134 | 0 |

Both complete the timeline, finish acknowledgment and normal process exit 0
without engine/lifetime errors, with frozen source/runtime guards. This is the
first clean substantial throughput result, still short of 140 FPS. The private
build retains Vulkan/OpenGL; absent Windows SDKs disable AccessKit/WinRT/ANGLE,
and D3D12 was explicitly disabled for this Vulkan-only experiment. It is not
yet a full-feature production engine replacement or live-server acceptance.

**UI acceptance remains open.** Shutdown screenshots happen after UI close and
cannot establish parity. A new pre-window capture runs before measurement reset
and before teardown. The native-clock attribution run also shows incomplete
party art/striped GUI panels in this earlier image. Matched old-kernel safe vs
separate images and offscreen UI render/readback fencing are being investigated;
the threaded engine has not been promoted on FPS alone.

`native-perf140-clock-profile-b1` is attribution only: all seven clock calls are
native/direct with zero opaque/fallback calls, about 131 RNG draws/frame are
native/direct, and pose callback invalidations are zero. There are still about
2,782 live pose reads and 876 within-call reuse hits/frame. Profiled particle
callback is 5.21 ms (eligibility/clock 1.36, pose 1.04, controls 0.46, simulation
0.87, geometry 0.54), rigs 1.13, world 0.94 and root 0.85 ms. These child spans
overlap their parent; do not sum them as exclusive frame time. Native cosine is
not an active barrier in this room and is not being implemented speculatively.

### Secondary-monitor and separate-thread checkpoint

Two further throughput candidates have no demonstrated gain and remain private.
The [terrain shadow proxy](NATIVE-140FPS-SHADOWS.md) reduces draws 5,968→5,689
but measures 18.610 ms / 53.73 FPS. The settled-admission candidate stops
scanning 2,048 resolved keys on every frame (119 focused original/candidate
checks; 67 full scans in the complete replay) but measures 18.859 ms / 53.02
FPS. Both preserve the complete view/content and pass delivery/lifecycle gates.
Neither is being promoted on these single observations.

The wrong-thread shutdown defect is independently reproduced by empty
no-extension Vulkan projects, in both editor/debug and official release
engines: safe mode exits cleanly; separate mode leaves two ObjectDB instances
and rejects RenderingDevice::finalize on the main thread. Fresh verified Godot
source, pristine backup, portable build tools and an isolated seven-line
ownership-return patch are prepared. No ordinary engine binary has changed.

Official release templates ignore `--script` when path overrides are disabled.
The first full PCK attempt launched the ordinary main scene and never reached
the replay handshake; its failed receipt is retained. A tiny release probe
confirms the supported global MainLoop class route, with a nonempty harmless
startup scene. A 90-second pre-handshake deadline now bounds future owned
startup failures. No performance claim is drawn from the failed release run.

`native-perf140-cold-monitor-a2` is a clean 30-second offline run on the
largest secondary monitor: 18.683 ms / 53.52 FPS, P95 22.823 ms, no >50 ms
hitches, with the complete 1,918 entities / 225 tiles and unchanged 5,968
draws / 353,308 triangles. The explicit main-thread witness reports
`RenderingServer.is_on_render_thread() == true` in the default mode.

The exact same source in `native-perf140-cold-separate-b1` reports 10.926 ms /
91.53 FPS and P95 14.970 ms, with the same view, geometry counts and no >50 ms
hitches. The main-thread witness now reports false. **This candidate is not
accepted:** normal shutdown logs a RenderingDevice::finalize wrong-thread
error and two leaked ObjectDB instances, even though timeline delivery and the
native finish handshake succeed and the process exits 0. The render agent is
investigating lifecycle/ownership before any promotion. This is a substantial
experimental throughput result, not a claim that the ordinary client now runs
at 92 FPS or has reached 140 FPS.

The earlier cold export had optional missing metadata logging errors after
measurement. A guarded `has_meta` export passes nine focused native checks;
the clean A2 run exports all 1,829 emitters. 1,490 are dormant destruction
explosion emitters, with no active particles or selected animation channels.
Only 150 endpoints belong to direct tiles. That shifts particle investigation
toward broad static-owner pose/RNG work, rather than a tile-only cache or
discarding effects. Shared native libraries and the protected editor/server
remain unchanged.

### Renewed-goal measurements, 2026-11-05

The new driver finish handshake and source/runtime guards pass in the complete
generation-2 room. `common-v1` freezes the successful recorder's native renderer
and adds begin/end view witnesses only. All rows below use the same capture,
3440×1369 viewport, camera (within floating-point tolerance), 1,918 entities,
225 tiles, ForwardPlus/Vulkan, MSAA2, VSync0, uncapped and unfocused. Detailed
profiling is off for throughput rows. Each steady window is30 seconds.

| Receipt | Mean frame ms | FPS | P95 ms | >50ms |
| --- | ---: | ---: | ---: | ---: |
| `native-perf140-baseline-a1` |18.635|53.66|22.661|0|
| `native-perf140-lamp-b1` |18.890|52.94|22.886|1|
| `native-perf140-combined-b2` |18.964|52.73|22.974|0|
| `native-perf140-baseline-a2` |18.593|53.78|22.638|0|
| `native-perf140-counters-b1` |17.792|56.20|18.978|0|
| `native-perf140-loading-all-b1` |18.528|53.97|22.614|0|

These single-run observations **do not establish a gain or regression**. Neither
lamp publication alone nor the combined first wave has demonstrated the needed
improvement. None has been promoted. The combined run retains5,968 draws and
353,308 triangles; weak recovery has zero hits in this initial room, so retaining
evicted identities cannot explain a steady improvement here. Its earlier `b1`
attempt failed on a loopback write reset before area/model creation, with no
engine/native crash; that failed receipt remains intact and is not an FPS result.

`native-perf140-profile-a1` is separate attribution evidence, not clean FPS
acceptance. Its final240-frame rolling window has particle callback4.82ms,
light history1.86ms (registry1.52ms), rigs1.31ms, world0.99ms and root1.19ms.
Frequent full diagnostic snapshots account for0.79ms averaged across all frames
and about4.49ms when present. Rendering CPU is4.79ms and GPU3.70ms. These spans
overlap and must not be summed into an exclusive total. The engine render-thread
witness reports the main thread. Larger event-owned input retention, diagnostic
cadence, and submission/threading changes remain investigations.

Private follow-up candidates include directory creation avoidance, first-use
hierarchy reuse, Controls copy removal, live common-input lookup, and a combined
particle candidate. Their dedicated correctness gates pass, but real-area/FPS
and visual acceptance remain pending. The directory fixture reports2.23→0.127ms
per repeated configure; its deeper fixture path means this is not a promised
real-area speedup. HUD counters pass15 clean isolated native checks plus a full
entry-point compile check; periodic detailed observation payloads remain intact.
Staging manifests: `reports/native-perf140-{first-wave,followup}-candidates-v1.json`.

The HUD counter change is now integrated after the A1/B1/A2 comparison,15 clean
native contract checks and a full current-entry compile in a private current
source/runtime capsule. Receipt `reports/native-perf140-hud-integration-v1.json`;
compile `.cache/native-140fps/root/entry-check-hud-current-v1/receipt.json`.
Only the HUD sample and detailed-observation boundaries changed in the existing
entry; reverse-patch hashing proves every other original byte was preserved.
Backup `backups/native-perf140-hud-before-v1.zip` SHA256
`c8a7a74adceff1a85eb6a32430938a103c21a32c7fe55ed5de2e9b56a2e3c5f4`.
No native output was rebuilt/promoted. Detailed observations and shutdown data
retain their full contract. No live-client validation is claimed.

The loading-all run reaches playable3.664s versus baseline4.255s / repeat4.145s;
this is promising entry evidence, not a repeated acceptance result or steady
FPS gain. The sparse GDScript readonly-loan candidate is rejected for performance:
actual recorded warm tile/furniture/door copies are slower despite its rigorous
mutation/lifetime contract. Job-digest, source-packet, raster selection, material
publication guard and stabilized Part publication remain private experiments.
See their owned agent notes for focused receipts and exact limitations.

Particle census `native-perf140-particle-census-b1` is complete/clean. Of1,829
eligible emitters,1,695 are empty before/after,134 nonempty and103 produce geometry.
Only7 use actor clocks;173 use modulo static clocks and1,649 unbounded clocks.
670 are chunks; their ordinary sphere gate is currently excluded. The binary's
chunk radius includes current child-Gob spheres, so an unconditional chunk or
empty-emitter skip is unaccepted. Cold per-origin/tile/flags export is queued.

The pushed-light GPU `native-perf140-light-inputs-b1` is invalid: loopback read
reset during partial replay. Do not use its partial77FPS as a gain. Registry
component tests pass, but no source evidence yet attributes the transport reset
to that candidate. Keep interrupted evidence intact and retry/isolate.

Monitor policy correction: the early rows above were matched on monitor2, but
startup had been on monitor0 and replay resizing subsequently migrated to the
primary. They remain historical throughput observations; do not claim they met
the requested non-primary placement policy. Monitor0 is1920×1080, monitor1 is
3440×1440 (both secondary), monitor2 is3440×1440 primary. The launch helper now
selects the largest secondary. Private `monitor-safe-v1` anchors replay resizing
back to its startup secondary and records actual placement/render thread. Future
graphics acceptance explicitly rejects a primary-screen migration; establish
fresh monitor1 baselines and do not compare different monitors as an isolated gain.
Monitor helper backup SHA256
`5230bb5990ff9b54799fcc134e6e9d24838f207248cf574d3f79d96b2ef44321`.

Root owns a private terrain shadow-only proxy experiment in
`tools/perf140/shadows/`: preserve original visible/pick/collision surfaces,
merge proven immutable opaque caster triangles with retained CPU geometry, and
leave alpha/deformed/mirrored/unproven parts on the original shadow path.
`shadow-unit-v2` passes42 structural/atomic-fallback checks; the v1 bad material
property failure is retained. No area integration, visual acceptance or FPS
claim yet. Its normal-bias/rounding, owner immutability and lifecycle contracts
need explicit graphical evidence before promotion.

The [stationary checkpoint](reports/native-dense-stationary-checkpoint-v3.json)
records the user's latest Arelith login, with no root-issued movement/gameplay
commands. Roughly 1,984–1,985 entities and 225 tiles settled around 37–40 FPS.
Representative instrumented callbacks measured:

| Owner | Approximate CPU time per frame |
| --- | ---: |
| Particle callback | 5.7 ms |
| Inclusive native particle presentation, inside that callback | 5.5 ms |
| Light history | 3.3 ms |
| Light registry polling, inside light history | 3.0 ms |
| World updates | 2.0 ms |

These are instrumented observations. Do not add child spans to parents, equate
outside-callback time with GPU work, or sum asynchronous CPU/GPU counters as
exclusive frame phases. Overlapping rolling windows are not independent samples.

Four fresh offline graphical runs completed 2,741 entities and 192 tiles, but
their total FPS differences are unaccepted: cold-run render/particle counters
varied and final focus state differed between baseline and candidate. Preserve
those runs; correct the experiment rather than treating the apparent gain as a
result. Lighting publication itself measured approximately 1.0 to 0.14 ms.

## Work order

The user's subsequent direction makes **duplicated/needless work and visibility
policy research the immediate priority**. Trace a whole frame and area entry
against the original binary before choosing further mathematical microchanges.
Inventory repeated entity/light/emitter visits, sampled fields and transform
conversions, already-culled work, copied state and recreated scratch/storage.
Keep necessary original work separate from avoidable work introduced by our
adapter/engine ownership. Measure invocation counts and time at those boundaries.

Also trace the original's spatial, tile/fog, object-visibility and animation/draw
gates. Loading/preparation, client-known state, animation, picking, shadow casting
and draw submission are different obligations. Do not introduce a guessed
"current room only" or player-line-of-sight rule as if it were native parity.
Godot frustum culling does not by itself suppress our custom CPU owners.

1. Make repeatable comparisons: identical camera/frustum, actual viewport, focus,
   graphics/particle settings, content closure and process contention. Separate
   empty prepared-cache, warm-cache, loading and fully settled measurements.
   Explicitly measure detailed-profiling overhead.
2. Split the native particle presentation cost into controls/pose, admission,
   simulation/collision, sorting/geometry and publication. Reuse persistent
   native state/buffers, avoid repeated conversion and inactive-emitter work,
   and test batching/threading where it actually removes the measured work.
   Preserve native effect order, lifetime, appearance and required semantics.
3. Remove unchanged light-registry work while retaining exact invalidation,
   visibility, animated-light, owner, frustum, property and fade behavior.
   Measure the existing unimported retained-registry candidate before accepting
   it. Recheck the corrected lighting rather than substituting ambient light.
4. Replace repeated full-world planning/snapshot scans with scoped memberships
   and updates at authoritative state/publication boundaries. Keep readiness,
   camera anchoring, area acknowledgements and lifecycle cleanup timely.
5. Reduce scene-node, callback and render-submission overhead. Inspect original
   binary culling, static/dynamic handling, retained geometry and draw methods.
   Use native/GDExtension batching where justified; keep engine calls on threads
   where they are supported. Do not blindly add workers around scene mutation.
6. Shorten indivisible model/template preparation and publication, especially
   synchronous scene packing. Reuse prepared models, caches and instanced data;
   bound main-thread work and prioritize player/nearby content. Cache absence
   only within the correct resource-catalog lifetime.
7. Validate movement/streaming under load against the original local server.
   The indexed collision candidate remains disabled by default until its cold
   indexing cost and gameplay behavior pass the combined gate.

Use Ghidra/REA to inspect the original's relevant implementation when evidence
is missing. Record what the binary actually proves, distinguish adaptations from
literal parity, and test the result rather than copying a presumed algorithm.

## Backups and live-session boundaries

Preserve all existing dirty and untracked work. Make verified backups before
noticeable shared changes. Broad foundational changes can be investigated and
tested in isolated copies; ask before promoting a drastic replacement to the
default method. Rendering, model preparation and UI remain native Godot/native
code, without JS scene staging.

The current manual run is `native-manual-1793855885809`. Preserve it while the
user is connected. No concurrent graphical benchmark, restart, shared native
output replacement or runtime source swap during this live session. Keep the
unrelated editor, original local server and other user processes untouched.

The user permits stationary Arelith profiling and performs the login. Do not
issue automated movement, gameplay or chat commands there. Exercise those flows
only on an owned original local server. Launches remain unfocused on a secondary
monitor. Credential contents must not be logged.

## Acceptance

- Focused native correctness tests cover every changed owner's state, missing
  resources, full/delta updates, removal, ID reuse, control changes, transitions,
  reconnects, cancellation and retirement as applicable.
- Original-local authoritative gameplay checks cover collision, movement,
  doors/interactions and streaming for changes that can affect them.
- Repeated alternating before/after runs use the same actual workload. Collect
  at least 30 seconds of fully settled samples per performance window, with
  independent runs rather than overlapping observations. Preserve rejected
  experiments, setup failures and their explanations.
- Record mean/p95/p99 frame times, FPS, >50 ms hitches, readiness and camera
  delays, full entity publication, queues, draw/triangle/node counts, memory,
  available CPU/GPU timing and cache conditions. Distinguish clean unprofiled
  FPS from instrumented diagnosis.
- Target representative sustained performance near the reported 140 FPS and
  materially faster streaming, without visual or gameplay regressions. If the
  target remains unmet, keep the goal unfinished and report the remaining
  bottleneck. A microbenchmark, lower counter, headless pass or 60 FPS result
  alone cannot complete this goal.

## Implementation status

- Active goal created; existing live/offline evidence carried forward.
- Missing-root admission and reduced lighting publication are integrated; the
  latter's paired correctness evidence is retained in the earlier goal.
- Finer particle spans are integrated; they locate cost but do not optimize it.
- Retained light registry: native correctness checks passed; copied-only
  graphical candidate ready at `.cache/native-dense-area/native-dense-registry-v2`;
  graphical acceptance pending.
- Indexed movement broadphase: isolated, ordinary-launch default off;
  cold-cost and original-local combined acceptance pending.
- The 140 FPS target and the streaming outcome are not achieved.

## First optimization and research checkpoint

The user finished the live test and authorized closing the replacement. Its
exact run/executable were verified; it closed normally with host/native exit 0,
`clean_exit=true`. Existing editor 25060 and original Prelude server 7568 remain
preserved. No public connection was opened for the following tests.

- [Settled-world planning](NATIVE-WORLD-QUIESCENT-PLANNING.md) now has a 236-check
  native correctness gate, four controlled 30-second graphical windows and
  two original-local connection/movement cycles for each of original/candidate.
  The original receiver/planner owns state; the new subclass retains only the
  proof that no preparation remains. Verified pre-integration backup:
  `backups/native-140fps-planning-before-v1.zip`, 14 entries, 94,392 bytes,
  SHA-256 `a0579968002401f5564351e39cb7db8c6ac43867b75189cd013c7617d48bf6ea`.
- In the instrumented captured scene, world callback means changed from
  1.792–1.813 ms to 0.231–0.237 ms. Total means changed from 21.209–21.314 ms to
  19.978 ms, roughly 47 to 50 FPS. Actual beginning/end view/frustum/focus and
  geometry counters matched in all four runs. They had zero >50 ms frames in
  their settled windows. There is no loading/pop-in improvement claimed.
- The candidate is selected by the normal `native_live_world.gd` entry after
  those checks. The exact original World remains its base class and oracle.
  The headless desktop proof's missing-map-art condition is identical in the
  baseline and candidate, so full UI acceptance is explicitly not claimed.
- No overall unprofiled FPS gain is established. The quiet candidate repeat
  averaged 20.893 ms versus a 20.781 ms baseline, but the baseline's actual
  beginning witness was focused and its ending witness was unfocused. It is
  excluded from a matched comparison. The first candidate also overlapped
  Ghidra work and is excluded. All four instrumented view/focus witnesses match;
  their scoped owner-time reduction remains valid. The consolidated evidence
  reducer preserves these failures instead of accepting mismatched runs:
  `reports/native-world-quiescent-evidence-v1.json`.
- The earlier synthetic fixture was missing recorded postprocess shader inputs; its
  `inc_common:2069` payload is absent even though presence is declared. This
  explains the unsupported postprocess profile in offline runs. Both variants
  share the limitation, while the last live session bound the inputs. Any
  repaired fixture must preserve the sealed original and verify added original
  bytes; disabling the profile check or fabricating bytes is not acceptable.
  This is historical evidence from that fixture. The newer sealed YaH3xf capture
  contains the verified bytes and configured output, as audited above.
- At this checkpoint, the unimported native pose-conversion cache primitive passed 10,166
  isolated C++ checks (including signed zero, each transform word, identity,
  nonfinite input, thrown conversion and randomized changes). Its source is in
  `native/experimental/particle_pose_cache.hpp`; it is not in the rendering
  path. No shared native output was rebuilt. Godot integration and performance
  remained unproven. This status is superseded by the integration checkpoint below.
- Fresh read-only binary dossiers are retained under
  `reports/native-140fps-investigation-v1/`. They establish BSP camera-volume
  collection before draw buckets; emitter simulation uses the collected list;
  tile visibility updates affect nearby object visibility and tile fog/fades.
  A separate room/portal wall-occlusion renderer and native loading gates are
  still being traced. Do not infer either from procedure names or fog alone.

## Visibility investigation checkpoint

The next trace identified the tile flag's inputs: the `PlayerInfo` handler's
0x200 section applies server-transmitted exploration state in delta, full-point
and bitset forms. Area construction initializes each tile with `(0,1)` and a
debug/DM-gated command reveals every tile. This is not proof of current
camera/wall line of sight. Separately, `CNWSMessage::TestObjectVisible` uses
range, creature visibility lists and special-case `ClearLineOfSight` calls;
that is server delivery policy, not a client room renderer.

The 0x2000 player visibility section also invokes a presentation-effect hook.
Its three flags must not be flattened into a guessed Boolean hide rule.
The detailed mapping and unresolved loading/render hooks are tracked in
[the visibility audit](NATIVE-VISIBILITY-WORK-AUDIT.md). No new room-hiding or
resource-unloading policy has been enabled from these incomplete observations.

## Integrated particle pose-work reduction

[Native particle pose reuse](NATIVE-PARTICLE-POSE-REUSE.md) is integrated after
verified backup, 22687 native engine checks, 10166 pure C++ checks, six matched
30-second offline graphics windows and two original-local connection cycles on
both the private candidate and the ordinary build. It preserves every live
node validation/transform read and reuses only unchanged finite conversion.
The two unprofiled pairs reduced mean frame time by 13.1% and 4.7%; the smaller
pair is roughly 55→58 FPS. Do not guarantee the larger gain or treat either as
live-room/native-binary parity. All scene/view/focus and main geometry counters
matched within their profiling policy, and settled >50ms counts were zero.

The newly published native subphases identify substantial eligibility/setup,
pose and control overhead around the actual particle simulation. Next split the
eligibility/setup residual before attributing it to clock callbacks, then test
earlier admission/retained state. Light registry polling also remains a major
owner cost. Do not enable guessed room hiding, skip live lifetimes, or remove
required lighting/effects to reach the target. The goal is still unfinished.

## Compiled light-input trial and live movement follow-up

The copied-only `native-dense-light-input-v3` candidate compiles the existing
per-lamp input polling into `NwnLightInputRegistry`, preserving live lifetime,
parent visibility, transform, range and raw-metadata checks each frame. The
existing native history solver and its publication tail are unchanged. It is
**not promoted to the ordinary renderer**. The candidate passed 463 exact paired
native checks, including 36 scheduled SceneTree frames. Two settled 30-second
instrumented offline windows had matched actual view/focus/workload witnesses:
mean frame time 22.911 to 20.584 ms; registry owner 4.086 to 2.054 ms. These do
not establish an unprofiled or live-room gain. Unprofiled paired comparisons and
original-local gameplay acceptance remain pending.

The user manually connected `native-manual-light-input-1793865483036` to Arelith.
Passive diagnostics show roughly 44–46 FPS with about 1,985 entities, 225 tiles,
584 registered lamps and 32 active history slots. Typical instrumented windows
show particle callback about 5.2 ms, registry about 1.6 ms, light-history total
about 2 ms, render CPU about 6 ms and GPU about 5 ms. These overlap. Periodic
bridge read/decode reached about 6 ms, apply about 3 ms and observation encoding
about 5.6 ms; those peaks are not every-frame means and do not prove the server
caused walking jitter. The user reports walking is very poor.

`reports/native-light-input-live-v1.json` and its frozen JSONL retain the live
observation. Sliding windows overlap and are not pooled. Ordinary logs lack a
persisted actual view/focus witness, so there is no matched live-before claim.
There are missing original bitmap/reference warnings, including `fxpa_cloud02`,
`alc_chunk_s01`, `alc_chunk_s02` and `px2_s01`; performance observations alone
cannot establish visual parity. Read-only module inspection confirmed the exact
private DLL SHA-256 `6d3c316a6bd92babb1d9cb4361599dd03d6724e11c745444b47551ac88a70634`.
The user session subsequently exited cleanly (native exit 0, workers 0, finish
acknowledged). Its ordinary host source guard is red because diagnostic work
changed the ordinary sources while the renderer used its copied project. The
separate `native-light-input-live-copy-guards-v1.json` verifies copied renderer
pins; this discrepancy remains explicit, rather than relabelling the host receipt
as a passing benchmark. Editor 25060 and original server 7568 stayed running.

At the user's request, [timed movement recording](NATIVE-MOVEMENT-RECORDING.md)
adds the missing movement input/dispatch, drive replies, native clock/frame
projections and post-decryption reliable packet boundaries to the existing
resource/presentation capture. The next run is user-driven, with original gaps
preserved in offline replay and late delivery reported. The first replay feeds
the native presentation boundary and ordinary native prediction; it is not a
full UDP/NetworkPeer simulator. No live walking fix or faithful jitter replay is
claimed yet. Seven Node cases and 20 native checks pass; the final copied session
entry compiles cleanly, with unchanged source/DLL guards. See
`reports/native-movement-timing-node-v1.tap` and
`reports/native-movement-timing-engine-v2.json`. No graphics benchmark, public
action or shared native rebuild was used for these checks. Preserve code and
runtime sources unchanged while the user makes the new capture.
