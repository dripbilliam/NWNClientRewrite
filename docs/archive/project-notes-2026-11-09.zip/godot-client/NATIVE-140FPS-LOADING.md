# Resource loading and live binding identity

The loading agent owns isolated preparation/cache/streaming candidates. No shared
renderer, native DLL, launcher, capture or original server has been changed.
The original captured world and all existing uncommitted edits are preserved.

## Candidate status

| Candidate | Correctness | Performance decision |
| --- | --- | --- |
| `weak-residency-v2` | 852 checks pass | No recovery opportunity in root's initial settled room; no FPS benefit established |
| `material-init-v2` | 7,738 checks pass | First-wave combination did not improve settled FPS |
| `cache-directory-v2` | 84 contract checks pass | Combined entry result is promising; needs repeated matched acceptance |
| `first-placement-v3` | 146 checks pass | Combined entry result is promising; needs repeated matched acceptance |
| `readonly-loan-v4` | 234 ordinary checks plus controlled mutation probes pass | Rejected: every measured captured model copied more slowly |
| `job-digest-v2` | 104 checks pass | Not timed or promoted |
| `material-pose-v1` | 2,080 checks pass | Awaiting matched rendered-scene measurement |
| `raster-selection-v2` | 59,055 checks pass | Fewer resource lookups; no timing or integration claim |
| `source-packet-v2` | 80 packet checks plus 118 job-integration checks pass | Not timed or promoted |

The reviewed loading combination reduced one matched playable-entry observation
from 4.255 seconds to 3.664 seconds, with terrain from 2.683 seconds to 2.234
seconds and unchanged scene/draw counts. Settled 18.528 versus 18.635 ms does not
establish an FPS improvement. Root owns the full receipts, repeated comparisons
and promotion decisions. No candidate in this document establishes 140 FPS.

## Evidence

The successful user capture's native report is
`reports/native-manual-light-input-movement-1793869228225.native.json`. Its final
world shares a cumulative pool with the prior area. It reports:

- 4,407 meshes created, with 311 primary mesh-binding evictions (limit 4,096).
- 672 textures created, with 160 primary texture-binding evictions (limit 512).
- 770 materials created, without material eviction in this particular capture.
- 550 templates created, with 38 template evictions (limit 512).
- First-publication material phases around 39–41 ms on three template peaks.

An eviction currently erases the pool's lookup binding even when an admitted
MeshInstance3D, material or template still owns that same Resource. A later exact
key lookup consults only the strong cache and can create a second live Resource.
The counts above establish real cache pressure, but do not alone establish how
many evicted keys were later requested. The separate controlled fixture proves
the recreation behavior. Root's captured-scene comparison must measure its actual
frequency and benefit.

## Weak-residency recovery candidate

Private source projects and verified baseline backup:

`godot-client/.cache/native-140fps/loading-agent/weak-residency-v2/manifest.json`

Only `systems/native_render/resource_pool.gd` and the new
`systems/native_render/weak_resource_residency.gd` differ. The generated candidate
adds a bounded weak directory of evicted exact-content mesh, texture and material
bindings. If the original Resource still exists, a cache miss recovers that exact
object into the primary cache. Expired weak references return a normal miss.

The primary capacities and LRU behavior stay unchanged. The weak directory owns
no Resources, retains at most 2,048 metadata entries per kind, and uses bounded
ring slots so it does not scan the whole cache per lookup. Stale ring slots are
checked before removal, so reinserting the same key elsewhere is safe. Explicit
`ResourcePool.clear()` clears this directory too; zero-retention settings remain
disabled. Existing content keys, main-thread checks, source validation, geometry,
textures, material policy, shadow/picking data and template behavior stay original.

Preserving an existing mesh/material object's identity also preserves a
prerequisite for Godot's automatic instancing. Whether this reduces actual draws
in the user's room remains a rendering benchmark question.

Useful new numeric snapshot fields:

- `pool.mesh_resident_hits`, `texture_resident_hits`, `material_resident_hits`.
- `pool.weak_residency`: recoveries, misses, expired entries, metadata evictions,
  entry/slot counts and capacity. No live Resources or WeakRefs are exposed.

### Correctness evidence

`.../weak-residency-v2/checks/results.json` contains 426 checks for each of
baseline and candidate (852 total), clean headless exits/logs, unchanged source
pins and unchanged shared DLL guards. The fixture intentionally uses primary
capacities of one and keeps two simulated consumers alive:

| Resources published for 102 alternating requests per kind | Baseline | Candidate |
| --- | ---: | ---: |
| Meshes | 102 | 2 |
| Textures | 102 | 2 |
| Materials | 102 | 2 |
| Exact resident-object recoveries per kind | 0 | 100 |

This is a deterministic publication/identity test, **not a graphical timing or
FPS result**. It also covers weak lifetime expiry/later allocations, key/kind
isolation, bounded metadata, reinsertion across stale ring slots, detached
snapshots, explicit clear, unchanged material inputs and disabled retention.
The first v1 check's test-only type-inference parse failure is preserved in its
own `checks/results.json`; the corrected v2 passes.

Prepare and check a fresh private label:

```powershell
node godot-client/tools/perf140/loading/prepare-weak-residency.mjs weak-residency-<fresh-label>
node godot-client/tools/perf140/loading/test-weak-residency.mjs weak-residency-<fresh-label>
```

The generated manifest pins its full frozen parent and original ResourcePool
backup. Original ResourcePool SHA-256:
`abecc7d402b845c4a3bf9d411e1dcc585bff4f2a020b63fc8c90b0d8b011625f`.
Candidate ResourcePool SHA-256:
`dadfb94d1ff74f90e37e227e446844a11d87dff7d0d4976868edf1db1e803ba7`.
The root can use its standard captured replay command with `--source-project`
set to the manifest's `baseline` or `candidate` paths; all other flags, view,
focus, content, timing, cache policy and profiling must match. Only root schedules
graphics/local gameplay acceptance and promotion.

## Batched material initialization candidate

Native material construction currently invokes `refresh_shader()` repeatedly
through exported-property setters while still initializing a new material, then
selects surface-output policy afterward. This can create intermediate shader
variants that will never be drawn. The independent `material-init-v2` candidate
suppresses only initialization-time shader refreshes and applies the final
surface-output policy before one refresh. Later property setters still refresh
immediately. The optional policy argument defaults to preserving the legacy
reconfiguration behavior.

Private source projects, pins and baseline backups:

`godot-client/.cache/native-140fps/loading-agent/material-init-v2/manifest.json`

Only `systems/native_render/native_model_material.gd` and its configure call in
`systems/native_render/resource_pool.gd` differ. The exact original material
script is retained as an independent oracle in both private projects.

`.../material-init-v2/checks/results.json` contains 3,869 checks for each of
baseline and candidate (7,738 total), with clean exits/logs and unchanged source
and DLL guards. It compares final shader source, twelve properties, eight
uniforms and metadata across 144 policy/filter/transparency combinations; later
setters; omitted-policy reconfiguration; and actual ResourcePool publication and
duplication. For the current native product policy over opaque, blend and scissor
materials, initialized shader programs fall from six to three. Final shader
sources and material state remain equal.

These are headless shader construction and contract results. They do not measure
GPU compilation, pixels, frame rate or the complete 40 ms material phases.

```powershell
node godot-client/tools/perf140/loading/prepare-batched-material.mjs material-init-<fresh-label>
node godot-client/tools/perf140/loading/test-batched-material.mjs material-init-<fresh-label>
```

Original material SHA-256:
`c4c0ac8a064ebf0bf87327c8886e9aa9aede10a5353f69e48f14ef9bbb81f998`.
Candidate material SHA-256:
`253bc7c738a506256858982d74dc9031b7ffe2a6ad55c24bb7de596855398ef0`.
Candidate ResourcePool SHA-256:
`af2453cfab7148efc8e254bed17799da3e27e7080b7fa3d0c1e7abf5fa96a961`.

## Combined loading candidate

The independent candidates and their evidence remain unchanged. The third
private project composes their exact resource identity and initialization changes:

`godot-client/.cache/native-140fps/loading-agent/combined-loading-v1/manifest.json`

Manifest SHA-256:
`1887fe620a361d36b1f0e347360bd31653f932afd8c3d892e832efa183a32337`.

Both focused suites pass against these combined files: 852 weak-residency checks
and 7,738 material checks, with the same creation/recovery and shader-program
counts as their independent candidates. The reports are respectively
`checks-weak-residency/results.json` and `checks-material-init/results.json`.
This catches the shared ResourcePool configure-call integration boundary.

```powershell
node godot-client/tools/perf140/loading/prepare-combined.mjs combined-loading-<fresh-label>
node godot-client/tools/perf140/loading/test-weak-residency.mjs combined-loading-<fresh-label>
node godot-client/tools/perf140/loading/test-batched-material.mjs combined-loading-<fresh-label>
```

All three candidate manifests pin baseline originals and private replacements.
Promotion remains pending root's matched captured-scene graphics and loading
comparison. No live-client, pixel parity or 140 FPS acceptance is claimed here.

## Repeated prepared-directory setup

Source inspection found that every `asset_service.decode_uncached()` calls
`PreparedCache.configure()`. Prework lookup, rig-cache lookup and deferred cache
writes do the same. Configure unconditionally requested recursive directory
creation even when the directory already existed.

Godot's own [DirAccess implementation](https://github.com/godotengine/godot/blob/master/core/io/dir_access.cpp#L123-L171)
walks each path component and calls `make_dir`; it does not return early for an
existing leaf. The capture's 2–4 KiB body-part sources sometimes report 8–15 ms in
the identity span containing configure, while actual decode takes less than one
millisecond. Those timings motivate this candidate; worker scheduling and other
work in that span mean they cannot all be attributed to directory setup yet.

The independent `cache-directory-v2` candidate adds one existing-directory query
before recursive creation. It keeps the original recursive creation/error path
for absent directories. It adds no permanent directory memo, so deleting an
empty cache directory externally and configuring it again recreates it as before.
All cache identity, checksum, publication, workspace rejection and file schema
logic stays unchanged.

`godot-client/.cache/native-140fps/loading-agent/cache-directory-v2/manifest.json`

Manifest SHA-256:
`a2f84ede55a6daffef09bd1273699903a639334646d905b4e7e2199fc59bd4c8`.
Original `systems/native_data/prepared_cache.gd` SHA-256:
`d5c714dcd8f39c2bc04468246c60020cfe0de675aa387a6fa1da9f52087bed8a`.
Candidate SHA-256:
`37375dca6478041c4d08b714ae002f13c11c9cbd1367f499eaca37c952625518`.

`checks-contract/results.json` passes 42 focused checks for each variant (84
total), clean native exits/logs and unchanged shared source/DLL guards. It covers
source/relative path rejection, absent/existing/normalized directories, valid
publication and cross-owner reads, identity mismatch rejection, deletion of the
owned empty leaf, recreation and subsequent publication. The v1 sandbox run's
certificate-store error is preserved; its contract checks themselves passed.

```powershell
node godot-client/tools/perf140/loading/prepare-cache-directory.mjs cache-directory-<fresh-label>
node godot-client/tools/perf140/loading/test-cache-directory.mjs cache-directory-<fresh-label>
# Only during a root-scheduled CPU window, with GPU checks stopped:
node godot-client/tools/perf140/loading/test-cache-directory.mjs cache-directory-<fresh-label> --benchmark
```

The optional benchmark interleaves seven sets of 128 configure calls against the
exact original script. `checks-benchmark/results.json` passes 43 checks for each
variant (86 total), clean logs/exits and unchanged source/DLL guards. In the
candidate process, medians are 284,863 microseconds for the original versus
16,255 microseconds for the candidate per 128 configure calls: about 2.23 ms
versus 0.127 ms each. The original-versus-original baseline control reports
242,499 versus 253,270 microseconds, so it does not create a false improvement.

This measures only existing-directory configure latency. The owned benchmark
path is deeper than the production prepared-cache path, so its approximately
17.5-fold factor must not be projected onto real-area load time or frame rate.
It ran in the root-scheduled shared CPU window with graphics tests stopped.

## First-placement construction reuse

`ModelTemplate.build()` constructs a complete physical hierarchy, packs it, frees
that hierarchy, and then `create()` instantiates a second hierarchy for the first
placement. The independent `first-placement-v3` candidate keeps that detached,
never-admitted construction hierarchy after successful packing and consumes it
once for the first placement. The existing immutable PackedScene remains the
source of every later placement. It still packs before returning a template;
there is no delayed pack of already-animated or admitted state.

The template's pre-delete notification frees a retained hierarchy if a template
is evicted or released without ever creating a placement. Once consumed, the
placement owns its nodes as usual; eviction/clear does not free a live placement.

`godot-client/.cache/native-140fps/loading-agent/first-placement-v3/manifest.json`

Manifest SHA-256:
`7d5c91c3697bd55b1a7e0db34612cff08bf3f2750e5946a9f3942ad44875affe`.
Original `systems/native_render/model_template.gd` SHA-256:
`6722f49f7d8baa1979ae030d40068995cac0d4bbe2976579ad4cbf1457a085e3`.
Candidate SHA-256:
`4c191fedc1b70c1b75b1aa15cfc73c2376ccdac9e3a8b3b2d58800dffb927e50`.

The headless gate passes 67 baseline and 79 candidate checks, with clean logs,
exits, source pins and shared DLL guards. It compares packed topology, rest
transforms, physical metadata, exact mesh/material/hit identities and later
mutation isolation in compact/separate layouts. It also exercises real
SceneTree light/reference/emitter entry and emitter source paths, independent
reference cancellation, eviction/clear with live placements and unused-template
destruction. First-placement reuse count and actual retained-root identity are
checked directly. The earlier fixture-only parse and absent-meta errors remain
preserved in v1/v2 evidence.

```powershell
node godot-client/tools/perf140/loading/prepare-first-placement.mjs first-placement-<fresh-label>
node godot-client/tools/perf140/loading/test-first-placement.mjs first-placement-<fresh-label>
```

There is no loading-time, GPU, pixel or FPS acceptance for this candidate yet.
It preserves current authored caster handling, including the separately audited
hidden-caster limitation, and changes no resource preparation/render policy.

## Review and promotion artifacts

Each completed private candidate has `integration.patch` and `integration.json`.
The plan records original and replacement hashes and exact baseline backup paths.
The patch is a review artifact. Root must compare current shared files to the
original pins before promotion and manually merge any concurrent changes.

```powershell
node godot-client/tools/perf140/loading/export-integration-patch.mjs <prepared-candidate-label>
```

The exporter checks source/backup pins, preserves previous evidence, and never
changes the shared working tree. Runtime acceptance remains root's responsibility.

## Remaining repeated-work audit

The frozen baseline already prepares immutable mesh upload arrays on workers;
the real report has zero main-thread mesh preparations. Moving that same math to
another worker again would not address this capture. Model discovery also has a
compiled resolved-entry index, decoded-source coalescing and original-byte
residency. These mechanisms should be measured before replacing them.

A larger remaining candidate is the completed-bundle preparation cache.
`preparation_store.gd::load_data()` always returns `duplicate(true)`, including
for cached static models. The report records 1,539 preparation-cache hits and
approximately 18.5 million shared-storage visits during its size accounting.
Those are counts, not a measured deep-copy duration. The lower decoded-source
path already has an explicit immutable borrow mode; that does not automatically
make every completed-bundle consumer safe to borrow.

The static rendering path inspected so far is `asset_service.gd::_work()` →
`area_stream.gd`/`object_stream.gd` → `resource_pool.gd::model_template()` →
`model_template.gd::build()` → `model_instance.gd::install()`. Source installation
reads model rows and gives helpers their own mutable runtime state. A static
bundle loan would still require auditing all remaining consumers, palette/rig
metadata updates, publication/cancellation and lifecycle boundaries, then testing
explicit mutation isolation. The independent candidate below now implements a
narrow static-model loan. It has not changed the ordinary renderer or completed
graphics/loading acceptance.

Another inexpensive-looking cache issue is linear LRU array erasure on every
hit. The actual report has only 313 mesh hits and 3,950 material hits, so a more
complex LRU structure is lower priority than proven repeated filesystem setup
or full model graph work. No LRU/capacity change is included in these candidates.

## Immutable completed static-bundle candidate

`readonly-loan-v4` adds a separate static-model completed-cache contract. Existing
actor/table/icon lookups and ordinary `load_data()` retain mutable deep copies.
It does not retain/freeze the cold job's graph. Instead it constructs a private
canonical graph at publication, makes its Dictionary/Array containers read-only,
and compiles a sparse recipient-copy plan.

Packed arrays require special handling. Godot's [PackedByteArray contract](https://docs.godotengine.org/en/stable/classes/class_packedbytearray.html#description)
states that packed arrays are passed by reference. Freezing their containing
Dictionary does not freeze a packed stream. Therefore only subtrees without
packed leaves are shared. Every container on a path to a packed array is detached
for each recipient, and every packed leaf uses `duplicate()` to obtain an
independent wrapper. The recipient owns a mutable outer result header; nested
containers are structurally read-only, while its packed streams are independently
mutable without affecting the canonical source or another recipient.

Object/Resource, Callable, Signal, RID, object-typed arrays, container/object keys
and excessively deep/large graphs reject the loan path. Existing deep-copy
publication is its fallback. Copy-plan metadata is included in native retained
size accounting; the fallback charges explicit conservative plan overhead.
Primary cache capacities, source/dependency identity and epoch semantics stay
unchanged. Generic cached/coalesced access also detaches packed wrappers for
loanable entries rather than exposing their canonical packed storage.

Audited static-model routes are terrain, decorative borders, static objects, sky
and optional terrain batching. They read source definitions and allocate mutable
physical/helper/runtime state separately. Inheritance and rig construction finish
before completed-bundle publication. No actor inheritance graph is loaned here.

Private manifest:
`godot-client/.cache/native-140fps/loading-agent/readonly-loan-v4/manifest.json`

Manifest SHA-256:
`67e92c11ab0bb0012d0f842829867493f01b06276be6c748ef9a9905be8a36c4`.
Changed files are `systems/native_data/preparation_store.gd`,
`systems/native_data/asset_service.gd` and new
`systems/native_data/readonly_bundle_loan.gd`. Exact originals, replacement pins,
verified backups and review patch are in the manifest and `integration.json` /
`integration.patch` beside it.

`checks/results.json` passes 115 baseline and 119 candidate checks with clean
engine logs/exits and source/DLL guards. Coverage includes:

- Mutable cold input, mutable default copies and recipient header changes.
- All ten packed-array types under index writes, `set()` and `append()`.
- Nested read-only metadata, safe structural sharing and typed scalar arrays.
- Unsafe/rejected, legacy fallback and over-capacity publication.
- Actual native-thread private/nonprivate coalesced followers; old-flight
  completion after epoch clear and same-key reuse; independent cache owners.
- Real authored static AssetService requests, repeated completed-cache hits,
  native template publication, catalog-layer replacement and errored models.
- Clear/eviction with held detached views and stale publication rejection.

The separate `checks-mutations/results.json` probes Dictionary `set`, Array
`set`/`append` and indexed assignment. Those four attempted writes produce exactly
five known native/script rejection diagnostics, with no unexpected diagnostics.
The mutation runner validates their precise tags, origins and messages; the
ordinary correctness gate still requires clean logs. Earlier fixture-priority
and diagnostic-count failures remain preserved in v1/v2.

```powershell
node godot-client/tools/perf140/loading/prepare-readonly-loan.mjs readonly-loan-<fresh-label>
node godot-client/tools/perf140/loading/test-readonly-loan.mjs readonly-loan-<fresh-label>
node godot-client/tools/perf140/loading/test-readonly-loan.mjs readonly-loan-<fresh-label> --mutation-probe
```

`preparation_cache.readonly_bundle_loans` exports small numeric publication/hit/
fallback/rejection and compile-time counters. Canonical data and copy plans never
enter diagnostics. No performance benefit is claimed yet: sparse GDScript copying
can be slower than native `duplicate(true)` when packed paths dominate, and cold
compilation adds work. The prepared benchmark compares cold clone/compile and
warm copy/release separately, with metadata-only and packed-heavy controls plus
actual sealed-capture bundles. Run it only in a root-scheduled quiet CPU window:

```powershell
node godot-client/tools/perf140/loading/benchmark-readonly-loan.mjs readonly-loan-v4 "--recorded-catalog=C:/Users/Niflheim/AppData/Roaming/nwn-model-viewer-research/native-loading-recordings/capture-YaH3xf/catalog-1" "--models=ttu01_w06_01,plc_s07,ttu_udoor_04"
```

The benchmark is complete, and this GDScript candidate is **rejected for
promotion**. Both headless runs exit cleanly; source/DLL guards and the sealed
catalog manifest guard pass. All three recorded models prepare successfully.
Within-process candidate medians are:

| Actual original static model | Deep copy per warm call | Sparse loan per warm call | Cold clone | Cold loan compile |
| --- | ---: | ---: | ---: | ---: |
| `ttu01_w06_01` (33 parts) | 0.204 ms | 0.464 ms | 0.216 ms | 2.827 ms |
| `plc_s07` (16 parts) | 0.493 ms | 0.682 ms | 0.563 ms | 6.452 ms |
| `ttu_udoor_04` (15 parts) | 0.965 ms | 1.475 ms | 1.101 ms | 12.455 ms |

The metadata-only control gains substantially, but the packed-heavy control and
every real model regress. The corresponding paired results in the baseline
process reach the same conclusion. Structural sharing saves container copies,
yet the GDScript sparse-plan traversal costs more than Godot's existing native
deep-copy implementation on these actual graphs. The measured cold compile
penalty makes promotion especially unsuitable for the loading goal.

Evidence is `readonly-loan-v4/checks-copy-benchmark/results.json` and
`capture-guard.json`. The actual original model SHA-256 and bundle shape/plan
counts are recorded per case. Full bundle hashes differ between processes;
these records also include preparation/cache diagnostics. No cross-process
graph/timing equivalence is asserted. Each timing comparison is interleaved
against the same bundle within one process. This measures copy/release work,
not full area entry, rendering or frame rate. The original capture is unchanged.

Keep the isolation contract and tests as a potential oracle for a future native
sparse-copy implementation if the measured owner remains important. Do not
enable this GDScript cache path merely because its correctness checks pass.

## One digest per preparation job

`job-digest-v2` removes repeated SHA-256 calculation within a single owned
preparation job. It does not add a name-to-digest cache. The root bytes are hashed
once, then the exact digest follows those bytes through completed-memory and
prework identities and the model, actor, table or image decoder. Dependency
proofs similarly pass the digest of the bytes just read. Malformed hints fall
back to hashing; failed reads and mismatched source name, type or byte length
cannot become dependency proofs. Existing prepared-file checksums and catalog
invalidation are unchanged.

Private manifest:
`godot-client/.cache/native-140fps/loading-agent/job-digest-v2/manifest.json`

Manifest SHA-256:
`f44ccf9a95f98205a64944fedf1dbbd0250999c1f205849f8c245eea3a6ea1f4`.
The changed files are `systems/native_data/asset_service.gd` and
`systems/native_data/prework_store.gd`; exact original and candidate hashes and
verified backups are in the manifest.

`checks/results.json` passes 45 baseline and 59 candidate checks with clean
engine logs, process exits and source/DLL guards. Coverage includes real model,
actor, table and raster jobs; same-length source changes; packed-buffer mutation
isolation; malformed and mismatched proofs; raw catalog root and texture
overrides; retained old catalog forks; warm decode; and deliberately corrupted
owned prepared payload recovery. No timing or live-loading benefit is asserted
from this correctness gate. This candidate remains separate from directory and
first-placement changes.

```powershell
node godot-client/tools/perf140/loading/prepare-job-digest.mjs job-digest-<fresh-label>
node godot-client/tools/perf140/loading/test-job-digest.mjs job-digest-<fresh-label>
```

The separate source-byte-packet candidate below extends this idea across warm
source-cache reads, tied to the exact admitted byte packet and catalog scope.
It remains unapproved. A raw first read may pay an extra hash even when its
consumer never decodes the bytes, so warm savings cannot establish a cold-entry
benefit on their own.

## Material pose publication guard

`material-pose-v1` is a separate runtime candidate for repeated material pose
publication. Godot's [ShaderMaterial implementation](https://github.com/godotengine/godot/blob/master/scene/resources/material.cpp#L393-L430)
updates its parameter cache and sends each `set_shader_parameter` call to the
rendering server when a material RID exists, even if the supplied value is
unchanged. The existing pose publisher sets diffuse, alpha, emission and
emission-enabled values on every invocation.

The [RD material storage path](https://github.com/godotengine/godot/blob/master/servers/rendering/renderer_rd/storage_rd/material_storage.cpp#L2391-L2406)
also overwrites the parameter and queues a material update without comparing
values. Its queue deduplicates list membership while setting dirty flags; the
later update still calls the material's parameter updater. The corresponding
[GLES path](https://github.com/godotengine/godot/blob/master/drivers/gles3/storage/material_storage.cpp#L2350-L2365)
has the same unconditional update behavior. This makes backend dirty work a
plausible target, while leaving the net gain for this scene to measurement.

This candidate skips that original publisher only when the incoming colors and
blend mode, shader resource identity, live backing properties and all four
resource-owner parameter values still match the exact snapshot captured after
the original function last ran. The original publication body is unchanged.
Variant serialization preserves types and signed-zero bits rather than
reimplementing its color conversions. Nonfinite inputs or outputs always retain
the original path. Ordinary external property and `set_shader_parameter`
mutations invalidate the snapshot and are repaired by the original function.

The owner parameter cache is authoritative. A production-source audit of
`systems/` and `native/` found no direct `material_set_param` writers. Raw
RenderingServer writes bypass that owner contract and are explicitly outside
this candidate's supported mutation scope. No per-material backend query or
synchronization is added to the hot path; the read-only ClientAPI exposes no
material resources or RIDs. A test-only raw-write probe records that boundary,
but the headless backend could not supply query values, so it is not a backend
mutation-parity receipt.

Private manifest:
`godot-client/.cache/native-140fps/loading-agent/material-pose-v1/manifest.json`

Manifest SHA-256:
`b6c77f912f2192dcedf14eda0afb451dec3e34559e190dd882a4adee15e7fc55`.
Only `systems/native_render/native_model_material.gd` changes, from SHA-256
`c4c0ac8a064ebf0bf87327c8886e9aa9aede10a5353f69e48f14ef9bbb81f998`
to `713530ea397069c3b77ae92d42025a8b53700a9b770153b7f0e4e5c8dbebb807`.
Verified originals and a review patch remain beside the manifest.

`checks/results.json` passes 833 baseline and 1,247 candidate checks with clean
engine logs/exits and source/DLL guards. The matrix covers both standard-light
and native-output modes, repeated/negative/HDR/signed-zero colors, blend/shader
changes, duplicate and unconfigured resources, nonfinite/overflow fallback and
mutated backing properties/API parameter values including wrong/null types.
The candidate matrix executes 424 original publications and skips 388 unchanged
ones. Those are fixture counts, not production scene counts.

```powershell
node godot-client/tools/perf140/loading/prepare-material-pose.mjs material-pose-<fresh-label>
node godot-client/tools/perf140/loading/test-material-pose.mjs material-pose-<fresh-label>
```

No performance gain is claimed yet. Owner-cache reads, Array construction and
serialization can cost more than the avoided writes, especially with a dummy
headless renderer. Root must measure this candidate against the same complete
rendered scene before deciding whether to keep it.

## Byte-packet digest reuse

`source-packet-v2` is incremental to checked `job-digest-v2`. A raw source-cache
entry retains the SHA-256 of its exact admitted bytes. Warm reads and coalesced
followers can reuse that digest. Recorded reads reuse the checksum they just
verified, while still checking the recorded payload on every read. There is no
separate name-to-digest cache and no removed disk/checksum validation.

A proof lookup accepts the actual PackedByteArray, rather than just its length.
It compares a retained detached byte snapshot and validates name, type, source
store identity/generation or recorded provider scope. Index assignment, `set()`
and append mutations therefore reject the old proof even when the length stays
unchanged. Catalog invalidation, cache clear/eviction and recorded remounts retire
their previous proof scopes. Each reader holds at most one transient detached
packed snapshot. Byte equality and wrapper overhead still require measurement;
the first raw read hashes even when a consumer never decodes that resource.

Private manifest:
`godot-client/.cache/native-140fps/loading-agent/source-packet-v2/manifest.json`

Manifest SHA-256:
`a5e8c4bf067b9e4ee7eb599f86afe000248dbf208ea01b5f1c8cee66023cba47`.
Changes are limited to `resource_catalog.gd`, `recorded_catalog.gd`,
`asset_service.gd` and `prework_store.gd`. Its parent manifest is the reviewed
job-digest candidate, so integration must account for that dependency; the exact
before/after hashes and verified originals are in `integration.json` beside it.

`checks/results.json` passes 31 baseline and 49 candidate checks. The separate
`checks-job-integration/results.json` passes 59 checks for each variant, both
using the checked job-digest contract. Logs/exits and source/DLL guards are clean.
Tests cover real catalog bindings, zero/missing/error reads, same-size loose
replacement, cache eviction/clear, overrides and retained forks, native-thread
coalesced first admission, packed mutation isolation, recorded checksum failure,
remounts and real model/actor/table/raster preparation. The first baseline parse
failure from a test-only Semaphore return-type assumption is preserved in v1.

```powershell
node godot-client/tools/perf140/loading/prepare-source-packet.mjs source-packet-<fresh-label> job-digest-v2
node godot-client/tools/perf140/loading/test-source-packet.mjs source-packet-<fresh-label>
```

This is correctness evidence, not a loading-speed or frame-rate result. No
shared source is promoted and no captured source was mounted by these gates.

## One raster-format selection pass

`raster-selection-v2` preserves the original storage-class priority and format
ties while resolving each of four supported raster formats at most once. The
old raw catalog may ask the identical name/type lookup four times while trying
different storage classes. The new pass retains the first format for each class
and returns immediately upon the first highest-priority loose result. The
recorded catalog uses the same ordering and normalizes the resource name once.
No new cache or stale lookup binding is introduced.

Private manifest:
`godot-client/.cache/native-140fps/loading-agent/raster-selection-v2/manifest.json`

Manifest SHA-256:
`3de3d65c094b93e66be6211bcdc57c20a100dfb8821c2de006d1ad9f5fe85793`.
Only `resource_catalog.gd` and `recorded_catalog.gd` differ. Review patches and
verified originals remain beside the manifest. It is independent of the digest
candidate; composing both requires merging their distinct functions in these
same two files, then rerunning both gates.

`checks/results.json` passes 26,247 baseline and 32,808 candidate checks with
clean logs/exits and source/DLL guards. An unchanged original-code oracle checks
all 6,561 raw and 6,561 recorded precedence patterns, implicit key/archive
classes, missing/unsupported classes, format ties, case normalization and real
layered/indexed loose fixtures. Across the raw fixture, identical selections
require 43,321 original lookups versus 22,185 candidate lookups. Those are
operation counts, not timings. The earlier raw fixture's unsupported String
storage class caused native typed-assignment diagnostics; v1 is preserved and
the corrected raw matrix uses the original method's supported integer domain.

```powershell
node godot-client/tools/perf140/loading/prepare-raster-selection.mjs raster-selection-<fresh-label>
node godot-client/tools/perf140/loading/test-raster-selection.mjs raster-selection-<fresh-label>
```

There is no claimed FPS or full-loading improvement until root runs the matched
captured-world comparison. The shared working tree and original capture remain
unchanged by this agent.

## Changed-source audit and root shadow fixture

`source-audit-post-hud-v1/receipt.json` audits only the union of changed source
paths in nine frozen loading candidates. Every existing shared file still
matches its frozen original; the new weak-residency helper remains absent as
expected. Every candidate and baseline-backup hash matches its manifest.
Source-packet's AssetService/Prework before hashes refer to the checked
job-digest parent, so their difference from shared originals is an integration
dependency, not new drift. This bounded audit does not assert whole-tree, native
DLL, HUD or graphical validation.

The loading agent also supplied an independent real-pipeline oracle for root's
private static-shadow experiment. Root owns and edited the proxy; this agent
only stages a pinned read-only copy from `tools/perf140/shadows/` into its own
private headless project. No shared renderer or root helper file was edited.

`shadow-pipeline-v3/receipt.json` passes 364 checks with clean engine logs/exits,
source guards and copied-root-module guards. Its manifest SHA-256 is
`33502f34455f0476543d0807cf782ee0735064f6da458960e5f67fbca29516e9`.
The fixture executes actual ActorData parsing, MeshPreparation, ResourcePool,
ModelInstance and Template.build/create through all eight combinations of
compact/separate physical Parts, native/standard materials and prepared/authored
normal streams. It includes nested quarter-turn Parts, positive scales, two
opaque surfaces and hidden collision geometry.

Test-only ArrayMesh readback verifies exact index order/winding and independently
specified baked positions (observed maximum error zero). The largest normal
error is 0.0000440, within the 0.0001 octahedral-upload tolerance. Original Part,
mesh, material and pick identities/data stay unchanged; cached plans install on
a separately placed clone, survive pool clear and retire with their Placement.
Eight changes after preparation—skin, both visibility ranges, cull margin,
authored render/shadow flags and Part index/parent provenance—reject atomically.

The first attempt preserves fixture-only type-annotation and harness project-pin
errors. The second run exposed a missing Part-parent provenance check in root's
helper; root corrected that boundary before the clean v3 run. Those failed
receipts remain intact. The proxy still requires an explicit immutable direct
terrain lifetime contract; this test establishes no graphical shadow/bias/seam
equivalence, GPU performance or real-server behavior.

```powershell
node godot-client/tools/perf140/loading/test-shadow-pipeline.mjs shadow-pipeline-<fresh-label>
node godot-client/tools/perf140/loading/audit-pending-source.mjs source-audit-<fresh-label>
```

The normal-bias ownership review uses the
[pinned engine receiver-light code](https://github.com/godotengine/godot/blob/ed1daf0bf/servers/rendering/renderer_rd/shaders/scene_forward_lights_inc.glsl#L463-L468)
and [Light3D's documented lookup offset](https://docs.godotengine.org/en/stable/classes/class_light3d.html#class-light3d-property-shadow-normal-bias).
Original main receiver surfaces remain intact. CPU-baked caster-position
rounding and combined culling bounds still require root's visual acceptance.

## Dependency-scoped processed-cache identity (private correctness gates clean)

**Use processor-identity-v3; do not promote v1 or v2.** Actual `NativeItemIcons` callers
supply Array descriptors; source review found that the new dictionary-only key
factory narrowed that existing contract. V3 source restores Variant descriptors
and adds actual Array worker cases. V3 also records actual rendering/display
backends for finished pixels only. V3's fresh functional gates pass; the earlier
receipts remain historical evidence. The candidate is still private, with no
main integration or measured performance claim.

Source review found that `Prework.processor_identity()` hashes every script in
`native_data` and `native_render`, plus selected GUI/model files. Editing an
unrelated runtime HUD, material publication or shadow helper therefore invalidates
saved world-model bundles. That can cause repeated cold-entry work after
development changes even when the calculated data is still valid.

The audited model graph currently has 24 source files and only one genuine
`native_render` data dependency: `particle_math.gd`. Finished icon **pixels**
need a separate larger renderer graph, and deterministic rejection policy needs
its own graph. Both real native DLLs remain tracked conservatively. The design
and safety boundary are documented in
[PROCESSOR-IDENTITY-DESIGN.md](tools/perf140/loading/PROCESSOR-IDENTITY-DESIGN.md).

The hardened source-only graph gate passes 173 checks in
`processor-graph-gate-v4/receipt.json`, including qualified-load, global
`class_name`, unsupported-resource and unknown-native checks. The pinned
`processor-identity-v1` candidate passes another 330 native checks (161 original,
169 candidate) in `checks-fixture-v2/results.json`, with clean logs/exits and
source/DLL guards. Actual descriptor regeneration adds 40 checks in
`descriptor-scope-checks/receipt.json`. No shared cache, renderer source or
native output has been changed, and no loading/FPS gain is claimed.

Current V3 manifest SHA-256:
`9a8f3ab3e0e5bcc52e8969e9bb3ee3374c9821860187e5ff794264296388e3c3`.
The initial failed graph analysis and fixture-only Node cleanup receipts remain
preserved. The final fixture explicitly frees its owned AssetService Node.

The candidate also isolates lower model/raster persistent derivatives; otherwise
a new final-bundle namespace could be repopulated from stale decoder cache data.
Other resource decoder caches retain their existing behavior in this first
candidate. Validity still requires all existing byte/existence/raster/absence
checks, checksums, publication generation and clear boundaries.

```powershell
node godot-client/tests/native_perf140_loading_processor_graph_test.mjs processor-graph-gate-<fresh-label>
node godot-client/tools/perf140/loading/prepare-processor-identity.mjs processor-identity-<fresh-label>
node godot-client/tools/perf140/loading/test-processor-identity.mjs processor-identity-<fresh-label>
node godot-client/tests/native_perf140_loading_processor_descriptor_test.mjs processor-identity-<fresh-label>
```

After composing the candidate with other private source edits, root must run
`regenerate-processor-descriptor.mjs <private-project>` against that exact
source cohort. A descriptor from mismatching source correctly disables optional
reuse instead of trusting an incomplete graph or manual revision.

V3's final evidence totals **716 checks**: 175 source graph checks in
`processor-graph-gate-v5/receipt.json`, 360 native checks in
`processor-identity-v3/checks/results.json`, 47 descriptor checks in
`descriptor-scope-checks/receipt.json`, and 134 actual captured-model checks in
`capture-provenance-v1/receipt.json`. Engine logs/exits and source/DLL guards are
clean. No active engine child remains. The source-only artifact export is at
`processor-identity-v3/integration.json` with its exact five-file patch.

The captured gate reads sealed `capture-YaH3xf/catalog-1` in place, using only
two requested MDLs and dependencies: `ttu01_w06_01` (33 nodes, 6 textures) and
`plc_s07` (16 nodes, 3 textures). It does not copy the capture or connect to a
server. Cold entries write; subsequent warm and unrelated HUD/diagnostic edits
hit the original final artifact with an exactly identical full envelope. A
relevant `particle_math` comment edit refuses reuse before regeneration and
misses the old namespace after regeneration. Recomputed model/image/dependency
data remain bitwise identical after canonical dictionary ordering and omission
of only explicit cache-hit/read-time/timing observation envelope fields. Those
omitted paths and all raw bundles are recorded in the receipt. The prior fixture
failure compared changing diagnostic timestamps as though they were model data;
it remains preserved rather than being hidden.

A private same-name MDL byte override changes the real root SHA and misses its
old final artifact; the untouched second model still hits. Original MDL checksums
and the sealed capture manifest remain unchanged. Deliberately seeded legacy
model/raster/rig lower-cache entries do not populate the new final namespace.
These establish cache provenance, not area loading speed, rendered pixel parity,
steady FPS, or native-client performance equivalence.

```powershell
node godot-client/tools/perf140/loading/test-processor-capture.mjs processor-identity-<fresh-label> capture-provenance-<fresh-label>
```

## Opt-in raster-value sidecars (private prototype)

The bounded eight-tile census found 44 image-value occurrences but only 13 unique
values: 5,417,112 encoded bytes repeated inside 9,234,456 bytes of final model
artifacts. The separate `raster-child-v2` candidate extracts only standard
raster packet `value` dictionaries, keeps every per-model descriptor/diagnostic
field and original lookup fact, and reconstructs complete packets through the
existing decoded-cache owner. The disabled regular path performs no child I/O.

Its 65 focused checks and real eight-model cold/write/warm comparison pass with
clean source/DLL/capture guards. Combined final artifacts shrink from 9,234,456
to 3,828,880 bytes (about 58.5%). The existing native retained estimate for eight
held warm packets decreases from 27,247,544 to 16,307,024 bytes (about 40.2%, not
RSS). Warm hydration performs 13 child reads and 31 existing-owner memory hits;
full packet/image/diagnostic data remain exact. No memory budget was increased.

Default remains off (`--prework-raster-children=enabled` for the private test).
This is not promoted main code or a measured loading/FPS gain. Detailed scope,
failure/clear semantics, artifacts, commands and results are in
[RASTER-CHILD-DESIGN.md](tools/perf140/loading/RASTER-CHILD-DESIGN.md).

The subsequent clean CPU-exclusive five-pair timing does **not** establish a
loading-speed benefit for raster sidecars. Eight-tile runtime preparation was
496.609 versus 491.534 ms, prepared reads 194.008 versus 193.144 ms, and
population regressed from 558.327 to 689.736 ms. These are request-clock corpus
medians with a warm/uncontrolled OS cache, not full-area loading or FPS. Keep
sidecars off; the separate disk/retained-graph reductions remain valid. The first
timing set overlapped root's compile and is explicitly invalidated in its saved
receipt. Clean evidence is `raster-child-timing-v2-receipt.json`.

## Avoiding unused static preparation before actor preparation

Actual worker tracing found a different source of duplicated work: five of the
eight tiles contain emitters. The original static-model path prepared the whole
static model, then discarded that result and prepared the same MDL again as an
actor to retain its emitter controllers. ActorModel itself invokes BinaryModel,
so this duplicates geometry parsing/preparation rather than preserving a unique
validation step. Raster parsing is already shared correctly: 44 requests produce
13 actual uncached raster parses and 31 existing decoded-cache hits in both modes.

The private `static-actor-route-v1` candidate adds a bounded binary-header/tree
hint. Proven emitter-bearing static jobs go directly through the existing actor
owner. Unknown/ASCII topology keeps the old path; failed direct attempts execute
the original path to preserve error precedence. All later rig, material, palette,
texture, emitter and resource processing remains unchanged. No cache tier or
renderer dependency is added. The option is off by default:
`--static-emitter-route=enabled`.

The isolated native gate passes **225 checks** across the same eight captured
tiles plus five malformed-resource cases. Calculated model, image and dependency
packets are identical after omitting only explicitly enumerated timing/cache-hit
observations, and all raw envelopes are retained. Original error strings remain
exact. Uncached MDL preparation decreases from 8 static + 5 actor passes to
3 static + 5 actor passes. This is a work-count result; no latency/GPU/FPS or live
server parity claim has been made. Frozen manifest SHA-256:
`1774e165d6a3818e23ef8f31c1c831d95ee63847c19247a67befaaf1ce610589`.

```powershell
node godot-client/tools/perf140/loading/prepare-static-actor-route.mjs static-actor-route-<fresh-label>
node godot-client/tools/perf140/loading/test-static-actor-route.mjs static-actor-route-<fresh-label> static-actor-route-gate-<fresh-label>
```

The exact eight-tile source/packet/error proof is in
`static-actor-route-gate-v1-receipt.json`. The candidate derives from the frozen
root fullruntime composition and keeps raster sidecars disabled by default.
Only root may promote it after independent loading/runtime acceptance. Any
composition must regenerate the source-pinned processor descriptor last.

Two subsequent CPU-exclusive five-pair sets pass (60 fresh phase processes).
With ordinary runtime deferred publication, eight-tile cold request medians
improve 436.369→387.294 ms (11.2%) and population 504.354→449.756 ms (10.8%).
The sync attribution control corroborates 491.054→422.517 ms cold. Prepared
reads and process-warm results remain effectively unchanged. Non-emitter cold
worker time changes only 107.417→108.238 ms across three tiles, but their request
clock shifts by roughly one presentation tick; full-area acceptance must still
check this. Exact brackets, limits and receipts are in
[STATIC-ACTOR-ROUTE.md](tools/perf140/loading/STATIC-ACTOR-ROUTE.md). This is a
bounded CPU loading improvement, not a settled FPS or live-server claim.

The earlier root-runtime derivative is `static-actor-route-runtime-v1`, SHA
`2fb27aae19e349a7a01d0355dd066bc2a6cfb03717ae709923b9b68ea5691309`.
It derives from exact `scene-snapshot-fenced-v4`, retaining its UI fence and new
native kernel. It includes processor V3 plus routing, excludes both raster child
and writer experiments, and passes a fresh 225-check packet/error oracle. Root
still owns full-area/local gameplay/visual acceptance and main promotion.

## Raster publication through the existing deferred writer

The actual eight-tile worker trace shows 44 raster requests but only 13 parsings;
pixel decoding is already coalesced/native or compressed-block preservation.
With an ordinary lower disk cache, the observed raster parse work was about
1 ms versus roughly 59 ms synchronous cache-save work, mostly filesystem
publication (~47 ms). This diagnostic ran during other native builds and is
owner attribution, not a clean speed comparison.

The independent opt-in `raster-write-queue-v1` extends the existing immutable
prepared writer to rasters after their private producer graph is admitted to
the decoded owner. It adds no cache or worker, keeps deep mutable consumer
copies, existing bounds/rejection and last-owner shutdown, and leaves explicit
sync/disabled policies unchanged. It passes 54 focused lifetime/mutation/error
checks plus 100 actual captured packet/queue checks. Default stays off pending
exclusive timing and root's full-area acceptance. Details and exact pins are in
[RASTER-WRITE-QUEUE.md](tools/perf140/loading/RASTER-WRITE-QUEUE.md).

## Bulk binary float-stream extraction

The independent, default-off `bulk-float-stream-v1` replaces per-scalar GDScript
vertex/normal/UV reads with native contiguous conversion only after bounded native
integer sort/search admits normal finite values or signed zero. Exact bit ranges
reject NaN/Inf/subnormals to the original loop; unknown layout also falls back.
There is no new DLL, cache tier or GD per-float validation loop. The 12,528-check
native gate covers random/edge IEEE words, error/bounds precedence, normal/UV
exceptional values, source mutation/COW and eight complete captured model packets.
Timing/full-area acceptance is still pending; native O(n log n) sorting must prove
worthwhile before adoption. See
[BULK-FLOAT-STREAM.md](tools/perf140/loading/BULK-FLOAT-STREAM.md).

## Cache correctness prerequisites for main adoption

Version metadata alone does not identify custom Godot executables. The private
`processor-identity-engine-v1` derivative adds actual executable SHA-256 once
per process under synchronized initialization, shared by every worker/service
and artifact kind. Failed proof disables optional derivative keys. It passes
164 native checks, including eight simultaneous callers with exactly one read.

`processor-identity-plt-v1` then closes a related lower-cache gap for body and GUI
PLT pixels: a new final namespace must not be filled from old unscoped lower
PLT derivatives. Original byte/row/selector facts and pixels are retained; missing
proof permits ordinary decoding but refuses cache reads/writes. Its 39 focused
checks and the full 193-check processor regression pass. No shared source, engine
or DLL changed. These are correctness prerequisites, not additional speed claims;
root still owns eventual runtime composition/visual/local acceptance. Exact
manifests, incremental patches and limits are in
[ENGINE-IDENTITY.md](tools/perf140/loading/ENGINE-IDENTITY.md).

## Latest independent root palette runtime compositions

Root supplied frozen `palette-fixed-lease-v1` SHA
`bcf1b0e01c7a4afebc33e468bdd820c2f4d2ac5155c8e1379db4e35961a15718`.
The following private copies preserve its native DLL `672bd24a…`, UI fence
`70cd84a2…`, immutable palette, clock/RNG/lease, entries, compact observer and
diagnostics. Each regenerates its processor descriptor on the final cohort and
adds executable/lower-PLT provenance correctness. Raster children stay excluded;
loading changes remain independent and off unless explicitly selected.

| Private manifest label | SHA-256 | New-cohort native gates |
| --- | --- | --- |
| `processor-identity-palette-v2` | `05bca95304af39340d5ba415321f450df019c8cf518aa34f4ec8ca01948cd549` | 193 processor + 164 executable + 39 PLT |
| `static-actor-route-palette-v1` | `6164d3662c1e1ce95689dbdc1484dabef9c7c5dbd2f6e70ebcee6b3ea8f4dcb4` | 225 original-data/error |
| `bulk-float-stream-palette-v1` | `100a92b68c9ca4c44776f9e12238fc34f2f65c491815e28ade66b354541706af` | 12,528 IEEE/parser/capture |
| `raster-write-queue-palette-v1` | `04d290150d62fc0c5399fab47c3e180ee8c7b9ecd60b297305c4bba2d490bbaf` | 54 ownership + 100 capture/queue |

All source/capture guards, logs/exits and review exports are clean. Each folder
contains `integration.json` and `integration.patch`. The first common staging
attempt selected a baseline pin while reading a candidate source and stopped
without creating a manifest; the partial `processor-identity-palette-v1` is
preserved. The corrected V2 does not bypass that check.

No variant has been promoted to main, run graphically or accepted against a live
server by this loading agent. Prior measured routing gains are from the older
same-engine CPU cohort. Updated full-area/local/visual acceptance and exclusive
bulk/writer timings remain root-coordinated work.

## Combined current engine handoff

`combined-loading-runtime-v1`, manifest SHA
`1f0fd6a94d4132ad8c14c822fefa69d7720ba7fadd7ab32a536ac709401d92f9`,
composes all three opt-ins onto exact root `builtin-light-fenced-v2`, preserving
constructor/lighting/palette/UI/entries and source/DLL guards. Both stock and
corrected `ce2d3640…` engine suites pass all 15 isolated runs / 13,307 checks.
No main promotion has occurred.

The controlled corrected-engine five-pair combined test measures eight-tile cold
requests 396.359→295.500 ms (25.4%), worker 318.577→210.451 ms, population
475.522→354.094 ms (25.5%). These are actual combined results, not a sum of
independent gains. Full cold fixture phase is 1187.837→1089.634 ms (8.3%), including
startup/verification. Executable SHA costs about 219–222 ms once/process, recorded
catalog mount about 490–492 ms, source/DLL proof about 9 ms. Prepared/warm behavior
has no consistent paired regression; final writer drain is about 0.15 ms and all
queues/source/data guards are clean. No full-area/FPS/live claim follows.

Root's exact ten-file before/after handoff, opt-in flags, source/runtime pins,
raw receipts, startup accounting, limits and rollback notes are in
[COMBINED-LOADING.md](tools/perf140/loading/COMBINED-LOADING.md). Root owns remaining
graphical cold/warm and local authoritative acceptance.

Root's subsequent complete-room comparison is clean and content/view matched,
but shows no demonstrated broad gain: steady 110.83/111.25 FPS, area ready
3825/3771 ms, playable 4245/4293 ms and last raw publication 22454/23249 ms
(off/on). Keep the eight-tile 25.4% CPU result scoped to its corpus. The combined
candidate remains private and unpromoted. The detailed handoff records the
full-room clocks and the queue-accounting caveat.

Source-only follow-up on recorded mounting, actual engine proof and repeated
retained-graph work is in
[STARTUP-ACCOUNTING-AUDIT.md](tools/perf140/loading/STARTUP-ACCOUNTING-AUDIT.md).
An independent opt-in discarded-copy gate has passed 337 focused headless checks;
it has no timing or live acceptance and remains private. A stronger exact native
builtin-access accountant hypothesis is source-prepared in
[ACCOUNTING-BUILTIN-ACCESS.md](tools/perf140/loading/ACCOUNTING-BUILTIN-ACCESS.md),
with a private build plan and exact oracle. No native build/test has run for that
hypothesis while the user is live testing.

## Walking-preview priority

Root's sealed live evidence locates three 162–302 ms stalls largely in
`keyboard_preview`, with roughly 4 ms GPU, zero asset workers/queue and zero
shader deltas. The actual frozen client selected the legacy flat collision owner;
it eagerly walks every entity and builds distant obstacle triangles before path
testing. The existing scoped index was implemented but not opted in. Its hooks
already cover full/delta/removal, motion, adoption and retirement; changing the
resource accountant does not address this input span.

Private probe, opt-in index and independent Basis-hoist derivatives are now
staged on the exact live parent. Corrected-engine headless gates pass the full
48,521-index / 213-World-adapter / 12-collision suites on each cohort, plus exact
CLI/factory/shape/subphase tests. Main remains legacy and untouched. No movement
latency or full-world graphics acceptance has been measured for these variants.
Exact pins, receipts, observed loops, instrumentation and next acceptance are in
[DRIVE-PREVIEW-AUDIT.md](tools/perf140/loading/DRIVE-PREVIEW-AUDIT.md).

The first indexed replay exposed repeated model-group collection per slide
probe. Independent `drive-preview-envelope-v1` now collects an input-wide
conservative XY view once and reuses exact geometry for contained probes, with
scope/lifetime/source/frame/endpoint fallback to the unchanged unrestricted
callback. Original heights/tiles/narrow phase remain byte-preserved. Corrected-
engine gates pass 49,315 checks, including explicit large/unknown-Z/pending/
corner geometry and lifetime/motion/authority safeguards. Root's matched replay
reduced peak keyboard preview from 396 to 217 ms, while height work remained
approximately 63 ms; the remaining hitch is still unacceptable. Original-local
Prelude authority cycles pass, with no held-WASD or UDP-emulation claim.
See [DRIVE-PREVIEW-ENVELOPE.md](tools/perf140/loading/DRIVE-PREVIEW-ENVELOPE.md).

The next independent private prototype moves only clear's heavy triangle loops
to a bounded native calculation cache, preserving original GDS height calls and
all stage ordering. It passed 10,013 pure plus 57,926 actual corrected-engine
headless checks. It has no timing/visual/server acceptance and is unpromoted;
the running user client does not contain it. See
[DRIVE-CLEAR-KERNEL.md](tools/perf140/loading/DRIVE-CLEAR-KERNEL.md) for exact
source/DLL pins, optional flags, ownership/fallback contract and pending gates.

An independent exact compiled-height proposal is documented in
[DRIVE-HEIGHT-DESIGN.md](tools/perf140/loading/DRIVE-HEIGHT-DESIGN.md). Its standalone
kernel now passes 40,053 pure checks and a 103,304-check golden run against 472
cases / 21,084 original Godot queries, including captured WOKs and custom table
cases. It preserves the walkable-first/denied-fallback physical-face policy and
explicit f32 grouping. No native DLL, runtime adapter or performance acceptance
exists yet; it is not bundled with clear.
