# Native clock protocol ingress (staged)

`tools/native-clock-ingress.cjs` is an event-driven transport adapter. It does not construct or simulate native timers, resolve objects, retain a world mirror, load resources, or prepare a scene. The Host now uses the dedicated `NativeClockBridge` before its later UI listener and before connecting the actual Session. World lifecycle witnesses are published at its accepted transaction boundary. SessionWorld admits the clock envelope synchronously after its connection fence. The new native runtime remains opt-in pending complete lower-provider and visual acceptance; these hooks are not a claim that it is the default clock path. Node fixtures do not establish original-gameplay clock equivalence.

## Actual World lifecycle projection

The versionless lifecycle schema below remains a compatibility test contract.
Production's private reader returns the distinct
`native_client_clock_lifecycle_v1` accepted record; ingress projects its fact as
`accepted-lifecycle` event **version 2**. It retains `lifecycleEpoch`, transaction,
ordered record index, object ID/type, ownership, numeric deletion bit `0|1|null`,
area, opaque physical token or null, `ownerAbsentCertified`,
`constructionCertified`, `aiRegistrationCertified`, and
`constructionHistoryComplete`. Connection, record coverage and each required
field are validated before publication. No raw/display lifetime is invented.

`ownerAbsentCertified` denotes a known-absent D no-op. It is false for fresh A;
the latter uses its distinct construction/AI certification and complete external
owner history. Unknown construction preserves complete transport coverage for a
fully observed valid record. Missing records, rollback or an uncertain write
still taint coverage. Per-entity physical uncertainty must not be relabeled as a
missing pause/rate packet or disable otherwise valid GUI T2 timing.

The actual World uses private prepare-before-assignment and
publish-after-assignment phases. Its opaque boundary readers reject injected
DTO metadata and old registry epochs. The bridge's current-session fence,
early attachment, exact listener retirement and contiguous serial stream stay
separate from timer construction. See `NATIVE-CLOCK-BRIDGE-CONTRACT.md` and
`NATIVE-CLIENT-CLOCK-LIFECYCLE-CONTRACT.md` for those owners.

## API and authority

```js
const ingress = new NativeClockIngress({
  send(frame, encodedLine) { /* synchronous outcome below */ },
  beginHistory(session) { /* trusted complete-history Boolean */ },
  acceptedLifecycle(session, privateBoundary) {
    // Root-owned accepted transaction witness; null means unrelated.
    return { complete: true, fact: /* fixed schema below */ };
  }
});
ingress.begin(session, connection);
ingress.observe(session, connection, decodedMessage, { generation, areaId });
ingress.lifecycle(session, connection, privateBoundary, { generation, areaId });
ingress.gap(session, connection, 'incomplete-records');
ingress.flush(session, connection);
ingress.retire(session, connection);
ingress.snapshot(); // Detached counters/history/limits only; no queued payloads.
```

`session` is an opaque identity, compared by reference. `connection` is an explicitly accepted, monotonically increasing safe integer supplied by the transport owner. `begin` does not inspect either object's fields or infer native process timer construction. Repeated/older connections cannot clear taint. Initial history is known complete only when the supplied trusted callback returns exactly `true` and a lifecycle callback is bound. The future owner must bind this before its first accepted relevant message; late binding is an explicit history gap.

Only the private lifecycle callback may authorize a lifecycle publication. It must obtain facts from the validated, transaction-private record boundary, not raw DTO flags, the first raw snapshot, a display lifetime, or a new JavaScript proxy. Constructor/reuse semantics remain with that owner. Facts are:

```js
{ operation: 'create' | 'remove' | 'reset', recordIndex: safeInteger,
  objectId: uint32, objectType: byteNonzero,
  nativeLifetime: positiveSafeInteger | null,
  knownLifetimeBefore: positiveSafeInteger | null,
  knownLifetimeAfter: positiveSafeInteger | null,
  ownership: 'new' | 'retained' | 'unknown',
  deletionFlag: boolean | null, cause: boundedAsciiSourceLabel }
```

These are transport witnesses, not clock state. A removal witness does not mean native hard destruction, and `reset` does not imply native clock reconstruction. `complete:false`, invalid facts, callback errors, rejected/incomplete decoding, capture gaps, serial exhaustion, uncertain sends, and queue loss permanently taint this connection. A later complete fact cannot repair earlier missing history. The adapter stores only its current opaque session reference, counters and bounded unsent frames.

## Wire projection

Each detached, deeply frozen frame has:

```js
{ kind: 'native-clock-protocol', version: 1, connection, serial,
  history: { complete: boolean, reason: string | null },
  scope: { generation: safeInteger | null, areaId: uint32 | null }, event }
```

Serials start at 1 for each accepted connection and never wrap. Supported events retain only:

| Event | Retained facts |
| --- | --- |
| `begin` | Whether a trusted lifecycle reader is bound; never a timer constructor |
| `module-info` | Received BYTE `minutesPerHour` only; no calendar or resources |
| `module-time` | Received BYTE `mask` as a boundary only; no reconstructed clock value |
| `module-pause-state` | Numeric 2-bit mask, numeric BOOL bit, ordered client IDs including duplicates/sentinels |
| `client-area` | Received area ID only |
| `object-control` | Player/object IDs and admitted source pair 5/2 or 14/14 |
| `accepted-lifecycle` | The private fixed fact schema above |
| `history-gap` | First pending loss reason, after any already queued prefix |

Unrelated decoded messages are ignored, with no serial allocation. Recognized but malformed messages fail closed without publishing partial facts. Accessor/inherited DTO properties are not treated as data. Received BOOL values must already have been narrowed by the actual native reader; this adapter never uses JavaScript truthiness to reinterpret them.

History on each queued frame describes the prefix known when it was recorded. After an overflow, older queued frames may still describe their earlier complete prefix. The dropped serial and the subsequent `history-gap`/false history identify the missing suffix. Consumers must validate contiguous serials and sticky certainty themselves; they must not restore certainty from an older prefix or a later snapshot.

## Synchronous send outcome and bounds

`send(frame, encodedLine)` must return exactly one of:

- `{status:'accepted', backpressure?:boolean}`: bytes were handed to the transport, including `socket.write(...) === false`. Remove the frame; never retry it.
- `{status:'unavailable'}`: the owner proves no write was attempted and no bytes were accepted. Queue/retry the same encoded line in FIFO order when the socket becomes available.
- `{status:'unknown'}`: delivery may have happened or been partial. Do not retry that frame, taint history, and stop all further writes on this connection. Later facts may only enter the bounded queue until a new accepted connection.

Throws, bare booleans, Promises, and malformed outcomes are unknown. The contract is synchronous; callbacks must not return an asynchronous operation or reenter this adapter. In particular, the wrapper around Node `socket.write` must translate both true and false to `accepted`, using false only as the backpressure field. No socket is touched by the ingress itself. The owner must retire an uncertain stream rather than retry or relabel it.

The known-unwritten queue is limited to **64 frames and 1,048,576 encoded UTF-8 bytes**, including newline delimiters and the begin frame. Options may lower these limits for focused tests, never increase them. Overflow drops only the new frame, keeps the prior bounded prefix, leaves an observable serial gap, and taints history. Snapshot counters saturate at the safe-integer limit. A new accepted connection discards the old unsent queue and starts a distinct serial namespace; it does not repair the old stream. No whole-world copies, scans, per-frame polling, keys, profiles or model data are required.

## Planned checks (not executed yet)

```text
node --test --test-timeout=5000 godot-client/tools/native-clock-ingress.test.cjs
```

The dedicated Node tests cover ordered projections, private accepted lifecycle authority, stale scopes, constructor non-inference, all pause mask/bit combinations, exact IDs/duplicates, accepted backpressure, zero-write retry, uncertain no-retry/stop, exact frame/byte caps, sticky gaps, serial exhaustion, immutable payloads, and invalid/accessor inputs. No engine, server, network, profile, native build or production integration is exercised.
