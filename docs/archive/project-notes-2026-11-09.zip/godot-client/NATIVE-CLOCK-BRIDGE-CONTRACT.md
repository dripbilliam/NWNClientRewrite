# Native clock Session bridge

`tools/native-clock-bridge.cjs` exports `NativeClockBridge`. It wraps the bounded ingress and the actual accepted Session/World event boundary. It owns one session/connection and no world rows, clock values, socket, catalog, resource preparation or renderer.

```js
const bridge = new NativeClockBridge({
  send(frame, encodedLine) { /* exact synchronous ingress send outcome */ },
  isCurrent(session, connection) { /* trusted Host identity check */ }
});
bridge.attach(currentSession, acceptedConnection); // Before later UI listener.
currentSession.on('message', laterUiListener);
await currentSession.connect(options);           // Caller owns connection.
bridge.flush(currentSession, acceptedConnection); // After known socket readiness.
bridge.retire(currentSession, acceptedConnection);
bridge.snapshot(); // Detached counters and scalar ingress status only.
```

Root owns Host integration and the actual socket writer. It must map both true and false from `socket.write` to `{status:'accepted',backpressure:!result}`; false is not a failed write. Known no-write returns `{status:'unavailable'}`. A throw, unknown result or asynchronous callback result is uncertain and never retried. The existing ingress bounds remain 64 frames/1 MiB; the bridge does not add a second queue.

`attach` validates the trusted Host `isCurrent` predicate, binds the actual World's native clock connection, captures its private lifecycle epoch, installs its message handler, and begins ingress. It calls neither Session.connect nor disconnect. An exact repeated attachment is idempotent. A higher new accepted connection retires the old attachment and its queue. An older connection cannot replace the current one. A closed/stale session cannot attach or forward facts. Callbacks capture the exact attachment; even invoking an old saved callback cannot target its replacement.

The bridge uses three exact Session listeners: `message`, `diagnostic`, and `closed`. Message handling projects admitted module-rate, time-boundary, pause, client-area and control facts through ingress. Object-update facts come exclusively from the actual World's private accepted-record batch and accepted-boundary getters. Raw DTO constructor/token flags are never used. Facts are forwarded synchronously before a later registered UI listener can mutate/coalesce the received records. A missing private batch becomes an explicit lifecycle gap.

The diagnostic listener marks actual decoder rejection, object-import failure, incomplete object records, Session delivery failure, and area-import failure as incomplete coverage. It does not infer a clock change from unrelated resource diagnostics. The closed listener only retires this bridge attachment; it never initiates network or process shutdown. All three listeners are removed by exact function identity on retire.

Complete record coverage stays independent from unknown creature construction. A valid P-before-A can publish an unknown birth and then a fully covered pause. Actual incomplete/rejected input is sticky within the connection; a later valid pause cannot repair it. Late attachment (`phase` other than the actual Session's `new`) explicitly begins incomplete. A replaced World/private lifecycle epoch emits `reset-unverified` once and fences further forwarding until a new attachment, without rebinding or reconstructing native clocks.

This uses the current `NetworkGameSession` accepted `message` boundary, after its decoder and World transaction. It performs no resource awaiting itself. It does not bypass the Session's own serialized delivery or any earlier core receiver/resource await. That is a separate owner boundary, not a claim that this bridge observes raw bytes before all asynchronous Session work.

The focused Node gate uses actual `NetworkGameSession`, `NetworkWorld`, the frozen lifecycle helper, current ingress, and in-memory MockPeer. Pause bytes use actual native scalar writer/shared decoder; other records are authored decoded-like values. No original game/server, GPU, resource catalog, key/profile or runtime clock owner is activated.

```text
node --test --test-timeout=5000 test/native-client-clock-bridge.test.js test/native-client-clock-world.test.js test/native-actor-name-world.test.js test/native-client-clock-lifecycle.test.js
```

The accepted first run passed 63 tests: 15 bridge, 15 actual-World (including the narrow current-owner transport projection), 10 actor-name World, and 23 frozen lifecycle cases. See `reports/native-clock-bridge-v1.json` for exact source/Node pins and terminal output. Host adoption remains Root-owned and separate from this gate.
