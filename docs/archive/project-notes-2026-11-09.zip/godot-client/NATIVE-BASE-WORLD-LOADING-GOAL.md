# Fast base-world construction and playable area entry

Active goal established on 2026-11-06 from the user's live test. Make tiles and
non-interactable scenery appear quickly, with the controlled character and
anchored camera ready for play. Remaining players, NPCs and interactables may
stream in when they cannot fit into initial preparation. Compare the original
binary's actual methods before selecting an implementation.

## Requirements

- Use received/model metadata to identify base scenery. A static transform is
  not proof that an object is non-interactable. Keep unknown classification
  explicit and preserve doors, portals, triggers, usable placeables and actors.
- Trace resource lookup, cache reuse, decode, preparation, mesh/material creation,
  scene attachment, references, collision and final visibility separately.
- Prioritize the player-near base world and controlled character without making
  the camera wait for unrelated distant entities. Preserve native area-ready
  acknowledgements so waiting for player replication cannot deadlock entry.
- Reuse immutable prepared resources and avoid rebuilding shared models per
  placement. Investigate bulk static construction and redundant main-thread
  work before simply raising budgets or adding workers.
- Keep the complete authored scene, lighting, elevated-surface behavior,
  collision, server state, entity lifetime and interactions correct while
  unfinished entity visuals stream. Do not drop or hide work to claim speed.
- Preserve existing uncommitted work, back up notable changes and coordinate
  shared source ownership. The running client remains untouched. Public-server
  connections and movement remain under the user's control.

## Existing implementation and original evidence

`NATIVE-PLAYER-CENTERED-STREAMING.md` records the original grid-order area loop,
`Scene::SpawnTile`, shared parsed-model lookup, reference expansion, static Part
processing/collapse and conditional combination. It does not prove a universal
native nearest-first entity scheduler or complete parity with those operations.

Current `systems/native_render/live_world.gd` has separate actor/static batch
limits, nearest-ready admission and a controlled-appearance priority. Existing
`NATIVE-STREAMING-PRIORITY.md` explicitly describes waiting for terrain and the
controlled actor before background static/object preparation. That policy alone
does not establish the fast base-scenery phase requested here. Identify what
content the observed delay belongs to before changing scheduling or readiness.

## Validation and completion evidence

Record comparable cold and warm loading separately. Capture entry receipt,
first base tiles, near scenery, complete base scenery, controlled-character
publication, camera anchor, input readiness and final entity completion. Where
a field is unavailable, instrument it rather than inferring it from buffered
logs or aggregate entity counts. Cover a dense captured area as well as the
local campaign, resource changes, transitions, removals and stale work.

Require visible scene/interaction correctness and measured improvement at
equivalent content/settings. A faster empty scene, readiness flag, hidden pop-in,
small unit fixture or different room is not performance acceptance. Retain the
unfinished 140 FPS and presentation-parity work in
`NATIVE-LIVE-PERFORMANCE-GOAL.md` and
`NATIVE-WORLD-PRESENTATION-PARITY-GOAL.md`.

Investigation, implementation and small isolated correctness checks may continue
while another game is open. Notify the user at major visual/loading/performance
checkpoints and obtain PC availability before heavy tests. Major rendering
foundations may be investigated privately; approval is required before promoting
a drastic change as the main method.

## Initial baseline and source checkpoint

The retained `live-walk-test-v2.native.json` records first terrain at 343 ms,
complete terrain at 1,253 ms, terrain admission at 1,270 ms, controlled-character
eligibility in the rendering registry at 5,967 ms, input readiness at 6,970 ms and controlled-camera binding at
7,026 ms. Only one eight-object scenery prefetch ran. Two-second observations
first show matching aggregate entity counts around 20.4 seconds after the first
area sample. Aggregate entity counts are not a verified static-scenery count.
Evidence and limitations: `.cache/native-presentation-parity/root/`
`base-world-entry-baseline-v1/analysis-with-native-milestones.json`.

The unfortunately named `controlled_received_ms` stamp is recorded when the
rendering registry contains the controlled ID. It is not a first-wire-receipt
timestamp. Sliding profile windows cannot apportion the intervening 4.7 seconds
between transport, canonical eligibility and presentation. The measured local
area-ready send finishes earlier; do not attribute the whole interval to server
latency. Sanitized lifecycle audit:
`base-world-preparation-agent/entry-lifecycle-v1/audit.json` in the same cache.

The native audit verifies that `area.staticPlaceables` becomes `staticState` in
the canonical transport. This provenance supports a separate base-scenery lane;
object type 9 or a static transform alone does not. The original record loops
are proven; an identical native per-frame time-slicing policy is not.

Working source now reuses the detached construction tree for a template's first
placement, retaining the packed scene for later instances. The current alpha and
provenance implementation is unchanged. Forty tiny actual-code checks pass;
unused-tree retention and memory/loading impact still need real-scene validation.
Guarded backup: `root/base-world-first-placement-integration-v1/` in the cache.

Working ObjectStream and AreaStream now use their existing time/shared-pool
budgets by default rather than the extra four/eight placement count limits.
Explicit positive caller limits remain binding and negative limits remain
closed. The shared 3 ms/16-unit policy is unchanged. Thirty-four tiny deterministic
checks pass; they are not throughput measurements. Guarded backup:
`root/base-world-publication-budget-integration-v1/`.

The local object publication timer now observes failed template attempts as well
as successful placements. Otherwise an all-failing ready queue could bypass the
elapsed guard. Thirty-one small actual-stream checks cover yielding, resuming,
mixed success/failure, caller limits and retirement. Shared-pool failure accounting
is unchanged. Guarded backup: `root/base-world-publication-attempt-integration-v1/`.

The continuing base-scenery lane is integrated in working source. It admits
bounded nearest-first waves of 64 verified static records before and after the
controlled character is available. One early low-priority worker limits
contention; a controlled appearance retains first request priority and a
reserved owner slot. The protocol area-ready condition is unchanged. Existing
receive/planning/adoption boundaries publish progress without a second world
store or another full-world scan every frame. Renderer-omitted malformed static
records stay explicitly unresolved rather than disappearing from completion
counts. The dedicated lane has 120 small headless checks covering these seams;
full scene integration is not established by that fixture. Guarded backup:
`root/base-world-scenery-lane-integration-v1/`.

Static-only waves also initially request just the placeables table, rather than
waiting for two unused door tables. A changed mutable batch requests the original
door tables before planning; mixed/live batches retain the original path.
Seventy-one focused actual-stream checks cover table fallback, errors and the
existing worker/publication controls. Guarded backup:
`root/base-world-static-table-integration-v1/`.

No running client or earlier immutable test capsule has been changed, and no
loading-speed improvement is claimed. `root/base-world-candidate-v1/` is a new
five-file composition derived from the last tested capsule. Narrow ports retain
that capsule's lighting, visibility, particle leases and motion timings; they do
not copy the entire working render tree. Its complete native entry dependency
check passed in about nine seconds with no diagnostics or changed source pins.
The capsule-specific first-placement fixture separately passed 40 clean checks.
These are parsing and small correctness evidence, not visual/performance proof.

Real assets, complete scene content, collision, visual correctness and cold/warm
loading remain pending PC availability. The next local comparison must use the
same captured area, delivery schedule, view, renderer, settings and cache policy
for baseline and candidate. Separate cold and warm results. Compare tiles, first
and complete verified base scenery, eligible controlled character, camera/input,
final entity completion and frame hitches. Keep unknown/missing content explicit
and verify scene counts and representative visuals, rather than accepting an
earlier readiness flag or less work. No automatic public-server connection is
part of this check.

## Prepared comparison and next reuse investigation

`tools/replay-native-loading.mjs` now has an explicit pinned client-capsule mode.
The ordinary replay path remains available. The new mode selects the same
reviewed engine and particle library as the live client, its gameplay lighting
profile, managed particle leases, indexed collision, whole-character highlight,
render thread, secondary display and current captured preferences. It records
the actual capsule manifest separately from ordinary source hashes. Seventeen
selection checks, seven actual argument-tail checks and four existing recording/
replay-control Node tests pass; no world or engine was launched by these checks.
Backup, receipts and prepared four-run plan:
`root/replay-capsule-driver-integration-v1/` in the parity cache.

The selected recording is `capture-YaH3xf`, generation 2. Its initial received
area contains 225 tiles, 1,784 static-placeable records and 34 placeable lights,
with a finite entry position. These are source metadata counts, not proven final
render eligibility or completeness. The planned pair preserves original
arrival/movement timing, compares separate prepared-cache cold and warm runs,
and does not clear or claim cold OS/driver caches. It remains unexecuted while
PC availability is pending.

Timing limitation under review: `base_scenery_first_complete_ms` is currently
the first complete planner observation, not a proven exact last-publication
timestamp. Dirty counts can remain unavailable while all background slots are
occupied. Do not attribute that possible observation delay to resource work or
use it alone to accept a loading-speed change.

A further source audit found that each new ObjectStream schedules table/model
jobs and copies prepared bundles before the shared render-template cache can
hit. The native FindModel path reuses earlier. A private follow-up experiment
will measure a persistent scoped scenery owner/table bank across the same
64-object waves, retaining per-wave model jobs to isolate those two costs.
Earlier template binding reuse is a separate possible experiment. Neither is
promoted or counted as a measured speedup. Audit:
`base-world-preparation-agent/repeated-base-owner-v1/`.

## First real-area comparison: candidate rejected

The user made the PC available and closed the original client. A fresh local
baseline replay completed on the current secondary monitor, unfocused, with
225 tiles, 1,918 eligible entities, no failed entities and complete final content.
It reached terrain admission at 1,315 ms, controlled eligibility at 1,809 ms,
playability at 2,819 ms and camera binding at 2,834 ms. Its shutdown scene image
was inspected. These functional-run observations are not a native 140 FPS claim.

The five-overlay candidate crashed with native exception `0xc0000005`, with
unchanged source and runtime pins. A separate owned debugger replay reproduced
the failure. Exact binary disassembly points to an Array `is_empty` builtin
dereferencing a null private array pointer; the precise GDScript caller and root
cause remain under investigation. Older linker maps do not match precise offsets
and must not be treated as exact symbols. There is no evidence yet to blame the
retained construction root, the scheduler, the classifier or particles alone.

The candidate is rejected pending correction. Warm comparisons were not run.
`root/base-world-candidate-v1/real-world-failure.json` records this status without
changing the immutable project or manifest. Full evidence:
`root/replay-capsule-driver-integration-v1/batch-result-v1.json`.
Earlier rehearsals remain retained: one overlapped the original client, and
another used a stale monitor index. The replay driver now permits a current
explicit display index and verifies native startup actually used a nonprimary
monitor. No public server was contacted during any test.

The exact complete World process callback, including its planner/progress paths,
passed a separate 16-case headless fixture with 1,957 authored rows. That fixture
does not include the real render/particle/owner callbacks and did not reproduce
the invalid Array receiver. Real child-script and native-lifetime coverage is
still missing from the earlier first-placement checks.

Two one-file diagnostic restorations are staged only: `root/`
`base-world-isolation-no-first-root-v1/` restores the baseline ModelTemplate,
and `root/base-world-isolation-no-early-lane-v1/` restores the baseline World.
All other candidate source pins are preserved. Neither is validated or promoted;
passing a single isolation run would narrow attribution, not prove the cause.

## Isolation checkpoint and renewed graphics hold

The authorized two-run isolation batch has ended. Restoring the original
ModelTemplate still crashed with `0xc0000005`; construction-tree reuse is not
the sole cause. Restoring only the original World scheduler completed the full
replay with exit zero, native gameplay/visual completion, clean shutdown and no
remaining workers. Source and runtime pins were unchanged in both runs. The
second run nevertheless opened on the primary monitor because a stale explicit
screen index was supplied. It is retained as crash-isolation evidence only;
the overall run correctly failed its display gate. It is not accepted loading,
visual or FPS evidence, and no candidate is promoted from it.

The user is opening Deadlock. Do not launch graphics tests, FPS/loading replays,
native builds, online sessions or offline world benchmarks during this hold.
Continue source investigation, guarded private implementation and small CPU-only
correctness checks. Ask about availability at the next major graphics checkpoint.

The replay driver now discovers the current display topology just before a
headed capsule launch. It ignores the capsule's historical screen index, rejects
an explicit primary/absent display before starting Godot, and retains the native
post-start display gate. Ordinary and headless replays do not invoke discovery.
Eight Node-only regression tests pass; a read-only Windows topology query also
returned valid metadata. No engine or scene was started by these checks.
Backup and receipt: `root/replay-current-display-v1/` in the parity cache.

A separate source audit passed 37 pin/control-flow checks and inventoried 42
Array `is_empty` sites. It found no proven crash cause. The small full-World
callback fixture and 52-case real-child first-placement differential do not
include the full native particle/resource interleaving. Preserve that limit;
do not add guessed null fallbacks or discard scenery to obtain a passing run.
Audit: `base-world-scheduler-review-agent/REVIEW.md` in the parity cache.

Private follow-up work remains separate: persistent scoped scenery owners/table
reuse (B1), earlier validated shared-template lookup before worker/bundle work
(B2), and default-off lifecycle instrumentation. These are prepared experiments,
not established gains or normal-launch replacements.

## Corrected inherited planner contract and full-room regression

The user subsequently made the PC available for local tests. Bounded owned
debugger replays localized the failing script to `live_world.gd`'s
`_profile_process`, with a NIL receiver in local stack slot 15 (`base_objects`).
The actual entry imports `live_world_support.gd`, which inherits
`live_world_quiescent_candidate.gd`. Its cached quiet result still supplied the
old two-list plan while the new parent reads three lists. Its nonempty-work
test also omitted the new base-scenery list. This is a concrete producer/consumer
contract mismatch; no Array lifetime, compiler, model or particle defect is
needed to explain it.

The shared descendant now supplies `base_statics` on cached returns and includes
that lane before remembering quiescence. The optional lookup in the nonempty
check preserves compatibility with the older two-list parent. Only two lines
changed, with a guarded backup in `root/base-world-quiescent-contract-v1/`.
Exact descendant hash changed from `d884f349` to `2a2e5f83`. The isolated actual
descendant fixture reproduced the old missing field safely, and the corrected
fresh fixture passed 29 native assertions with clean diagnostics. Its first
startup-cache diagnostic remains preserved as a strict failed receipt.

The six-overlay capsule `root/base-world-candidate-quiescent-v2/` retains the
five previous overlays and changes only that descendant. Full client dependency
parsing passed. The complete captured room and movement replay then exited
cleanly with 1,918/1,918 entities, zero pending or failed entities, full visual
completion, no remaining workers, unchanged source/runtime pins and a verified
secondary display. It is useful crash/content evidence; there was no public
connection.

That run nevertheless failed renderer acceptance: Vulkan device enumeration
failed and Godot fell back to OpenGL compatibility. The installed Windows
`vulkaninfo --summary` also fails outside this project. Disabling implicit
layers for that diagnostic child did not fix enumeration. Windows reports
NVIDIA 621.14 while the fallback context reports 617.42. Explicit installed-ICD
diagnostic children also failed. No registry, driver, system setting or other
process was changed. No loading/FPS win is accepted from the OpenGL run, and
the native 140 FPS requirement is still unfinished. Driver status was requested
from the user while source work continues.

The source-only builder now includes the descendant repair and its regression
receipt so it cannot recreate the incomplete five-overlay composition. Its new
`base-world-candidate-contract-v3` output is staged only; no further scene test
is implied. All older failed capsules and diagnostics remain immutable.

Other private correctness checkpoints: B2's corrected v5 main fixture passed
157 assertions, including actual retry failure/cancellation and adoption
fences; capsule/native rendering and performance are still unverified. Entry
lifecycle v2 passed 36 GDS assertions against 10 imported fixture scripts after
fixture-only declaration/CA corrections; its earlier 48 JS and 37 static checks
remain separate. Neither private feature is promoted by these counts.

## Driver transition and next cache comparison

The user confirmed a recent NVIDIA update. The installed `nvidia-smi` reports
617.42, while the configured driver service and Windows metadata point to
621.14. The newer package was created at 00:56 local, after Windows booted at
00:22. This supports completing the installation with a Windows restart before
another FPS comparison. The exact driver/crash cause is not inferred from that
version mismatch. Read-only receipts: `visibility-agent/driver-state-v1/`.
No driver, registry, global environment, system setting or other process was
changed. Do not keep running GPU comparisons against the fallback renderer.

The replay selector now supports an explicit reviewed manifest experiment
descriptor for retained base owners and early template reuse. Both stay off in
existing capsules, template reuse requires the retained owner, and ad-hoc
command-line overrides are rejected. Five experiment-policy and eight current
display tests pass without a native process. No new feature has been enabled
in a normal client by that plumbing.

The separate recorded-source scope extension passed 235 tiny native assertions
(157 prior B2 regressions and 78 blob/ERF scope checks), with clean diagnostics
and unchanged guards. It preserves payload checksums, fork/remount isolation and
known resource absences. It adds a once-at-mount immutable metadata pass, whose
real capture cost is not yet measured. The extension remains private; a fair
comparison must apply that same provider implementation to the cache-ready
control, retained-owner variant and retained-owner/template variant. Also
compare the original corrected client so added default-off/setup overhead cannot
be disguised as a gain. No captured-room B1/B2 improvement is established yet.

Private work continues on base-progress updates at state boundaries (including
quiet-cache frames), and reusable model-layout bindings that retain every
authored Part, mesh, effect, light, reference, collision and physical owner.
Those have their own correctness and real-scene acceptance requirements; neither
is an excuse to remove content or weaken the rendering/performance goal.

## Local visual testing resumed after driver clarification

The user explicitly authorized continued local visual tests despite the driver
transition. This supersedes the earlier hold on graphical runs above. Keep the
actual renderer attached to every result; do not reinterpret the OpenGL fallback
as a valid Forward+ / native-client FPS comparison. No driver changes or public
server connections are needed for the authorized visual/content checks.

The immutable `root/base-world-residency-v2/` family has now completed both its
control and retained-owner/template recorded-room runs. Each supplied all 225
tiles and 1,918 entities, with zero failed admissions, no pending work, zero
remaining workers, clean exit, unchanged source/runtime/driver pins and verified
unfocused startup on a secondary display. The final images were inspected and
show consistent scenery, texture and lighting coverage. The tile-leaf census
also has the identical 2,479-row structural multiset after excluding process
IDs: hash `0d19e42839183b441d8ae95f2e01776524aadad204559bc2f55fb235fa960490`.
That census is not full entity/material-payload equivalence.

Both runs used OpenGL compatibility and failed the driver's explicit-renderer
acceptance gate. They are functional/cache-work evidence only. The retained
variant created one scenery owner and reused it 27 times; the control created
28 owners. Boundary progress reports all 1,784 positively identified base
objects resolved in both. The first-known-population milestone was about 31
seconds versus 49 seconds, but later recorded population changes reopened it;
49 live placeables retain explicit unknown provenance. Do not describe that
milestone as the final arrival of every possible server object. The third,
owner-only local run also completed cleanly; its first-known milestone was
about 40 seconds and it retained one owner across the same 28 base waves.
The template directory recorded 732 early request hits and 385 actual base
model jobs, with no pool misses or scope/metadata invalidations. Owner-only
had 1,122 base jobs; differing wave grouping means that paired delta is not
identical to the 732 directly observed avoided requests. None of these
experiments is promoted to the normal client yet.

A separate one-file model-layout capsule also completed the room cleanly.
It changes only ModelTemplate `9d5568d2` to the 169-check candidate `5bf357c1`,
with both residency flags off and the other 2,681 pinned files unchanged.
All four final images were inspected and have consistent visible coverage;
all four 2,479-row tile structural hashes match. This supports correctness,
not an established loading/FPS win for layout caching. The reviewed capsule
allowlist addition passed the existing 13 experiment/display tests. Its helper
backup and bounded four-run receipt are in `root/layout-family-v2-test-v1/`;
the receipt hash is `9d2d32430d491f84c75d29b9970814cf658f86f379131a52d79a227c88908405`.

The exact protocol replay is shared by these comparisons, but delivery/adoption
interleaving and dynamic presentation can differ. Existing unavailable emitter
bitmaps/reference models remain explicit in every run; complete object counts
do not prove those resources are present. Further live-authoritative transition,
removal/re-entry and normal-source integration checks remain required before
promotion. No emitter callbacks were suppressed: the high callback census came
from OpenGL's unshared route, where those callbacks still own simulation and
publication. Active shared-stream members already disable individual callbacks.

## Main-source integration and complete captured scope replay

The next turn is progress: the full 5,704-event recording, including the session
reset, 16-entity first world and subsequent second area generation, passed the
strict headless replay. All 360 recorded inputs were accepted; one old world
was retired and released, with zero pending retired worlds/workers, zero forced
drains and no remaining workers at final clean exit. Final world state contained
1,918 entities and six lifetime replacements. This is real native session/scene
execution against captured delivery, not a live UDP peer or a graphics/FPS test.
Original gaps are retained subject to explicit loading gates; maximum observed
delivery lateness was about 183 ms. Receipt:
`root/base-world-main-integration-v1/all-scopes-headless-a.json`.

The exact MAIN companion then passed 199 focused CPU assertions and a separate
complete actual MAIN NativeSession script dependency parse with all five target
Scripts instantiable and no native diagnostics. The parse did not instantiate
the production session/World. All 1,514 relevant pins were unchanged. These
complement the earlier 277-check ObjectStream/source-scope suite and the frozen
capsule's scene runs; they do not make those scopes interchangeable.

Four reviewed MAIN sources are now integrated, with exact-byte backups and
before/after guards in `root/base-world-main-integration-v1/`:

- World `1c3dac8b` -> `00f6a153` (B1 ownership plus boundary-driven progress).
- ObjectStream `926332c0` -> `a71eef05` (B1/B2 plus completion diagnostics).
- RecordedCatalog `53c54e15` -> `90357e83` (transactional sealed source scope).
- New base_template_directory `5d0d7c66` (bounded metadata, existing pool owner).

The two reuse flags remain default off. No launcher, preference, compiled output,
other process or ModelTemplate was replaced by integration. The normal MAIN
runtime/default-enable gate remains open: live ResourceCatalog full/delta,
unfinished-stream abort, reconnect, real door transitions and actual reuse must
be checked. The original Prelude local server was started as owned PID 20400
on UDP 5121 using the verified installed binary, private existing test home,
non-public mode and disabled NAT punching. No public connection was made.

The layout-only candidate remains private and lower priority: one comparison
saved only 5.87 ms in terrain cloning across 225 tiles, while first-known base
completion differed by roughly 54 ms near 49 seconds, with some worse maxima.
Its correctness result does not justify default promotion or an FPS claim.

## Gaming hold and the next loading candidates

The user is opening another game. Continue investigation, implementation and
small isolated authored correctness checks; inform the user and wait for
availability before local gameplay, captured-room graphics or FPS tests. No
new live client was started after that instruction. The owned Prelude server
remains preserved; its client/reconnect test is prepared but unrun.

That private primary test is
`visibility-agent/local-server-primary-main-v1/prepared-v5/launch.ps1`.
It uses the actual MAIN source closure, existing protected broker by default,
headless local-only connection, two completed joins and one unfinished-stream
disconnect in one client process. Fresh native disconnect receipts and actual
retirement drain are required. Positive base reuse and a specifically running
base worker are not inferred from ordinary pending-batch counts. Server identity
uses the same CIM creation-time provider at both boundaries: a read-only check
found a 9-tick precision difference versus Get-Process.StartTime, which would
have rejected the unchanged server. The wrapper repair changes no game code.

A guaranteed multi-wave functional fixture has been authored, not installed:
`tools/native_parity/performance/stage_base_reuse_fixture.mjs` produced
`root/base-reuse-fixture-v1/fixture.json`. Two areas each contain 128 explicitly
static/non-useable props and 64 tiles, with clear player entry positions. GFF/ERF
roundtrip and field/count checks passed. Native-server and effective live-catalog
validation remain pending. It is not a representative loading/FPS benchmark.

The V8 ready-template probe is private and default off. The existing worker
capacity test precedes cache lookup, so a few cold requests can block warm groups
in the same reservation. V8 permits those warm hits to queue without a worker,
preserves later ordinary lookups after a probe miss, and refreshes ready priority
before publication. Both exact profiles passed 351 authored checks (277 prior
regressions plus 74 focused cases), with clean diagnostics and unchanged guards.
The fake render seam remains explicit; no full-world speedup is claimed.
Receipt: `base-world-preparation-agent/base-template-b2-v1/ready-probe-v8/`.

The fixed eight-admission cap is also under separate private investigation.
The 1,784 captured base objects require at least 223 adoption callbacks at that
cap, irrespective of worker speed. This is a structural bound, not measured
elapsed-time dominance. A proposed experiment preserves the original first
eight adoptions, then admits only eligible nearest-ready base objects within
the same three-millisecond deadline and existing 64-row reservation. No shared
publication budget, actor policy or production default has been changed.

A tiny exact-MAIN World retirement test executed three authored cases. Its
strict result is failure: two real held-base-worker retirement/close cases
completed, but the third stopped at an oracle that compared deliberately padded
scene bounds with raw mesh width. Source inspection identifies the conservative
padding policy; no captured numeric discrepancy or production bug is inferred.
The failed receipt remains immutable. A corrected geometry oracle is being
prepared with physical vertices, source-axis padding and exact first/cache-hit
equivalence; remount/physical coverage is still incomplete until it passes.
