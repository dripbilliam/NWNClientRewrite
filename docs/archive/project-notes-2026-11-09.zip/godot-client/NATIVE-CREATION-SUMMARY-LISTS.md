# Live creation summary Feats and Spells

2026-11-01. The real connection-owned native creation draft now supplies its
source Feats and Spells pages. This is a partial creation milestone. The source
creator remains staged and hidden while the other original child screens and
helper workflow are unfinished. The shipping fifteen-page creator stays active.

The subsequent [live Skills-cache follow-up](NATIVE-CREATION-SKILL-SUMMARY.md)
now also supplies Skills through its original acceptance/reset lifecycle. The
pending-Skills notes below describe this earlier checkpoint's scope.

## Original behavior and evidence

Pinned nwmain.exe SHA256:
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.
The [REA/Ghidra dossier](reports/native-creation-summary-lists-research-v1.json)
retains the original live callbacks, shared numeric getters, known-spell getter
and initial creature/stat constructors.

- Live Feats9c0920 follows owned successor chains, deduplicates primary results
  and excludes primary membership from the bonus pass. Bonus rows can still
  duplicate a primary successor result. It shares the already verified admission
  policy with saved-BIC Feats9c0db0.
- Live Spells9c1810 differs from imported-BIC Spells9c1b50: only classes whose
  active `SpellbookRestricted` is nonzero list individual known spells. Other
  classes contribute a highest-castable-level summary when that level exceeds0.
  Physical class3 selects the original Druid summary references; other classes
  use the original Cleric references. This is source behavior, not a class-name
  guess. Minimum7f7130 and slots7f6b20 remain shared numeric getters.
- Live known arrays store DWORD IDs at stats+148, class stride150 and level
  stride10. GetKnownSpell7f5c50 multiplies the row index by4. The serialized BIC
  Spell field remains WORD. Native live lists retain their stored levels and
  duplicates; they do not regroup the draft through the BIC import path.
- Live Skills9bfda0 reads cached eligibility+E0 and values+D0. The base stats
  constructor7ea230 allocates255-byte arrays and clears the mask. Creation-child
  writes still need tracing. Skills stays explicitly pending rather than using
  the picker's import-time eligibility reconstruction.

`scripts/inspect-native-creation-summary-lists.py` executes unchanged original
live Feats/Spells instructions using the existing isolated CPU harnesses. Object
lookup, raw tables/stat fixtures, allocation, TLK and GUI row insertion are
explicit boundaries. Original minimum/slots/gain/known getters also execute.
This is not a running original-client comparison, full draft-initialization
proof or pixel acceptance.

Accepted corpus: `backups/animations/native-creation-summary-list-observations-v2.json`,
15 feat cases and72 spell cases, SHA256
`a092ab8cb97c99c29aea4d176be647c34e703bb9b35f172336b91f93a1bf776d`.
V1 is preserved but rejected: its original row captures were correct, but its
derived live-books fixture mistakenly read WORD elements instead of DWORD.

## Native ownership and input

`native_data/creation_summary_lists.gd` projects the actual draft's derived and
chosen feats, known levels, class, race, abilities and school. Active server
2DAs/TLK resolve policy, names, icons and help. `live_summary_spells.gd` uses the
verified numeric helpers without importing a BIC or fabricating an actor.
Unpublished dependencies keep content pending. It is for an unbuffed creation
draft, not an authoritative in-world spell or effective-stat calculator.

`game_ui_rules.gd::record_feat_entries` shares projection between gameplay,
picker and draft without changing their ownership or granting actions.
`native_lobby_record_feats.gd::configure_view/present_entries` now also serves
the creation summary. Source geometry, row artwork, scrollbars, integer values,
ordering and selection/help behavior remain shared. The picker keeps its own
typed-BIC Skills/Spells projections and interaction epochs.

The source frontend owns three list views beneath the shared page hosts. Draft
scope/generation and held press/release tickets guard interaction. Hidden or
retired views cannot select rows. Unchanged projections preserve controls,
selection, help and scroll; active rule/text changes replace the content.
Original ID-minus-one spell summaries change selection while retaining help.
Changing source data-art ownership retires the prior views. Cancellation clears
content/provider scope; replacement drafts get fresh bindings. Borrowed pregame
artwork and active data services remain separate. These controls inspect the
draft only: they never cast, upload a character or fabricate a server outcome.

## Accepted checks and remaining work

- `native-creation-summary-lists-v3` and
  `native-creation-summary-lists-release-v1`:334 strict editor/release-headless
  checks each. They compare all87 original callback cases and numeric outputs,
  then exercise actual draft recommendations, source tabs/rows, help, unchanged
  selection, late active TLK, server class-table policy, held input, cancellation
  and replacement scope. Source frame artwork is an explicit non-rendering
  double; these are not original pixels.
- `native-creation-summary-lists-picker-v1`:50 existing saved-BIC picker/list
  regressions pass after sharing the view and feat projection.
- `native-creation-summary-lists-binding-v1`:74 existing real-draft summary,
  portrait, text-ownership and stale/reentrant binding checks pass.
- `native-creation-summary-lists-parent-v1`:35 original parent/portrait/reset/
  cancel and component-input regressions pass.
- `native-creation-summary-lists-local-v1`:17 native/session checks, followed by
  original localhost Prelude admission, authoritative movement and export. The
  Wizard source list reads the same draft whose13 feats and13 known spells the
  original server accepts and exports. It confirms real entry binding and data;
  the source creator remains staged. Shutdown has protocol acknowledgment,
  zero remaining workers and no native exception.

Final receipts retain unchanged source and no engine/lifetime/native error.
No graphical launch, GPU benchmark or public connection was used. Earlier
testV1 caught an incorrect native UI rules-owner reference plus the rejected
fixture-width issue; V2 exposed a test that dismissed its provider before reuse.
Those failed receipts remain retained and unaccepted; V3 is the corrected run.

Remaining: HP/AC and full details/XP (Skills-cache initialization/binding now has
its separate follow-up),
completion-mask/parent-helper integration, remaining original children,
preservation-safe existing-character saves and original-client visual review.
Full summary, creator and [whole UI parity](NATIVE-UI-PARITY-GOAL.md) stay open.
Checkpoint: `backups/native-creation-summary-lists-v1.zip` and its verified
read-back manifest.
