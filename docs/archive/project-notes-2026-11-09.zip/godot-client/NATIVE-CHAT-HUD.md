# Native chat HUD and adjustable chat

2026-11-01. Connected to the production native gameplay UI. This is a scoped
HUD milestone. [Local authoritative acceptance](NATIVE-CHAT-LOCAL-ACCEPTANCE.md)
now confirms scoped Tell/reply/party outcomes. Original-client visual comparison
and complete chat/UI parity remain open.

## Controls and preferences

Open **Client Options → Interface → Chat settings**, including before joining
a world, or Shift-right-click a chat pane's top bar. An ordinary right-click
now opens the [original chat filter radial](NATIVE-CHAT-CATEGORIES.md).
Settings use the common native
client-menu builder, shared original-style theme and draggable-window owner.

- Drag the top bar vertically to change pane height. Click it to collapse or
  restore that pane. The two split panes retain independent heights.
- Drag the top-right edge to change overall chat width. In split mode the
  available width is shared equally by the two panes.
- Alt-drag a top bar to move the chat HUD and input strip together. Position
  and bottom offset can also be entered in Chat settings.
- Configure message font size, background opacity, local timestamps with
  optional seconds, combined/separate panes, and a compact input strip.
- Show/hide Talk, Shout, Whisper, Tell, Party, DM and combat/server feedback.
  These are client display filters; hiding a channel retains received history
  and does not change server delivery or the selected outgoing chat mode.
- Set retained history to50–2000 entries independently for ordinary and server
  feedback. Follow-new-messages preserves a deliberately scrolled reading
  position; it can also be disabled. Jump to latest remains available.
- Lock position/size to prevent accidental layout changes. Original-style
  preset restores defaults:720px combined pane,134px height,14px text,
  original bottom-left anchoring, timestamps off and all channels visible.

The user explicitly requested adjustable chat and common MMO-style settings;
these additional settings are client features, not claims about original menu
behavior. Preferences and pane heights share the existing menu-layout ConfigFile
(`user://native-menu-layout.cfg`, or the launch's `menu-layout` override).
Unrelated sections are preserved. The pregame Options route and active HUD
acquire the same window/file. A new gameplay owner loads preferences on creation;
retired owners disconnect from that window before the next world uses it.

## Original evidence and resource inventory

Pinned nwmain.exe SHA-256:
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.

[Initial REA/Ghidra dossier](reports/native-chat-research-v1.json),
[follow-up font/anchor/sender dossier](reports/native-chat-followup-research-v1.json),
[source model geometry](reports/native-chat-source-v1.json),
[edit model hooks](reports/native-chat-text-models-v1.json),
[background model parts](reports/native-chat-background-parts-v1.json).

| Original function / source | Behavior used here |
| --- | --- |
| CGuiInGameChatWindow constructor878800 | PNL_CHAT, caller's edit model and360/720 bar model |
| Owner6f9190 | Main EDIT_CHAT_MAIN/BAR720 at(0,134); secondary EDIT_CHAT_RIGHT/BAR360 at(360,134) |
| Prompt constructor87abb0 | PNL_CHAT_PROMPT at bottom-origin(0,36), EDIT_CHAT_PROMPT and CTL_LST/BTN_CHATMODE |
| Font selection19aaf0 | Ordinary dialog font is `ttf fnt_default 14`; large font alternative is `ttf fnt_default_hr 16` |
| Base anchor6f7b00 | Quickbar36px plus prompt20px gives56px base |
| Height87a850, hooks879780, click879a90 | Original height hooks,67px collapsed minimum, expand/collapse |
| Combined8793c0 / split879560 | Authored720px combined and360px split models |
| Submit87b0d0, cancel87b390, focus87b450, blur87b4b0 | Original prompt entry events, five-mode index and GUI focus events1/2 |
| Dispatch87b590 | Single-line command processing and selected outgoing channel |

Resources: PNL_CHAT; EDIT_CHAT_LEFT, EDIT_CHAT_RIGHT, EDIT_CHAT_MAIN;
BUT_CHAT_BAR360, BUT_CHAT_BAR720; PNL_CHAT_PROMPT, EDIT_CHAT_PROMPT;
CTL_BTN_CHATMODE, CTL_LST_CHATMODE; SCROLLBAR_SIMPLE, PB_SCRL_UP and PB_SCRL_DOWN.
The animated scrollbar uses the actor-model decoder so animation controllers
survive actual worker loading. Static GUI models use mdl-original.

The five original mode entries use TLK refs66751,66752,66754,66755,66756 and
channels2,3,1,6,14 respectively: Shout, Whisper, Talk, Party, DM. Talk is the
default mode at index2. Tell is handled through commands, not a sixth mode in
this original list. Active server text revisions update captions.

The original prompt text region is16px high, beginning at x78; the72×17 mode
button sits to its left. The native LineEdit is centered inside an unscaled
clip so its intrinsic minimum height cannot distort the source font. There
is no prototype1000-character cap. Entry Enter submits; Escape clears/releases
focus. Text is limited to its first CR/LF as in the source dispatch.

Implemented case-insensitive commands are `/s`, `/w`, `/p`, `/dm`, `/tk`,
`/talk`, `/t`, `/tell`, `/tp`, `/tellplayer`, `/o`, `/invite` and `/accept`.
The [reply follow-up](NATIVE-CHAT-REPLIES.md) distinguishes character-name Tells
from account-name/PLAYER_ID Tells and connects original portrait reply controls.
The [executed-dispatch follow-up](NATIVE-CHAT-DISPATCH.md) corrects character
versus account lookup, raw object-ID fields and host forwarding. Malformed Tell
clears silently; missing recipients show original local feedback. Unknown slash
commands are forwarded in the selected mode so server commands can work.
Unimplemented `##` and `/d` console paths stay local. Complete console/global
history behavior and wider original/local-server acceptance remain open.

## Native flow and ownership

[native_chat_hud.gd](systems/native_chat_hud.gd) reuses ServerChat's received
rows and real entry control, replacing its prototype presentation with source
geometry/art. [chat_hud_layout.gd](systems/native_data/chat_hud_layout.gd)
parses source bounds/hooks; [chat_prompt.gd](systems/native_data/chat_prompt.gd)
owns the mode/command policy. UI, source preparation, rich text and layout stay
in Godot. Existing JS transport only sends raw chat and original GUI packets.

Backgrounds bind once per source variant, then crop vertically and widen their
flat area as needed. NinePatch bar endcaps remain12px wide; text/icons are not
stretched with the pane. Font changes affect received messages independently
of the original input font. Opacity changes affect backgrounds, not glyphs.
Dragging width/position does not enqueue model-raster jobs. Scroll restoration
coalesces same-frame arrivals around the first reading anchor.

Only actual chat controls contribute world pointer-blocking regions. Empty
space in the full-screen layout owner stays available for world input.
Hidden gameplay cannot submit drafts or focus the entry. Retirement hides the
native stage, disconnects queued scrolling and preference subscriptions, and
unbinds borrowed artwork/fonts before their owners close. Shared client settings
can remain available while no gameplay world exists.

Chat focus messages use original112/53/1 GUI requests, event WORD1 or2,
mode WORD0–4, invalid object and zero XYZ only for server builds8193.35+.
The session transport checks the current actor/area/generation. Outgoing chat
does not insert a local echo; received server speech remains authoritative.

## Verification and remaining acceptance

- `native-chat-adjustable-v2`:86 strict editor-headless checks covering original
  source loading, real mouse/key/focus input, resizing/moving/locking, numeric
  input, filters/timestamps, scroll behavior, persistence and reconnect ownership.
- `native-chat-adjustable-release-v1`:86 packaged release-headless checks.
- `native-chat-adjustable-reminder-v1`:87 current strict editor-headless checks
  reverify the adjustment/settings/reconnect path after the user's reminder.
  Sources remain unchanged, with no debugger/engine/lifetime error.
- `native-chat-adjustable-reminder-release-v1`:87 packaged release-headless
  checks reverify the same saved settings and actual control input. Unchanged
  sources, no debugger/engine/lifetime error, no public connections. This is
  functional headless coverage; it does not replace original-client pixel review.
- `native-chat-adjustable-phase-v1`:20 full gameplay-UI visibility/focus checks.
- `native-chat-adjustable-route-v1`:19 actual session policy/pregame route checks,
  including the shared menu-layout settings file with no gameplay world.
- `native-chat-adjustable-text-v1`:35 received-text regression checks.
- Node native chat GUI packet and network-session regressions:39 tests pass.

All native receipts trap crashes and reject script/lifetime errors. No graphical
window, GPU benchmark or public connection was used; the user's heavier game
and existing editor/local server were preserved. These checks do not establish
pixel equivalence or authoritative chat outcomes. The subsequent
[55-check local follow-up](NATIVE-CHAT-LOCAL-ACCEPTANCE.md) confirms actual
Tell/reply/party outcomes against the original server without a GPU test.

The [category/context follow-up](NATIVE-CHAT-CATEGORIES.md) replaces the initial
ordinary-versus-server split with original per-pane masks and connects the
original seven-entry radial. It passes126 scoped native headless checks.
Remaining chat work includes original tooltip pixels/timing and message
formatting/speaker metadata, sent-command history, remaining slash commands,
sound/tooltips, scale/fullscreen pixel review and wider original/local-server behavior.
Native text selection/copy shortcuts are enabled; physical clipboard acceptance
remains separate from headless control checks.
Portrait controls and account replies now have a [scoped source/input milestone](NATIVE-CHAT-REPLIES.md);
the [tooltip/transition follow-up](NATIVE-CHAT-TOOLTIPS.md) now connects original
party-member details and verifies history/draft retention across area changes.
Original tooltip timing/spacing/pixels remain open; scoped local chat outcomes
are now recorded in the authoritative follow-up.
Retained history across gameplay-UI recreation also needs auditing.
Other HUD/menu work and the active whole-UI goal remain unfinished.

Baseline: `backups/native-chat-adjustable-baseline-v1.zip` (verified2254 files).
Final implementation checkpoint: `backups/native-chat-hud-adjustable-v1.zip`.
