# Particle frame phase instrumentation

2026-11-04. This narrow follow-up to `NATIVE-DENSE-PARTICLE-PLAN.md` changes only
`systems/native_render/particle_stream_group.gd` among existing runtime files.
The exact prior file is preserved in
`backups/native-dense-area-prechanges-2026-11-04-v1.zip`, SHA-256
`c2287a214cc443f2a068d285ded55f6d3cc45ec12074cb6e010b8389baa3c5f1`.
Its member SHA-256 is
`9284902bb8f0e69de7700128f7b25dd67cff475b99a15209d99472bbb795b285`;
the test's NEW before fixture is byte-identical to that member.

The existing `callback_particles` remains the inclusive frame owner. Eight
bounded child spans use the existing `FrameProfile.begin/finish` methods:

| Span | Actual boundary |
| --- | --- |
| `particle_frame_queues_ms` | Deferred removals, registrations and control commands, in existing order |
| `particle_frame_inputs_ms` | Existing current-camera lookup, unsupported-fog check, camera binding and view/fog input packet construction |
| `particle_frame_lighting_dto_ms` | Optional native-color light-owner lookup and `particle_lighting()` DTO creation |
| `particle_frame_collision_indices_ms` | Optional existing collision-index provider and two-index assignment |
| `particle_frame_native_presentation_ms` | Native dispatch 1, including control/pose handling, admission, simulation, geometry, packet and counter work; not exclusive simulation time |
| `particle_frame_scene_publication_ms` | Optional dispatch 9 plus scene-batch consume; absent for the current native-color path |
| `particle_frame_renderer_submit_ms` | Existing renderer dispatch 1; submission wall span, not completed GPU work |
| `particle_frame_renderer_status_ms` | Existing renderer dispatch 2 and its status packet construction |

No child name is added to `FrameProfile.CALLBACKS`; adding the child durations to
`callback_particles` would double-count. These spans exclude the surrounding
branch/error/cleanup gaps. Missing-camera and unsupported-fog returns finish the
input span; result/refusal cleanup remains in its original order. No additional
camera, lighting, collision, native or renderer query was introduced. Profiling
off uses the existing inert begin/finish guards and records no additional phases.
No native C++, provider, graphics setting, simulation schedule or renderer
default changed. There is no performance improvement claim from adding probes.

The dedicated fixture `tests/native_particle_frame_profile_test.gd` compares the
actual inherited `step/_process` against the exact before file in
`tests/fixtures/native_particle_stream_profile_before.gd`. It retains real
queue/register/control/close logic, Camera3D, fog/view helpers and FrameProfile.
Native dispatch, renderer, light DTO, scene consumer and compositor installation
are adapter doubles. It checks exact command order and captured inputs/results,
profiling off/on, optional legacy branches, native/scene/submit/status refusal,
deferred close, missing camera and unsupported fog. It does not exercise native
simulation, actual GPU submission or performance.

Runner: `node godot-client/tools/test-native-particle-frame-profile.mjs <fresh-label>`.
The isolated copied project has no extension list or session startup. The runner
pins its recursive static closure, baseline source, engine, Node, main project
and extension-list presence, six native outputs and copied manifest; it caps the
owned engine at 35 seconds and output/result sizes at 1 MiB/128 KiB. Every
failure label is retained. No server, socket, key/profile read or build is used.

Accepted execution: `.cache/native-particle-frame-profile/native-particle-frame-profile-v2/proof.json`,
**236 checks / 18 cases / 20 pinned inputs**, clean engine exit 0 in 1.58 seconds.
Owned engine 59728 exited and closed normally; no kill was requested. Source,
copy, engine, Node, six native-output, main config/extension-list and manifest
guards remained unchanged. Current producer SHA-256:
`94f1a49d5ffef427780c56f2baa1763aa6996b1005198f9568a67789877b35f3`.

The v1 rejection remains preserved: the NEW adapter omitted configure's normal
world `native_particle_stream_group` metadata binding, so actual close emitted
a missing-meta error before assertions. Only that fixture binding changed for
v2; all 236 assertions, the runner, prior-source bytes and producer were retained.

`reports/native-dense-particle-frame-spans-v1.json` records exact accepted hashes
and cleanup. The instrumentation is integrated in source; simulation/native-GPU
execution, performance, and a measured live breakdown remain unclaimed.
