# Connection follow-up audit — 2026-11-04

Read-only review found one reproduced admitted-peer disconnect race and one
unreachable reset block. No production change, original-server run, engine,
socket, DNS request, profile/key read or user-process action was performed.
The historical Cleric reconnect close remains unexplained.

The machine-readable receipt is
[native-connection-next-audit-2026-11-04-v1.json](reports/native-connection-next-audit-2026-11-04-v1.json).
Existing tests passed 41/41. A new socket-free regression deliberately retains
one passing control and one failing race, exit1. This is failure evidence, not a
fixed-client acceptance.

## Current owners and boundaries

| Boundary | Current owner | Relevant behavior |
| --- | --- | --- |
| Join, Cancel, local/server chooser, reconnect identity | `tools/native-lobby.mjs` | `join`57–68 advances connection, owns AbortController and races cancellation; `leave`146–154 advances again before cleanup and releases busy/menu state in `finally`. Late session/preview results are scope-checked. |
| Interruptible native commands | `tools/native-command-pump.mjs`4–12 | Lobby/control commands start independently of the ordinary serial command lane, so a queued upload does not block Cancel. |
| Installed session construction | `../electron/installed_network_session.mjs`8–24 | Abort checks separate asynchronous setup stages; a stale constructed session is disposed by Host before attachment. No actual construction was invoked in this audit. |
| UDP admission, reliable serial work and disconnect | `../electron/network_peer.mjs`24–50,92–111 | Peer serial queue; timeout starts after DNS/bind/identity preparation. Pre-admission disconnect closes immediately; admitted disconnect is queued. |
| Resources, character admission and area acknowledgement | `../electron/network_game_session.mjs`57–62,169–207,697–704 | Serial accepted-message delivery; close is marked before pending resource reads can publish/upload. Current area generation is rechecked after the area-ready send. |
| Godot catalog/setup and raw snapshots | `native_live_world.gd`180–226; `native_session_world.gd`109–125,453–495 | Retired connection messages are rejected before dispatch. Setup continuation checks the captured catalog-loader owner. Raw deltas require accepted serial plus current epoch. |
| Host attach/retire and raw acknowledgement | `tools/native-session-host.cjs`406–408,501–515,624,903–918 | Resets Host delta owner on attach/retire; tags connection and checks raw ACK ownership. `rawSerial`108 is process-monotonic, not restarted per join. |
| Cross-server character transfer protocol | `../electron/network_portal_transfer.mjs`8–57 | Downloads the handoff character, disconnects old peer, drains delivery and emits destination readiness. Late prepared sessions are disposed on cancellation. |
| Direct native handoff availability | `tools/native-session-host.cjs`477–479 | **Explicitly unavailable:** Host replaces `portalTransfer.prepare` with a throwing callback. Passing generic portal tests do not establish a working native cross-server handoff. |

## 1. Admitted queued-send/disconnect race — reproduced

`NetworkPeer.disconnect()`101–105 sets `disconnecting=true` synchronously, then
enqueues the cleanup task. If an admitted `sendGameMessage()`92–99 is already
queued but has not started, its97 guard throws because of that newly set flag.
The generic `enqueue()`24 rejection handler calls `finish()`, closing the peer.
The queued disconnect then hits the same queue's closed-owner guard **before
entering its own `try/finally`**, and rejects with
`Native network peer is closed`.

Exact deterministic repro, without any real transport:

1. Construct `NetworkPeer` with fake crypto and a fake `send` boundary; mark the
   authored unit state admitted and give it a reliable-window stub.
2. In the same synchronous turn call `sendGameMessage([112,1,0])`, then
   `disconnect()`, before the queue microtask starts.
3. Await both results. The cancelled request rejects; the peer closes once;
   **normal cleanup also rejects**. The idle admitted disconnect control passes.

The fixture is
[`../test/network-peer-disconnect-race.test.js`](../test/network-peer-disconnect-race.test.js).
Its unchanged production path ran with:

```powershell
node --test --test-reporter=spec test/network-peer-disconnect-race.test.js
```

Retained output:
`.cache/connection-next-audit/2026-11-04-v1/admitted-disconnect-race-red.log`.
Result:2 cases,1 pass/1 fail,exit1. No `connect`, UDP, DNS, external crypto
helper, credentials or gameplay authority was used. The expectation is the
existing local cancellation/cleanup contract, not a new claim about original
native wire shutdown details.

Practical consequence: `NetworkGameSession.disconnect()`701 propagates the peer
rejection; Host's disconnect callback515 awaits it; `NativeLobby.leave()`153
stores its message as the user-visible error. A successful local cancellation
can therefore be reported as a connection failure. This test does not establish
a permanent hang: its actual outcome is a closed peer with rejected cleanup.

Proposed correction scope is only the peer queue's distinction between an
expected cancelled request and a fatal protocol failure, plus idempotent
disconnect cleanup if the peer closed while queued. Keep genuine protocol
errors observable, prevent post-close sends and retain exactly-once closure.
Root owns any production patch; none was applied here. Add a composed mock
Session→Lobby regression before accepting a patch, and retain the idle control
and the current red test.

## 2. Raw snapshot reset is unreachable — confirmed source defect

`native_session_world.gd`794–799 currently contains:

```gdscript
func native_pointer_blocked(point: Vector2) -> bool:
    if closing or not is_instance_valid(world): return true
    return (the existing pointer-blocking expression)
    raw_world={}
    accepted_raw_serial=-1
    label.text="Native renderer · choose a server or character"
```

All three trailing statements are unreachable. `reset_session()`741–770 retires
render/UI/catalog owners and resets epoch but leaves both the partial raw
assembler and the accepted raw base intact. No other reachable reset of
`accepted_raw_serial` exists after its initial declaration. A partial raw frame
can consequently remain retained after cancellation/disconnect.

**Limits:** old connection frames are already fenced by109–125; cancellation
also rejects most same-connection work. A current valid Host restart sends a new
full frame with a larger process-wide serial, replacing the assembler. Reset
also sets epoch−1, so an ordinary old-area delta cannot use the retained base.
No stale world display, failed live reconnect or 30-second close was reproduced
from these lines. This is a definite reset invariant/retention defect whose
broader playability impact remains bounded by those existing fences.

Proposed exact shared change, for Root after its live source freeze: move the
three lines from797–799 to the end of `reset_session`, immediately after its
current770. Do not reset `raw_serial`: the Host serial is intentionally global
across connections. Do not change pointer policy, delta admission or connection
fences.

Proposed new isolated headless test (NOT run in this audit):

- Extend actual SessionWorld with startup suppressed; construct only the label
  and safe owner dependencies required by `reset_session`. No ticket, provider,
  server, catalog worker or visible window.
- Seed a partial assembler, `accepted_raw_serial=17`, `raw_serial=18` and active
  epoch. Invoke actual reset; require empty assembler, accepted base−1, preserved
  global serial18 and the default caption.
- Exercise actual connection admission with a retired chunk/end: it must still
  be ignored before payload processing. A same-scope orphan tail after reset
  must fail as incomplete, rather than reuse a retained partial frame.
- Check repeated reset and the existing pointer-blocking return behavior; a
  pointer query must not mutate raw assembler state.
- In the later already-authorized local reconnect suite, retain full-frame,
  stale-ACK and repeated-generation checks. Do not launch that suite during the
  current authority run.

## Retained local failures and superseded findings

The newest retained local reconnect failure reviewed is
`reports/native-creation-vault-cleric-v1-reconnect.json`, as summarized by the
existing `native-creation-cleric-reconnect-close-audit-v1.json`. The latter
retains exact source/artifact hashes and contrary evidence. Native chooser
selection proof completed; first raw ACK arrived10.930s later; the Host observed
`ECONNRESET`30.016s after proof with `ending=false`. Godot recorded
`poll_error=0/status=0` before shutdown. Two snapshots were received; the final
native state had0 rendered entities/18 desired. The later original-server leave
is consistent with cleanup, and does not prove server-first termination.

No captured close initiator/FIN stack establishes that cause. No peer/game-session
failure diagnostic or requested local disconnect links the newly reproduced
queue race to this older run. The30-second coincidence must not be relabeled as
a peer login timeout, fixed bug, or reason to extend waits. No saved Cleric login
or retry was performed.

Older issues already guarded in current source and the41 passing existing mocks:

- Cancel interrupts blocked preparation and upload; late attachment/preview
  cannot claim a replacement lobby.
- Closing during resource lookup prevents delayed upload or publication.
- Acknowledgement of an older area cannot put the newer area into playing.
- Generic portal character handoff and cancellation dispose old/destination
  owners correctly in mocks. Native Host destination integration is still an
  explicit separate limitation.
- Earlier ScriptFloating local-allowlist and inherited movement-probe failures
  were test-harness issues with retained changed-method acceptances; they are
  not current admission defects demonstrated here.

## Next bounded work

First correct the admitted cancellation race under the new red mock, then run
the composed mock Session/Lobby case and the existing41 checks. Independently
move the three reset statements and run the proposed actual SessionWorld test
in Root's next exclusive headless lane. Only then consider an explicitly
reviewed local admission/cancel/reconnect case. Preserve the Cleric rejection
and use evidence capture of actual close boundaries for its unresolved failure;
do not infer ownership from elapsed time or add an automatic retry.
