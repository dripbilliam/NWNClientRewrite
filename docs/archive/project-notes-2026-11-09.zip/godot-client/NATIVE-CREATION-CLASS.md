# Original Class chooser and active creation rules

2026-11-01. The source CG_CLASS child now commits through the real native draft
and scoped CG_MAIN coordinator. The complete original-style creator remains
staged until its other children and save workflow are finished. This is creation
mode; the original Class panel's level-up/multiclass routes are recorded but are
not accepted by this implementation milestone.

## Data ownership and shared controls

The user reiterated that creation and level-up must use the base or connected
server's `.2da` data. The independent pregame catalog owns GUI/model/font assets;
the active connection owns classes, races, prerequisites, stat gains, attack and
spell tables, feats, ruleset values and TLK text. No stock class names, selectable
classes, prerequisite lists, spells or feats replace those data. Catalog/TLK or
draft replacement retires held input and old result tickets.

`native_creation_choice.gd` and `native_data/creation_choice_layout.gd` now share
the actual list/help/radio-row/scrollbar machinery between Race and Class.
Individual state/view owners retain their own commands and commit semantics.
Authored CTL_CG_BTN_CLASS rows remain324×42, advance44, and keep32×32 icons in
aspect. Frames remain native Godot; neither this view nor its data projection
introduces JS rendering or a second character writer.

Class rows use the low BYTE physical class count and PlayerClass flags. Available
and unavailable classes remain listed; unavailable rows can be selected to read
help but have gray captions and disabled OK. Creation opens on the first visible
row. Title61920 and general-help480/484 follow source binding, rather than the
GUI's unmodified title140. Recommended uses physical row4, whose visible name,
icon and rules still come from the active table. A server without that row gets
no invented Fighter. The optional original sorting policy is implemented in the
choice projection: available rows first, then unavailable, with case-insensitive
insertion within each group. Its application preference UI remains unported.

`creation_class_rules.gd` replaces the earlier approximate first-level check.
It follows original case-sensitive requirement types, independent RACE/FEATOR/
CLASSOR alternatives, both feat lists, signed skill/save bytes, unsigned BAB,
CLASSNOT and class-level SPELL/ARCSPELL tests. Unknown types are ignored by that
original routine. Pending resource tables remain pending; completed missing
tables retain their empty-row behavior. Creation uses the initialized base-save
caches and active class level1 BAB, not an in-world buffed saving throw.

`CreationRules.commit_class` resets raw allocation even for the same class,
preserves a nonzero same-class hit-die cache, queries active HitDie/stat gains/
ruleset/primary-ability/racial adjustments, and records the original remaining
point BYTE separately. The original switch's initial alignments are retained;
they do not replace the following Alignment child's active table restrictions.
Package choice and derived reset belong to the parent: the source controller
resets skills/feats/spells/domains only when Packages had already been enabled,
then handles result8004 and invalidates later completion flags. Cancel/Escape
return2 without a draft commit. Results from replaced/reentrant drafts are refused.

## Original evidence and verification

Pinned nwmain.exe SHA256:
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.
The complete [REA dossiers](reports/native-creation-class-research-v3.json)
include bind8ec4b0, population8df5c0, selection8e6c50, recommendation8e6390,
OK8e36d0, Cancel8e10c0, Escape8e3340 and prerequisite7f5150. Class loader2a4a90
and draft/stat constructors resolve data offsets and initialization. CG_CLASS
resource SHA256 is45156aa0e9d86248573551f32bb1b955a9558688b2aa5c8f01f91f65ced5aa1e.

- `scripts/inspect-native-creation-class-prerequisites.py` executes600 original
  prerequisite cases, with explicit C2DA, allocation, feat-array, BAB-cache,
  class-slot and CRT providers. Corpus v2 SHA256:
  `91c7ef88d732a10e670b5c1224851afa05f42aa3bc498ba03ac10aa9d2c7ec38`.
- `scripts/inspect-native-creation-class-commit.py` expands the original vital
  instruction harness to record point/alignment fields across49 configurations
  and255 operations. Corpus SHA256:
  `0bf1aa0767c8e35a2418b0804ce4a96e2424f83dc6128de0a4ce6f0bad598850`.
  It covers159 Class commits, custom rules/gains and same/different-class caches;
  modal/lookup/stat-provider boundaries remain explicit in the harness.
- `native-creation-class-binding-v3` and `native-creation-class-release-v1`
  each pass1,108 headless checks against those corpora and actual source control
  input, help/availability, scoped commits, replacement tables/text, scaling,
  parent resets and retirement. Artwork/fonts use nonrendering doubles here.
- `native-creation-class-race-regression-v1` passes1,131 Race/Subrace original
  callback, key-guard and actual input/draft checks after shared-view extraction.
- `native-creation-class-overrides-v2` passes19 checks with actual authored
  server2DA/custom-TLK files mounted over the original install. The source Class
  control displays Server Mystic, omits the absent physical4 recommendation,
  and commits its HitDie6, primary INT, gain1, raw INT10 and remaining28 points.
  Existing custom spell/feat/package and replacement-catalog checks also pass.
- `native-creation-class-local-v2` passes26 creation checks on the already-owned
  original Prelude server127.0.0.1:5121. Actual source Gender/Race/Subrace/Class
  actions modify one real draft; the prototype Package/remaining pages finish
  it. The original server admits and exports Wizard10 level1, correct school,
  feats, known spells, all28 skill ranks and matching identity/race fields.
  Native and server-confirmed movement are1.500033m. Native exit0, acknowledged
  shutdown, zero workers/public connections, no exception and unchanged source.

Retained failures: initial prerequisite execution missed the cookie runtime
boundary; corpus v1 incorrectly clobbered the pending return register there.
V2 preserves it, checked against the original tail instructions. Binding-v1
also exposed a missing shared helper preload and typed JSON dictionary comparison;
binding-v2 retained only the invalid-oracle failures. Production rules were not
weakened to accommodate either. Local-v1 exposed the test adapter clearing its
staged summary provider on modal return; v2 restores that binding before continuing.
No failed corpus or receipt was overwritten or counted as accepted.

## Remaining acceptance and next work

Original-client pixel/hover/sound/key comparison, wider source help warning
variants, original optional-sort preference UI, all level-up Class routes and
the remaining source children stay open. The separately recorded Class point
BYTE is exact here; the prototype Attributes allocator still needs original
cost/limit/remaining-cache parity, especially custom gains that initialize a raw
primary below the usual base minimum. Do not claim full point-allocation or
character-creation parity from the Class commit corpus. Existing-BIC
preservation/save/customization remains unaccepted.

The later [Alignment follow-up](NATIVE-CREATION-ALIGNMENT.md) binds that source
child and shares its readonly help with Race/Class; the Class1,108-check
regression passes. Next are Abilities and Package, retaining the shared native
framework where original resources support it. No public join, visible/GPU
benchmark or user/editor process restart was performed.

Before-change checkpoint: `backups/native-creation-class-before-v2.zip`, SHA256
`217a82e9732d4d0eb854767f70277f8caab23cd714a75ef979a4c565f5c8591e`.
V1 was an additional project-only checkpoint; v2 also includes the prior authored
workspace reference scripts. The full UI goal stays active.

Verified final checkpoint: `backups/native-creation-class-bound-v1.zip`,2,403
files, SHA256
`c97f9be90e73248fc6b5c9675b54acce04dab8901c014fda429e255f01d7d443`.
The [acceptance receipt](reports/native-creation-class-bound-v1.acceptance.json)
rechecks every listed production source against the four headless receipts and
records local-server/export/shutdown and checkpoint verification. It explicitly
leaves graphical, level-up and full-goal acceptance false.
