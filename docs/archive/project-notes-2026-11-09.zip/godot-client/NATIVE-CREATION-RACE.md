# Original Race chooser and Subrace dialog

2026-11-01. The original CG_RACE child is connected to the real native creation
draft and scoped CG_MAIN parent, alongside Gender and Portrait. The full source
creator remains staged while Class, Alignment, Abilities, Package and the other
children/save workflows are ported. This is a functional child migration, not
activation or visual acceptance of a complete creator.

## Original resources and behavior

CG_RACE SHA256:
`5d1c7fcce1814e932de57a25bacaa90a54e2b3e05a5e8a65d244212d8b792170`.
UTIL_EDITPOPUP SHA256:
`bca0ac612d83a58193f708a9c26dff1db1c5ba628f88bc5dfafb5f4f28dc2a45`.
`native-creation-race-layout-source-v1` reads the four original creation/helper
GUI resources and their models. Runtime geometry uses their hooks and bounds,
not screenshot coordinates. CTL_CG_BTN_CLASS rows are324×42 with44-pixel advance;
the help text body is323×317. Row captions use text0/text1, with left alignment;
icons keep their aspect ratio at the original icon hook. Original scrollbars
retain their animated model/rail/thumb ownership.

The original pinned binary is SHA256
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.
Read-only REA dossiers are `reports/native-creation-race-research-v1.json` and
the correcting/expanded `native-creation-race-research-v2.json`. The latter
retains LoadRaceInfo2aa460 and the generic-edit functions as well as Race help
and Escape. Important verified mappings:

| Original field/action | Source behavior |
| --- | --- |
| LoadRaceInfo / InitializeRace | The physical row count is stored in a BYTE; eligible PlayerRace rows keep ascending physical IDs, without alphabetical sorting |
| Row name / selected help title | Name / **NamePlural**, respectively; the title is not ConverName |
| Help description / biography | Description / **Biography** |
| CNWRace+54 | **AbilitiesPointBuyNumber**, not a skill-point field; Race OK copies its low byte |
| Recommend8e6730 | Selects physical race6; an absent row produces no selected entry, not an invented Human fallback |
| Title8e7dd0 | Restores general help481/485 while preserving the selected row |
| Race OK8e53e0 | Writes selected race/appearance, biography, age and base allocation, then returns800a; the reset also happens when race is unchanged |
| Race Cancel8e1250 / Escape8e34a0 | Return2 without committing the preview |
| Subrace8e7730 / accepted8e7810 | Opens UTIL_EDITPOPUP with title8185 and typing limit20; acceptance writes the text/flag and immediately invokes Race OK |

If Subrace is accepted while no race is selected, the text/accepted flag remain
but Race does not complete. Later choosing a valid race preserves that accepted
text. Without an accepted Subrace callback, changing race clears the old text.
Recommended availability follows active CHARGEN_ENABLE_RECOMMENDED_BUTTON and
uses the original gray caption when disabled. A missing recommended row clears
the help description while retaining the prior title, as the original callback
does. The raw base abilities reset to CHARGEN_BASE_ABILITY_MIN without reapplying
a class-primary minimum; class and base-hit-die cache are retained.

## Native owners and framework

- `native_source_modal.gd` shares original GUI/model worker preparation,
  source-button construction, scope tickets, held-input retirement and close.
  It uses the existing native painter/menu builder rather than another theme.
- `native_race_chooser.gd`, `creation_race_layout.gd` and
  `creation_race_state.gd` own the source list/help and local selection. The
  original title action and separate Race/Subrace Escape paths are wired.
- `native_generic_edit.gd` owns the shared original text-edit popup used here.
  Existing text is not silently truncated: the original derived edit checks
  length when receiving a key. The native guard preserves the observed editing
  keys at the limit. Enter submits and Escape cancels this popup alone.
- `NativeCreation.commit_source_race` validates the current editing draft,
  applies active-table/text values, and handles the original conditional
  derived-choice reset. The shipping sidebar now delegates its race write to
  the same rule owner. Its visible list observes the original physical count.
- `native_creation_frontend.gd` commits the current child ticket before
  advancing CG_MAIN. Active choice/text replacement retickets the view; stale
  release/callbacks cannot write a reopened draft. Reentrant owner retirement
  cannot overwrite the new parent's data. Rejected radio releases restore the
  widget's actual checked state, including the existing Gender radio path.

Frames/art/buttons remain owned by the independent pregame catalog/TLK. The
choices, names/descriptions, rule values and eventual native BIC use the active
server catalog/text. Changing server data does not reskin the pregame frame.
The point-buy cache is copied into the native BIC worker's draft validation.
No standalone server action is invented for a local selection; the finished
native BIC carries the accepted values through the original protocol.

## Evidence and limits

`../scripts/inspect-native-creation-race.py` executes384 unchanged original
Race OK/Cancel/Subrace callback cases, with explicit object/table/text/setter,
unarmed-cache and GUI lifetime boundaries. Corpus SHA256:
`ca7e4016c4cbca47afd96dc4d19e6775237924e08060686b2c65577c627003cf`.
`../scripts/inspect-native-generic-edit-keys.py` executes325 original
SetMaxCharacters/HandleKeyPress cases with ASCII length, wrapper access and
parent-edit boundaries. Corpus SHA256:
`3a18509ac2043d5ad9abf4f54df688ef4ac8644886f4d536d2590cbf2b79cfdd`.
Both corpora are under the workspace's `backups/animations` directory.

- `native-creation-race-binding-v9` and `native-creation-race-release-v2` each
  pass1,131 strict checks. They compare the original corpora and exact GUI
  hashes, then use real source controls/creator input for row preview,
  OK/Cancel, title help, Enter/Escape, over-limit text, missing/disabled
  recommendation, accepted-Subrace retention, same-race reset,512×400 scaled
  pointer alignment, text replacement and stale/reentrant retirement. Artwork
  and fonts are non-rendering doubles: these are not original-pixel checks.
- `native-creation-race-gender-regression-v2` retains208 original Gender and
  actual input/lifecycle checks after the shared/retirement changes.
- `native-creation-race-local-v2` passes24 complete localhost creation checks.
  The actual source Race and Subrace controls commit race6 and Native Subrace
  before the native Wizard BIC is built. The original Prelude server admits it
  and exports matching race, subrace, age18, appearance6, biography, gender1
  and all28 skill ranks. Native and authoritative movement both reach1.50003m;
  exit0, acknowledged shutdown, zero workers/public connections and unchanged
  source. V1 also passed before the final input refinements; V2 is current.

Retained early failures: the first Python Race-oracle attempt used an exclusive
Subrace callback bound that omitted its final return; the provider-confirmed
inclusive end8e7891 corrected that boundary before any corpus was written.
Binding-v1 was a test-local missing type annotation; v2's single failed assertion
expected the dormant pane to have active text before it was opened. The scoped
frontend already held that provider; the test now checks each ownership stage.
Neither was a green runtime/gameplay receipt. Subsequent versions added concrete
input/lifecycle coverage; none of those failed receipts was erased.

Full source-creator activation, remaining children, preservation-safe existing
BIC/save/customization, exact font/art/hover/sound/scale pixels, broader keyboard
and clipboard/composition behavior and other generic-edit consumers remain open.
The original Race Escape target was read at vtable+140 and decompiled, while
fresh physical input is separately checked; not every inherited key route is
claimed. No graphical/GPU test or autonomous public connection was run, and no
user/editor process was closed or launched. The complete UI goal stays active.

Before-change checkpoint: `backups/native-creation-race-before-v1.zip`, SHA256
`22c8e4cdbe228b960b116d638d6746726115e3ce98f15aedd181c07dd01819a9`.
The later [Class follow-up](NATIVE-CREATION-CLASS.md) extracts the shared
Race/Class list/help owner and binds Class to the same draft. Race's1,131-check
regression passes after that extraction. The next children are Alignment,
Abilities and Package; imported-BIC projections cannot replace the real draft.
