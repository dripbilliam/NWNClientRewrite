# Controlled actor stored-name initialization audit

The bounded source audit does not certify constructor-empty names for an existing controlled proxy. Login, module, object-control, player-state and area entry establish lookup, selection or reattachment; none of the reviewed immediate bodies publishes stored-name initialization. Keep that state unknown until an actual certified native construction/load/publication exists.

The important additional writer is client stats GFF loader `7f7e20`: `FirstName` and `LastName` are localized loads into stats `+20/+30`; raw `DisplayName` is copied into override `+40`. A BIC/UTC-loaded owner can therefore carry a nonempty override. This is distinct from the all-empty fresh constructor proved in [the prior review](NATIVE-ACTOR-NAME-OWNER-REVIEW.md).

All seven recovered direct callers of that loader were inspected. They load character-list, selection, customization, save-game or local character-sheet preview data. In particular `88ad50` constructs a separate **internal** preview creature before loading BIC/UTC; the selected character and its name are not thereby proved to be the external controlled actor. This audit did not find a certified transfer and does not assert none exists.

Among all eight recovered direct `7fb140` creature-constructor callers, `77f870` is the actual external A path. It first looks up an existing typed creature and only constructs/registers when absent; repeated A reactivates the existing owner. The other reviewed paths are UI/preview/creation or transient effect dummies. This direct-call coverage does not exclude indirect registration or clone paths and cannot by itself certify a generic JS proxy as a native actor.

The exact next bounded native boundary, if required, is `CGameObjectArray::AddExternalObject 295b30` and its actual callers: determine whether any local BIC/preview owner is transferred into an external controlled ID before A. The immediate A dispatcher is `7b23e0`; the controlled-ID setter `6acc50` only stores the ID. Do not manufacture a transfer or replace the missing fact with UI-name equivalence.

[The compact report](reports/native-actor-name-controlled-load-audit-v1.json) preserves original evidence IDs, exact name-loader/A snippets and direct-caller classifications. No production/test changes, engine/server run, GPU work, user-process action, profile/key access or native build occurred. The separate snapshot-fetch45 gate is not controlled-name lifecycle acceptance.

