# Native familiar and companion creation

The source-backed native data/layout slice now has actual controls and a creator
binding. The standalone controls passed 30 native input/lifecycle checks; the
composed creator/worker/BIC path passes 24. See
`NATIVE-CREATION-FLOW-INTEGRATION.md` for current wiring and evidence boundaries.
This does not accept complete source creation, original pixels or level-up parity.

## Original owners and behavior

The original `9c69a0` coordinator opens `CCharacterFamiliarPanel` after Domains,
School and Spells when the physical class's `MinAssociateLevel` byte is at most
the current class level. Its constructor passes the actual `Arcane` field and
imports `CG_FAMILIAR`. This path uses ordinary `CGuiPanel::Activate`; modal RTTI
does not establish membership in the GUI manager's modal array.

`9c5ca0` loads `HEN_FAMILIAR` when Arcane equals 1, and `HEN_COMPANION` otherwise.
It walks physical rows in their original order. A row is present only when its
`STRREF` integer lookup succeeds and `BASERESREF` string lookup succeeds with a
nonempty value. There is no stock creature list or name-based sorting. Row IDs
remain physical IDs even when rejected rows leave gaps.

`9ca900` takes a visible list index, maps it through the row-ID vector and asks
the existing character sheet to load UTC type 2027 using `BASERESREF` followed
by the current level formatted with at least two digits. Native resource names
retain their 16-byte reference limit. The no-selection callback disables OK.
The original initial stored type is used as a visible index rather than being
searched as a physical ID; sparse tables preserve that behavior.

The type/name storage branch tests Arcane against zero, which differs from the
table branch for unusual values such as 2. The native policy preserves that
distinction. Empty names use the active original name generator; no invented
default name is supplied. The original OK callback continues the parent sequence
before writing the selected physical ID/name and destroying the child. Cancel
resets derived choices and returns creation code 3 (level-up code 2). Full panel
preparation, name generation and those commit/cancel callbacks have static
evidence here, not complete execution acceptance.

## Native slice and evidence

`systems/native_data/creation_associate_state.gd` owns only detached chooser
metadata, selection and name values. It borrows the existing typed physical 2DA
reader. Unloaded or unresolved data remains unavailable; a loaded empty table
has no invented row. Selection views cannot mutate private state, and an empty
name commit requests an actual generated name. Unsafe negative stored tabs,
which would cause an original out-of-bounds read, remain explicitly unavailable.

`creation_associate_layout.gd` validates the original list, edit, row, button
callbacks and character-sheet attachment. Installed `CG_FAMILIAR` SHA256:
`69ad9599bb1dec2a1fe7942897e3cc9ac1eca9cc8b123a6f365f5946c8b39ce0`.
The source row helper is `CTL_CG_BTN_FAMIL`, distinct from the class/spell rows.

`scripts/inspect-native-creation-associate.py` executes the complete original
loader `9c5ca0` and selection callback `9ca900` instructions in an isolated CPU
emulator. C2DA getters/load, allocation/string formatting and GUI/sheet services
are captured boundaries. Its 180 cases preserve actual physical rows, table
selection, preview resource/type and OK admission. Oracle SHA256:
`42fa04027a490deb766c035a7f6ed13a3cb9168ad779f0c8015c252fa1c2d0a5`.
The immutable original client is
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.
Complete static dossiers are in `reports/native-creation-associate-static-v1.json`.

`native-creation-associate-state-v2-receipt.json` passes 563 focused native checks,
including comparisons with all 180 original cases, sparse/empty/missing data,
physical duplicate-column precedence, name ownership and mutation isolation.
Eight 1,024-row active-table decodes took 6.717–9.725 ms. This is CPU boundary
work, not repeated per-frame work, FPS, cold control readiness or a whole-client
benchmark. The earlier v1 runner retained a copied, incorrect scope label from
the spell helper; its result/logs are preserved. V2 corrects that evidence label
without changing the policy or assertions.

`native-creation-associate-resources-v2-receipt.json` passes four installed-layout
checks, including missing-row-helper rejection. Both accepted engine logs are
clean with exit 0, no timeout and unchanged copied static inputs. Tests use hidden
isolated headless projects, no server, GPU benchmark, credentials, shared native
build or user-process restart.

## Remaining integration

The source Control now uses original row/edit/scroll geometry and the existing
private character-sheet owner. Its native UTC, stats and name-service bindings
are wired and undergoing composed actual-input/draft/BIC testing. Original
continuation/write order, preparation-time side effects and Cancel/reset need
their complete acceptance evidence. The full source creator must
still pass original-client visual comparison and authoritative save/admission;
level-up needs its own active-state path. This slice does not establish those
requirements or complete gameplay readiness.

```powershell
./godot-client/tests/run-native-creation-associate-state-tests.ps1 -Name unique-policy-run
./godot-client/tests/run-native-creation-associate-resources-tests.ps1 -Name unique-layout-run
```
