# Creator title and class availability repairs

The reported CG_MAIN title used an unbounded text anchor at the title bar's
left edge. Original initializer `1408ec740` sets `TitleLabel`'s bounds flag4
before `ImportLayoutData`. `creation_main_layout.gd` now retains the original
rectangle, so its existing center alignment applies within the title bar.
The earlier nine-menu title repair had omitted this parent frame.

`creation_class_state.gd` now enables its existing original available-first,
name-sorted grouping by default. Hidden/non-player classes stay excluded;
unavailable rows remain selectable for help with OK disabled. All entries
retain physical server class IDs. Active prerequisites and localized names
determine the grouping each time the owner publishes a new context, rather
than through a per-frame scan.

Validation uses isolated copies, not the running user client:

- `native-creation-title-main-after-v1`: 108 clean checks using actual installed
  GUI/MDL and native FontFile/atlas glyph bounds across ten title bars and scale.
- `native-creation-class-order-after-v2`: 17 clean checks, including actual
  Class pointer input, changed server prerequisites, unavailable help/OK,
  recommendation, physical ID preservation, stale input and scaling.

Receipts are under `.cache/creation-claimed-titles/` and
`.cache/creation-class-order/`. The initial restricted-process title baseline
reported the expected three CG_MAIN geometry failures, but also Windows
certificate-store errors; it is retained as rejected environment evidence.
The accepted run has no engine errors or warnings. Original title evidence is
`reports/native-creation-main-title-source-v1.json`.

Dirty before-files were preserved in
`../backups/native-creation-title-class-before-20261103-205741/`.
Ability row artwork/UV alignment and the remaining Customize sequence are
separate fixes; these checks do not establish full UI, pixel or server parity.
