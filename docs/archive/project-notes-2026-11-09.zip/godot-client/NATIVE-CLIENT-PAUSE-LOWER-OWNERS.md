# Native client pause lower owners

This is a parked, read-only source audit. Root stopped the clock investigation on 2026-11-04 to prioritize visible chat and area borders. Only the findings already traced below are retained. No production hooks, tests, native execution, engine, server, build, GPU or live-process actions were performed.

The bounded evidence is [native-client-pause-lower-owners-v1.json](reports/native-client-pause-lower-owners-v1.json). It pins static observations of original `nwmain.exe` SHA-256 `3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`. Existing [clock lifecycle](NATIVE-REMOTE-CLIENT-CLOCK-LIFECYCLE.md) and [service contract](NATIVE-CLIENT-CLOCK-SERVICES.md) remain separate evidence.

## The callback called audio controls scene animation

In pause setter `1406e1fc0`, the chain is client render owner → current area at `+f8` → area scene at `+248`. The call on entering pause is virtual `d0`; the unpause call is virtual `c8`. The native Scene vtable `140d8dd30` maps these to **Scene::DisableAnimations `1400c7550`** and **Scene::EnableAnimations `1400c9270`**. They write the Scene animation byte `+b9` to zero/one; `Scene::IsAnimating 1400cafe0` reads it.

The pure component's label `audio(on)` therefore must not be bound to an audio pause API. No sound endpoint was found in this branch. The current area's exact allocation/derived override closure was not completed before the stop; this report retains the static slot identity and the creature model scene-switch use, not a runtime pointer observation.

## Exclusion callbacks enable forced model animation

`1407630a0` returns `CNWCObject+78`. This is an **animation-owner pointer**, not directly a Gob or Scene. Creature `LoadModel 140802cc0` constructs `CNWCAnimBase 140960b40` or one of its native model variants and stores that pointer. Its vtable is `140e6e978`.

| Pause callback | Native chain | Effect |
| --- | --- | --- |
| Incoming virtual150 | `961480 → model(ff) → Gob virtual1c0 → 08de00` | Set Gob byte1a=1, EnableForceAnimations. |
| Old-list virtual158 | `961420 → model(ff) → Gob virtual1c8 → 08ddc0` | Set Gob byte1a=0, DisableForceAnimations. |

The TW variant (`998ad0`, vtable `e74980`) applies the same operation to three extra model pointers before the base model. Static Head/Wield/HeadWield/Parts slot bytes and immediate adjustment wrappers are retained in the report; this is not a claim to have reconstructed every model-family side effect.

The relevant `Gob::Animate 14004dbd0` predicate is `(no scene || scene.IsAnimating() || gob.IsForceAnimated()) && gob.IsAnimating()`. Earlier behavior callbacks and outer bookkeeping precede that gate. Thus these callbacks let selected models animate while ordinary scene models stop. A whole Node, SceneTree, animation-player or popup pause would be too broad.

The closest existing Godot owners are `native_render/live_world.gd` installed instances, `model_rigs.gd` entity model records, and each `model_native_animation.gd` owner before its `ModelRuns.advance`. That existing run port does not yet model the outer scene enable/forced-animation admission. A future adapter needs the actual native model set and exact physical owner lifetime, including replacements. It must not infer a live visual owner from a numeric ID alone.

## Reset means only previous object time

Creature reset `140807680` writes day to `+50` and time to `+54`. It does not reset the FIFO cooldown, current animation, popup duration or movement. Named base `CGameObject::ResetUpdateTimes 1402964d0` is an actual no-op. Current ClientClockServices/ClientObjectClocks thin-reference reset staging is the appropriate existing boundary when the constructor/AI/physical-owner fact is known.

Order remains significant: `6d6770` resets old-list object timestamps using post-transition flags/timers, then calls virtual158 and finally clears the old buffer. `6e1fc0` then visits incoming entries: virtual150 first, selected-time reset second. Duplicate callback occurrences are not permission to collapse these operations.

## GUI values are not generic profile or pause state

The pure argument named `profileMode` is **CServerInfo+128, PlayOptions/PauseAndPlay**. `StartServices 6e3c80` allocates the CServerInfo at client-internal `+8`; ctor `2ccad0` initializes the field to one and registers its named option pointer. It is not a player-profile mode or DM permission. The GUI input blocker bypasses when this setting equals one. A ctor default does not certify the current remote value after updates.

`guiActive 6f9a90` returns the GUI owner's DWORD28. Its complete activation/publication lifecycle was not traced. `guiBlocked 6fae70` creates one cached `GUI_EMPTY` modal panel and activates/deactivates it, updating panel modal-input pointers. An additional native global `141297008` gates actual blocking; its settings owner remains unresolved. This is input routing, not time advancement.

`guiSetFlags 6f63d0` and `guiClearFlags 6fa410` manage portrait models. Bit2 is `CTL_BTN_PB_TMSTP`; bit4 is `CTL_BTN_PB_PAUSE`. Native pause mask1 maps to portrait bit2 and mask2 to bit4. Setting creates/attaches the badge, clearing deletes it. Separate bit1 is a level-up badge. These callbacks do not change bubble clocks.

## Pause text is feedback log output

Setter text IDs205/206 are feedback cases, not StrRefs. `6cb2e0` cases `cd/ce` call native lookup/parse helper `6d7700` with TLK refs **104d2/104d5**. The common nonempty tail wraps the supplied six-byte native RGB prefix and closing `</c>`, then sends `6f68d0` with flags128. The setter supplies bytes `3c 63 ff 01 01 3e`. These cases do not establish an overhead popup or audio action.

Gameplay's existing TalkText/native feedback and chat owners are relevant implementation points, but a certified publisher must preserve the native retained parser state and current chat preferences. This audit did not add such a publisher or resolve the installed TLK text.

## Remaining boundary

Scene animation admission, current PauseAndPlay publication, exact GUI active/global-block state and certified pause feedback routing remain actual provider work. Ordinary speech and ScriptFloating active GUI timers continue to use the separately owned T2 delta; forced model animation must not freeze them. No missing callback is licensed as a no-op. Cross-model behavior, native renderer pixels and live pause behavior are unproved. Further tracing and implementation are parked by Root's instruction.

