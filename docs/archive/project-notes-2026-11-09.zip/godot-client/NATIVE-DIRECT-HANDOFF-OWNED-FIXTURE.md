# Owned current direct-route handoff fixture

This NEW fixture targets `tools/native-session-host.cjs` and the current
`native_session_world.gd` entry. The older `local-host.cjs` A→B→A/recovery
receipts cover a different host and presentation route. They are source references,
not acceptance of this route.

Only file preparation, nine Node tests and PowerShell AST parsing have run.
No server, query, Godot, GPU, OS input, credential or user-process action has run
for this fixture. Root owns the production coordinator, shared flags and later
runtime grants. The NEW GDScript entry/probe is authored but not yet compiled.

## Private fixture and preserved inputs

Prepared directory:
`.cache/native-direct-handoff/native-direct-handoff-roundtrip-v1/`.

| Side | Endpoint | Module / client NWM | Entry | Arrival waypoint |
| --- | --- | --- | --- | --- |
| A | `127.0.0.1:5129` | `NativeHandA1` | `dense_a` | `NativeArrivalA` at `[52,40,0]` |
| B | `127.0.0.1:5130` | `NativeHandB1` | `dense_b` | `NativeArrivalB` at `[52,40,0]` |

Each server has a distinct new private profile. Both modules derive from the
pinned authored GodotFeedback1 baseline. Each changes only its IFO, `godot_chat`
NCS and entry GIT. The GIT change only appends one arrival waypoint; existing
objects/spawns are preserved. All 11 other payloads, including both ARE grids,
are byte-identical. Both private client NWM files exactly match their server MOD.
The inherited stream-grid limitation is unchanged and is irrelevant to this
headless ownership/transfer check; no scenery pixels are claimed.

The script prepends the literal `-native-direct-handoff` command and calls the
installed original `ActivatePortal(oTarget,sIPaddress,sPassword,sWaypointTag,
bSeemless)` with the destination loopback address, empty password, destination
arrival tag and seamless flag 1. Arguments are pushed in original reverse formal
order. Other chat branches remain in the original authored NCS tail.

## Root-owned shared hook contract

The exclusive opt-in is:

```text
--direct-handoff-check
--direct-handoff-directory=<absolute prepared directory>
--direct-handoff-scenario=roundtrip|cancel|failure
--native-headless
--native-runtime=editor
--run=native-direct-handoff-...
--private-login-pipe=<ephemeral private pipe>
```

`native-direct-handoff-mode.cjs.options(argv)` enforces this exclusive argument
set. The Host must allow only the two descriptor endpoints and remove the
ordinary loopback 5121 default. Initial admission uses the unchanged installed
`wizard.bic`; transfer admission must use the original downloaded character,
without a second chooser/upload of the installed fixture.

The Host may import these NEW fixture methods:

- `prepare(directory)`: fresh file-only preparation; refuses existing evidence.
- `read(directory)`: strictly rebuilds and verifies both private module/catalog
  byte sequences, descriptor paths, baseline, original executable and API pins.
- `identityPin(directory,{host,port})`: after an owned server starts, selects only
  its exact descriptor endpoint and extracts its public identity from its bounded
  fresh log. Returns `pin`, `fileSha256`, `identitySha256`, `descriptorSha256`.
  Never put private key or character bytes into reports or Godot messages.
- `COMMAND`, `SERVERS`: exact command and two endpoint/module rows.

Shared join/bootstrap changes belong to Root. The NEW wrapper requires
`DirectHandoffCheck`, `DirectHandoffDirectory` and `DirectHandoffScenario` join
parameters before any server/key activity. The join mode must preserve no-build,
headless editor, private pipe, scoped endpoint, bounded broker timeout and owned
process-tree cleanup. The Host must select
`res://tests/native_direct_handoff_world.gd`, add `--direct-handoff-check=true`
to its user args, and branch before unrelated movement/picking probes.

The Host sends, only for its current accepted connection:

```text
{kind:'probe-direct-handoff', connection,
 mode:'observe'|'chat'|'cancel'|'retry', generation, areaId}
```

`observe` waits for the genuine controlled world and retirement of weak previous
world/UI/HUD/catalog owners. It reports:

```text
{kind:'direct-handoff-observed',connection,result:{
 success,failures,scope:{connection,generation,areaId},source:{
 id,objectType,nativeLifetime,knownLifetime},worldReady,guiOwned,
 catalogInstance,module,worldInstance,gameplayInstance,retiredAlive,position}}
```

`chat` calls the actual current `Chat.submit(COMMAND)` and reports
`direct-handoff-command`; it injects no pose, packet, clock or received outcome.
`cancel`/`retry` push viewport mouse events only onto visible, enabled actual
controls and return `direct-handoff-control`. They do not activate an OS window.
Recovery wiring and those GDScript paths remain unrun; no hidden button or
fabricated control readiness is accepted.

## Evidence methods and required provenance

`native-direct-handoff-capture.cjs` exports `DirectHandoffCapture` and `evaluate`.
Construct with the strictly read descriptor and scenario. The methods consume
detached, bounded DTOs built at the corresponding actual Host/backend boundaries:

| Method | Required DTO fields / actual boundary |
| --- | --- |
| `admission(dto)` | `connection,endpoint,phase:'playing',confirmed,areaId,generation,source`; `catalog:{ready,instance,module,archiveSha256}`; `waypointRequests,waypointRemaining,position`; actual probe `native` result. Catalog hash comes from the published current descriptor/resource source, not a guessed label. |
| `transfer(dto)` | `from,to,endpoint,character:{kind:'bic',bytes,sha256},transmittedSha256,originReleased,originHandoffReady,stages`. Record actual downloaded original BIC hash and actual destination payload hash separately. Roundtrip hashes must match. Before failed/cancelled connection, transmitted hash may be explicit `null`; that does not prove an upload. |
| `readCharacter(dto)` | Actual installed file read only: `connection,key:'installed:wizard.bic',sha256`. Roundtrip allows only the initial read; origin recovery permits one fresh read on the final connection. |
| `recovery(dto)` | Actual `success,sourceWorldRetired,destinationClosed,privateCharacterWiped,joinWhileClosing,menuUsable,retryPointer,cancelPointer,destinationConnectCalls,destinationStopped,error`. Cancel requires zero connect calls; failure requires one and an owned stopped destination. |
| `finalExport(dto)` | Actual final original-server BIC result: `kind:'bic',bytes,sha256,connection,parsedOriginal:true`. No raw BIC enters the DTO. |
| `terminal(dto)` | Actual `nativeExit,disconnected,workersRemaining,forcedStop`, after cleanup. |
| `snapshot()` / `evaluate({beforeShutdown})` | Detached evidence / 21 strict predicates. `beforeShutdown` only defers the final exit predicate. Final wrapper acceptance requires actual shutdown. |

Call counts are bounded. Password/private-key/raw-character fields and oversized
DTOs are refused. Mock tests verify the predicates and rejection of legacy route,
stale scopes/lifetimes, reused catalogs, re-selection, mismatched BIC hashes,
arrival failure, lingering owners and incomplete cleanup. A passing mock is not
evidence that any of those real boundaries occurred.

The initial roundtrip is the priority: admitted A→B→A, source release before each
new admission, original character transfer twice, fresh destination catalogs,
original arrival requests and final export. Cancellation/failure recover to a
usable menu and a fresh A admission; they are separate scenarios, not substitutes
for the roundtrip.

The current Host driver deliberately implements **roundtrip only** and refuses
the reserved cancellation/failure scenarios. Recovery predicates and wrapper
barriers have mock tests, but recovery orchestration is queued for a separate
review and run.

## Current Host driver hooks

`native-direct-handoff-host-check.cjs` exports `NativeDirectHandoffHostCheck`.
Construct with `{fixture,scenario,send,finish,getScope,characterDigest,rawCombat}`.
`getScope()` returns the actual `{session,lobby,catalogReady,rawSerial}`.
`characterDigest` is synchronous and parses actual original BIC input, returning
`{kind:'bic',bytes,sha256,parsedOriginal:true}`. The driver independently verifies
the byte length and SHA. Its Node control-flow unit test supplies a labelled mock
parser; that mock is not native BIC or server evidence.

| Hook | Exact placement / behavior |
| --- | --- |
| `boot()` | On actual browser-ready, after native authentication and lobby construction. Calls real `lobby.join` for A once. |
| `tick()` | Alongside normal setup/catalog/raw publication. Owns initial `lobby.choose/play` only; then probes actual playing scopes. It must replace only generic test selection/movement branches, not suppress the shared publication tail. |
| `command(message,current,connection)` | Synchronous bool before generic dispatch. Handles native probe messages; returns **false** for the actual portal chat command so normal chat transport still runs. It may start asynchronous work internally. `browser-ready` also starts `boot()` idempotently. |
| `readCharacter(current,connection,key,bytes)` | In actual installed file reader. Initial preview and play legitimately read the same file twice; bounded initial-connection reads are allowed, destination re-selection is refused. |
| `preparing({current,connection,next,endpoint})` | After the policy-checked destination session is created, before returning preparation. Records weak origin ownership and instruments only that test destination's actual `uploadCharacter`. |
| `ready({previous,next})` | **Synchronous** portal-ready listener registered before the production adoption listener. Original `acceptPortalCharacter` has already copied its BIC into `next.session.character` and released the source. Hashes that view without retaining raw bytes. |
| `install({previous,next,connection})` | At actual destination attach/install, before destination connect; validates the original released owner and new connection. |
| `transferevent({stage,from,to,endpoint?})` | Actual coordinator event. Uses the endpoint captured by policy-checked preparation. If an endpoint is supplied, it must match. Production `connected` is scope-checked then ignored; it does not fabricate an installation. |
| `exported(current,connection,bytes)` | In actual `persistCharacter` callback. Captures only the final export it requested; returns false for unrelated saves. |
| `terminal(dto)` | After actual native exit/disconnection/worker cleanup, with the fields specified above. |
| `snapshot()` / `evaluate(options)` / `close()` | Detached current evidence / strict gate / restore only the test's upload-method wrappers and release callback bookkeeping. |

The upload instrumentation calls the original method unchanged. It hashes the
actual pending character before that method and records transmission only when
the original awaited send succeeds. No previous session is retained strongly;
the driver keeps weak origin/destination references and small digests. Native
source witnesses use the same `EntityDisclosureLifetimes.token` as
`transportRow.clientKnownLifetime`, after at least one actual raw publication.

## Failure barrier and guarded runner

The failure-only Host test hook may write `stop-destination.json` in the exact
fresh fixture directory after character download, before destination connect:

```text
{version:1,kind:'native-direct-handoff-stop',host:'127.0.0.1',port:5130,
 fixtureNonce:<descriptor nonce>,from:<source connection>,to:<new connection>}
```

The wrapper checks this bounded request, stops only its exact B process after
binary/profile/module identity checks and waits for its own UDP socket to clear.
It creates `destination-stopped.json` exclusively, containing `version:1`,
`kind:'native-direct-handoff-stopped'`, the same endpoint/nonce, SHA256 of the
request and `stopped:true`. The Host must validate all those fields before making
its one real failed destination connect attempt. No public or arbitrary endpoint
is allowed. Cancel must be coordinated before connect without this stop barrier.

The NEW wrapper prepares files with `-PrepareOnly`; a runtime run requires the
already reviewed prepared descriptor. It uses private ALT lease/pipe, nonpublic
max-1 local-vault servers, existing original server/editor/process/profile/six
output guards and finally cleanup of only identities it started. Its child join
wrapper is bounded to 720 seconds and, on timeout, only its verified owned process
tree can be terminated. It never controls the protected Prelude/editor process.

Reserved command, **not executed**:

```powershell
pwsh -NoProfile -File godot-client/tools/test-native-direct-handoff.ps1 -Run native-direct-handoff-roundtrip-v1 -Scenario roundtrip
```

Separate explicit Root grants are required for copied Godot compilation and for
the original-local-server authority run. Source pins, current preparation hashes
and mock/AST results are in the accompanying preparation receipt. There is no
current direct-route live acceptance, native pixel or performance claim.
