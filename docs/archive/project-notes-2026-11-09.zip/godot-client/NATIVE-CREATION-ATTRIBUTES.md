# Original Abilities screen and active allocation data

## Static row artwork correction,2026-11-03

The later screenshot exposed a separate artwork error. The text coordinates
were correct, but the six native labels had been rendered as animated buttons.
Original constructor8db730 creates them through822b60 as `CGuiCharGenLabel`;
the up/down arrows are separate `CGuiTimerButton` objects. The original label
loader retains the model's static texture pose. The port selected the unused
button `up` clip, whose UVs cross two rows of the installed `CTL_ATT` atlas.
That split background made correctly placed text appear half a row too high.
The [original owner dossier](reports/native-attributes-static-label-owner-original-v1.json)
retains the constructor, label loader and distinct button loader evidence.

Only `native_attributes_chooser.gd` changes for this correction. Each ability
row now draws its exact static model image, with a transparent input Button
above it for the existing help/capture behavior. It has no animated button
geometry or draw callback. The name hook, numeric rectangles, claimed Title,
layout and allocation rules stay unchanged. Actual arrows retain their native
button states and held-repeat behavior. No Y offset or shared Painter change
was applied; level-up's use of the same chooser receives the same correction.

The new raster fixture uses installed artwork and fonts, then measures the
real glyph ink against the black interior of the actual rendered row texture.
The earlier real-font test used artwork doubles and mesh bounds, which could
not detect the atlas-state error. The actual installed atlas is512×256 with
`mipmap 0`, `filter 0`, `downsamplemax 0`; the static pose samples the full black
row, while `up` straddles the black and blue rows.

- Clean preserved-before replay:24 checks, exactly12 expected failures, for
  name and numeric ink in each of the six actual black row interiors. Case:
  `.cache/creation-attributes-art-origin/attributes-static-pose-baseline-v5/`.
- Corrected installed-art/font raster:24/24 clean, including before/after
  offscreen/nonactivating window guards. Case:
  `.cache/creation-attributes-art-origin/attributes-static-pose-after-v4/`.
- Actual source input and installed-font regression:42/42 clean, with physical
  help/arrows, active custom costs, strict repeat/release, stale retirement and
  Cancel. Its artwork remains a double; the separate raster case covers art.
  Case: `.cache/creation-attributes-text-geometry/attributes-static-rows-input-v5/`.

The actual raster and its preserved-before replay use the same assertions and
35-second child bound. They reassert an offscreen position after Godot's initial
window placement, verify it does not intersect any screen, and abort before UI
rendering if isolation fails. Six native outputs remain unchanged. Earlier
diagnostic isolation failures and a rejected main-window `hide()` experiment
are retained separately; they are not accepted raster evidence. These are
bounded graphical correctness checks, not an FPS benchmark or original-client
pixel comparison. No server/key, native build, user-client stop or restart was
performed. Before/after images and exact copied inputs are indexed by
`reports/native-attributes-static-rows-v1-checkpoint.json`.

The bounded follow-up audit found that mode1 level-up overrides `assemble()`,
so it did not inherit this creation fix. Its distinct constructor8dc330 likewise
uses822b60 labels, and binder8ed110 explicitly claims Title with bounds flag4.
The mode1 chooser/layout now use static rows, exact name hooks, numeric
foreground and bounded Title. Its preserved-before raster has25 expected
failures; the same corrected raster passes38 and physical/font input passes45,
all clean with unchanged copied inputs and six native outputs. See
[mode1 source and proof paths](NATIVE-LEVEL-UP-ATTRIBUTES-PRESENTATION.md),
`reports/native-level-up-attributes-label-owner-original-v1.json` and
`reports/native-level-up-attributes-static-rows-v1-checkpoint.json`.
The mode0 source is8db730/8ea6a0; mode1 is8dc330/8ed110. Their accepted
checkpoints remain separate66- and83-check scopes, with no rule changes.

## Attributes presentation correction,2026-11-03

The six numeric strings existed and the installed font covered every digit,
sign and parenthesis. They were obscured because the view added each numeric
Label before the opaque artwork for its ability row. The ability-name caption
also used the generic footer-button center instead of the original MDL `text`
hook. The claimed title was incorrectly treated as an unbounded text anchor,
putting its literal installed-font rectangle at(-131,-5.5), outside the panel.

The view now builds each row artwork first, attaches the name to its original
left/vertical-center hook, then adds the numeric text above the row. The
Attributes layout retains the claimed title's original740×30 alignment region
as required by8ea6a0's explicit bounds flag4. Ability values, costs, thresholds,
racial/class adjustments, repeat policy and active-server data are unchanged.

`native_creation_attributes_text_geometry_test.gd` loads the actual installed
`fnt_galahad14` FontFile and checks literal text rectangles, real glyph
availability and nontransparent source atlas ink in each numeric field. It
also checks sibling draw order, name/number separation and title containment.
The prior clean16-check baseline retained its title failure; the corrected
real-font case is34/34 under
`.cache/creation-attributes-text-geometry/attributes-text-order-hook-v3/`.
The final current case is42/42 clean under
`.cache/creation-attributes-text-geometry/attributes-real-font-input-v4/`,
adding physical numeric help, real arrow signals with active custom costs,
strict held-repeat/release, retirement and Cancel. The unchanged original
1344-action/actual-CreationRules regression also passes2690/2690 under
`.cache/creation-ability-rule-regression/attributes-original-rules-v1/`.
That first copied rule runner retained an inaccurate generic `scope` string
from its template; its script,1344-action corpus, checks and engine receipt
identify the actual rule regression. The original receipt is preserved and
only the future runner description is corrected.
One fixture-only missing variation-selector argument was rejected and preserved
before the unchanged bounded retry. This is CPU/source-font acceptance, with
artwork publication doubled; no GPU screenshot comparison is claimed.

2026-11-01. CG_ATTRIBUTES now edits the real native draft through the scoped
CG_MAIN coordinator. The full source creator remains staged until Package, the
other children, safe save/customization and original-client visual acceptance
are complete. This accepts neither the whole creator nor level-up's distinct
attribute screen.

## Data and source behavior

Creation and level-up must use the base tables, replaced by the active server's
resolved2DA/TLK/HAK/NWSync/Workshop resources where supplied. Independently owned
pregame artwork must never substitute stock gameplay rules. Classes, races,
feats, spells, packages, costs, limits, grants and prerequisites follow the
active catalog and referenced tables. Original engine semantics and fixed UI
help references are distinct from server-authored content. The authoritative
original server accepts a completed upload or level-up.

`native_attributes_chooser.gd` reuses `native_source_modal.gd`, the original
painter, readonly help region and GUI repeat timer. It uses the source frame,
all35 GUI entries, six ability labels, twelve timer arrows, numeric boxes,
title and three footer buttons. Numeric labels show effective score and signed
modifier. Initial general help261/457 has blank Cost; title selection restores
that help with cost0. Ability help lists raw score, signed racial bonus, class
gain, effective score and signed modifier before the active description. Its
format is reconstructed from the original function; complete original string/
GUI delivery and pixels are not part of the instruction oracle below.

The real draft now owns the original remaining-point BYTE rather than deriving
it anew from all six scores after every source action. Increment cost uses the
current raw BYTE and active CHARGEN_ABILITY_COST_INCREMENT2/3/4 thresholds.
Limits use CHARGEN_BASE_ABILITY_MIN/MAX/MIN_PRIMARY. Decrease refunds the cost
of the resulting raw score. The primary minimum compares effective score using
SpellcastingAbil even when SpellCaster is false, without an extra raw-minimum
gate. Custom class gains may initialize a primary raw score below8. Original
BYTE arithmetic is retained for edge cases.

Recommended copies six active classes.2da ability values and sets points to0;
missing values follow the table default/zero policy rather than an invented
stock build. It refreshes numeric labels while retaining the selected help/cost
snapshot until the next help selection, as the original does. Active rules
control Recommended availability. Arrow controls remain enabled; callbacks
enforce affordability and limits.

Physical arrows act immediately, then repeat after a strict greater-than
500000-microsecond first delay and50000-microsecond period, once per GUI tick.
Release does not apply another action. Focus loss, active text/catalog changes,
draft replacement and retirement stop held input. Own synchronous edits update
the model without restarting its repeat scope. Stale/reentrant results cannot
mutate another draft.

Edits and Recommended change the live draft. Cancel/Escape returns2 without
rollback. OK requires remaining0, returns8003 and enables Package. If Package
was already enabled, the parent resets later derived choices. The native BIC
worker copies the allocation snapshot and remaining-point cache. The older
provisional sidebar still has a computed allocation path until the full source
creator replaces it; this milestone does not claim that replacement is done.

## Evidence and checks

Pinned nwmain.exe SHA256:
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.
CG_ATTRIBUTES SHA256:
`5b73d80375d34ad2d2b95a247e5b7c1494b66b7c0f977e7d247157be169b2eac`.
The [REA dossier](reports/native-creation-attributes-research-v1.json) retains
constructor8db730, bind8ea6a0, cost8e05e0, can-down8e0790, refresh8ee3d0,
help8eeaf0, Recommend8e5cf0, OK8e3520, Cancel8e1000, twelve arrow callbacks,
timer behavior and2DA getter semantics. Vtable140e642b8 resolves Escape8e3280;
help table141298620 supplies six ability pairs and general261/457. The label
binding8e2b00 is a code label, not a separately recovered Ghidra procedure.

`scripts/inspect-native-creation-ability-points.py` executes unchanged original
instructions for96 configurations times14 operations: twelve arrows, Recommend
and Cancel. Original ability/vital getters/setters, cost/can-down and inline
numeric callback instructions execute. GUI delivery, string formatting, object
lookup, configuration, allocation and modal lifetime are explicit providers.
Corpus: `../backups/animations/native-creation-ability-points-observations-v1.json`,
SHA256 `040e68746f5c6831b78845292a5bb1c5ab1a9da0b64aeedb3910f7548aa6ec48`.

- `native-creation-ability-points-v1`:2690 checks against1344 original
  transitions, including custom thresholds/gains/primary enums and byte edges.
- `native-creation-attributes-binding-v3` and `...-release-v1`:2719 each,
  covering actual source controls, physical pointer/hold/release, help, live
  edits, parent acceptance, scaling and stale/reentrant retirement. Artwork and
  fonts are nonrendering doubles; no original-pixel acceptance is claimed.
- `...-overrides-v2`:30 checks with actual authored server2DA/custom-TLK files
  mounted above the original install. Threshold9 spends1 then2; decrease refunds
  those same costs. Recommend copies all six custom class scores and separately
  displays its gain. Actual source OK and same-Class reset run. Existing custom
  class/alignment/spell/feat/package and replacement-catalog checks pass.
- Class1108, Alignment3231, Race1131 and draft-reset237 regressions pass in
  `native-creation-attributes-*-regression-*`. These are headless with unchanged
  source per run, no engine/lifetime errors and no debugger exceptions.
- `...-local-v1`:33 checks on the preserved original Prelude server at
  127.0.0.1:5121. Real source arrows transfer one point from Strength to Wisdom
  in the same draft built by the native worker. Original admission/export
  returns Wizard10 level1 with the exact selected six scores. Class/school,
  feats, spells, all28 skills, alignment and race/identity comparisons pass.
  Native/authoritative movement is1.500033m. Clean native exit0, acknowledged
  shutdown, zero workers/public connections. Prototype pages finish unported
  steps; the isolated source Attributes leaf uses Package's parent gate false
  to preserve those completed choices. Full source Package flow is not tested.

Failed runs remain retained and excluded: binding-v1/v2 exposed inferred-type
compile errors; explicit annotations fix them. The owned parse-failed headless
v2 process was retired without touching the editor/server. Overrides-v1 found
prerequisite fixtures altered by the new recommendation; v2 resets through
source Class and explicitly provides its negative-Fortitude fixture. Reset-v1
still expected same-race OK to preserve Biography. The independent original
Race corpus proves a reset; reset-v2 checks that exact policy while retaining
unrelated authored fields. Production semantics were not weakened for fixtures.

Before-change verified checkpoint:
`backups/native-creation-attributes-before-v1.zip`,2411 files, SHA256
`e3371dd3eb7feb1c7125a343123e1d4fe6c245dd874567cca6c05bef7764c47a`.

Next: [Package's remaining configuration/helper work](NATIVE-CREATION-PACKAGE.md)
and other original children. Full source creator, level-up
variants, safe existing-BIC save, wider content/input/role coverage, sounds and
original-client pixels remain open. No public join, visible/GPU benchmark or
user/editor restart was performed.

Verified final checkpoint: `backups/native-creation-attributes-bound-v1.zip`,
2418 files, SHA256
`a7c6abe561809b096e8dee243cfab7444f88472fccaf26521876a1283b38eb93`.
The [acceptance receipt](reports/native-creation-attributes-bound-v1.acceptance.json)
checks current production hashes against seven headless receipts and the local
original-server run, verifies the backup digest and records exported scores
`[9,14,14,16,13,10]`. Full-goal, graphical and level-up acceptance remain false.
