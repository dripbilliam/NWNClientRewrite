# Chat portrait tooltips and transition history

2026-11-01. Continues [portrait replies](NATIVE-CHAT-REPLIES.md) through the
production native gameplay controller. The complete UI parity goal remains
active; no graphical or public-server testing was performed.

## Original evidence

[Read-only REA/Ghidra dossier](reports/native-chat-tooltip-research-v1.json),
pinned original SHA256
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.

The original879f10 callback resolves the retained player ID to its current
controlled object at+34, then asks the party manager851c60 for that object's member
record. Without a player or member it displays no tooltip. It formats the cached
name, integer current/maximum HP, newline and module area name. The area lookup
7cc560 uses the received module area list, not the currently rendered scene.

Member8509c0 and portrait850330 initialize name empty, HP0/0 and areaINVALID.
These explicit UI defaults differ from an authoritative health update:853820
then stores current HP and clamps maximum to at least1. Member creation851220
adds the creature's temporary HP to its current value.853430 copies its resolved
name;8537f0 updates its area. A retained member can therefore still supply details
when no corresponding creature is visible in the current area.

This is static binary evidence. No original-process memory was modified and
no original tooltip function was executed as an oracle in this pass.

## Native implementation

[party_details.gd](systems/native_data/party_details.gd) owns only small copied
name/HP/area values for the received party roster and controlled portrait.
NativeGameDesktop observes it on every admitted world update, before the HUD
needs to draw. Partial updates replace only supplied fields. Missing scene
objects preserve cached details; roster removal and controller close retire
them. Rejoining starts a fresh record rather than reviving an earlier cache.
No model, texture, scene reference or private inferred stat enters this cache.

The source-shaped reply button's native `_get_tooltip` delegates to the current
HUD/player roster and this cache. It follows the current controlled player ID,
ignores the separate character ID and nonmembers, and resolves module area names from
received data. NPC/departed-player rows, hidden gameplay and retired callbacks
return no tooltip. Hover sends no request. Source name/HP/location lookup and
all display work remain in Godot; no JS rendering or new protocol is involved.

Ordinary generation/area changes already retain ServerChat and NativeChatHud in
native_live_world. The new full-controller check confirms that received rows,
sequence numbers, draft, outgoing mode, rendered history and portrait control
identity survive an actual native gameplay hide/set-world/show transition.
There was no reason to add another history owner or serialize chat messages.
Native reset_session still retires the gameplay owner; a newly configured
owner has empty history and disclosure. The original's complete disconnect and
cross-server history policy is still unestablished and is not claimed as parity.

## Verification

- `native-chat-lifecycle-v2`:23 strict editor-headless checks. Uses the actual
  gameplay controller, queued server-speech route, active original catalog and
  native Control tooltip accessor; covers area transitions, partial updates,
  absent members, roster/player changes, hidden UI, closure and a fresh owner.
- `native-chat-lifecycle-release-v1`:23 packaged release-headless checks.
- `native-chat-tooltip-replies-v1`:148 existing native reply/category/settings
  input and lifecycle regressions.

All receipts report unchanged sources during execution and no debugger,
engine or lifetime error. The rejected lifecycle-v1 receipt is retained: its
fixture used `speech` instead of the actual `server-speech` message kind and
then indexed an empty history. Only its owned headless process was stopped.
The corrected check waits for actual queued speech and portrait publication.

Exact original tooltip pixels, timing and stationary-hover refresh, physical
selection/scroll/copy, disconnect-history policy, remaining commands/formatting
and wider authoritative scenarios remain open. The subsequent
[local follow-up](NATIVE-CHAT-LOCAL-ACCEPTANCE.md) confirms actual Tell/reply/party
outcomes. The standard Godot tooltip accessor test proves content/lifecycle,
not the original tooltip's appearance.
No GPU tests or public connection were used. Editor25060 and local server7568
were preserved.

Baseline: `backups/native-chat-replies-v1.zip` (2269 verified files).
Checkpoint: `backups/native-chat-tooltips-v1.zip`.
