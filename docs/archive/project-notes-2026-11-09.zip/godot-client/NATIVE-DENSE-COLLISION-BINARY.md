# Original area collision storage and query

2026-11-04. Fresh read-only REA/Ghidra analysis of the pinned original NWN:EE
x64 executable, SHA-256
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.
No original executable, analysis metadata or running game process was modified.
The [retained observation](reports/native-dense-collision-binary-v1.json) includes
full analyzed bodies, pseudocode, instructions, call edges and limitations.

| Function | Entry | Observed behavior |
| --- | --- | --- |
| `CNWArea::AddStaticObject` | `0x140296e60` | Allocates/grows retained vertex/face arrays; rotates and translates supplied vertices once at registration, computes min/max, stores per-object offsets/counts and rebases face indices. |
| `CNWArea::AddStaticBoundingBox` | `0x140296cc0` | Retains supplied min/max pairs and IDs with capacity growth. This is a distinct storage channel; its existence alone does not prove it is the polygon routine's producer. |
| `CNWArea::NoNonWalkPolysDetailed` | `0x140297c50` | Loops retained static-object records, rejects their XY/Z bounds before triangle loads/tests, then calls the separate door routine. |

The important difference from our old movement collection is **retained prepared
collision data**. The original query reads area-owned bounds/offsets/vertices;
it does not build model descriptors, request missing model work or construct
transformed triangle sets for every entity at every input preview.

Do not describe these native functions as a balanced-tree or BSP traversal.
The observed routine scans retained arrays. An O(N) loop over compact prepared
bounds is substantially different work from rebuilding GDScript obstacle records.
Our balanced-tree broadphase is an adaptation whose update and query costs must
be measured against simpler retained prepared bounds, particularly at load time.

Registration retains geometry and computes bounds before queries. That supports
caching prepared footprints at source/geometry changes, not moving all expensive
work into a synchronous new-world callback. Our integration must measure entry,
shared-model arrival, far-object updates and movement while streaming, as well as
warm queries. A global prediction pause while distant entries are pending would
be a separate playability regression, not an accepted optimization.

These observations do not execute original collision, map every registration,
removal or door-update caller, or prove replacement polygon equivalence/FPS.
The earlier [client query controller evidence](../evidence/multiplayer-client-drive-collision.md)
and [native prediction limits](NATIVE-DRIVE-PREDICTION.md) remain applicable.
