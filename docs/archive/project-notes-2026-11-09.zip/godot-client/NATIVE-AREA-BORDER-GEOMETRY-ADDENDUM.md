# Actual installed border model geometry gate

Status: **accepted headless geometry gate:992 checks, clean engine exit,97 unchanged source/copy pins and six unchanged native outputs**. The accepted evidence is `.cache/area-border-geometry/native-area-border-geometry-v3/`. No production source changed. This is actual native model-data/scene acceptance, not rendered-pixel acceptance.

The existing stream gate validates production installed Edge2DA planning and actual static-model worker decoding, but uses controlled templates for scene publication. The new `tests/native_area_border_geometry_test.gd` closes that precise gap: all planning, model/texture decoding, ResourcePool template construction, PackedScene instantiation and retirement use the actual production owners.

The fixture mounts the installed catalog and asks the real Loader for a forest `ttf01_Edge` plan, using the retained unchanged-original `ttf01-turn0` case and actual SET rows in a small2×2 grid with physical tile IDs0/17/34/51, orientations0–3 and heights−1–2. It selects only genuine returned placements: one per available quarter-turn, a repeated same-model row, and a negative-height row. Every selected model, rotation and native position FLOAT bit is compared with that original execution. Missing coverage is an explicit failed fixture prerequisite; it does not invent a model or transform. Model/texture bundles are read and prepared in GDScript workers, never in the JavaScript runner.

The new case checks:

- Actual ArrayMesh vertices and complete triangle winding against decoded original MDL streams, physical part identities/parents/rest transforms, and per-placement quarter-turn/height.
- Source render AABBs separately from conservative original-face template bounds, including composed hierarchy and planned world transform.
- Original texture dependencies and actual production materials, plus immutable decoded model data.
- Private cloned physical nodes with shared mesh/material resources and an independent surviving scope.
- Observed scene-addition counts under the configured publication budget, immediate hide plus incremental retirement, release of all retired nodes, and rejection of a late captured real completion.
- No CollisionObject3D/CollisionShape3D/navigation nodes or gameplay/selection IDs/groups; `picking=false` leaves all CPU hit metadata passive and no pick shapes built.

The last point does not claim that model parsing contains no hit data. ResourcePool intentionally retains immutable CPU geometry metadata even with picking disabled. The test distinguishes that data from physics shapes or entity/selection registration. No World, collision index, selection owner, walkmesh registry, Session or network owner is admitted into the fixture. It establishes the isolated decorative scene contract, not packet/world-authority behavior.

The orchestrator `tools/test-native-area-border-geometry.mjs` copies the static native source closure into a fresh private project, pins the existing editor engine and six shared native outputs, runs one65-second headless case at60fps, and rejects source/copy/output/engine mutation, error/leak logs, excessive output or an owned process that fails to close. The fixture itself has a45-second shared wait ceiling. All caches and evidence belong to the new private directory. It performs no builds, downloads, profile/key reads, connections, visible launch, renderer benchmark or user-process action.

Accepted command, run only after root's direct engine handoff:

```text
node godot-client/tools/test-native-area-border-geometry.mjs --execute-approved native-area-border-geometry-v3 root-approved-border-geometry-v1
```

Headless mesh/material resource construction is not rendered-pixel or native scenery screenshot acceptance. Native fog/sky/terrain shading and original equal-depth draw order are outside this test. Any unavailable texture, unsupported real model publication, budget mismatch, bounds discrepancy or scoped-retirement failure must remain visible in its rejected receipt rather than being replaced with controlled geometry.

V3 instantiated five actual placements from a140-placement source plan: `ttf01_z01_01`, `ttf01_z10_01` and `ttf01_z04_01`. The real Pool built59 mesh resources,15 textures/materials and three templates. All2,342 vertices and1,444 triangles across those five clones were checked, along with original part poses and bounds. A sixth independent-scope clone reused a cached template and survived retirement of the first five. All observed additions respected the one-instance-per-frame count. The2ms publication time budget is soft: an indivisible first template unit may exceed it (the functional run recorded3.681ms). This result does not claim a hard2ms bound or benchmark acceptance.

Both rejections remain intact: v1 failed before checks on restricted Windows certificate-store access; the identical elevated v2 engine ran cleanly but rejected the rural fixture's unsupported all-four-turn assumption. The retained original rural case genuinely produces turns0/1/2, while the unchanged forest case produces all four. V3 corrected only the new test's source scenario and added direct original-call checks; no production correction was necessary.
