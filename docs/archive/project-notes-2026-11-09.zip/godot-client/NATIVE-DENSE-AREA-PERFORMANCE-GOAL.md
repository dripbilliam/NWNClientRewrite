# Dense-area loading and gameplay performance

Active goal, requested 2026-11-04. This is an implementation and validation
goal, not a declaration that profiling has fixed the problem.

## Required outcome

Make dense areas materially quicker to enter and responsive while nearby assets
arrive. Target sustained 60+ FPS in a representative dense scene, with fewer
loading and movement hitches. Preserve original geometry, textures, established
lighting, collision correctness, resource precedence, server authority and
compatibility with native clients/servers. Native Godot remains responsible for
rendering, model preparation and UI.

Do not obtain a passing result by removing required scenery/effects, changing
lighting or camera/resolution, disabling collision, or measuring a smaller room.
Synthetic tests prove bounded algorithms and behavior; matched scene measurements
must establish any claimed gameplay improvement.

## Starting evidence

The manual run `native-manual-1793848496660` supplied the current evidence:

- Generation 3, area 2147618612: first sampled state to all approximately 2,000
  entities published took 23.555 seconds. Player/control readiness appeared
  earlier, around 2.081 seconds, with only 73 of 1,935 entities rendered.
- Loading frame windows reached 211.132 ms. Movement collision/path previews
  reached 137.328 ms while objects were loading.
- A settled 240-frame window reported 35 FPS, 27.859 ms mean wall time and
  34.780 ms p95. Asset queues were empty.
- Disjoint callback owners included particles 5.992 ms and light history
  4.113 ms. Light registry collection 2.962 ms and publication 0.923 ms are
  children of that light-history time, not additional costs.
- About 7,385 draw submissions and 47,502 scene nodes warrant investigation.
  These counters do not prove a GPU bottleneck. Roughly 10.225 ms outside the
  measured callback envelope remains unattributed.
- Missing chunk models/bitmaps generated initialization failures. Their warnings
  stopped before several settled samples; repeated frame-by-frame asset retries
  do not explain the measured sustained slowdown.

Source reports (frozen prefixes, not the entire still-growing log):

- [Frame findings](reports/native-manual-1793848496660-frame-findings-v1.json)
- [Frame analysis](reports/native-manual-1793848496660-frame-analysis-v2.json)
- [Asset analysis](reports/native-manual-1793848496660-assets-analysis-v1.json)

Do not sum overlapping 240-frame observations. Do not add child spans to parent
owners or label all time outside callbacks as GPU time.

## Implementation priorities

1. Replace whole-world movement collision collection with a scoped spatial
   broadphase. Include noninteractable static obstacles, doors, moving creatures
   and conservative pending geometry. Keep the exact narrowphase and original
   authoritative movement behavior. Update membership at existing state changes;
   reject stale area/entity lifetime state and clear on retirement.
2. Reduce unchanged lighting registry and publication work. Retain same-frame
   updates for moving/animated lights, view changes, visibility, ownership,
   properties, radius and tile priority, plus the native history/fade policy.
   Existing corrected lighting must not regress to a global ambient substitute.
3. Reduce particle bookkeeping/publication and scene update/submission overhead.
   Separate simulation, instance bookkeeping, buffer publication and rendering
   evidence before choosing a change. Preserve required effects and semantics.
4. Shorten cold/warm preparation and publication while keeping player/camera and
   nearby-world priority. Bound individual main-thread work units. Scope negative
   resource caching to the correct catalog lifetime so resources from another
   server or a later mount are never incorrectly suppressed.
5. Identify remaining input/protocol application and engine-side stalls. Inspect
   the original binary's relevant mechanisms when current evidence is insufficient.

## Safe working state and ownership

At goal creation the manual launcher PID 61760 and graphical client PID 47096
were verified running. Preserve that session and every unrelated process.
While the user tests, no shared runtime source changes, client restarts, engine
launches, native rebuilds, server control or automated public connections.
Independent new candidate helpers, unexecuted native tests, read-only analysis and
plans can proceed without changing the running implementation.

Initial delegated ownership is non-overlapping:

- `native_ui_parity`: new `systems/native_render/drive_spatial_index.gd`,
  `tests/native_drive_spatial_index_test.gd` and `NATIVE-DRIVE-SPATIAL-INDEX.md`.
- `character_picker`: new `NATIVE-LIGHT-UPDATE-CACHE-PLAN.md` and dedicated new
  analysis reports; existing lighting sources remain read-only.
- `entity_api`: new `NATIVE-DENSE-PARTICLE-PLAN.md` and dedicated new analysis
  reports; existing particle sources remain read-only.
- Root owns this goal, shared integration decisions and later backup/test gates.

Inspect current dirty files before integrating. Back up noticeable changes and
verify the backup against source. Isolate drastic alternatives; obtain approval
before promoting a drastic replacement to the default method. No unrequested
credential logging, JS scene staging or optional clock/DLL work.

## Validation and acceptance

- Native query/oracle tests: negative coordinates, swept bounds, large objects,
  moving creatures, pending geometry, static/noninteractable objects, open/closed
  doors, removals, full/delta updates, control changes, ID reuse and area reset.
- Lighting tests: unchanged static input reuse plus every invalidation listed
  above, native fade advancement, removal/transition cleanup and publication
  equivalence. Preserve the established lighting comparison behavior.
- Particle tests: lifecycle, visibility, update/batch membership, animation and
  required lighting/collision semantics for every changed owner.
- Matched frozen-scene cold/warm comparisons with the same content, camera,
  resolution, settings, native outputs and process contention. Separate profiling
  overhead, warmup, setup and diagnostic captures. Collect readiness/player-camera
  delay, full publication and pop-in, mean/p95/p99 frame times, >50 ms hitches,
  CPU/available GPU timings, draws/nodes, queues and memory.
- Owned original localhost server checks for authoritative movement, doors,
  combat/effects and transitions after relevant changes. No automated Arelith or
  public world/chat connections. Do not substitute mock or headless results for
  actual graphical/server acceptance.
- Repeat representative settled and streaming measurements after each accepted
  change. Retain rejected candidates and failures with their evidence. Do not
  claim a performance win from unmatched runs or from a lower counter alone.

Graphical and live checks remain pending at goal creation. This goal is not
complete until working changes and representative measured improvement satisfy
the outcome, without compatibility or visual regressions.

## First implementation checkpoint

The user subsequently finished testing and authorized closing the replacement
client for local tests. Its exact run/executable was verified before a normal
close request; launcher 61760 and client 47096 terminated, with native exit 0 and
`clean_exit=true`. The editor and original localhost server remain preserved.

Before shared edits, 20 existing dirty source/test/manifest files were archived
and every entry read back and checked against its source:
`backups/native-dense-area-prechanges-2026-11-04-v1.zip`, 21 entries including
manifest, 136,834 bytes, SHA-256
`c2287a214cc443f2a068d285ded55f6d3cc45ec12074cb6e010b8389baa3c5f1`.

- [Missing-root admission](NATIVE-REFERENCE-ADMISSION.md) is integrated and passes
  16 actual-entry headless checks. It avoids absent-root worker jobs, retains
  explicit missing errors and permits later mounts/present-resource retries.
- [Lighting publication](NATIVE-LIGHT-UPDATE-CACHE-PLAN.md) is integrated and
  passes 114 paired pre-change/current owner checks, using the existing native
  history solver. Registry polling and area writes remain unchanged. A lower
  setter count in this fixture is not an accepted FPS improvement.
- The [spatial broadphase](NATIVE-DRIVE-SPATIAL-INDEX.md) initial copied gate passed
  44,638 checks. Production collision/motion integration and its further API
  changes still need their own combined native check and local validation.
- [Particle investigation](NATIVE-DENSE-PARTICLE-PLAN.md) identifies existing
  batching/caches and remaining work. The [eight callback child spans](NATIVE-DENSE-PARTICLE-FRAME-SPANS.md)
  pass 236 paired actual-entry checks across 18 cases. They retain the inclusive
  parent and do not claim exclusive native simulation/GPU timings or a speedup.
  Native simulation/rendering changes are not yet accepted.
- [Fresh original-binary analysis](NATIVE-DENSE-COLLISION-BINARY.md) verifies that
  static collision registration retains transformed vertices and bounds, while
  queries reject cached bounds before triangle tests. The inspected native
  routine scans packed arrays; it does not prove a balanced-tree implementation.
  Retained geometry is the relevant distinction from our old per-query setup.

Matched graphical measurements and original-local gameplay validation remain
required. No new online connection or native rebuild was performed for these
first implementation checks.

### Collision candidate: first measured rejection

The first adapter gate passed 111 functional/lifecycle checks, but its synchronous
per-leaf tree insertion was rejected on performance: a 2,001-row pending-world
capture/index cost 385.255 ms, versus 27.842 ms for the fixture's actual World
without the index; a shared-model 2,000-owner publication cost 391.316 ms.
Its warm query factory was much cheaper (0.024 ms versus 45.779 ms for the
retained legacy factory), but that does not excuse the new load hitch.

The next candidate batches full/model cohorts rather than rotating/refitting
the GDScript tree for every leaf, and includes a retained-flat-bounds control.
It must be rechecked and measured. Ordinary launches retain the exact original
`drive_collision.gd`; the candidate is isolated in `drive_collision_indexed.gd`
behind an explicit opt-in route. It is not an accepted default improvement.

The subsequent split/bulk gate passed 151 checks and reduced the 2,001-row
capture/index to 124.910 ms, with 41.418 ms attributed to tree rebuilding; the
2,000-owner model publication still cost 119.823 ms (49.721 ms rebuilding).
That candidate remains unaccepted. A retained-flat control was cheaper to
construct but substantially slower for the tested repeated segments. The next
experiment groups static position membership and per-model conservative extent
data so one model arrival need not transform and reinsert every placement.
The updated pure bulk tree gate separately passed 48,511 checks; this does not
substitute for stream/movement or graphical performance validation.

### Reproducible offline dense input

The [dense fixture generator](NATIVE-DENSE-BENCHMARK-FIXTURE.md) passes 13 Node
checks against the actual sealed source. Root materialized a fresh
`.cache/loading-benchmark-worlds/arelith-dense-hubint-2x2-v1` and verified its
113-event timeline and unchanged catalog/resource/talk seals. It contains 2,813
raw rows, 192 tiles and one captured controlled character, using translated
copies of the captured static/light/sound/pin cohort. No geometry is prepared
in JS and no game-server connection is involved.

This is synthetic load input, not the user's exact recent room, and a camera
viewing one quarter does not establish four times the visible density. Captured
resource errors and unavailable payloads remain explicit; active resource closure,
native completion and performance have not yet been validated for this fixture.

## Resumed graphical and stationary live checkpoint

The user cleared the PC for testing, then explicitly permitted stationary
Arelith testing and performed the login. The replacement was launched at Main
Menu with detailed profiling, the gameplay lighting profile, no movement probes,
no native rebuild and secondary-monitor/non-activating startup. Root issued no
movement, gameplay, logout, close or graphics-ablation commands during that live
observation. The original editor and localhost server remain preserved.

The authoritative checkpoint is
[native-dense-stationary-checkpoint-v3.json](reports/native-dense-stationary-checkpoint-v3.json),
SHA-256 `54d8d1d7e5b8ba346740ed03f594a13bf74cd5970134538d4f35bcc967f6b8d5`.
Earlier v1/v2 draft analyses are retained but superseded: their warm-pair
limitation text did not correctly identify the differing focus state.

- Four fresh offline graphical runs completed all 2,741 renderable entities and
  192 tiles, acknowledged their explicit twelve-second post-completion windows,
  and exited cleanly. Source/runtime/output guards and protected processes were
  unchanged. These establish functional completion for the synthetic fixture,
  superseding the earlier statement that native completion was unvalidated.
- No total-FPS gain is accepted from these runs. The cold baseline had materially
  different particle culling/render counters; in both cold and warm pairs the
  final window-focus state differed. Final physical viewports matched at
  3440 by 1369, while cold-run logical window geometry also varied. The observed
  warm means of 22.268 and 21.701 ms are observations, not a causal speedup claim.
- Lighting publication measured about 1.001 ms before and 0.142 ms after in the
  warm rolling profiles. Registry polling remained about 3.3 ms. The isolated
  paired correctness tests support the publication change; this does not claim
  native lighting parity or a corresponding total-FPS gain.
- The user-connected Arelith room settled around 37–40 FPS with 1,984–1,985
  entities and 225 tiles. At two-second observation granularity, tiles were
  visible about 2.5 seconds after the first world observation, readiness around
  6.6 seconds, and first full entity completion around 21.0 seconds. These are
  polling milestones, not exact network/transition or worker durations.
- Representative steady live owners measured roughly 5.8 ms for particles,
  3.3 ms for light history, and 1.9 ms for world updates. The new particle child
  spans place most of its cost inside the existing inclusive native-presentation
  call, not DTO construction or renderer submission. Render CPU/GPU counters are
  asynchronous and overlap the wider frame; do not add them as exclusive phases.
- The retained-registry candidate passed its 225 native checks but remains
  unimported. A verified copied-only graphical capsule is ready at
  `.cache/native-dense-area/native-dense-registry-v2`; its only parent-content
  delta is Focus. Graphical measurement is still pending.
- The indexed movement candidate remains disabled for ordinary launches.
  Stationary tests do not validate its query benefit or initial indexing hitch.
  Original-local movement/streaming checks and better-matched repeated graphics
  measurements remain required. The 60 FPS objective is not achieved.

## Other unfinished work remains unfinished

The [direct handoff goal](NATIVE-DIRECT-HANDOFF-GOAL.md) still requires canonical
continuity integration, native cancellation/recovery checks and resolution of
intermittent full-path IPC/loading failures. Its successful scoped local A-B-A
run is not full completion. The [broader playability plan](NATIVE-PLAYABILITY-PARITY-GOAL.md)
and [UI parity goal](NATIVE-UI-PARITY-GOAL.md) also retain their remaining native
binary parity requirements. Prior performance evidence is retained in
[the previous performance goal](NATIVE-PERFORMANCE-GOAL-2.md).
