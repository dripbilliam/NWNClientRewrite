# Native direct-route handoffs

Active continuation requested 2026-11-04. Original client/server interoperability
remains the top requirement. The broader [playability plan](NATIVE-PLAYABILITY-PARITY-GOAL.md)
continues after this milestone; this document does not declare either complete.

The previous direct Host explicitly rejected transfers. The current change wires
the [reviewed coordinator](NATIVE-DIRECT-PORTAL-CANDIDATE.md) into the actual
`native-session-host.cjs` route. Original ActivatePortal, character download,
source release, waypoint and seamless-login behavior stay in their existing
protocol owners. Godot continues to own rendering, model preparation and UI.

Implemented, pending full original-server acceptance:

- Separate private resource configuration and persistence for each Session;
  destination factory work never inherits the origin's credential or server pin.
- Policy checks before destination preparation; exact Session/connection binding
  and listeners before destination connection; fresh destination catalog/setup.
- Old clock/raw ownership retirement, cancellation before Lobby advances, the
  null-Lobby interval, late factory disposal, failure cleanup and shutdown.
- Persistence remembers the exact character vault identity, including a first
  save completing between destination preparation and original-source release.
- Godot rejects a delta immediately after reset until it has an accepted full
  snapshot. The retained failing native test demonstrates the former sentinel
  `-1` base/epoch defect; the unchanged 26 checks now pass.

Evidence:

- [Actual Host closure and coordinator checks](reports/native-direct-handoff-host-closures-v1.json):
  9 actual extracted Host-closure checks plus 26 coordinator/Host-contract mocks.
- [Actual Godot lifecycle checks](reports/native-handoff-lifecycle-acceptance-v1.json):
  26 checks, including old catalog, UI, NUI, speech and raw-world retirement.
- [Protected bootstrap checks](reports/native-direct-handoff-bootstrap-v1.json):
  14 exact-branch checks; the new owned check uses an ephemeral test key rather
  than modifying the interactive saved login.
- [Owned A/B fixture and driver contract](NATIVE-DIRECT-HANDOFF-OWNED-FIXTURE.md).
  The first attempt stopped at a sandbox process-inventory denial before launch.
  The next actual run reached a playable initial world but was rejected by its
  archive identity gate: the fixture did not advertise its matching client NWM.
  Its failure receipts remain preserved; this is not a successful handoff claim.

The first original-local A→B→A acceptance slice now passes, as recorded below.
Still required: stronger canonical semantic character continuity, cancellation
at each boundary, unavailable-destination recovery and successful retry, and
resolution of the intermittent IPC/loading failures. Mocks or an admitted first
world do not substitute for those results. Public worlds, pixel parity, FPS and
custom server-wide acceptance have not been tested for this change.

The fresh fixture now advertises both original NWM fields with their native
types (BYTE `Mod_IsNWMFile` and CExoString `Mod_NWMResName`). The next two runs
were rejected for an IPC disconnect before any portal command: v3 after `hello`,
v4 after catalog readiness. Both original servers were cleaned up; guarded
sources, six native outputs, two encrypted profiles and protected processes
were unchanged. The reset's cause is unresolved. The optional clock runtime is
disabled and returns before loading its provider in both runs. The next step is
an explicit owned-process socket-close trace, rather than another blind retry.

The v5 traced run subsequently performed three admitted worlds (A→B→A), two
original character downloads/uploads with matching hashes, the requested arrival
waypoints and a final original-server export. It exited cleanly, but remains a
rejected run: the diagnostic probe sent Godot RefCounted instance IDs as unsafe
JSON numbers. The probe now sends signed-64 decimal strings, with invalid or
reused IDs still rejected. That correction does not retroactively accept v5.
Its [isolated actual Godot JSON check](reports/native-direct-instance-ids-v1.json)
passes all 12 assertions; it is separate from handoff acceptance.
The trace did not reproduce or explain the earlier IPC reset.

The fresh v6 run stalled before its first playable world; the broker's deadline
expired before Host could write its result. This is also rejected, with its
original evidence retained. The owned check now orders deadlines as Host360s,
broker480s, wrapper720s so Host cleanup can produce a report. Normal launches
retain their previous behavior. Bounded test-only progress diagnostics are the
next step to locate the stalled boundary. All v5/v6 owned servers were cleaned
up and their protected process/profile/native-output/source guards passed.

Existing dirty files were backed up exactly under
`.cache/native-direct-handoff-integration/before-v1/` before edits. Preserve the
running original local server/editor and all user sessions, encrypted profiles,
six shared native outputs and failed evidence. No public server automation,
native rebuild, GPU benchmark, focus or mouse-control change is needed here.

Compressed core checkpoint: `backups/native-direct-handoff-core-2026-11-04-v1.zip`
(13 entries, SHA-256 `a4780ec07b3a5aa89484836370f11257e5dc6266b8af3f19471e9748ff38ca15`).
Every entry was read back and matched its source. It predates the optional
socket-trace launch switch and is not an accepted two-server result.

## Current direct-route acceptance

The normal headless v8 run passed all 21 checks on the current integrated route:
three actual admitted worlds A→B→A, matching original character download/upload
hashes, arrival waypoints, a final parsed original-server export, three fresh
lossless catalog IDs, retired native world/UI owners and final protocol ACK with
zero remaining workers. Both owned servers closed; protected processes, two
encrypted profiles, six native outputs and 1,673 runtime inputs were unchanged.
No debugger, native rebuild or public connection was involved. See the
[acceptance receipt](reports/native-direct-handoff-roundtrip-acceptance-v1.json).
This scoped acceptance does not erase earlier failed runs or establish stability.

Before recovery changes, every v8 runtime input was sealed in
`backups/native-direct-handoff-v8-2026-11-04-v1.zip`: 1,674 entries including the
manifest, 4,286,664 bytes, SHA-256
`0a47f955b76cb3b890103c91be9d77829f86a14ae3bcad3451244932c927d041`.
Every archived entry was read back and verified against its accepted source.

V7 progress evidence located its stall before any world application: Godot had
accepted raw-world-begin but retained a 10,971-byte incomplete frame while the
Host awaited serial1 ACK. New diagnostics add sender queues and pending-frame
boundaries, without recording payloads. A separate actual TCP/framer test passed
78 checks; its extended 35-second partial-frame idle test passed 91 checks with
2,104 polls, no early EOF and correct completion after the tail arrived. These
[transport checks](reports/native-tcp-idle35-acceptance-v1.json) do not reproduce
the full Host/resource/UI path or explain the intermittent IPC reset.
