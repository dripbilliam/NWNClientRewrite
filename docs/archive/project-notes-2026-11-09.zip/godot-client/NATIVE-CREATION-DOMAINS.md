# Native creation: Domain chooser

The staged original-resource creator now implements `CG_DOMAIN` between Feats
and the later class-dependent children. Active class `PickDomains` selects this
route, including custom classes. The shipping fifteen-page creator, full source
chain, level-up, authoritative upload and original-pixel comparison remain open.

## Ownership and behavior

`creation_domains_state.gd` owns temporary physical IDs and help state; the
existing connection draft owns committed domains. The frontend transfers the
Package callback through Domains and School, preserving original8013 rather than
inventing another800e result. Cancel/Escape return3, clear derived choices and
reset the existing coordinator. Connection/draft tickets reject stale commits
and held input. The existing feat owner derives grants from committed domain IDs
without duplicating editable feat allocations.

Active `domains.2da` owns Name, Description, Icon and GrantedFeat. Original
LoadDomainInfo stores the low byte of row count. A failed Name read marks a row
invalid; a successful zero Name is separately excluded by the picker. Label is
not a filter. Missing Description/GrantedFeat retain constructor sentinels;
undefined integer conversion remains unavailable. Package Domain1/Domain2 owns
Recommended in that order. Unknown or duplicate recommendations disable that
control instead of inventing a pair; malformed-package crash behavior is not
reproduced or claimed as parity.

Original GFF/model geometry supplies the list, two selected-domain attachment
points, arrow helpers, help scrollbar and footer. Available rows remain in
physical ID order. Row selection changes help; arrows move choices. Two choices
enable OK; removal shifts the remaining selected slot and reinserts the removed
ID in source order. Text-only reticketing preserves candidates and refreshes help.

Domain preparation starts on opening this class-dependent child, following
original on-demand construction. It adds no Domain jobs to ordinary picker
startup. Complete optional all-menu prebaking remains a separate requirement.
Moves reuse row widgets and icon bindings; no per-click model preparation,
per-frame world scan or duplicate world store is introduced.

Actual input exposed a shared painter lifetime fault: Godot reparenting emits
`tree_exiting` for live controls. `native_gui_painter.gd::relocate` now guards only
the moving subtree's registered button IDs during that synchronous relocation.
Persistent final-exit cleanup retires actual deletions; unrelated exits still
retire normally. Dirty before-files were preserved.

## Evidence and limits

Original client SHA256:
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.
`reports/native-creation-domains-static-v1.json` retains loader/constructor and
callback dossiers. The separately executed288-case original corpus is
`native-creation-domains-original-v1.json`, SHA256
`050d99f54cd76972b7950d2464ac30fb8e417c2be86470d537f496b9af96fbfe`.
It executes original add/remove/selection/help/OK/Cancel and domain setters with
explicit GUI-list/construction and final-coordinator boundaries, not full GUI
or table-loader execution.

Accepted receipts in `reports/`:

- `native-creation-domains-state-v2-receipt.json`:2,629 native checks including
  all288 original cases, active metadata/sentinels/order, unavailable
  recommendations and detached-model isolation.
- `native-creation-domains-resources-v1-receipt.json`:3 read-only original
  resource inventory checks. GFF SHA256:
  `c40606b4a168cba12c8aa11c5029882ef8cad909ced7d056b3eb148e34028216`.
- `native-creation-domains-view-v5-receipt.json`:19 actual control/help,
  arrow/Recommended/OK/Escape, scaling, reticketing, widget reuse, nested painter
  lease, unrelated-exit and final-cleanup checks.
- `native-creation-domains-binding-v2-receipt.json`:24 actual
  Gameplay→creator→frontend Package→Skills→Feats→Domains→School input/draft
  outcomes, grants, cancellation/reopening and stale draft rejection.
- `native-creation-school-binding-post-domains-v1-receipt.json`:25 regressions
  for the earlier no-Domains School route after the shared changes.

Every accepted run exited0 with clean engine/lifetime logs and unchanged
relevant copied inputs. Tests use isolated hidden headless projects, the pinned
existing runtime and controlled art/font doubles. No server/GPU benchmark,
shared native build or user process restart occurred. Geometry/input/state tests
do not establish original artwork, text clipping/wrapping or pixels. No source
interaction fabricates an upload.

Twelve synchronous actual add/remove handler pairs in the four-domain fixture
measured0.497–0.985ms, excluding awaited test frames. These are CPU handler
measurements, not live FPS, first resource-open time or a maximum-sized custom
table benchmark.

Failed attempts remain retained: original-emulator fixture range/color-object
errors; view fixture assertion-signature parse error; the reproduced painter
relocation fault; and a full-chain run with24 successful assertions but duplicate
modal-surface signal errors. The modal owner fixed that shared-parent notification
bug with a separate15-case regression before the clean rerun. Engine-error runs
were rejected despite passing assertions.

Focused runners:

```powershell
./godot-client/tests/run-native-creation-domains-state-tests.ps1 -Name unique-state-receipt
./godot-client/tests/run-native-creation-domains-view-tests.ps1 -Name unique-view-receipt
./godot-client/tests/run-native-creation-domains-binding-tests.ps1 -Name unique-binding-receipt
```

Unique names preserve prior receipts. Compressed snapshot/per-entry verification:
`reports/native-creation-domains-checkpoint-v1.json`. The snapshot accepts only
the listed scope. Later shared edits, full modal coverage, Spell/Associate
children, all rule variants, complete saving/admission and level-up remain open.
