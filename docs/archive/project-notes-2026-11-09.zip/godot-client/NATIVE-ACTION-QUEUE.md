# Native action queue — source layout and persistent widgets

2026-11-01. Connected to the native gameplay desktop. This is a scoped HUD
milestone; complete UI, original pixels and authoritative gameplay acceptance
remain open.

## Original evidence

The pinned installed nwmain.exe SHA-256 is
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.
REA/Ghidra evidence is retained in
[the research dossier](reports/native-action-queue-research-v1.json).
No original executable was modified.

- CPanelActionQueue constructor873a90 uses PNL_ACTIONQUEUE and its Queue hook.
  Append873df0 attaches the first widget at Current and the next at Queue;
  subsequent widgets follow CTL_ACTIONQUEUE.NextLink.
- Special insertion8741f0 retains the special prefix and moves the previous
  current widget into the linked list. Remove8748b0 removes the first matching
  type/group and promotes the next widget. The Godot view consumes this order
  from the existing received queue; it does not invent combat action ordering.
- Click874a00 dims the selected widget to0.5 and forwards its WORD type/group.
  Sender7bf390 writes two16-bit words to client message6/0x14. Local
  widgetSerial identifiers are never sent.
- Ordinary icon construction873df0 uses the active actions.2da ICONRESREF or
  ir_use when GetCExoStringEntry fails. GetCExoStringEntry1a68f0 returns failure
  for empty cells. The loader's **** cells represent empty data. Special
  insertion has no ordinary fallback. Type4/type19 explicit spell/feat handling
  remains in the native rules projector.
- CGuiIcon CResRef constructor1e2f00 selects1x1. CreateCopyIconModel1e3b00 uses
  GUI_ICON_1X1L and substitutes the icon resource. Its source quad is32x32,
  centered at(-16,-16).

Read-only installed geometry reports:
[queue models](reports/native-action-queue-source-v1.json),
[icon model](reports/native-action-queue-icons-v1.json).

| Source model | SHA-256 | Geometry/hooks |
| --- | --- | --- |
| PNL_ACTIONQUEUE | f605e5b1e95e14b56efe99c027741b076df90ee2dff1b87885ff3530e417f99a | Current(3,3), Queue(46,3) |
| CTL_ACTIONQUEUE | 2ae516b492ba3cd719a35c529535890ec5ff3ba5c99a30078acafb3c2a3fab95 |40x40; Icon(20,20); NextLink(43,0) |
| GUI_ICON_1X1L | 25be233eb047c98fd6204504cb578c2b93113a30282aa6b96af36eade07f27ec | centered32x32 quad |

## Native implementation

[action_queue_layout.gd](systems/native_data/action_queue_layout.gd) derives
rectangles from parsed source models.
[server_action_queue.gd](systems/server_action_queue.gd) now owns manual native
controls instead of a48px HBox that rebuilt every update.

The view warms three small source models with the native asset service,
retaining received rows until geometry is ready. The shared source painter
provides authored up/hilite/down/disabled artwork. Icons retain the original32px
footprint and bitmap orientation; source skins are not stretched to prototype
sizes. All received widgets are represented; the inherited arbitrary ten-widget
cap is removed. The panel remains at its source top-left origin.

Surviving local widgets persist across append, special-prefix insert, deletion
and metadata updates. Unchanged presentation does not rebind icons or request
new model artwork. A rules-text revision reprojects names/icons even when the
server queue itself has not changed.

Cancel dims immediately and awaits authoritative removal. Rejection restores
the same controls. Reset/changed wire identity retires controls and invalidates
old callbacks, including reuse of the same local serial. Removal unbinds borrowed
raster/style targets. Close drains native source jobs, detaches the painter and
rejects late metadata/snapshots. Desktop closes this owner before closing shared
art. Input blocking covers actual buttons rather than empty row space; buttons
do not take keyboard focus.

## Verification and remaining acceptance

[The native test](tests/native_action_queue_test.gd) passes35 checks in both
strict editor-headless and release-headless runtimes:

- installed geometry, active server-style action/spell/feat metadata and WORD IDs;
- real viewport mouse press/update/release through the actual Desktop command;
- pending/server removal, surviving-control identity and special-prefix reorder;
- repeated snapshots without added model/raster requests;
- stale controls across reset and changed wire identity;
- all12 test actions, gap click-through and original raster orientation;
- blank icon update, close, unbinding and late completion;
- actual asynchronous native asset-service preparation of the three source models.

Receipts: native-action-queue-v5 and native-action-queue-release-v2.
Related strict headless regressions pass18 combat-feedback and16 desktop-rules
checks (native-action-queue-combat-v1, native-action-queue-desktop-v1).
These are CPU/input checks with rendering disabled and zero public connections.

Earlier v1 stopped at a test type-inference error. V2 found a controlled-raster
fixture mismatch; v3 passed before the empty-cell policy was corrected against
the actual GetCExoStringEntry body. V4 verified the correction; v5 adds the actual
source-worker path and a late raster reply after close.

No graphical launch, GPU benchmark or public-server join occurred. Original
pixel/scale/hover comparison, source tooltip timing, sounds, action-related
world feedbackVFX (875070), exact overflow/clipping and authoritative localhost
queue use after this change remain unverified. The real click test confirms
request routing, not an actual server-confirmed cancellation. Existing older
local action probes are not acceptance evidence for this new view.

The later [HUD tooltip/local cancellation follow-up](NATIVE-HUD-TOOLTIPS.md)
connects its painter to a borrowed shared native tooltip scope and now confirms
actual mouse cancellation against the original server: pending opacity precedes
received deletion/control retirement. The combined owned local receipt passes178
checks. Exact overflow, broader action/special-state, sound, VFX and graphical
acceptance remain open; this does not complete the action queue or full UI goal.
