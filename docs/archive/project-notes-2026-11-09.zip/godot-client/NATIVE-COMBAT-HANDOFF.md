# Native combat presentation handoff

Scoped status, November 3, 2026: the cast-base handoff and immediate received-facing delivery are implemented. Full combat, motion handoff, original pixels and mixed-client gameplay parity remain open.

## Corrected behavior

The original creature receiver `781e80` calls `SetBaseAnimation764300` with250–253/261 before queuing cast17–20/61. Previously `Combat.base_frame` recorded that base but left the preceding walking/running visual active. The queue admits cues only from a looping presentation category, so a cast could remain queued indefinitely until another idle update. Both the replicated-base and direct received-cast paths now use the same original base transition. A positive-duration attack retains its visual owner; locomotion, looping visuals and expired cues yield according to the original guard. This changes presentation state only, never received coordinates or authoritative action results.

The protocol bridge also omitted `facingTarget` from its immediate creature movement projection and initial movement whitelist. Facing-only received changes now travel through that existing channel. Native motion already accepts the field, resolves the current target and executes the original bounded turning step. No target is inferred from mouse position or forced every frame. Explicit native unlock, older movement revisions, removed targets and closed worlds are covered.

## Evidence and validation

- [Original receiver dossier](reports/native-combat-receiver-research-v1.json): complete retained pseudocode,79,947 UTF-16 units; receiver’s cast-base calls are explicit.
- [Original CPU corpus](reports/native-combat-base-handoff-original-v1.json):120 executions of the complete original764300 body and classification leaves. Model queries/flags/playback and unavailable GetAsCreature are captured boundaries; there is no live process or rendering claim.
- Pre-fix native repro: `.cache/combat-handoff-tests/native-combat-handoff-before-v2`,286 checks/275 failures, clean engine and unchanged inputs. The earlier v1 test annotation parse failure is retained.
- Final copied-source receipt: `.cache/combat-presentation-tests/native-combat-presentation-v3/proof.json`, **5,070 passing checks**:286 handoff,4,595 existing selector/queue/events/actual AnimationPlayer,15 direct combat ownership,15 target facing,141 native motion/rig and13 actual World-to-native facing checks, plus5 copied Node protocol tests. All six engines exited cleanly; all1,464 pinned inputs were unchanged. Existing native extension/DLL/manifest were copied, with no build, GPU test or server connection.
- Rejected batch v1 omitted the copied extension/DLL; v2 had a copied Node directory mismatch. Both packaging failures, their exact logs and their passing scoped assertions remain retained. Assertions, production behavior and case deadlines were not relaxed.

With captured model playback,45 received cast transitions measured34µs median/78µs p95/90µs maximum scheduler CPU work. Three native facing deliveries measured13–16µs. These are isolated handler measurements, not server latency, GPU timing or gameplay/FPS acceptance.

## Remaining work

A later [resting-base/path milestone](NATIVE-COMBAT-LOCOMOTION.md) now adds the actual LiveWorld handoff and38 owned original-server input/model/cast/facing/cancel checks. That later receipt does not retroactively expand this earlier checkpoint. Original pixels, broad NPC/repeated combat, shape-specific clips and full animation parity remain open. No path is stopped by guessing from attack records. Combat selector metadata still follows raw snapshot refresh, distinct from the immediate native-facing owner. Existing [combat migration evidence](NATIVE-COMBAT.md) remains scoped as documented.
