# Client creature construction boundary

A missing `NetworkWorld` proxy alone does **not** certify a fresh original creature. A first *observed* A can encounter an external creature retained from earlier or incomplete native history. The inspected normal BIC/preview path, however, does **not** supply a hidden BIC-loaded client creature to a well-formed external A lookup: its preview occupies the internal ID namespace, while server object IDs occupy the external namespace. These are separate conclusions.

This static audit uses unchanged `nwmain.exe` SHA256 `3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`. [The bounded report](reports/native-client-creature-construction-boundary-v1.json) retains 37 selected function dossiers, the ten recovered direct `AddExternalObject` caller classifications, exact relevant bodies/excerpts and incoming-reference coverage. It extends the [controlled-name load audit](NATIVE-ACTOR-NAME-CONTROLLED-LOAD-AUDIT.md) and [clock lifecycle audit](NATIVE-REMOTE-CLIENT-CLOCK-LIFECYCLE.md). No production/test/native output was edited; no game, engine, server, original-code oracle, live-memory inspection, Computer Use, GPU, key/profile or native build action occurred.

## Why the BIC preview does not alias external A

`CNWSMessage::WriteOBJECTIDServer 4763e0` sets `0x80000000` on every non-invalid ID; `0x7f000000` is the explicit exception. Client `ReadOBJECTIDClient 9737c0` returns the raw DWORD. The A/type5 reader therefore retains the wire namespace rather than stripping it to a generic registry ID.

`CGameObjectArray::GetGameObject 296470` selects a hash-table half using the ID's high bit and compares the stripped low31 bits inside that half. `AddInternalObject 295d40` allocates an internal ID and inserts in the low-half buckets. `AddExternalObject 295b30` inserts the supplied pointer in the external-half buckets and marks the reference ID external. Equal low31 values do not make an internal preview an external lookup result. This depends on the actual original tagged wire path; malformed or imported untagged input is not certified by this argument.

The local character-sheet loader `88ad50` obtains the existing client array, deletes its previous preview, constructs a new `CNWCCreature` of size `0x480`, calls `AddInternalObject(...,0)`, and then loads BIC/UTC stats through `7f7e20`. It can carry a nonempty `DisplayName` override, but remains a distinct internal owner. Character-list/download handler `77b640` uses temporary stats for captions and calls pregame refresh/preview owners; its immediate bodies contain no `AddExternalObject` transfer. This is the same client array with two namespaces, not evidence of a second unrelated array being accidentally compared.

## Runtime local and server-vault character ownership

Original login `457850` passes advertised references for server-vault/saved-character subtypes and opaque BIC bytes for the local/create branches to server `LoadCharacterStart 55bb90→564b10`. The latter selects server owners `CNWSPlayer::LoadLocalCharacter 4bc0c0`, `LoadServerCharacter 4bc1e0`, or the saved-module/DM branches.

The inspected local and server-vault loaders both allocate a **server** `CNWSCreature` of size `0xae0`, install it through `CNWSPlayer::SetGameObject`, and call server `LoadCreatureData 4bb450`; local loading uses `TEMP_CHAR`, while server-vault loading uses the selected reference. These are not client `CNWCCreature 7fb140` objects and do not transfer a C++ pointer into the client's external registry. Server preview transfer17/4 supplies a stats BIC for inspection, whose client path above remains internal. No reviewed direct client registration path moves those preview stats or its `DisplayName` into an external controlled creature.

This closes that specific BIC-transfer hypothesis at the inspected owners. It does not turn a UI label, a BIC descriptor, a controlled-ID packet, a generic `applyArea` proxy or party U data into a stored actor-name/clock publication.

## Fresh and retained creature A

Dispatcher `7b23e0` routes type5 to `77f870`. That reader checks message overflow, performs typed lookup `6ab9e0→6d8100`, and handles an existing creature before the allocation branch. The typed lookup requires successful registry lookup, object type5 and virtual `AsCreature +58`.

When absent, `77f870` allocates `0x480`, invokes `CNWCCreature 7fb140`, assigns the actual received ID/area/pose, and calls `AddExternalObject`. On its successful return it immediately calls `ClientAIList.AddObject 7675d0`, before model/equipment readiness. `AddExternalObject` itself only inserts the supplied pointer; it performs no construction, BIC load, cloning, name initialization, clock birth or AI registration.

The constructor creates client stats through `7ea7a0`; the previously certified first/last/override string constructors initialize those presentation slots empty. It also samples **base T0** via `6ac330→CWorldTimer::GetWorldTime` into previous day`+50`/time`+54`. This is the native birth stamp, not a selected-clock sample, first enqueue time or new disclosure-token time.

When a typed creature already exists, A clears/reactivates its removal/visual state and reuses it. It does not run the constructor, reset stored names, sample a new birth pair or call `AIAdd`. A D+A redisclosure can therefore preserve the original physical owner. The second typed lookup in the reader is retained explicitly; neither lookup is replaced by JS proxy absence.

`7675d0` deduplicates actual IDs and appends when absent, recording the list index. A return of0 means the ID was already in the AI list, not that membership is missing. It has no mesh readiness condition. Membership still does not prove that a complete eligible AI pass ran: module/area admission, manager early-exit behavior, the selected timer and ordered reset callbacks remain separate clock-owner requirements.

## Recovered registration closure and admissible facts

All ten recovered direct `AddExternalObject` callers were inspected. Only `77f870` is the external type5 construction path. The other A branches handle types6/7/9/10/11; additional calls are item updates, decorative/gore placeables and sound registration. Recovered `AddObjectAtPos 295f50` direct callers are server `CNWSArea`, `CNWSObject` and `CNWSPlayer::EatTURD`; `AddCharacterObjectAtPos 295950` has no recovered direct caller. Raw incoming references, including data references, are retained without treating them as runtime calls. Unresolved indirect/export/plugin paths are not exhaustively ruled out by this direct-call closure.

A source-derived fresh-construction fact needs all of the following:

1. An accepted, valid external-tagged type5 A and complete external-owner history from a known client-registry lifecycle boundary.
2. No preceding still-live external typed creature for that ID, including retained D/fade history; a new raw disclosure token is insufficient.
3. No import/reconnect/history gap or unsupported out-of-band insertion. Unknown histories stay unknown.
4. The normal successful fresh A path for constructor T0 birth and AI membership, followed by separately admitted eligible AI phase history.

Under those conditions, internal BIC preview construction does not invalidate the fresh-A proof. Without them, the narrow correct result is unavailable construction/birth state, even if a new JS proxy has just been allocated. Constructor-empty names are known initialized **client presentation** state only; they must not be reported as received server statistics. Current stored-name publication P and packet-time snapshots remain distinct from party/UI U names. This report introduces no constructor flags or runtime hooks.
