# Staged quickbar Commands associate sectors

This change is **not imported by production**. The open user client, Desktop,
Session, quickbar policy, Painter, Art, protocol and credentials are unchanged.

The source-proven SELF-wheel Cancel Polymorph branch was already integrated:
`creature_radial.self_role` reads received playerFlags bit10 and bit17, publishes
sector4/type43/-1, and Desktop dispatches the typed direct6/30 request. The
separate accepted `native-world-polymorph-local-v2.json` has38 original-local
checks including physical self-wheel reversion and locked-role absence. It was
not rerun or reimplemented for this slice.

## Original boundary

- World self98ec00 selects9914b0, which calls9945d0 with **mode0**.
- Empty quickbar9ac860 calls9945d0 with **mode1**, retaining the originating
  shortcut widget in the root context+828.
- Associate sectors require mode1 **or** `GetDungeonMasterEXERunning`. Received
  server DM permission is a different owner and cannot establish that executable
  gate. Normal world Commands therefore remains its existing five entries.
- Native party queries851dd0/851ff0/8520c0/852180 resolve current creatures and
  compare type274/master270.851d80 returns the first matching **raw physical
  party index**, including entries preceding the filtered associates.
- Count0/1 uses direct Inventory1, Disarm0, Unlock7. Count2 publishes named0/1
  plus an empty More7. Count3 places the third name at7. Larger counts use More,
  with seven names and continuation when more than eight remain, otherwise up
  to eight names. The native count2 behavior is preserved.
- Explicit INVALID membership can produce direct sentinel-target entries when
  count0; this is retained as original data, without substituting the actor.
- Named callback98f7d0 puts physical index in the high WORD and command -19,
  -20 or -18 in the low SHORT.995f10 interprets the high WORD as **signed SHORT**;
  -1 uses the root actor, other invalid indices yield INVALID. With +828 present,
  it assigns type39/associateType1 rather than executing gameplay immediately.

`native-command-associate-original-v1.json` executes80 cases including missing
lookup, foreign master/type, duplicate IDs, ID0 and INVALID. The independent v2
extension executes96 root/pagination cases, actual98f7d0 child construction and
18 signed callback/index boundaries. Services for UI publication, allocation,
canonical lookup and names are captured explicitly; unchanged pinned PE bytes
own the decisions, raw party queries and callback target resolution. No target
process, network or native rebuild is used. The earlier unwind excerpt is
explicitly an instruction audit, not complete function execution. The retained
v1 module heading lists98f7d0 as part of the researched path, but v1 does not
invoke that child callback; v2 provides its actual execution evidence.

## Staged implementation and acceptance

`systems/native_data/staged_command_associates.gd` captures scalar query metadata
at a menu boundary through explicit canonical lookup and text callbacks. It
does not copy an entity store. Missing type/master/party revision remains
unavailable; it does not create an enabled default. It builds exact original
entries, raw-index submenus and signed type39 bindings. The DM executable input
accepts only explicit Boolean true and remains separately unbound.

The test-only `tests/staged_command_associate_desktop.gd` integrates that helper
with the existing production Desktop methods. It holds only the private menu
query result and exact generation/area/actor/disclosure identity. Revalidation
runs at input boundaries, not per frame. Party revision, membership/ownership,
actor or target disclosure replacement and old wheel tokens reject stale work.
Its derived menu metadata is retired with the originating shortcut context.

The copied functional receipt at
`.cache/staged-command-associates/20261103101436364-fc497d90/runner.json`
accepts6,826 checks with340 unchanged source/oracle inputs:

- 6,772 policy comparisons and explicit unknown/mutation/lifecycle cases.
- 17 actual ServerRadial/Quickbar pointer checks, including named and paginated
  Inventory/Unlock/Disarm assignment, Use, stale/context rejection and unchanged
  five-row normal-world Commands.
- 37 unchanged Session/controlled-peer checks consuming those actual native
  requests. Independent scalar decoding verifies one30/2 assignment then one
  6/27 Use for each signed command, matching exact IDs100/110 and slots0/1/2.

Both native logs are clean, all owned processes exit, and no socket/login/GPU
or user-process action occurs. Controlled art and TLK fixtures are used here;
this is input and transport acceptance, not original pixels or a new server
gameplay result. The original bound39 local acceptance remains a separate proof.

Rejected receipts are retained: first fixture inline-lambda declaration scope
parse error, then a real staged-helper malformed-DM-object comparison error.
Only the new fixture declaration and explicit Boolean gate were corrected.
Assertions and35s case bounds were retained.

## Exact future production reservation

No hook is applied while user PID53284 is open. The proposed next patch is
Desktop-only plus the new helper import:

1. In `ability_entries`, replace only the `quickbar-commands` return with the
   staged capture/materialize/decorate path. Read the already-forwarded
   `state.party` and `state.partyListRevision` with presence checks, the existing
   canonical `objects` lookup, current `owner_ui.text`, and real
   `clientKnownLifetime`. Do not treat the existing header default0 as proof
   of an absent received field; either use the known host contract or preserve
   explicit presence in the two Gameplay projections in a separately reviewed
   hunk.
2. Add the exact private captured menu scope. After existing request/menu/slot
   admission in `radial_select`, validate it before branch/assignment use.
   Clear it in the existing exact shortcut/wheel retirement boundaries and at
   accepted leaf completion. Retire on the explicit snapshot party revision or
   actor scope replacement, without scanning the world.
3. Leave world-commands, received DM permission, Session assignment/Use and
   normal five rows unchanged. Do not bind DM-executable menus until its actual
   executable owner is established.

The accepted test-only subclass demonstrates those boundaries. It is not a
claim that the final production patch was applied or accepted. Promotion needs
root ownership review, dirty-before backups and a new exact-source acceptance.
