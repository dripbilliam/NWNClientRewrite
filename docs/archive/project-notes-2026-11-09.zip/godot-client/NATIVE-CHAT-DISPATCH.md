# Native chat commands and the complete outgoing route

2026-11-01. Continues [adjustable chat](NATIVE-CHAT-HUD.md),
[reply controls](NATIVE-CHAT-REPLIES.md) and
[tooltips/transition history](NATIVE-CHAT-TOOLTIPS.md).
The full UI goal remains active. No game window or public connection was used.

## Original behavior and corrected field meanings

[REA/Ghidra evidence](reports/native-chat-dispatch-research-v1.json) and
[executed original dispatcher observations](../backups/animations/native-chat-dispatch-v2.json)
use pinned original nwmain SHA256
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.

Earlier reply/tooltip prose and synthetic tests reversed the two object-ID
fields and misnamed the character-name lookup as an account lookup. The
original player-list reader7a8c60 proves the following mapping. Those earlier
interpretations are superseded; their historical evidence remains preserved.

| Original client field | Received data / purpose |
| --- | --- |
| +10 | Account name, exact lookup6d8a20 |
| +34 | First wire OBJECT_ID: player.objectId, the current controlled object |
| +38 | Second wire OBJECT_ID: player.character.id, the character |
| +40 | Resolved first name, with one space and last name when the latter is nonempty; exact lookup6d8910 |

The reply button879ba0 and tooltip879f10 use+34. Player-list selection888ce0
sends GUI12 with+38; Tell889140 sends GUI28 with+34 and primes `/t "full name" `.
Chat portrait replies instead prime `/tp "account name" `. Both priming paths
preserve the selected outgoing mode. Invite/Kick888a30 and Transfer889280 use
the character at+38. These namespaces differ when a player possesses another
creature; testing only equal IDs would conceal the error.

Original87b590 now has260 executed synthetic cases across all five modes.
255 non-console cases are compared with the native Godot dispatcher; the five
privileged `/d` cases remain explicitly deferred. Source string slicing and
both roster lookups run unchanged original instructions. Allocation, copy/free,
ASCII CRT comparison/search, application/network access, senders, feedback and
privilege checks are captured boundaries. No packets are sent by this emulator.

The resulting native behavior is:

- `/t` and `/tell` resolve the exact full character name to PLAYER_ID.
- `/tp` and `/tellplayer` resolve the exact account name to PLAYER_ID.
- Missing exact recipients produce original feedback106/TLK61899.
- `/o` preserves the separate name-addressed Tell wire format, including its
  original empty-name parsing cases.
- `/invite` looks up the unquoted full remainder as a character name and sends
  the original character target. `/accept` sends OBJECT_INVALID; the original
  authoritative server decides whether an invitation exists and can succeed.
- Unknown slash commands retain the entire line and selected channel, allowing
  server-authored commands to work. `/s`, `/w`, `/p`, `/dm`, `/tk` and `/talk`
  preserve original payload slicing, including bare-prefix and empty-payload
  edge cases. No trimming or substitute mode selection is added.
- Enter clears and releases the prompt before dispatch. Malformed Tell syntax
  cancels silently as in the source. Local/privileged `##` and `/d` console
  interpretation remains unavailable and does not leak into public chat.

The single-line edit1e9d70 delegates other keys to1e99b0; its Up/Down path moves
the caret rather than recalling sent messages. This does not establish the
absence of history shortcuts elsewhere in the original client. Full global
input/sent-history behavior remains to audit.

## Native controller and raw transport

[chat_prompt.gd](systems/native_data/chat_prompt.gd) owns all parsing, active-TLK
character-name resolution and typed native requests. NativeChatHud owns prompt
input and received feedback. NativeGameplayUi routes chat through the current
desktop controller so actor, area and generation are captured at submission.

The former host branch discarded PLAYER_ID/account metadata and replaced actor
ownership with the current actor. That would break account Tells despite the
lower-level session checks passing. The host now calls the production
[chat-input.mjs](tools/chat-input.mjs) raw forwarding helper, retaining the
submitted actor, PLAYER_ID, account identity and explicit name recipient.
The extra account identity is checked against the current received roster and
does not go on the wire. JS neither resolves character names nor renders chat.

The distinct native-chat-party route sends original Invite/Accept packets
without borrowing player-window availability restrictions or predicting party
state. The regular player-window route retains its own received-state checks;
its selection, Tell and party targets now use the correct original fields.
Transport success does not append speech, create membership or acknowledge a
server action. Current transport refusal appears as a local client notice;
old actor/area refusals cannot appear in a new gameplay scope.

## Checks and reproduction

- `native-chat-dispatch-v2` and `native-chat-dispatch-release-v2`:260 checks
  each, including255 original dispatch comparisons and five fixture/provider
  checks. Console cases remain deferred rather than counted as parity.
- `native-chat-routed-replies-v1`:148 headless input/reply/category/settings
  checks with corrected source field mappings and priming behavior.
- `native-players-routed-chat-v1`:39 actual player/invitation control checks,
  including distinct controlled/character IDs and original `/t` priming.
- `native-chat-routed-lifecycle-v4` and release-v1:27 full-controller checks,
  including actual Enter/Invite/Accept requests, retained history/tooltips and
  scoped refusal feedback. Their emitted requests are retained in the report.
-66 Node checks pass with zero skips when `NWN_NATIVE_CHAT_RECEIPT` points to
  the successful lifecycle report. This feeds actual Godot input output through
  the production forwarding helper/session and decodes the resulting packets.
  Transcript: `reports/native-chat-dispatch-route-v1.tap.log`.
- `native-chat-routed-phase-v1`:23 full gameplay/pregame canvas, focus and
  visibility checks remain green after routing chat through its controller.

Use a fresh report name for each run. Example offline original reproduction:

```powershell
py ./scripts/inspect-native-chat-dispatch.py --report=native-chat-dispatch-review-v1.json
```

The script refuses to replace prior observations. Native headless checks use
`tools/test-native-kernel-debugger.ps1` with the corresponding test script and
an absolute `--oracle` path for `tests/native_chat_dispatch_test.gd`.
For the routed Node check, set `NWN_NATIVE_CHAT_RECEIPT` to the successful
`native_chat_lifecycle_test.gd` report before running
`node --test godot-client/tools/native-chat-route.test.mjs`.

Rejected receipts are preserved: the first dispatch comparison had JSON
float-versus-integer fixture equality mismatches; routed lifecycle-v1 had an
inferred-type parse error in its new fixture variable. The corrected checks
preserve numeric wire types and use an explicit fixture type. An empty native
string reader returns bytes:null with length0; its test asserts that form.

The [authoritative local follow-up](NATIVE-CHAT-LOCAL-ACCEPTANCE.md) now adds55
checks with actual native Enter/mouse input and a second real participant.
Tell, portrait reply, Party chat and typed Invite/Accept reach the original
server and receive their intended outcomes. The earlier routed packet check
alone proves the native control-to-transport path, not server acceptance.
Original pixels, console/global-history behavior, complete formatting and
wider authoritative scenarios remain open.
Editor25060 and local server7568 are preserved; no GPU tests were run.

Baseline: `backups/native-chat-tooltips-v1.zip` (2272 verified files).
Checkpoint: `backups/native-chat-dispatch-v1.zip`.
