# Shared original fixed character summary

2026-11-01. The production character picker and the in-progress CG_MAIN frame
now use one native mode-zero summary builder. Existing picker data/projections,
availability, private input tickets and admission remain with their controller.
CG_MAIN's summary **frame** and scoped tab input are connected; its live draft
content, complete parent/children and original pixels remain unfinished.

The [connection-owned binding follow-up](NATIVE-CREATION-SUMMARY-BINDING.md)
now stages real draft identity/ability/portrait data with original completion
masking and lifecycle guards. Remaining content and child workflow stay open;
the source presentation remains hidden pending that work.

The [live creation list follow-up](NATIVE-CREATION-SUMMARY-LISTS.md) also binds
the real draft's Feats and Spells to shared source list views, with original live
callback and localhost admission/export checks. Live Skills-cache initialization
now has its own [Skills follow-up](NATIVE-CREATION-SKILL-SUMMARY.md); remaining
vitals/details and source creator workflow are still open.

## Shared source view

`native_data/character_summary_layout.gd` validates the original fixed geometry.
`native_character_summary_view.gd` constructs its controls from decoded source
models. It owns no catalog, BIC parser/writer, gameplay calculations or network.

- PNL_CHRSHT2 header, PNL_CHRSHT_CHAR2 statistics, PNL_CHRSHT_SKIL2 list pages.
  Original page/tab/title/ability/value hooks retain their coordinates.
- CTL_CHRSHT_NOSIZ fixed IgnoreHitCheck footer; no close control or resizer.
  The source default extent is360x468. PRE_PLAYMOD keeps its separate417px
  clipped viewport, preserving the Play/Cancel area beneath it.
- CTL_CHR_BTN_TAB5/6/7/8, TLK10560/327/326/5215: Character Sheet, Skills,
  Feats and **Spells**, distinct from the three-tab in-game sheet.
- Original20px Character-detail spacing, unscaled portrait/glyph proportions,
  original scrollbar owners, and a shared font/artwork owner.

The production picker retains its existing native BIC worker projections,
active server rules/TLK, row/help behavior, data images, selection epochs and
availability. Existing Skills/Feats/Spells owners attach to the shared page
hosts. Field aliases preserve diagnostics/tests without a second builder.
Static captions refresh from the bound text owner. Pregame frame artwork stays
independent of the active server catalog; server data does not replace it.

CG_MAIN prepares these source models and attaches the same view at(380,42).
Its own scope/revision guards retire held tab clicks across dismissal or draft
changes. Tabs change only the embedded page and send no gameplay action.
`embedded_summary_frame_ready` describes the frame only; acceptance and full
creator parity flags remain false. The shipping creator still uses its fifteen
pages pending full original parent/child integration.

Close unregisters this view's tooltips, removes its button geometry, disconnects
its font subscription and retires its detail scrollbar. Borrowed painter/art/
fonts remain alive for other menus.

## Original evidence and next data work

Pinned nwmain.exe SHA256:
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.
The [REA/Ghidra dossier](reports/native-shared-character-summary-research-v1.json)
retains original constructors/factories, complete Character data, title refresh,
provider-confirmed constructor LEA and the complete8-byte data-vtable slot.

88a0a0(mode0) selects these resources. Character factory88a830 uses CHAR2;
Skills88a970, Feats88a8e0 and Spells88aa00 use SKIL2.9c1220 explicitly constructs
CCharPageSpells.9b3440 writes CCharPageChar's vtable at e78b20: the confirmed
LEA at9b3493 and slot e78c70 prove virtual+150 dispatches to **9b6380**.

That complete data routine consumes a live draft creature ID and completion
mask: bit2 gates race text, bit16 alignment, bit4 class text, bit8 the score/
modifier fields plus HP/AC (confirmed by the later executed-region follow-up).
88b180 separately uses bit1 to append the draft name to the
localized Character Record title. CG_MAIN now has the correct initial unnamed
title, but has not yet bound the full data behavior.

Do not blindly reuse the picker's imported-BIC projection for creation: existing
picker evidence covers9bbfc0, while the creation dispatch above is9b6380.
Geometry is shared; different data inputs/calculation/disclosure paths still
need explicit mapping. Continue with draft initialization, mask/content/list
callbacks, the live parent adapter, remaining source children and preservation-
safe existing-BIC saves. Reuse the already connected
[draft-reset corrections](NATIVE-CREATION-DRAFT-RESET.md).

## Verification

| Receipt | Scope |
| --- | --- |
| `native-summary-shared-compile-v1` |6 actual entry/probe compilation/construction checks |
| `native-summary-shared-lobby-v1` |29 production picker/source/input checks |
| `native-summary-shared-statistics-v1` |25 native typed-BIC statistics/details, retention/replacement/retirement checks |
| `native-summary-shared-lists-v3`, `native-summary-shared-lists-release-v1` |50 editor/release headless checks each:15 original feat observations, real BIC/rules/TLK, Skills/Feats/Spells input/help, both arrows,125-percent input and stale selection |
| `native-summary-creation-parent-v3`, `native-summary-creation-parent-release-v1` |35 editor/release headless checks each: actual source geometry/mouse input, fixed summary/title/footer/Spells, held-input retirement and prior parent/portrait/reset/cancel paths; non-rendering artwork double |
| `native-summary-shared-local-v1` |11 creator checks, original localhost Prelude admission, authoritative movement and Wizard class/School/spell/feat export |

The localhost result is a production entry/creation regression; it does not
accept the still-unbound CG_MAIN content. Accepted receipts have unchanged
source, no engine/lifetime/native errors and zero public connections. Local
shutdown acknowledges the protocol and has zero workers. The existing editor
and Prelude server remain open. No GPU test or public join was used.

Headless caveat: GUI model artwork uses SubViewport/frame_post_draw, which the
headless renderer does not emit. ListsV1/V2 failed the prior graphical-only
scrollbar-readiness assertion despite correct real text/list ranges and no
asset failure; V2 retains those diagnostics. V3 explicitly substitutes only the
texture-provider boundary with a non-rendering image, records
`headlessScrollbarArtDouble=true`, and exercises real source geometry, ranges,
arrows and input. No assertion is skipped and production rendering is unchanged.
This proves input behavior, not artwork/pixels; original graphical review stays
required when GPU testing is permitted.

ParentV1 failed on a duplicate test variable. ParentV2 passed35 assertions but
correctly failed strict acceptance because the old font double lacked the real
owner's fonts dictionary; V3 fixes the test interface. Failed receipts remain
retained and unaccepted.

Checkpoint: `backups/native-shared-character-summary-v1.zip`, with verified
read-back manifest. The [whole UI goal](NATIVE-UI-PARITY-GOAL.md) remains active.
