# Native chat and player controls — local authoritative acceptance

2026-11-01. Scoped follow-up to [adjustable chat](NATIVE-CHAT-HUD.md),
[original dispatch](NATIVE-CHAT-DISPATCH.md) and
[player controls](NATIVE-PLAYERS-FRAME.md). The complete UI goal stays active.

## What was exercised

`reports/native-chat-authority-v4.json` passes55 checks against the unchanged
original NWN:EE server executable, using the owned `GodotPlayers1` fixture at
127.0.0.1:5125 and two real protocol participants. Only one participant runs
Godot; the other receives/sends original server packets without a renderer.

The native participant submits actual Enter events through the chat LineEdit
and a viewport mouse click through its received-message portrait reply control.
The other native player-window controls are exercised through their real
pressed handlers. Success reads incoming original-server speech, GUI feedback,
attitudes, creature party flags and both participants' received party lists.
The probe does not insert speech, predict membership or alter live characters.

Confirmed outcomes include:

- `/tp "account"` and `/t "full character name"` deliver distinct Tells to
  the intended second player. The peer retains only fixed owned test markers.
- Unknown slash text reaches the server unchanged as Talk, allowing server
  commands to remain server-owned.
- A received Tell creates the native portrait reply control. An actual mouse
  click reaches GUI event27 with the intended target account and focuses the
  `/tp` prompt. Enter then delivers the reply to the other real participant.
- Typed Invite, typed Accept with OBJECT_INVALID and Party chat produce actual
  server invitation/membership/delivery outcomes in both clients.
- Player selection and Tell use GUI events12 and28; Tell only primes entry.
  Independent local/incoming attitudes, Reject, Accept, leadership transfer,
  Kick, Leave, Ignore and explicit party-list refresh have server receipts.

The run also retains the existing authoritative movement check, receives an
exported character, closes all native workers and exits cleanly. Its report
records success, zero public connections, sourceUnchanged:true, no native
exception and no engine error. This is a behavioral acceptance receipt, not an
FPS measurement or original-client pixel comparison.

## Headless scope and reproduction

The user's other game remained running. No game window or GPU test was opened.
The bootstrap has `--disable-gpu`; native Godot uses the headless renderer and
a60 FPS process cap to avoid unbounded CPU loops. This cap is not a game limit.

This specific headless Players scenario joins through protocol admission to
the owned local server. It explicitly excludes graphical prejoin profile/
Direct Connect, character-preview, desktop-settings and pixel acceptance.
Ordinary graphical action tests retain their original admission controls and
artwork gates. The production UI's artwork-readiness behavior was not relaxed
to make a dummy renderer satisfy a graphical test.

Use a fresh run name and the existing protected local credentials:

```powershell
& ./godot-client/tools/test-native-actions.ps1 `
  -Run native-chat-authority-review-v1 -Players -Headless `
  -ProtectedKeyFile ./runtime-logs/local-multiplayer-server/native-barter-main.dpapi `
  -BarterPeerKeyFile ./runtime-logs/local-multiplayer-server/native-barter-alt.dpapi
```

The harness verifies the pinned original server, requires free UDP5125, starts
its own hidden/public-disabled fixture and retires only that exact owned server
in finally. The campaign server at5121 and the user's Godot editor are preserved.
Private keys pass through protected settings pipes; reports/checkpoints do not
contain plaintext keys. The protocol-only participant accepts only fixed marker
text for its test-chat operations and is restricted to loopback5125.

The current runner also includes the later
[HUD acceptance scenario](NATIVE-HUD-LOCAL-ACCEPTANCE.md) in the versioned
GodotPlayers3 fixture. Its81-check receipt extends this historical55-check
GodotPlayers1 result; the original module and receipts remain preserved.

## Rejected receipts and remaining work

- `native-chat-authority-v1` failed before connecting: its graphical admission
  test awaited rendered artwork under Godot's dummy renderer.
- `native-chat-authority-v2` failed before connecting because the explicit new
  headless admission path still encountered the graphical-only admission guard.
- `native-chat-authority-v3` confirmed the chat deliveries and reply click, then
  attempted another invitation after the original-server Ignore action. The
  corrected scenario finishes acceptance tests before Ignore, which runs last.
  No production party policy or server state was changed to pass that check.
- `native-chat-authority-v4` passes all55 checks and clean shutdown. Failed
  receipts are retained rather than overwritten.

Remaining chat work includes original pixels/fonts/tooltips/timing, full
formatting and sound, complete console/global input/history policy, physical
clipboard review, wider roles/content/possession/server variants and original
disconnect/cross-server history behavior. The broader HUD/nameplate/menu audit
is still unfinished. This local result does not authorize public testing.

Baseline: `backups/native-chat-dispatch-v1.zip` (2277 verified files).
Checkpoint: `backups/native-chat-authority-v1.zip`.
