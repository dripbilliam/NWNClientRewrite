# Native overhead clock runtime

`systems/native_client_clock_runtime.gd` connects the existing protocol and
presentation owners. It is an **opt-in candidate**, not the default clock path.
Host accepts `--native-overhead-clocks` only with the editor runtime and forwards
`--native-overhead-clocks=true` to Godot. Release packaging, a launcher option
and default activation are not accepted yet. Offline captures do not enable this
path without a clock-source/bootstrap contract.

## Owners and ordering

- `NetworkWorld` owns canonical received proxies. Its private lifecycle helper
  observes actual ordered records, prepares metadata before canonical assignment,
  and publishes opaque witnesses after a successful transaction. It keeps
  record coverage separate from physical-construction certainty. No timer value
  is calculated in JavaScript.
- `NativeClockBridge` binds before Session.connect and before the later Host UI
  listener. Clock facts cross the authenticated local transport without waiting
  for catalogs, models, fonts, UI or the 200 ms raw-world publication. Exact
  session/connection/registry fences and listener retirement prevent stale
  callbacks. Backpressure is an accepted write, not a reason to duplicate it.
- `native_live_world.gd` provides explicit startup, pre-receive and post-receive
  hooks. SessionWorld initializes the runtime before connecting its local peer,
  snapshots clocks before polling, reduces admitted clock envelopes synchronously
  after the connection guard, and finishes conceptual entity timing before the
  late speech owners run. Asynchronous resource handlers do not own these facts.
- `ClientClockServices` owns the three process-lifetime timers and thin physical
  clock references. An actual fresh external creature fact captures base T0
  immediately, before raw/display lifetimes exist. Those missing lifetimes stay
  explicitly null. Later model/UI publication never invents a birth timestamp.
- The three speech owners read the same completed T2 GUI delta. ScriptFloating
  FIFO cooldown instead queries its exact physical entity clock. The adapter
  first checks the actual current raw row, disclosure witness, area, connection
  and client-owned `nativeClockOwner` token. It neither reads renderer movement
  delta nor treats unavailable timing as zero.

The physical sampler has no whole-world frame scan. It retains the previous
completed conceptual AI snapshot and samples individual relevant bindings lazily.
Only an explicit area boundary enumerates thin references for same-physical
scope transfer. Removal or ambiguous reuse retires the clock reference, without
claiming native physical destruction. Active orphan GUI widgets have independent
GUI lifetimes. Connection cleanup precedes UI/registry teardown and preserves
process timers. Final process release severs callbacks/resources even if a
previous transition was unsupported; it does not claim successful cleanup.

## Absolute source

`native_data/native_clock_source.gd` explicitly loads an immutable descriptor and
the reviewed existing DLL from `.cache/native-clock-source-v1`. It verifies both
before loading and rejects an identically named class owned by another
extension. The hidden directory requires no change to the editor's
`.godot/extension_list.cfg`; no shared native output is rebuilt. Until the
artifact is explicitly installed, enabled startup reports unavailable and does
not invent a substitute source.

The reviewed 25 KiB DLL and exact descriptor are now installed in that ignored
directory for the explicit editor candidate. The install manifest records the
accepted 233-check runtime baseline and all eight preserved shared/configuration
guards. Installation performed no compilation, engine launch, process action,
editor auto-registration or default switch. The baseline itself used a copied
library and observed the main installation absent; the later installation is
separate evidence.

The DLL is the original-backed **direct-Real** Win32 QPC/GetTickCount conversion.
It returns exact unsigned microsecond words, with no Godot/process-origin
subtraction. This is distinct from the original default timer thread's cached
sample phase. Its earlier independent conversion/original-instruction evidence
remains separate from ownership and runtime tests. No cached-thread equivalence
is claimed.

## Remaining acceptance

The candidate deliberately supplies no fabricated scene150/158, audio, GUI or
pause lower-provider callbacks. Ordinary unpaused timing is supported; a
nontrivial pause transition that needs those providers becomes explicitly
unavailable. It must not silently fall back to renderer delta. Native pause
lower-owner behavior, final process packaging and an actual original-local-server
run of this complete candidate remain required before default activation.

The actual three speech `_process` methods and full client script tree at that
checkpoint pass the copied 54-check headless gate. That proves timer input, missing-data
behavior, one-clock handoff, orphan GUI lifetime, reader cleanup and script
compilation. It does not instantiate the real client root, establish pixels,
exercise a live server, or prove lower-provider parity. Runtime tests using the
actual Session/World/Bridge fixture and private Win32 source pass 233 checks
across 17 batches and 15 actual bridge frames. They verify delayed raw publication,
previous-AI timing, retirement, scope transfer, reconnect, unsupported-transition
unavailability and final resource release. Those tests use passive GUI holders;
they are not a live original-server run or pixel acceptance. An initial rejected
fixture passed JSON FLOAT arrays directly where the actual UI uses normalized
integer witnesses/scopes. The correction uses those existing production
projection helpers, preserving both raw received rows and runtime fences.

The interrupted local visual comparison, retained-model deletion fade,
historical nested parser providers, nonidentity item sampling and exact native
border culling remain open. The level-up flash and broader UI/migration goals
remain open as recorded in their existing goal documents.
