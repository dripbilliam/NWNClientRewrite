# Native Appearance and Character Information

`native_appearance_chooser.gd` and `native_character_info_chooser.gd` are original-resource Controls with private edit transactions. The shipping first-level creator now connects them through `native_creation_tail.gd`; `native_creation.gd` and its frontend remain the authoritative draft/flow owners. No network command is sent by either view. Current composed model/BIC and responsiveness acceptance is recorded in `NATIVE-CREATION-TAIL-INTEGRATION.md`; the standalone evidence below keeps its original scope.

## Evidence and current acceptance

- First UI checkpoint: actual keyboard/modal24 +installed-art/font raster27
  +GenericEdit/Subrace input13 are clean against immutable current closures.
  The supporting installed swatch/board resource inspection has10 checks.
  Exact cases and remaining coverage are below; these counts are separate from
  the earlier standalone/state and shipping Tail model/BIC milestones.
- Current voice-caption follow-up:82 clean checks (installed-art/font raster30,
  actual Information input28 and current keyboard/modal24). Its exact preserved
  before replay retains3 caption bounds/alignment/ink failures. This corrects
  the Info view/layout beyond the first64-check checkpoint; the earlier shared
  GenericEdit13 scope remains separately preserved.
- Original body/head arrow instructions:480 cases in `reports/native-creation-appearance-arrows-original-v1.json` (unchanged).
- Original `CompareNoCase` BOOL, Appearance inversion and actual enable branch:16 cases in `reports/native-creation-appearance-model-gate-original-v1.json`. **P models are editable; non-P models are disabled.** Earlier authored tests interpreted this backwards; their receipts remain historical and do not establish source-policy parity.
- Original palette release conversion/removal/callback:195 cases in `reports/native-creation-palette-release-original-v1.json`.
- Current corrected private state:1188 clean checks under `.cache/creation-appearance-state/appearance-state-palette-v3/`, covering all three unchanged-original corpora plus state isolation/availability.
- Original-resource Appearance controls:23 clean actual-input checks under `.cache/creation-appearance-view/appearance-title-order-input-v6/`, including capture/drag/release, outside cancellation and current tickets.
- Character Information controls:21 clean actual-input checks under `.cache/creation-character-info-view/character-info-title-input-v3/`, including typed fields, voice samples, nested Deity and scoped asynchronous names.
- Installed GUI/MDL metadata:43 clean checks under `.cache/creation-tail-resources/appearance-info-resources-v1/`.
- Actual installed FontFile/atlas-ink and source paint-order checks:66 clean under `.cache/creation-tail-text-geometry/tail-real-font-title-order-v2/`. The unchanged66-check baseline retained9 failures: two off-frame Titles and seven absent Appearance row backgrounds. Both claimed Titles now use their source740×30 alignment regions; row/viewer backgrounds precede foreground captions. Original8eb480 and8e8df0 explicitly set the claimed Title bounds flag4. Other source label anchors remain unchanged; no generic Painter/Dialog change is made.

Earlier failed copies are preserved: the Info scrollbar initially used the static-only decoder instead of the existing animated decoder; a palette capture alias was cleared during retirement before validation; the first model-type fixture inverted BOOL CompareNoCase; and the blank unclaimed editor label enlarged the frame. None of those failed receipts establishes acceptance. Input tests use artwork/font publication doubles; the66-check text test uses real installed fonts and CPU atlas ink with artwork publication doubled. Concurrent tests establish geometry/state, not performance timing.

The source frame is742×526 and model preview slot347×406. CG_APPEARANCE includes an empty unclaimed `TGuiLabel4` editor rectangle outside the frame; it is preserved as metadata but cannot enlarge or shift the actual frame. Layout and input tests do not establish rendered font, hover, selected color swatch or3D preview pixel parity.

## Appearance owner contract

Call `configure(painter,text,catalog,cache_path)`, `start()`, `set_context(context,ticket)`, then `open()`. `dismiss()` invalidates held input and color-board capture; `close()` also drains its asset owner. The painter/catalog provide original pregame frame resources; choices must come from the current active rules/catalog.

`context` contains:

```text
appearanceValid: bool
modelType: String                 # active appearance MODELTYPE, P is editable
customizeMode: int                # original0=new draft,1=existing customization
enabledPhenotypes: signed/unsigned32 integer
headIndexComplete: bool
heads: Dictionary<WORD,bool>      # actual model presence, no invented choices
paletteSizes: {skin,hair,tattoo1,tattoo2: integer}
clothing: [{id,resRef,bodyParts[19],colors[6]}]
value: {phenotype,head,skin,hair,tattoo1,tattoo2,tattooPattern,
        bodyParts[19],skinParts[19],clothes,clothingIndex,materialColors[6]}
```

Unavailable choice data disables the related input. A successfully loaded UTI may use the native field defaults: all19 parts `ReadFieldWORDorBYTE(...,0)` and six material colors `ReadFieldBYTE(...,0)`. A missing/unreadable UTI must not be replaced by a fabricated all-zero variation. Original clothing initialization filters active `ChargenClothes` physical rows and deduplicates successful `ItemResRef` strings. Initial head presence uses gender's row selected by `(gender==1)` and active appearance RACE, always prefix phenotype0; do not reuse the legacy draft-phenotype/byte-only head filter.

Signals:

- `finished(accepted,value,ticket)` returns a detached final private appearance. Accept is the original0x8002 child result; flow owner opens Character Information next.
- `preview_changed(value,ticket)` requests an asynchronous private preview, without changing the draft.
- `preview_attached(slot,ticket)` exposes the private original model hook rectangle to the existing native preview owner. The view does not create a second renderer or block input while a model prepares.

Original skin/hair/tattoo selected swatches now use the source
`gui_replace01`→`GUI_CG_COLOR_TMP` PLT replacement. The nested descriptor is
`{resource:"gui_cg_color_tmp",palette:[packedSelector]}`: skin uses its BYTE
index, hair uses`0x100|index`, tattoo uses`0x600|index`. The selected palette is
not an ordinary world-PLT row index. The shared worker helper changes only the
swatch mesh and preserves the source `gui_boxes_chrgen` frame. Active worker
rows carry exactly1024 bytes plus the source TGA hash, keyed by packed selector;
declared-but-missing rows stay explicitly unavailable and retire old pixels.
They cannot silently fall back to the installed palette. No complete palette
graph is copied on an input refresh. Actual source-model pixels, physical board
selection, a distinct active-row fixture and stale-pixel retirement are tested;
this is not original-client or chrome-environment-map pixel acceptance.

## Character Information owner contract

Use the same configure/start/context/open lifecycle. Its context contains `value:{firstName,lastName,ageText,description,deity,soundset}`, `voices:[{id,name,resRef}]`, and `randomReady:bool`. All five text fields are required strings. Soundset IDs are actual physical WORD IDs; missing or unadmitted selection remains null. The active voice table's original filter accepts TYPE0 or2 with exact character gender and nonempty ResRef; the old generic TYPE0-only list is insufficient.

The screen retains the source first-name→age→last-name→biography Tab order, a bounded source voice-row pool, two original scrollbars and the native GenericEdit child for Deity (title8156). Repeated soundset selection cycles0..48; changing ID restarts0. Initial admitted selection requests sample0 once.

Signals and responses:

- `voice_requested(id,resRef,sample,ticket)` delegates to the existing native SSF/audio service. Original selection writes soundset immediately to its owned temporary character; the creator owner must preserve that timing when binding this signal. The view alone keeps edits private.
- `random_requested(request_id,ticket)` delegates native LTR/name-filter generation to the existing scoped resource/worker owner. Respond using `generated_names(id,first,last,ticket)` or `generation_failed(id,ticket)`. One job per view is pending; stale/cancelled replies cannot mutate a replacement.
- `finished(accepted,value,ticket)` returns original accepted result0x8007 or cancellation. `value.description` maps to the existing draft's `biography` field.

Original OK uses first/last `Left250` encoded bytes, biography `Left8192`, removes lowercase `<c…>`/`</c…>` tags and parses age with signed native `atoi`; whitespace is preserved. The staged result now uses the existing native GFF writer/reader's CP1252 codec. Accented/exceptional CP1252 characters consume one byte; unencodable input remains explicitly unavailable rather than becoming an empty submitted field. This establishes the current native serialization path, not arbitrary Unicode/locale edit parity. Malformed unclosed color-tag behavior remains unsupported.

The staged view now offers `set_random_ready(ready,ticket)` so a current name-resource publication can update availability without resetting typed fields. When both names remain empty, the original automatic Random operation is requested exactly once for the open scope. Repeated readiness notifications do not duplicate it. A reply is retired when its scope/request is stale or either name was edited after the request; successful replies focus the first-name edit as original8e5be0 does.

## Staged active-data provider and names

`native_data/creation_tail_provider.gd` is detached, read-only projection code
consumed by the shipping Tail worker. Its
`appearance(tables,selection,model_names,loads,palettes)` and
`character_info(tables,selection,text)` return `{ready,context,provenance}` or an
explicit unavailable reason. Catalog I/O and draft mutation remain owner
responsibilities. `clothing_candidates` supplies canonical resource requests
before `clothing` publishes the complete admitted list. A `loads` entry is
`{status:"ready",document,sha256}`, known`absent`/`native-load-failed`, or pending.
Unknown bytes/decode errors cannot become a zero-filled outfit. No projection
caches across table/catalog/character publications.

The first provider checkpoint passed38 checks under `.cache/creation-tail-provider/tail-provider-active-v6/`; current44-check validation at `.cache/creation-tail-provider/tail-provider-nonp-v7/` adds the original non-P dependency case. These use actual separately mounted active2DA and typedUTI bytes, physical-row identity, lowBYTE class versus fullUINT race/gender restrictions, exact alignment comparison, post-success case-sensitive raw-resref dedupe, extended parts, native palettes/head/phenotype initialization, existing-mode preservation, active voice/text publication replacement and detached results. Native `ReadFieldWORDorBYTE` reads **only a WORD from `(x+field).left(16)`**, otherwise only a normal-label BYTE; a normal-label WORD is not a substitute. Six material channels read BYTE with native loaded-UTI default0. Source dossiers are `native-creation-tail-field-getters-original-v1.json`, `native-creation-tail-typed-owners-original-v1.json` and `native-creation-tail-callbacks-original-v1.json` in `reports/`.

The native2DA string getter writes table default on an invalid lookup while returningfalse. The parser stores a literal `****` cell as empty even with a nonempty table default, so the getter clears its output and returnsfalse for that cell. The clothes loader consumes the written output, never retaining a preceding outfit. Exact source proof is in `native-two-da-missing-token-original-v1.json` and `native-creation-tail-string-name-original-v1.json`.

Initial voice selection is source-proven as a **filtered visible index** from active `Packages.SoundSet`, then mapped to the actual physical WORD soundset ID. AddButton stores physical IDs in a separate4-byte metadata list; SelectTab indexes the checkbox array directly, and8e7110 reads the WORD at that selected visible position. Positive out-of-range package indices remain unavailable because the original callback may read outside the valid list. Evidence: `native-creation-voice-metadata-original-v1.json` and `native-creation-voice-tab-index-original-v1.json`. The source voice filter includes TYPE0 or2 and exact BYTE gender.

`native_data/creation_character_names.gd` implements235000 resource routing from active racialtypes `NameGenTableA/B`, the original fallback/special races, `m`/`f`/`l` suffixes and conditional `rand()%2`. First-name probability generation finishes before the independent last-name table-choice sample. No fallbackHuman name is invented for unsupported races. `scripts/inspect-native-character-name-routing.py` executes the complete unchanged original routing/cache body:446 cases in `reports/native-character-name-routing-original-v1.json`. Current911-check differential/installed-LTR proof is `.cache/creation-character-names/character-names-routing-v3/` (445 routes plus the exact cache-hit observation).

`native_character_names.gd` is a staged asynchronous pair owner using the existing AssetService/decode cache and the verified native probability generator. Configure with `(active_catalog,scope,name_plan)`, wait `prepared(scope)`, check `available(scope)`, then `request_names(scope)`. `names_ready(id,{ready,firstName,lastName,scope,...})` is detached. It admits one generation job globally, including a retired job while draining; replacement/cancel cannot build an unbounded queue. Actual resources prepare on asset workers and probability generation runs on a worker. A known optional NameFilter parse/load failure is distinct from missing captured bytes. Close drains both kinds of work. Current20 clean checks: `.cache/creation-character-names-owner/character-names-owner-v2/`.

Character Information's earlier28 actual source-control checks are
`.cache/creation-character-info-view/character-info-name-readiness-v5/`. They
include automatic generation, late readiness preserving typed edits,
repeat/stale notifications, reply retirement, voice input, nested Deity and
private result handling. Those receipts retain their standalone scope; the
shipping Tail integration has separate composed creator/parsed BIC evidence.

## First-level keyboard, modal and actual-art correction

Appearance and Information now route a nonrepeat Escape only to the currently
admitted modal owner. Original Appearance vtable140e64168+140 targets8e3300;
Information vtable140e647c8+140 targets8e3380. Both return native Cancel2.
Appearance's attached color board is not a separate native modal, so Escape
cancels that screen and retires the board. A top Deity child handles its own
Enter/Escape; it cannot submit or cancel Information underneath. The existing
first-name→age→last-name→biography Tab order and its reverse are preserved.
No unconditional screen submission was added for Enter in a text field.

Actual rendering exposed a separate shared edit issue: Deity's prompt wrapped
one letter per line. Original `CPanelGenericEditBox::InitializeModel`201960 sets
MessageLabel bounds flag4 before importing it. The port treated it as a
one-pixel unbounded anchor, then enabled wrapping. Only GenericEdit's own layout
classification changed: the source MessageLabel rectangle now owns text and
wrapping. Shared Painter/Dialog are unchanged. The same bounded raster has27
checks: preserved old GenericEdit bytes fail exactly3 message rectangle/line/ink
assertions, while corrected bytes pass27/27 with a readable one-line prompt.
Real-font GenericEdit input13 also covers the original Subrace8185/20 contract,
initial over-limit text, admitted navigation/deletion, Enter/Escape/OK/Cancel,
retired tickets and two immediate reopen stages. A failed first input fixture
used blocked End to position its caret; the preserved correction uses admitted
Right events, without changing production input policy or expected results.

The CG_MAIN parent was checked independently: constructor8dbf60 chooses
vtable140e64678; its Escape slot+140 is the base1eea30 implementation returning0.
Therefore editing-phase Escape has no original parent cancel action and remains
unchanged. Exact original evidence is retained in
`reports/native-creation-tail-visual-keys-original-v1.json` and
`reports/native-generic-edit-message-owner-original-v1.json`.

Current UI cases:

- `.cache/creation-tail-keyboard/tail-keys-modal-current-v2/`:24 clean physical
  keyboard/mouse/modal checks; artwork/font publication doubles.
- `.cache/creation-tail-visual/tail-visual-message-after-v2/`:27 clean actual
  installed GUI/font/swatch/Deity raster checks, including both offscreen and
  no-focus guards and six unchanged native outputs.
- `.cache/generic-edit-bounds-input/generic-claimed-message-input-v2/`:13 clean
  source-input/real-font checks; artwork publication double.
- `.cache/creation-swatch-resources/tail-swatches-original-resources-v2/`:10
  read-only actual PLT/TGA/button/board metadata checks, counted separately.

The actual composite PNGs include Appearance, captured color board, changed
selection, a deliberately distinct supplied active palette row, Information and
the corrected Deity child. The source preview slot is intentionally empty in
this isolated view raster; the shipping private model preview is tested by the
separate Tail owner. Each raster child retains its35-second bound, runs outside
all display rectangles and cannot activate. No visible user process, server/key,
native build, FPS benchmark or audible playback was used. Screen-to-screen BIC
flow, active-row worker publication and audio loading have their own owner
receipts. Original-client pixel identity, environment reflections, arbitrary
locale/IME behavior and unproven voice-list key shortcuts remain outside this
UI checkpoint.

## Source voice-caption attachment

A final bounded review found that voice rows still centered names across the
entire animated button. Original initializer8ecc60 instead calls715100 with
float0 (fresh bytes at140db1f98 are00000000), selecting left horizontal
alignment. Constructor8dcbc0 fixes font`fnt_galahad14` and vertical alignment0.5.
Model initializer8850c0 attaches to the`text` hook when present, otherwise to
the`text0`/`text1` rectangle. Installed`CTL_CG_BTN_SNDS` takes that fallback:
the text rectangle relative to its row is(13,5)..(317,39), rather than the full
324×42 button. The Info-only layout/view now uses that source attachment with
bounded label content. Voice IDs, row selection, sample0..48 progression,
audio signals, name workers and the private transaction are unchanged.

Original source and constants are retained in
`reports/native-creation-voice-caption-original-v1.json`. The same30-assertion
actual raster reports3 caption failures with preserved before Info bytes and
passes30/30 after correction. It measures real installed glyph ink starting at
the left text attachment without crossing the frame/scrollbar, and retains all
swatch, active-row, Deity message and offscreen isolation checks. Corrected Info
PNG was visually reviewed. Current cases:

- `.cache/creation-tail-visual/tail-visual-voice-after-v3/`:30 actual raster.
- `.cache/creation-character-info-view/info-native-voice-caption-input-v6/`:28
  physical voice/name/Deity/typed-field and stale-scope checks.
- `.cache/creation-tail-keyboard/tail-keys-modal-voice-current-v3/`:24 physical
  keyboard/modal checks.

The follow-up checkpoint is
`reports/native-creation-tail-ui-v2-checkpoint.json`; v1 retains the earlier64
UI checks plus10 supporting resource inspections. These are overlapping
regression scopes, not additive proof of an entire creator or audible playback.

The real installed FontFile/atlas-ink/paint-order regression remains66 clean at `.cache/creation-tail-text-geometry/tail-real-font-current-provider-v3/`. The sealed provider-v1 name/input/font checkpoint totaled1063 checks, with clean engine logs and unchanged copied dependency closures. The446 unchanged-original routing observations are supporting evidence, counted separately. Current non-P and staged writer validation is documented separately in `NATIVE-CREATION-TAIL-BIC.md`. No timing/performance or running-client acceptance is inferred from these functional tests.

## Remaining integration and validation

The first-level runtime integration now accepts the active-table/UTI provider, typed body/head fields, native preview admission and cancellation, Appearance→Info→CG_MAIN, scoped name/explicit audio-sample handoff and parsed BIC. See `NATIVE-CREATION-TAIL-INTEGRATION.md` for exact current counts and limits. Existing-BIC picker Customize remains explicitly unsupported and cannot use the first-level writer. File-preserving save semantics, public-world behavior, rendered client pixels, audible playback and authoritative upload remain separate work.
