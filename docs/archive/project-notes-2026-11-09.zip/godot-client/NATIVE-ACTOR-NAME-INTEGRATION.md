# Native stored actor-name integration

Constructor-certified creature names now have a complete protocol-to-Godot-to-chat path. Generic, imported and BIC-loaded owners whose prior stored-name state is unknown retain the previous compatibility adapter; they are **not** certified by this implementation. Visual acceptance and the broader goal remain unfinished.

## Authoritative owners

`NetworkWorld` owns thin private name provenance in a WeakMap keyed by its actual canonical proxy. Only an accepted type5 A with explicit typed-owner absence and complete tracked history admits the native constructor defaults. The original `7fb140 -> 7ea7a0 -> 7ea230` initializes stored first, last and override strings empty. P mask400 writes actor first/last; U mask10000 is a party/portrait label. It cannot replace actor slots. The original constructor, writers and GFF caveats are pinned in [the independent source review](NATIVE-ACTOR-NAME-OWNER-REVIEW.md).

Metadata and its sequence are staged with the existing canonical transaction and committed only after validation. Rejection leaves old names and the sequence unchanged, while lowering history certainty. The actual decoder's `complete` flag now reaches that boundary: partial prefixes, untracked calls and failed transactions cannot certify later fresh constructors until a World reset. No world scan is needed to lower this connection-level certainty.

Serialized metadata is not an authority for construction. Imported or injected row properties cannot create private ownership. Public/internal diagnostic reads through `nativeActorNameFor` are detached. The existing raw transport borrows a deeply immutable view through `nativeActorNameTransport`; unchanged names do not require another deep copy on every world update.

D preserves bytes. Since the original delayed destruction is not implemented by the proxy owner, an ambiguous D+A does not manufacture a constructor or assert that old first/last values remain current. Known-empty override is invariant under either retained reuse or a new empty constructor; potentially stale nonempty data is preserved without being promoted as current. A new P can supply the current first/last publication.

## Native data and receipt-time names

The protocol helper captures literal or localized first/last declarations, wire genders, selected direct override presence/raw text and, only when required, native CUSTOM bytes and explicitly available parser state. It performs no TLK fetch, token expansion, rendering or scene preparation in JavaScript.

The existing raw snapshot carries `nativeActorNameState` and `actorNameHistory`. `ActorNameState`, a Godot `RefCounted` owner beside TalkText, observes those fields at accepted state-update boundaries. It stores resolved strings and pending name receipts, not complete actor rows, Nodes or another world store. `data_changed` visits pending records only; there is no processing loop. Ordinary name reads do not fetch or parse again.

`NativeTextEventScope` also captures the exact private name state at the actual chat event, before later raw snapshots can coalesce a rename. Godot Header captures a detached historical name receipt at ingress. It uses matching ready cached slots where available, otherwise the event's own captured P publication. Neither a newer P, deletion, same-ID replacement nor a later CUSTOM/override update can rename that queued chat. Connection/area-generation changes reject old bindings. Pending lookup stays on the captured Text owner; resolved strings no longer need that reader.

The namespace and lifecycle contract is in [the received-name API](NATIVE-ACTOR-NAME-RECEIVED.md). Missing fields remain pending or explicitly unknown. No renderer position, controlled-character fallback or party label supplies a native stored name.

## Fetch semantics and display

`TalkText.fetch_native_reference_snapshot` selects the captured override without mutating the live override map. It retains native invalid-reference ordering, TLK-family publication/female fallback and raw parseFlag0 behavior. `lookupComplete` distinguishes a completed native false/empty fetch from an unavailable file or lookup provenance. The ordinary default API keeps its prior virtual lookup boundary.

Override parsing uses the captured CUSTOM/context state. A nested named reference without a captured override selection stays unavailable instead of reading a later live override. Complete historical nested provider state remains a limitation.

Successful empty names remain successful empty strings. `nativeNameResolved` lets both chat painters preserve the native separator rather than replacing that name with Unknown or dropping its colon. Prefixes and explicit remote names use the same snapshot lookup; a later override cannot replace an earlier base label.

The name metadata does not enter the renderer's model signature. This work adds no model lookup or preparation in JavaScript. The existing appearance signature still contains the P name field itself; avoiding unnecessary model preparation on a name-only P is a separately identified follow-up, not a performance claim made here.

## Evidence and remaining work

- Actual canonical transaction, event-boundary capture, private-view isolation, disclosure and completion lifecycle: [51 Node checks](.cache/native-actor-name-world/native-actor-name-event-v1/proof.json).
- Native stored-name component and historical receipt/coalescing behavior: [65 checks](reports/native-actor-name-state-v2.json).
- Actual World-generated JSON through real Gameplay set/update/receive/queue/speech/present and both chat painters: [122 checks](NATIVE-ACTOR-NAME-GAMEPLAY-ACCEPTANCE.md).
- Default native parser, ordinary body/HUD and ScriptFloating regressions have separate current receipts. Counts overlap and are not a parity score.

These are functional/lifecycle checks, not GPU, FPS or native pixel comparisons. The current original-local-server run, when recorded, must be cited separately; authored fixture boundaries do not prove a native constructor executed in a live client.

Controlled/BIC ownership still needs the exact transfer/load owner: native GFF loader `7f7e20` can set `DisplayName` into override+40, and reviewed login/control/area readers do not prove its initialization. See [the bounded controlled-load audit](NATIVE-ACTOR-NAME-CONTROLLED-LOAD-AUDIT.md). Unknown owners retain explicit compatibility status; a proxy ID, lifetime token, first snapshot or plausible serialized constructor flag never supplies missing evidence.
