# Native skill allocation and active-server rules

Updated2026-11-02. The original CG_SKILLS source screen now edits the live native
draft through Configure Package. Allocation, help, repeat input, recommendation,
Cancel and OK have scoped headless checks and original localhost rank export.
The remaining Feats/class-dependent continuation, full creator/level-up,
preservation-safe saving and original-client pixels are still open. The complete
source creator remains staged; this does not complete the UI goal.

Later lifecycle correction2026-11-02: `clear_rows` now removes row/up/down IDs
from the shared painter geometry registry before freeing controls. The focused
`reports/native-skills-late-art-repro-v1.engine.log` first reproduced a real
previously-freed-instance access when model artwork published after retirement.
`reports/native-creation-skills-late-art-v1.debugger.json` now passes5147 checks,
including an actual held source arrow, active dependency removal, registration
retirement and all three delayed model callbacks. sourceUnchanged=true; no
engine/lifetime/debugger error. This additive headless lifecycle result does not
rewrite the earlier sealed5144/local41 acceptance or claim new visual/server
acceptance. The shared feat-slot caller correction is separately documented in
[Feats](NATIVE-CREATION-FEATS.md).

## Required data ownership

Character creation **and** level-up must use the base or current server's
resolved `.2da` data and its referenced resources. The connection-owned catalog
includes the applicable HAK/NWSync/Workshop/override layers and custom TLK.
Follow table references such as a class's SkillsTable and StatGainTable; do not
embed stock class/skill/feat/spell lists or substitute base tables for a server
replacement. Preserve physical rule IDs across presentation and submission.
The pregame artwork catalog owns presentation resources, not the gameplay rules.
Changing servers must retire the old draft and rule context. The original server
remains authoritative over uploaded characters and level-up proposals.

`creation_skill_rules.gd` implements original7ec0c0/7f7a00/7ee3e0 arithmetic
against the supplied tables. Class SkillPointBase, race modifier ability, extra
points, first-level multiplier, class skill references, usability and ruleset
modifier/rank-cap fields come from that context. Original byte/word widths and
the first matching class-skill entry are preserved. An absent modifier-ability
column defaults to INT; an unrecognized present string means no modifier, as in
the original race loader. It is not interpreted as an arbitrary numeric index.

The live creation draft now tracks its original remaining skill-point WORD.
Package preferences spend through the actual allocator in listed order without
filling unlisted skills. The existing native level-up owner now uses the shared
budget/rank rules with the new total level and server-supplied carried points,
instead of its former fixed modifier calculation and `(level + 3)` cap formula.
The full source level-up coordinator and snapshot semantics remain separate.

Actual control testing also found that level-up's `Dictionary.merge` ignored
row-specific disabled flags. The owner now applies those flags while preserving
the submitting lock, so skill-cap and other availability states reach the view.

## Evidence and checks

Pinned original nwmain.exe SHA256:
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.
The [original function dossier](reports/native-creation-skills-research-v1.json)
retains27 procedures for the constructor, binding, population, help, timers,
recommendation, OK/Cancel, allocation and downstream coordination. Historical
research cache names can be misleading; use the procedure address/code.

`scripts/inspect-native-creation-skills.py` executes the original budget,
rank-up/down, class-skill/usability, rank/cache setter and preference allocator
instructions. Ability/vital instructions are reused; raw loaded rules, 2DA
services, allocation and object lifetime are explicit providers. The immutable
144-case corpus contains2,333 operations:
`../backups/animations/native-creation-skills-observations-v1.json`, SHA256
`5c608eb2b37493295b6f3be7706f64a267d2ef68f0a0dd42ceca3db2969b0aca`.

`scripts/inspect-native-level-up-skills.py` repeats those original instructions
at total levels2/3/10/20/40/60 with carried point WORDs and custom rule records.
Its144 cases also contain2,333 operations:
`../backups/animations/native-level-up-skills-observations-v1.json`, SHA256
`ca7d734843053e460f2bdff7c4199121c11885fd8e69ce06c08a7ad0d996aee6`.
These execute the shared allocator, not the entire original level-up screen.

- `native-server-skill-rules-v3` and `...-release-v1`:2,529 checks each. Original
  later-level instructions plus two distinct authored `.2da`/custom-TLK layers
  mounted over the real install, actual native parsing, creation draft allocation
  and native level-up buttons. Checks cover different budgets/caps/costs,
  first matching duplicate skill entries, unknown modifier strings, carried
  points, cap disabling, submitting lock, cancellation and base catalog isolation.
  The level-begin snapshot and command sink are fixtures; this is not a server
  admission or complete session-transition test.
- `...-creation-regression-v1`:5,100 original first-level allocation/cache/
  preference comparisons through the real creation draft.
- `...-overrides-regression-v1`:34 existing actual mounted-server Class,
  Alignment, Attributes and Package controls, custom feats/spells/preferences,
  custom TLK and connection-resource replacement checks.

All four receipts are headless, source-unchanged, with no engine/lifetime error
or debugger exception. No public server, GPU benchmark, visible client launch
or preserved user/editor process was touched. Failedv1/v2 receipts are retained:
they exposed the disabled-flag merge bug and an incorrect test expectation that
a cross-class row should retain the full class cap. Original evidence was not
changed to make those tests pass.

## Bound source screen

`native_skills_chooser.gd` shares the source modal/painter/help/scrollbar and
original GUI repeat timer. `creation_skills_layout.gd` reads the original nested
GUI hierarchy and model hooks. The frame remains742x526: Available Skills is a
nested label inside SkillsButtonBox, while the unused empty off-frame label
does not enlarge the panel. Original324x42 skill rows attach the16x16 arrows
and34x34 rank box at their authored hooks. Raw item icons preserve their aspect.

`creation_skill_state.gd` composes active-table names, class-skill suffixes,
physical IDs, availability, hidden rows, signed rank/modifier/check values and
point costs. Entries use legacy case-insensitive insertion order. Static row
metadata is separate from numeric updates, so the owner's own edits retain
the row controls and held action ticket. External text/context changes retire
held clicks and repeat state. If referenced rules become unavailable, the view
retires input, unbinds/removes old rows and clears rule-derived numbers/help/icon
content. Republished rules create fresh rows and general help; a pending context
does not require an already-published text provider. Initial selection is empty, with general
help58250/58251 and blank Cost. The original help constructor centers its title.

Arrow press selects its row and acts immediately. Repeat uses strict500ms/50ms
thresholds, at most one action per tick and no duplicate release action. The
native draft owner loads SkillPref2DA on demand; Recommended resets only skill
ranks/points and fills listed preferences while retaining displayed help/cost.
It preserves unrelated feat/spell/domain choices. Pending work disables duplicate
input and rejects a result after draft/ticket/text revision retirement.

Cancel/Escape performs the original derived reset and returns3 to CG_MAIN.
OK accepts unused points, commits the eligibility mask and transfers the existing
callback to `package-feats` or the staged `package-post-skills` coordinator.
Those downstream source screens remain unported; Skills must not mark Package
complete prematurely. Their original sequence, cancellation and final result
still need implementing before promoting full source creation.

The [attachment dossier](reports/native-creation-skills-attachments-v1.json)
retains six additional original functions and the pinned PE string `Icon` at
RVA0xdc498c. Original9d2a90 requests that named attachment, and
Gob::AttachToObject8c540 returns no attachment when it is absent. The shipped
CTL_CG_HELP has no Icon node. The view retains the requested help icon resource
without inventing a position. Complete original-client pixel/attachment review
remains an independent acceptance gate.

## Source-screen acceptance evidence

- `native-creation-skills-binding-v4` and `...-release-v3`:5,144 checks each.
  These include the5,100 original allocation/cache comparisons plus actual
  physical source row/arrow/repeat input, live draft mutation, recommendation,
  reset/OK, active text replacement, pending work, scaling and reentrant/stale
  retirement. The pending-rule regression withdraws the actual class SkillsTable
  during a physical held arrow, checks late input is inert, passes pending/null
  text context and republishes the table. Source artwork/fonts are nonrendering doubles; these are not
  original-pixel checks.
- `...-overrides-v3`:38 checks with real authored server `.2da`/custom-TLK
  files mounted over the install. The Skills controls honor custom names/IDs,
  hidden/unavailable rows, class/cross costs and KeyAbility, alongside existing
  Class/Alignment/Attributes/Package/feat/spell/resource-replacement checks.
- `...-package-regression-v3`:389 original Package instruction/input/draft,
  asynchronous ownership and BIC gold/equipment checks. Configure now expects
  the bound Skills child rather than an unported child request.
- `...-local-v4`:41 checks on the preserved original Prelude server at
  127.0.0.1:5121. The probe enters this source leaf after a legal automatic
  Package, transfers two ranks through its native controls and does not rerun
  recommendation afterward. Prototype appearance/name and already-selected
  later choices remain explicit boundaries; this does not pretend the full
  source configuration chain is complete. The server admits/exports the native
  BIC with all28 ranks exactly matching, alongside selected abilities, gender,
  race and alignment. Native exit0, acknowledged protocol finish, zero remaining
  workers, source unchanged, no debugger exception and zero public connections.

The four final headless receipts are source-unchanged with no engine/lifetime
error. Failed `binding-v1` retains a corrected test type-inference error.
`local-v2` retains an intermittent loopback disconnect before creation and a
secondary resumed-await-after-test-node-destruction error. It is not acceptance;
`local-v3` passed without further production changes and the reviewed pending
correction then passed `local-v4`. The underlying disconnect
and probe retirement remain open investigation items.

Independent review additionally reproduced the populated-to-not-ready indexing
failure in `native-skills-pending-review-repro-v1`: an expected failing diagnostic
with unchanged source and an array index error. The corrected view now retires
its old rows before accessing unavailable entries; the real held-arrow regression
above covers loss/restoration rather than merely hiding that diagnostic.

Next: original CG_FEATS and the class-dependent Domain/School/Spells/Associate
continuation, then remaining source creation children, safe saving and original
visual/input review. Keep the full UI objective active.

Before this follow-up: verified checkpoint
`backups/native-server-skill-rules-before-v1.zip`,2,429 files, SHA256
`c599c9f9f9993d95aa626c51d78070c78a1a66d685d5f4428898c84b2d79dc1c`.

Verified implementation checkpoint:
`backups/native-server-skill-rules-bound-v1.zip`,2,432 files, SHA256
`9eafbfe667b00ba4a59193b83df94ba13b903bb0b6843d47d2532c1a740dd18e`.
The earlier [allocation acceptance receipt](reports/native-server-skill-rules-bound-v1.acceptance.json)
records the then-current production hashes and four headless receipts, pins both
original corpora and verifies that archive. At that checkpoint source Skills,
complete
level-up/UI, graphical and authoritative level-up acceptance remain false.

Before the source-screen changes: verified checkpoint
`backups/native-creation-skills-screen-before-v1.zip`,2,432 files, SHA256
`3f0fed3d21f7f1a09d95159143b52dca139c71da6fcbb9fd71156a134b300057`.

Verified reviewed source-screen checkpoint:
`backups/native-creation-skills-screen-bound-v1.zip`,2,436 files, SHA256
`6f33582ddeff092181d5899b1c24979b65b0b75b35033f44165032c18c7b7a91`.
The [source binding acceptance ledger](reports/native-creation-skills-screen-bound-v1.acceptance.json)
matches16 relevant current production files to all four final headless receipts,
the final localhost receipt and the archive, and pins the original binary and
three immutable corpora. Full source creator, level-up, graphical, safe-saving,
whole-UI and goal-completion gates explicitly remain false.
