# Native creation: class-dependent continuation and School

The staged original-resource creator now routes its post-Feats continuation
from the active class data and implements the original `CG_SCHOOL` child.
The shipping fifteen-page creator, complete original creation chain, level-up
adapter, original-pixel comparison and authoritative character-upload acceptance
remain separate gates. This milestone is a first-level draft integration.

## Data and lifecycle owners

`systems/native_data/creation_post_feats.gd` implements original9c69a0's cursor:
Domains, School, restricted spell selection, then Associate. It reads physical
active class metadata (`PickDomains`, `PickSchool`, `SpellbookRestricted`,
`SkipSpellSelection`, `MinAssociateLevel`, `Arcane`). Missing conditional loader
values remain unavailable and do not consume a stage. This is neither a class
name whitelist nor a second world store. [Domain controls](NATIVE-CREATION-DOMAINS.md)
now have a separate first-level input/draft milestone. Spells/Associate controls
remain explicit unported-child requests; routing to them is not acceptance.

`native_creation.gd` owns the draft and cursor. Its frontend owns child tickets,
callback transfer and the actual source controls. Original `CGuiPanel::Deactivate`
delivers the parent callback while handing it to the next child. Accordingly,
Feats800e marks Package complete behind an active School child; SchoolCancel3
reverses that progress. School800f does not invent another Package800e callback.
Missing metadata leaves an explicit pending continuation instead of guessing.

`creation_school_state.gd` supplies nine physical school choices and their help
from the connection's `spellschools.2da`. The fixed General-through-Transmutation
source button surface comes from the original program. Names/descriptions are
active TLK/2DA data. Initial General0 is highlighted without its selection-help
callback, so introductory title/body381 remain until input or Recommended.
Recommended reads the current first-level package's School value. Later-class
package selection and level-up are not bound by this first-level adapter.

`native_school_chooser.gd` and `creation_school_layout.gd` prepare installed
`cg_school`, the shared source frame and help geometry through the existing
native resource owners. They retain nine tabs, Recommended/OK/Cancel, Escape,
scaled hit geometry and held-input retirement. A text-only reticket refreshes
active help while preserving the uncommitted candidate. Retired drafts cannot
commit.

School OK follows the observed original order: clear memorized spells, clear
known spells, recompute slot counts using the **old** school, then write the new
school byte and route800f. `creation_feat_snapshot.gd::school_slot_reset` composes
the existing original-backed spell-gain getter. `creation_rules.gd` owns the
resulting ten-level slot cache and clears its provenance on derived reset.
Unavailable capacity stays pending. This does not claim complete original
spell-cache or level-up behavior. Cancel clears derived choices and the cursor;
it does not invent a reset of the already committed school.

No per-frame world scan or full entity copy is added. School projection is
bounded to nine entries and ten spell-level counts at the existing draft
boundaries. The Feats cache regression still passes; its earlier steady-read
measurements do not establish live School or whole-client FPS.

## Evidence and accepted checks

The immutable original client SHA256 is
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.
`reports/native-creation-school-static-v1.json` preserves the original procedure
excerpts, parent callback timing and conditional class loader. Executed corpora:

- `native-creation-post-feats-original-v1.json`:3,876 complete coordinator and
  class-level getter cases, with explicit GUI allocation/activation boundaries.
- `native-creation-school-original-v1.json`:84 callback cases including actual
  SelectTab/SetChecked and SetSchool instructions. GUI/table lookup, clear/reset
  services and the final coordinator are declared fixture boundaries.

Accepted native receipts under `reports/`:

- `native-creation-school-state-v3-receipt.json`:7,998 checks against both
  digest-pinned original corpora, metadata availability and slot-cache order.
- `native-creation-school-view-v2-receipt.json`:14 installed-source control,
  active help, Recommended, scaling, Escape and lifetime checks.
- `native-creation-school-binding-v2-receipt.json`:25 actual Gameplay/creator/
  frontend Package→Skills→Feats→School physical-input and draft outcome checks.
  A custom class0 with coherent physical table cells enables School, demonstrating
  data-driven routing independent of a built-in Wizard class number.
- `native-creation-feat-binding-post-school-v1-receipt.json`:17 actual Feats
  controls/lifetime regression checks with the updated parent callback timing.
- `native-creation-feat-adapter-post-school-v1-receipt.json`:515 adapter checks,
  including480 original CanChooseFeat cases after the slot-cache addition.

Every accepted run exited0 with clean engine/lifetime logs and unchanged
relevant copied inputs. Runs use isolated hidden headless projects and the pinned
existing runtime, no servers, GPU benchmarks, shared native rebuilds or user
process restarts. View/binding fixtures use controlled raster/font doubles, so
they establish geometry/input/state behavior, not original artwork pixels.
The earlier failed fixture copies and logs remain retained. No source interaction
fabricates a character upload.

Focused runners:

```powershell
./godot-client/tests/run-native-creation-school-state-tests.ps1 -Name unique-state-receipt
./godot-client/tests/run-native-creation-school-view-tests.ps1 -Name unique-view-receipt
./godot-client/tests/run-native-creation-school-binding-tests.ps1 -Name unique-binding-receipt
```

Use unique receipt names to preserve prior evidence. Runners require normal
Windows certificate-store access for a clean Godot log. The checkpoint receipt
`reports/native-creation-school-checkpoint-v1.json` identifies the verified
compressed accepted snapshot, per-file digests and dirty-before provenance.
That sealed snapshot is not a blanket acceptance of later shared-agent edits.
