# Staged source tail BIC patches

`systems/native_data/creation_tail_bic.gd` returns detached typed field patches; it never reads a catalog or changes a live draft. The shipping builder selects it only for a verified first-level `sourceTailChoices` transaction, rechecking its mode/context/accepted values. Generic creation keeps its existing path. Runtime acceptance is in `NATIVE-CREATION-TAIL-INTEGRATION.md`; standalone typed-helper evidence below retains its original scope.

`first_level(appearance_id,value,choice)` accepts the current physical outfit `{id,resRef}` and a private Appearance value with `head`, `phenotype`, four color BYTEs, `skinParts[19]`, `clothes` and `clothingResRef`. It emits the original807950 appearance fields. Root body fields use the **skin half** of the appearance block at+0x26, not the clothed preview's first19 parts. The18 root slots omit Robe. Unknown optional tail/wings DWORDs are listed in `unavailableFields`, never invented as0.

The exact native writer is `CResGFF::WriteFieldWORDandBYTE1401a3790`. It always writes a normal BYTE and `(x+label).left(16)` WORD. For values over255 the compatibility BYTE is0; it is not the low byte. It writes the extended WORD even for values under256. Both SaveStats and the actual first-level client807950 use this writer.

The first-level `Equip_ItemList` is one struct of type2 containing **only** `EquippedRes` of typeCResRef11. Original807950 receives that selected outfit reference from its caller. Embedding a complete UTI here would conflate the server's SaveItem format with the client creation format.

`private_outfit(document,value,choice)` is separate: a detached typed UTI appearance overlay for private preview/source preservation. It writes all19 actual armor parts and six material BYTE colors while retaining unrelated source fields, localized text, nested lists, binary data, exact unsigned64 words and existing per-part dye fields. It does not claim full native SaveItem serialization and must never become the first-level equipped BIC row.

`information(value)` accepts already-processed `firstName,lastName,description,deity,age,soundset`. It preserves whitespace and the existing CP1252 serialization contract. Missing age/soundset, unencodable text and names exceeding their accepted transaction limits remain unavailable. `merge_fields(base,patch)` copies the base and patch, preserving unrelated generic fields without mutating either source.

## Validation

- `scripts/inspect-native-tail-appearance-save.py` executes the complete unchanged WORDandBYTE function40 times and12 bounded appearance slices from each of807950 and model3 SaveItem46b760. The64 observations are in `reports/native-tail-appearance-save-original-v1.json`.
- Current194 checks pass clean under `.cache/creation-tail-bic/typed-tail-bic-v3/`:157 native GDScript checks plus37 assertions from an independent copied JavaScript parser reading the actual generated BIC/UTI bytes. Cases include head300, all19 parts over255, compatibility BYTE0, skin/actual distinction, six colors, reference-only equipment, CP1252/whitespace/negative age, soundset50001, mutation isolation and preservation of unrelated typed data.
- A real staged bug was retained in v1: Dictionary.merge without overwrite preserved old compatibility BYTE values in the private UTI overlay. v2 fixed the overwrite; v3 repeats acceptance against the current provider closure. None of these tests changes the shipping builder.

Fresh source dossiers: `native-creation-tail-save-owners-original-v1.json`, `native-creation-tail-client-item-save-original-v1.json`, `native-creation-tail-save-labels-original-v1.json` and `native-creation-tail-buffer-save-original-v1.json` in `reports/`. The bounded slice evidence does not prove complete original BIC byte parity, original GFF file-header behavior, creator completion, server admission, model rendering or audio.

## Non-P data dependency correction

Original8eb480 disables every P-specific control for other MODELTYPE values. Original97b080 still performs a single current-head resource check and ignores GENDER/RACE getter status, consuming their written default/empty strings. The staged provider therefore does not require a successful nonempty RACE or palette choices for disabled F/C controls. It preserves the source head normalization but publishes no head index or palette choices. New active-data44 checks and actual source-control10 checks are clean at `.cache/creation-tail-provider/tail-provider-nonp-v7/` and `.cache/creation-nonp-appearance/nonp-source-input-v1/`. The source10 case performs no repeated-input benchmark. Evidence is `reports/native-creation-nonp-head-check-original-v1.json`.

Production first-level creator/preview/audio/BIC and composed parsed-BIC acceptance is now documented in `NATIVE-CREATION-TAIL-INTEGRATION.md`. Server admission and existing-vault file-preserving customization remain unaccepted; mode1 is explicitly blocked from the first-level writer. No user client action, server/key use, GPU benchmark or native build was performed.
