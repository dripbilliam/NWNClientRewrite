# Original character-creation parent — native component

The original CG_MAIN source frame, completion/callback policy and scoped child
coordinator are implemented. The coordinator opens the native portrait pane,
validates its draft commit and returns to the original parent. **The live
client still uses its existing creator.** The actual owner/session now
[constructs and stages the source binding](NATIVE-CREATION-SUMMARY-BINDING.md),
but does not activate its presentation. The [shared fixed summary frame](NATIVE-CHARACTER-SUMMARY.md)
has scoped identity/ability/portrait data; remaining summary getters, source
children/helper actions and pixels/keyboard/scaling remain unfinished.
Customize remains disabled. This is progress toward complete UI parity, not an
alternate completed creator or permission to rebuild existing high-level BICs.

The user's heavier game remains running. All work in this milestone used static
binary analysis, isolated CPU instruction observations and native headless input.
No GPU benchmark, original game or public connection was started. Preserve this
constraint until the user says graphical testing can resume.

## What the original does

`8dbf60` constructs CCharacterGenerationPanel using CG_MAIN. Its GUI has14
resource controls including the root:11 buttons, TitleLabel and the gold bar.
The eight main choices are Gender, Race, Portrait, Class, Alignment, Abilities,
Package and Customize, with separate Play, Reset and Cancel. This is not the
existing prototype's flat15-page sidebar. `8ec740` imports those controls,
disables dependent choices and encourages Gender. Completion is separate from
availability and encouragement; it cannot be inferred from initialized draft
defaults.

The same initializer constructs a non-gameplay CPanelCharSheet at the original
CharacterSheet hook, initially page0. `88a0a0(mode0)` selects PNL_CHRSHT2,
CTL_CHRSHT_NOSIZ and tab5/6/7/8, with no in-game close button. Its source hook is
`(380,42)` in the normalized742x526 parent. The current in-game sheet's model,
three tabs and resizer are not an interchangeable replacement. This creation
summary frame is now shared with the production character picker; its creation
data projection and full acceptance remain open in the linked follow-up.

`8e9be0` handles returned child codes:

| Result | Parent behavior |
| --- | --- |
| `0x800d` Gender | Complete Gender, enable/encourage Race |
| `0x8017` special Gender result | Reopen an already completed Portrait, then the Gender result behavior |
| `0x800a` Race | Complete Race, invalidate downstream choices, enable/encourage Portrait |
| `0x8009` Portrait | Complete Portrait, enable Class or the original application-mode Customize route |
| `0x8004` Class | Complete Class, invalidate downstream choices, enable Alignment; use the original stock Paladin shortcut only when its active restrictions match |
| `0x8001` Alignment | Complete Alignment, invalidate downstream choices, enable Abilities |
| `0x8003` Abilities | Complete Abilities, invalidate downstream choices, enable Package |
| `0x8008` / `0x800e` Package | Complete Package, enable Customize |
| `0x8007` customization information | Complete Customize, enable Play |

The policy retains source behavior for default/ignored callbacks, code3,
summary-mask updates, encouraged-button ownership and reset. For example, an
enabled unfinished encouraged button can retain encouragement when a later
callback asks to encourage another button. Reset does not invent a new source
encouragement operation. The ignored callback is interpreted as signed32.

The class shortcut reads physical Paladin row6. `LoadClassInfo2a4a90` proves
that AlignRestrict is stored at stride-relative4a1 as BYTE, AlignRstrctType at4a2
as BYTE, and InvertRestrict at4a4 as INT. The callback checks21/3/0 and selected
class6 before assigning85/85 and completing Alignment. Native
`creation_main_state.paladin_rule_default` reads those **active** class fields,
including their original byte widths. It does not assume a class name, server,
campaign or stock restriction when those fields were replaced.

The later [live draft-reset follow-up](NATIVE-CREATION-DRAFT-RESET.md) executes
the complete original reset7edcc0 with documented lower providers and fixes
domain/derived-choice invalidation in the shipping owner. It also traces original
client/server class-file writes through real local admission/export. The new
parent's reset_derived command still needs binding to that owner when the parent
is integrated. The fixed summary's fourth tab is Spells (TLK5215), implemented
by original CCharPageSpells; it is not an in-game close or description tab.

Mode1 existing-character customization is a different route: original picker
`710130` imports an existing BIC and opens Portrait directly; portrait0x8009
opens Appearance, final0x8007 requests existing-character saving, and result2
cancels the whole customization flow. The new coordinator retains these routes
without enabling the unfinished BIC editor/save lifecycle.

Static dossiers: `reports/native-creation-parent-dossiers-v1.json`, pinned original
SHA256 `3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.
Source inspection: `native-creation-main-source-v3`, with CG_MAIN, CG_SEX,
CG_RACE and the creation-mode summary models. The first inspection guessed
CG_GENDER, which does not exist; its failed receipt is retained. V2 corrected
CG_SEX; V3 adds the summary variant models. These are CPU source observations,
not original-window or visual acceptance.

## Native responsibilities and integration contract

* `native_data/creation_main_layout.gd` parses the original frame, actions,
  gold bar, title and CharacterSheet hook.
* `native_data/creation_main_state.gd` owns only source completion/enabled/
  encouraged state and callback/helper-command order. It does not mutate a
  live creature, normalize a draft, save a character or send a packet.
* `native_creation_main_frame.gd` loads the original GUI/models on native asset
  workers and uses the common source painter. It retains its controls through
  child round trips, applies original caption colors and requests the original
  encouraged pose. `source_art_ready` excludes acceptance of the unfinished
  summary; it must not be advertised as full-creator readiness. Encouragement
  animation timing still needs graphical review.
* `native_creation_frontend.gd` owns exact draft/child tickets, parent and
  portrait visibility, centering and retirement. Configure/prewarm it from the
  **pregame** source painter/catalog. Dynamic portrait art/choices and class
  restrictions belong to the active draft/server catalog. Server resources do
  not replace the pregame GUI frame.

Begin a source parent with an exact draft scope, original-mode/query context and
the active physical class rows. `child_requested(tag,ticket)` routes non-portrait
panes to their eventual source owners. Only the matching ticket can return a
child code through `accept_child`; a source pane must commit its draft fields
before acknowledging success. Bind portrait choices through
`bind_portraits(scope,values,current,active_art,catalog,commit_callable)`.
The values come from the existing shared portrait policy. While active, a late
different-scope binding is refused. A new scope cannot silently reuse the
previous draft's portrait catalog.

The portrait commit callback must validate and write the real draft and return
success. A refused commit keeps the child open. If that callback reopens or
replaces the frontend—even with the same scope—the original child result is
retired. Cancel returns to Main without committing tentative portrait selection.
Mode1 follows its separate Appearance/save/cancel route.

`command_requested(operation,scope)` reports the original helper boundaries in
order, such as `reset_derived`, summary `refresh`, `retire_draft`,
`initialize_draft` and `finish`. Their labels are adapter contracts, not proof
that the original helper's internal draft work has already been ported. The
eventual `native_creation.gd` adapter must implement those effects from source,
including exact prerequisites/recommendation behavior and server admission.
The coordinator guards reentrant command batches so an earlier reset cannot
continue initializing a replacement draft. Play itself does not fabricate a
server acknowledgment or successful BIC save.

## Verification and remaining work

`inspect-native-creation-main-flow.py` runs unchanged8e9be0,8e6780 and8ef940
instructions in an isolated CPU emulator. GUI/string, rule/draft queries,
summary refresh, child opening and destruction are documented captured helper
boundaries. Its V2 corpus has292 callback cases plus4 reset cases, including
both original modes, enabled/completed/encouraged patterns, direct modified-
Paladin restriction cases and the valid no-creature Class branch. It does not
execute the original model renderer, child panes, derived-draft normalization,
storage or protocol admission.

`native-creation-main-state-v3` passes304 pinned release-headless checks against
that corpus and the active restriction-field policy. V1 passed270 against the
first smaller corpus; V2 passed303 with the expanded corpus/byte widths; V3 adds
unsigned-alias/signed32 equivalence for the ignored callback.

`native-creation-frontend-v4` passes30 release-headless checks. It loads actual
installed source GUI/MDLs/TLK through native services, uses actual native
`CreationRules.portraits` admission, and commits a selection into the real native
draft through actual Godot mouse input on a non-rendering viewport. It verifies
the original parent→portrait→parent round trip, tentative Cancel, every source
completion/dependency route, Play/Reset/Cancel routing, retained control identities,
mode1 portrait→Appearance/cancel, held input, late source replies, stale child
tickets, refused commits, same-scope reentrant callbacks and worker cleanup.
Non-portrait children return scoped test results; artwork is a non-rendering
double. This is not pixels, a complete original character sheet or live creator.
The unsigned callback normalization postdates V4 and is covered separately by
the current state V3 receipt.

Frontend V1 failed on a test type-inference parse error; V2 passed25 checks,
V3 passed29 and V4 adds late-source isolation. Passing receipts retain unchanged
source/runtime, no native/engine/lifetime errors and zero public connections.
Earlier failed receipts are not overwritten or accepted. Current native/original
server/editor sessions are preserved.

Next: implement the creation-mode summary and original remaining child panes;
connect the coordinator to the real creator's draft and helper operations;
verify input/keyboard/scroll/scale/font/UV/animation appearance after graphical
testing is allowed; validate new and customized BICs with the owned authoritative
local server. Keep existing-BIC preservation and server-selected tables intact.
Complete UI parity, lighting acceptance and the overall client goal remain open.

Verified checkpoint: `backups/native-creation-parent-v1.zip`,2,224 source files,
SHA256 `1325f88f153219abe30e6df3ea2a4fa92bdedf932e89061a222bf6b055760d65`.
It includes the new original-instruction capture script and prior related
transport/reference source. Reports/original corpora remain outside this source
archive. This receipt was appended after archive verification.
