# Native actor-name Gameplay acceptance

The current copied headless integration passed **122 checks**, with all **710 source/copy pins**, fixture bytes, the engine and six native outputs unchanged. [The acceptance receipt](reports/native-actor-name-gameplay-v1.json) links the exact accepted `native-actor-name-gameplay-v4` proof and producer hashes.

Eleven fixture scenarios execute actual NetworkWorld/identity/disclosure/text-event/delta owners before JSON transport, then actual Gameplay world publication, received queue and chat formatting with real TalkText selected fetch/parser and valid controlled TLK data. P stored names are independent of U party labels. Both coalescing directions preserve the packet's name snapshot. Cold references retain P-time override absence; captured CUSTOM survives later changes. Pending names can finish after newer P/deletion/redisclosure without retargeting. History, malformed metadata and reconnect fences remain strict. Known-empty native names keep the colon in both real chat painters.

No production code was edited by this task. Three rejected labels remain intact: a new-fixture type annotation, the restricted certificate-store environment, and a new-fixture typed-array assignment. Corrections changed no assertions.

This is functional integration evidence, not original-server or native-pixel acceptance. Unrelated inventory/desktop/barter/examine services are passive. The SessionWorld graph is parsed without starting a Session. Native history painting uses real text/scroll Controls; unrelated portrait attachments are excluded from that punctuation-only check. Unknown imported/BIC-controlled stored-name provenance remains an explicitly unproven adapter, as recorded in [the controlled-load audit](NATIVE-ACTOR-NAME-CONTROLLED-LOAD-AUDIT.md). No server, GPU, keys, profiles, native builds or user-process actions were involved.

