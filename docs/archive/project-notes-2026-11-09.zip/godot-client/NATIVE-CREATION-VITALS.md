# Original live creation HP and armor class

2026-11-01. The staged CG_MAIN summary now receives vitals from its actual
native first-level draft. It does not import the character picker's BIC or
replace the original-server character admission/save rules.

## Original evidence

The complete creation branch of Class OK `1408e36d0` clears the base-hit-die
cache at stats+84 only if the selected class changes. `SetClass1407f9820`
fills a zero cache using `1407f4df0`; reselecting an unchanged class preserves a
nonzero cached die. That getter includes the original physical class37 Dragon
feat precedence and active ruleset values, truncated to the consumed byte.
The native draft retains that cache through ordinary derived-choice resets and
clears it for a new draft. Previous chosen/granted feats are read before class
replacement/reset, matching the original Class OK ordering.

Class OK resets all six raw abilities and sets a caster's effective primary
score to `CHARGEN_BASE_ABILITY_MIN_PRIMARY`. It subtracts racial/class increases
even when the resulting raw score is below the ordinary initial minimum; it
does not use the earlier replacement's `max(0,delta)` shortcut. Ability/racial
bytes and the verified original class-gain policy now feed the same draft
scores used by the summary and existing first-level workflow.

`CON1407f96d0` updates first-level, zero-XP HP as max(1,cached die+signed CON
modifier). `DEX1407f9ba0` caches AC as10+signed-byte(DEX modifier+DEX adjustment).
The separate getter `1407f1ed0` is an active Expertise-mode bonus, not inventory
armor. New unbuffed creation drafts have no such active mode or temporary HP.
The summary provider now names this `armorModeBonus`; the older bounded-format
oracle's opaque `armorItems` name remains only a compatibility fixture input.
Missing active data, an uncommitted hit-die cache or invalid modifier rules keep
these fields unavailable. Source summary completion masks still control when
labels appear.

Reproducible CPU oracle: `../scripts/inspect-native-creation-vitals.py` executes
the unchanged Class OK, class/ability setters, class gains, starting-die and
HP/AC getters from the pinned original executable. Object lookup, GUI
deactivation/destruction, ruleset lookup, feat-array Contains, unarmed-cache
refresh and spell-slot refresh are explicit provider boundaries. Raw table/stat
fixtures are not a full original resource parser or creator workflow.

Corpus: `../backups/animations/native-creation-vitals-observations-v1.json`,
48 configurations and240 transitions, SHA-256
`0650c6924fe381bf544872f596a1905238964f2a0b6a2b901a1600fa6f803601`.
It covers active custom modifier/minimum/Dragon rules, byte wrapping, racial
and class gains, CON/DEX writes, unchanged-class reacceptance and class
replacement. Its arbitrary temporary-HP fixtures are not imported into the
unbuffed new-character model.

## Validation and remaining scope

- `native-creation-vitals-v2`:677 strict headless checks compare the actual
  CreationRules class/reset operations, raw/effective scores, hit-die cache,
  HP/AC and summary labels against that original instruction corpus.
- `native-creation-vitals-binding-v1`:80 strict headless checks exercise the
  actual creator/source-summary binding, including physical CON/DEX clicks,
  active text, portrait commit and cancel/reopen ownership.

Both retain unchanged source and no native/script/lifetime error, with zero
public connections. VitalsV1 is a rejected fixture receipt: every ability vector
was numerically equal but JSON-float arrays/dictionaries were compared against
integer containers without normalization. V2 converts the oracle's recorded
numeric types explicitly; all numerical assertions remain.

The later `native-creation-gender-local-v1` passes20 actual original-server
creation/admission/export/movement checks with this provider active, committed
source Gender and all28 exported skill ranks matching. Original source
children/CG_MAIN activation, details, preservation-safe existing
BIC customization/save and original pixels remain required. The shipping fifteen-page creator
still owns input while the original source parent remains staged. These checks
do not complete creation, lighting or the overall UI parity goal.
