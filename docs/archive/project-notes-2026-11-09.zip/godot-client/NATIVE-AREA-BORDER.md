# Native scenery outside the playable area

The replacement was missing the original `CNWCArea::LoadBorder` path. The
original loads `<tileset>_Edge.2da` and selects original models using the
boundary tiles' corner types, edge types, orientation and height. It places a
five-tile / 50-metre ring outside the main tile grid. It does not make those
positions walkable.

Exact original evidence, installed tables, source gates, rejected oracle
fixtures and comparison limits are in
[NATIVE-AREA-BORDER-RESEARCH.md](NATIVE-AREA-BORDER-RESEARCH.md). This is separate
from the existing sky/skyfade and fog systems.

## Native policy and resources

`native_data/area_border.gd` implements the four ordered native border passes,
including exterior corners, first matching physical 2DA row, swapped-corner
orientation, original height conversion, native model reference truncation,
tile centres and Godot coordinate conversion. There is no generated filler
model. Missing tables or unmatched rows produce no invented scenery.

The global native setting `graphics.tile-borders.enabled` / `Enable TileBorder`
defaults to on. The server area's separate DWORD `+10c` disables borders.
Its ARE key is **`TileBrdrDisabled`**, with that original spelling. Current raw
network packets preserve it as `area.fields["10c"]`. The adapter accepts the
actual JSON numeric BOOL 0/1 as well as typed bools. Missing or malformed fields
remain unavailable; they do not become zero or an inferred Interior flag.

Options → Graphics → **Show scenery beyond area edges** persists the user
setting. It applies to the next area. Dynamic hot rebuilding on a changed
server flag is not claimed by this implementation or the retained native
caller evidence.

## Streaming and lifetime

`native_render/live_world.gd` starts the optional owner only after
`ready_for_control()`: the base tiles, movement surface and controlled
character are already admitted. Off, server-disabled or unknown area gates
skip decorative work. Borders do not participate in gameplay readiness.

`native_render/area_border_loader.gd` reads the original optional edge table and
prepares plans on a private worker/catalog fork. It borrows the accepted,
immutable terrain definition. It does not copy or alter the gameplay grid.

`native_render/area_border_stream.gd` uses the existing native AssetService and
shared resource pool/model templates. It prioritizes nearby placements and
bounds publication attempts, including failed attempts. Only private scenery
instances are created. No gameplay object IDs, selection bodies, walkmesh or
collision registry are added. This is an asynchronous adaptation of the native
loading order; the original's synchronous scene-collapse optimization is not
newly reproduced here.

The private render scope is `[World instance nonce, generation, area ID]`;
the nonce is not a network connection or an entity reference. Old results
cannot publish into a different World. Loader/asset tasks participate in
existing retirement joins, pure prepared data goes to existing deferred
disposal, and scene resources retire within the remaining frame budget.
The shared pool stays with its existing owner. Optional failures are reported
under `world.area_border` without revoking player control. Detailed profiling
attributes stream and planning-poll CPU work to `callback_area_border`.

## Verification limits

The pure plan matches the original x64 routine in the retained installed-table
scenarios; native GDScript equality checks are separate. Streaming checks use
actual installed edge-table/model decoding plus controlled native model
publication to verify ordering, budgets and lifetime behavior. Settings checks
exercise real controls and isolated persistence.

The subsequent [real model geometry gate](NATIVE-AREA-BORDER-GEOMETRY-ADDENDUM.md)
also instantiates original forest models through the production pool/templates
and checks vertices, bounds, sharing and retirement. It passes992 checks with
no production changes. Its publication duration is a soft budget; the result
does not assert a hard2ms or FPS bound.

These are headless functional/data checks. Live appearance, culling costs and
GPU performance still require a graphical comparison. No public-server world
connection or chat send was made to validate this feature. The broader
[overhead chat and area-edge goal](OVERHEAD-CHAT-AND-AREA-EDGES-GOAL.md) remains
active until its visual acceptance is recorded.

The subsequent [scenery completion audit](NATIVE-AREA-SCENERY-COMPLETION-AUDIT.md)
found a separate atmosphere publication bug: the live root sent time/area fields
only when entering an area. `publish_area_environment` now forwards changed
accepted same-area headers to the existing atmosphere owner too. Unchanged
headers do not reset interpolation, a new received phase starts from its
transition milliseconds, and field/duration-only changes carry current elapsed
time. World/area/generation/connection/environment retirement guards remain.

Its35 isolated actual Root/Session checks pass. A later original-local-server run
also accepts the real fixed-day header and advances without repeated resets;
that server run does not exercise a phase change or sky geometry. The exterior
geometry's97 original inputs still match unchanged. These scopes are recorded
separately in [checkpoint v4](reports/native-overhead-native-methods-checkpoint-v4.json).
