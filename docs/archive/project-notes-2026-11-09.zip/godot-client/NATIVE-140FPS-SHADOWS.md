# Static terrain shadow-batching experiment

Status: private, not promoted. The complete recorded room did not show a useful
frame-rate gain at its existing one-light shadow budget.

The prototype is [static_shadow_proxy.gd](tools/perf140/shadows/static_shadow_proxy.gd).
Only AreaStream's immutable direct terrain placements are eligible. It builds
one depth-only mesh per tile model/light-layer group from retained CPU geometry;
original normal meshes, materials, picking resources, collisions and lights stay
intact. Opaque, undeformed, single-surface casters with valid finite transforms
are admitted. Unproven materials, alpha, skin, mirrors, ranges and changed
provenance fall back atomically. The cache lasts only for the area scope.

The 42 structural checks pass. A separate real ResourcePool → ModelInstance →
Template pipeline fixture passes 364 checks across compact/separate layouts,
native/standard materials and prepared/authored normals. Baked positions and
indices match; encoded-normal error is at most 0.0000441. It checks clone
resource/picking identity, changed provenance and retirement. Receipts:

- `.cache/native-140fps/root/shadow-unit-v3/receipt.json`
- `.cache/native-140fps/loading-agent/shadow-pipeline-v3/receipt.json`

The frozen `shadow-area-v2` runs the same generation-2 capture, actual camera,
3440×1369 viewport, secondary screen, MSAA2, lighting, particles and normal
content as `particles-cold-monitor-v2`. Detailed profiling is off. Both runs
complete delivery and normal shutdown with unchanged source/runtime guards.

| 30-second receipt | Mean ms | FPS | Draws | Triangles |
| --- | ---: | ---: | ---: | ---: |
| `native-perf140-cold-monitor-a2` | 18.683 | 53.52 | 5,968 | 353,308 |
| `native-perf140-shadow-area-b1` | 18.610 | 53.73 | 5,689 | 356,872 |

The candidate converts 1,557 original casters into 164 proxy groups across 164
tile placements; 61 placements keep their original path. Total preparation is
44 ms, peak unique-plan preparation 2.58 ms, install 19 ms. Coarser shadow
culling increases submitted triangles, despite fewer draws. The two shutdown
screenshots were inspected and show the same scene; this is not multi-angle
pixel/animation parity. CPU transform association and shadow seams remain
limitations requiring additional visual validation if this path is revived.

The native binary uses stencil-volume shadows, so this prototype does not claim
to reproduce its algorithm. It tests Godot submission overhead while preserving
the visible geometry. No main scene files or shared native output were changed.
