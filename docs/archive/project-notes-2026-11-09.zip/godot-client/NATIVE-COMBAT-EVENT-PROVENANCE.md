# Installed combat event provenance

The duplicate `blur_start`, `hit` and `blur_end` entries observed in the owned [combat run](reports/native-combat-presentation-local-v2.json) are authored in the original installed model. They are not evidence that two private model owners emitted the same callback incorrectly. No production deduplication or parser/rig change was made.

The native diagnostic mounts the original installed catalog, resolves `pme0:nwreach`, `pmh0:nwreach` and `pmh0:1hslashr` through the existing native inheritance pipeline, then independently reads the physical MDL animation/event offsets. Every inherited event's name, timestamp, order and multiplicity equals the physical bytes. All three resolve to `a_ba`, SHA256 `a38c9f0de00a7e401419d1e668ad1b9d825cfc9635712cdb9ae63e840104ee2b`.

`nwreach` physically has two `blur_start` entries at0.400000005960464, and two `hit`/`blur_end` pairs at0.5. `1hslashr` likewise has two `blur_start`, two `hit` and two `blur_end` entries. The diagnostic preserves these arrays. Actual `ModelRigs` event dispatch over two authored empty-pose following parts produces both parts' model events, but only one selected `animationSource` forwards actor events. Its actor sequence equals one full physical event array, including the authored duplicates.

[Native receipt](reports/native-combat-installed-events-v1-receipt.json):19 checks, clean exit/engine,66 pinned static inputs unchanged, no game connection/GPU/native build. The exact result is retained under the receipt's copied evidence directory. The two-part rig isolates event ownership; it does not reproduce the full live model graph, pose or original pixels.

[Original CPU proof](reports/native-combat-installed-events-original-v1.json) executes complete original `AnimateEvents14004fce0` and `Gob::DoEvent140050d50` over those three exact physical arrays. The original forwards every physical entry in order to the explicitly registered wildcard listeners, including repeated names/timestamps; active dispatch handles retire correctly. Allocation, ASCII comparison and explicit test listeners are captured boundaries. This does not claim original loader/clock/combat-callback/audio/renderer execution or establish full effect parity.

The original CPU harness and native diagnostic are new read-only research/tests. Existing production files and the separate combat checkpoints remain unchanged. Event multiplicity must remain intact unless a later specific consumer's original behavior proves an additional gate.
