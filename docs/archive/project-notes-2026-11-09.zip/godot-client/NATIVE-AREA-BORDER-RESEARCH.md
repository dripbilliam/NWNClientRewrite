# Original area-border scenery

Current native AreaDefinition/AreaStream loads only the ARE's width×height
tiles. Original CNWCArea.LoadBorder1407dea10 additionally loads the active
`<tileset>_Edge.2da` and places selected original models in a five-tile,
50-metre exterior ring. Sky, horizon and fog already have separate native
owners; they do not replace this missing geometry.

`systems/native_data/area_border.gd` produces private value plans and is now
integrated through the optional native border stream. Source dossier:
`reports/native-area-border-source-v1.json`, pinned
nwmain SHA2563b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a.

The user setting is `graphics.tile-borders.enabled`, default true; legacy
label `Enable TileBorder`. Native LoadArea calls LoadBorder only when enabled
and area DWORD+10c is0. Exact ARE field `TileBrdrDisabled` is BYTEasBOOL with
prior-field default; modern received area retains `fields["10c"]`. No inferred
Interior/SkyBox gate. Flag setters do not directly rebuild. Construction is
proven at area load; dynamic hot application remains unaccepted.

The table uses physical rows and Corner1,Edge,Corner2,Height,Model columns.
Matching tries each row's direct pair then reversed pair, case-insensitively,
and takes the first match. Missing `****` strings are empty. Missing table
skips borders; an unmatched row has no model and cannot acquire filler.
Resource adapters must distinguish pending from completed known absence.

| Pass | Source corners | Source edge | Direct/reversed orientation |
|---|---|---|---|
| Left |3,2|3|0,2|
| Right |0,1|1|0,2|
| Bottom |2,1|2|1,3|
| Top |3,0|0|1,3|

Corner indices: TopRight,BottomRight,BottomLeft,TopLeft. Edge indices:
Top,Right,Bottom,Left. Getters add authored tile orientation and mask3.
Left/right include four corner extensions; bottom/top cover authored width.
Native position `(10*x+5,10*y+5,height)` uses
`height=(boundary Tile_Height+table Height)*Transition`. SET corner heights
are not added. One conversion gives Godot Vector3(x,z,-y). SpawnTile receives
orientation,flag1,null quaternion; native static/BSP processing is separate.

Nine unchanged-x64 scenarios over four installed SET/Edge tables produce1,120
SpawnTile attempts. JS reference passes4,430 checks; copied native GDScript
passes7,826 checks, strict clean engine/exit0, seven unchanged source/copy
pins. See `reports/native-area-border-original-v2.json` and
`.cache/area-border/native-area-border-v2/proof.json`. Both left/right
extensions cover all four orientations across scenes. Negative heights are
exercised on left/bottom; a separate right-negative case is not in this set.

Retained rejections: first oracle's overlapping fixture memory, corrected
candidate right-corner mapping, first GDScript run's sandbox root-certificate
error, and initially misaligned disassembly windows. Original bytes and
assertions remain unchanged.

The pure-plan receipts above do not establish stream/publication lifecycle or
installed-art pixels. Subsequent native World, settings and stream checks,
including actual installed model decoding, are documented separately in
`NATIVE-AREA-BORDER.md` and `reports/native-area-border-stream-v1.json`.
No graphical/GPU acceptance is claimed. This research did not use a server,
key, user-process action, visible launch or native build.
