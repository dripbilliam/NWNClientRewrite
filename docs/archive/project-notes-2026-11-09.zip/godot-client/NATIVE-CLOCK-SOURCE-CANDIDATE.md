# Private direct-Real clock-source candidate

The isolated candidate compiled cleanly and passed663 headless checks:105 authored source-formula cases, metadata/error contracts and four actual Win32 samples. This accepts the private ABI/source candidate only. Original-instruction differential equality and the native default cached-thread phase remain pending. No production import, default switch or main-project clock descriptor was installed.

All files are under `.cache/native-clock-source-candidate-v1`. The static `NwnClockSourceCandidate.sample()` returns explicit `ready` plus unsigned microseconds as exact `{hi,lo}` DWORD limbs. Its live PreparedConfiguration caches QPF result/frequency, branch, divisor and constructor MXCSR once; sample performs no divisor recomputation, calibration or origin subtraction. QPC failure returns unavailable, never an invented tick fallback. Frequency/QPC/TickCount metadata has explicit availability flags and null values where not measured. `convert_for_test` performs a labeled authored constructor+Real pair without Win32 queries.

Observed direct source: QPF result1,10MHz frequency, `qpc-f64` branch, cached binary64 divisor bits `4024000000000000` (10.0), constructor/current MXCSR `1f80`. These are four direct WinAPI samples, not evidence of native cached-thread timing or whole-client behavior.

Accepted artifacts:

| Artifact | SHA256 |
| --- | --- |
| `builds/build-v1/bin/nwn-clock-source.dll` | `497e483e44595a7518b860f92c55e3ab3cef9cd372b15c53a2ac31dfd2498190` |
| `manifest.json` | `779aab6051a30eb949517630344efdd9e4f58352cc192aeaa33b968109156f6f` |
| `builds/build-v1/build-manifest.json` | `23a0e24994c71a7cef4ff12994dd78f6826c63ff2ce52d6468e54b4509d973d6` |
| `runs/clock-source-headless-v1/proof.json` | `831d4323f2aa8b263200ee12b7dba9be2d9c840ca1fd66567bf45c7c62326e1f` |
| `runs/clock-source-headless-v1/result.json` | `46c4d05db8605a1b926cc563453cfb49b1ef0755c65d6ce7b81ecc1c21773859` |

File-only finalization verified all7 frozen candidate source/manifest files,11 reviewed inputs plus8 guards (both engines and six shared native outputs), six private build files and six private run files against their accepted hashes. Build/source/header/DLL/probe/case copies read back exactly; build and run receipts match the same manifest. Accepted receipts record owned compiler60232 and engine21868 closed. No new compiler/engine or user-process action occurred during finalization.

Existing immutable source/header inputs in `builds/build-v1/inputs` and probe/case/DLL inputs in `runs/clock-source-headless-v1/project` are the backups. No extra binary/profile/key copy is needed. The descriptor exists only in that private run project.

Bounded receipt: `reports/native-clock-source-candidate-v1.json`. Native source references are pinned to original SHA256 `3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`: constructor14016dd60 (`ev_efd8a516…`) and direct getter14016e110 (`ev_9d9f5e82…`). Those read-only dossiers support the formula; they do not replace the separately pending opcode oracle.

The UI agent has the accepted DLL/API/hash handoff for a separately approved private provider→Timer gate. That handoff grants no runtime lane or production installation. No FPS, pixel, network, server, gameplay or complete clock-lifecycle claim follows from these checks.
