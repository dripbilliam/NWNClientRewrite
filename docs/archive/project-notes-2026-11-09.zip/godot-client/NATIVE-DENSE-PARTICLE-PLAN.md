# Dense native particles: next performance work

2026-11-04. Read-only source/evidence investigation. No implementation or measured
speedup is accepted here. Client 47096 and launcher 61760 were reported live by
Root and were left untouched. This investigation ran no tests, engine, sockets,
servers, builds, process controls, or new original-binary executions. Only this
NEW document and the `reports/native-dense-particle-plan-*` report are authored.

## Measured scope

The retained [frame findings](reports/native-manual-1793848496660-frame-findings-v1.json)
and [captured analysis](reports/native-manual-1793848496660-frame-analysis-v2.json)
describe a completed 240-frame steady window: wall mean **27.8592 ms**, p95
**34.78 ms**; disjoint `callback_particles` mean **5.992242 ms**, p95 **6.33 ms**.
That callback wraps shared-owner input preparation, native simulation/publication,
and submission. There is no exported exclusive simulation/pose/upload breakdown
for this window. Its approximately 35 FPS does not establish a stable rate.

The exact captured counters must remain distinct:

| Counter owner | Captured values |
| --- | --- |
| World particle metrics | 2,090 emitters; 120 failures; 1,484 simulated; 5,283 active; 31,668 vertices |
| Native presentation | 1,970 registered; 1,857 prepared; 435 culled; 4,892 active; 29,322 vertices; 703,728 bytes; 123 ranges |
| Native renderer | `native_surface_output=true`, `batch_ranges=true`; **80 actual last draws**, 29,322 last vertices; pending 0 |

The task also cites about 99 batches in another observation. The pinned analysis
above contains 80 last draws, not 99. Neither number is an emitter count or a
MultiMesh count. Particle metrics retain their own cumulative/current semantics;
their totals must not be forced to equal presentation counters or asynchronous
renderer observations. In particular, `simulated` is not the native prepared
count for this frame.

**The observed path has zero scene batches.** `native_surface_output` bypasses
the pooled engine-lit MultiMeshes and uses the native shared vertex stream.
Optimizing `particle_scene_batches.gd` first would target a different path.

The findings also report light-history 4.113 ms, root 2.373 ms, world 1.960 ms,
and rigs 1.285 ms. Particle work is the largest measured disjoint owner, but its
improvement alone cannot establish whole-frame 60 FPS. Render-CPU, postdraw wall,
and callback spans are not additive GPU measurements. This plan makes no claim
about exclusive driver, GPU, or original-client timing.

## Actual frame and ownership boundary

1. `particle_stream_group.gd:144-178` drains deferred membership/control changes,
   gets the current camera/fog/collision owners, obtains a late light packet for
   the native color carrier, calls presentation operation 1, and submits the
   completed packet. Renderer operation 2 then checks failure and exports stats.
   `_process` supplies the measured `callback_particles` span. Native mode runs
   at priority 110, after the light owner at 100.
2. `native/particle_presentation.hpp:149-175` walks the explicit registered order.
   Every enabled entry checks actual SceneTree visibility/process eligibility;
   a fast entry validates its source, probes pending chunk readiness, advances
   its channel clock, and calls `Step.advance`. Ready chunks discard their
   script readiness callback, so this is not an existing steady callback per
   ready emitter. Custom owners retain synchronous fallback dispatch.
3. `Step.advance`, lines 27-60, samples controllers **before** admission, applies
   patches/detonation, reads pose/source transforms, resolves wind/admission, and
   invokes the compact native simulator when admitted and animation-eligible.
   Culled emitters retain the established clock/state/RNG behavior.
4. Lines 176-200 separately sort active owners with the original-derived sort,
   count active geometry, allocate a fresh packed stream/Packet and ranges,
   sample native particle tint, and write geometry directly into active slices.
   No per-particle Godot Dictionary conversion or shared-path capacity-tail
   clearing occurs. Geometry can update atlas fields; it is not a pure memcpy.
5. Lines 201-205 make another registered-order pass and publish 15-field fixed
   counter records. The GDScript `members` dictionary is primarily lifecycle
   ownership; the shared hot loop is native, not a GD scan of every emitter.
6. `native/particle_stream_render.hpp:42-46,105-130` retains immutable packets
   across RenderingServer callbacks. GPU capacity grows geometrically; uploads
   cover the active byte prefix. Draws already merge **consecutive contiguous**
   equal sampler/pipeline ranges. Pipeline/uniform resources are cached.

`focus_lighting.gd:203-224` is an additional input cost *inside* the particle
callback: it duplicates the area packet, walks the current admitted light list,
reads actual lamp transforms/properties/fades, and allocates light DTO rows.
`emitter_lighting.hpp:7-14` imports them into a fresh native Snapshot. This is
separate from the measured light-history callback, though both use its results.
Do not transfer time between those owners without new disjoint measurements.

## Existing optimizations that a candidate must preserve

| Existing mechanism | Why further work can still be useful |
| --- | --- |
| Private compact emitter/particle pools and fused native arithmetic | Entry bookkeeping, engine pose conversion, controller writes, packet allocations, sorting and rendering still occur around that arithmetic. Re-porting the math to C++ would repeat completed work. |
| Cached single-row non-Bezier controller values and stable destination bindings (`particle_resident.hpp:234-268,334-350`) | Each sample still copies the cached private value into parameters/state and reapplies its typed field. This includes required byte/pulse writes. |
| One camera packet; native camera decode cached by stamp (`particle_bounds.gd:60-85`, resident lines 277-282) | Source and emitter transforms still resolve/read/orthonormalize/convert per prepared entry. `sourceId==poseId` already avoids the duplicate source read. |
| Direct active-only frame slices and geometric GPU capacity | A new CPU packed array, Packet and temporary vectors are still constructed per simulation frame. The old fallback ArrayMesh tail-clear cost is not this shared-path cost. |
| Immutable canonical packet and visibility-only refresh (presentation lines 208-239) | Refresh already reuses geometry/vertex generation without advancing simulation. Ordinary completed frames still create a new packet and vertex generation. |
| Adjacent draw merging, cached pipeline/uniform objects | More material sorting would change native painter order. Remaining work is repeated descriptor preparation/binding lookup, not an unimplemented universal batcher. |
| Fixed native diagnostic counters | End-of-frame code still visits every native entry and recomputes/stores records even for entries that did not change. |
| Pooled scene surfaces keyed by material occurrence | Useful for the alternate engine-lit path, but this captured native-color path never calls `SceneBatches.consume`. |

## Proposed order of changes

Each item is a separate reviewable candidate with an independent rollback and
source receipt. These are proposed hooks, not edits made by this audit.

### 1. Remove repeated membership and scratch work, keep the native work order

Start in `particle_presentation.hpp` only. Retain an ordered `Entry*` view of the
existing uniquely owned entries, rebuilding it at `add`, `erase`, `set_order`
and close boundaries. Reuse owner-private drawing/scene-index/count scratch
vector capacities rather than reconstructing them every frame. `running`
already forbids native registration/removal/order mutation; the GD wrapper
defers reentrant membership operations. Do not retain a pointer after its
entry is erased, and do not use hash iteration as scene order.

Keep a small ordered dirty-counter list and flush at the **existing end-of-frame
boundary**. Entries whose native state/channel/culling counters did not change
need not republish identical 15-field records. Revalidate counter membership at
flush: a chunk callback can retire its counter record before deferred removal.
Maintain immediate lifecycle removal accounting and all diagnostic semantics.
An explicitly disabled entry can be excluded from the work view only if its
ordinal and exact re-enable position are retained. Visibility/process changes
must continue to use actual eligibility; zero active particles is not inactivity.

This removes bookkeeping, not effects. Its speed contribution is unmeasured.

### 2. Reuse pose conversion, then optimize static controller application

First add a private per-endpoint cache near `read_engine_pose`/`Step.advance`.
Every use must still resolve and validate the real Node3D ID and read its actual
global transform. Reuse derived quaternion/scale/maximum-scale **only when all
12 transform words match** the retained input. This saves repeated conversion
for static endpoints without assuming they cannot move. A same-frame callback,
reparent, animation change or freed source must invalidate naturally through the
actual read. Do not use only frame number, model name, or a presumed static flag.
Do not share across owners through an unsafe cache of borrowed Node pointers.

Next, compile constant-channel typed assignments at configure/clip selection.
The current cache already skips interpolation; the new opportunity is avoiding
repeated private Var copying/type lookup for unchanged numeric destinations.
Keep per-sample writes for fields consumed/reset by simulation (especially
`detonate`), and reapply fields dirtied by a runtime patch at the next sample.
Preserve original channel order, parameter observations, byte reinterpretation,
negative-zero/f32 words, invalid-clock checks and lazy malformed-storage timing.
One-row Bezier channels remain sampled. A general “sample once” flag is wrong.

These two changes should be separate so a rejected channel shortcut cannot
invalidate an independently correct pose-conversion improvement.

### 3. Reuse publication allocations without mutating an in-flight frame

Retain Packet/range scratch capacity and consider recycling packed byte storage
only after its **last** canonical, queued, ready-renderer and inspection owner
releases it. The current explicit immutable ownership is mandatory. If storage
is still retained, allocate another owned packet as today; do not block, drop an
effect/frame, reuse an aliased PackedByteArray wrapper, or assume three buffers
are sufficient. Measure outstanding packets and retained capacity.

Keep geometry side effects and active-byte upload semantics. Do not skip a
geometry call just because particle positions look unchanged: camera-facing
modes, light/fog/opacity, atlas `frame44/field48`, splats and chunk callbacks can
change. Reuse vertex generation only for a proved identical publication, as the
existing visibility-refresh path already does. Existing capacity-tail removal
is not a new optimization to claim.

A lower-risk subchange is caching fog-buffer contents independently of packet
generation: compare all eight float words, upload when changed, and invalidate
on GPU resource recreation. Current renderer uploads the same 32 fog bytes for
each new packet generation. This is a small exact change, not a predicted large
gain. Shader/color, lighting and collision defaults remain identical.

### 4. Reuse draw preparation; do not broaden material batching

In `particle_stream_render.hpp`, prepare a compact ordered list of the same
contiguous runs once for each packet/material/renderer-resource generation.
Reuse it for repeated view draws of that packet; retain per-view matrices,
framebuffer/MSAA handling and actual GPU resource lifetime checks. Cold pipeline
and texture creation must still happen before a draw list opens. Existing
sampler/pipeline boundary and hidden-gap rules remain byte-equivalent.

This can remove redundant range traversal and hash lookups; it need not reduce
the already-batched draw count. Joining non-adjacent textures, regrouping by
material, replacing the native partial comparator with `std::sort`, or changing
alpha/depth behavior is outside this proposal. Roughly 80-99 draws does not
justify claiming all 7,385 scene draws are particles.

### 5. Coordinate the late lighting-input cache with its actual owner

Only after measuring input import, consider an immutable typed light snapshot
published after the actual priority-100 history/fade/update boundary and borrowed
by priority-110 particles. Root must coordinate the `focus_lighting.gd` owner and
native presentation hook. Preserve physical order, duplicate contributions if
present, area fades, no particle exclusion list, attached lamps, current source
positions and all invalidation/removal boundaries. A constant lamp count or
registry membership revision is insufficient: animated color/radius/position,
fade and area values can change without membership changes.

The smallest first step is retaining native Snapshot vector capacity; it does
not by itself remove the GD packet rebuild. Avoid a second lamp registry or a
whole-world invalidation scan. Do not bypass native CPU tint, scene wind,
collision, or original light history to obtain a faster number.

## Changes explicitly deferred

- No blanket return for empty Explosion/Fountain/Single pools. Even empty native
  Animate updates transform history/basis, explosion latch/detonation or spatial
  debt; controllers can enable births later. Any kind-specific algebraic fast
  path needs a complete exact state/provider/RNG comparison before adoption.
- No lower particle count, lifetime, resolution, draw distance, collision/wind,
  light maximum, quality, missing-resource suppression or reduced animation rate.
- No GPU simulation switch, new rendering architecture or worker-thread native
  simulation; shared RNG, mutable providers, chunks and order need separate proof.
- No live-client instrumentation, loaded-library replacement or competing
  benchmark while the current client remains open.

## Required evidence and future checks

The pinned original is NWN:EE 89.8193.37-17 `nwmain.exe`, SHA-256
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.
This audit read retained evidence, not an original process:

- `NATIVE-RADIAL-PARTICLE-GOAL.md:1465-1527` and
  `reports/native-particle-native-chain-research-v2.json`: Scene bucket admission,
  separate ordered simulation/draw, direct typed records, shared reusable stream.
- `backups/animations/native-emitter-bucket-v1.json`: 384 controlled original
  instruction cases, SHA `6aa48a21bf15e89cd7f5be588d9cfd4937d260d022e660251e1c138c2e2bba01`.
  Original Scene::DoEmitterBucket `1400c7ae0`, Animate `140061210`, comparator
  `1400c91f0`, sort `1400c0580`. Lower update/render providers are explicit bounds.
- Original `RenderEmitter140062900`, shared stream/lock/commit and driver draw
  chain: `backups/animations/native-particle-draw-v1.json`, 130 cases, SHA
  `7a5427b43e27a43bd998710508390fe3225a4b2193068e426b3975726df66739`.
  Initial capacity 1,024 with geometric growth; active-byte warm commits are
  source-backed, not persistent GPU mapping.
- `evidence/particle-emitter-runtime.md`, `NATIVE-COMPILED-PARTICLES.md` and
  `NATIVE-PARTICLE-ADMISSION.md`: original lifetime, per-kind scheduling, packed
  vertices, controller-before-radius, strict admission/fade/delta and RNG rules.
- `NATIVE-LIGHTING-CORRECTION.md:444-480`: existing adjacent-range batching,
  exact-pixel boundary tests and sparse 1,506-effect ABBA result. That historical
  sparse improvement is not a prediction for the current dense room.

Future checks (none run for this plan):

1. Expose optional **frame aggregates** of the existing native Step phase fields
   and add packet/counter/input/submission spans under the existing top owner.
   `controls_ms`, `pose_ms`, `admission_ms`, `simulation_ms`, `geometry_ms` already
   exist but are not exported by current summary/inspect. The current pose phase
   includes patch/detonation handling, and collision is a simulation child;
   name scopes honestly and do not add child time twice. Count endpoint reads vs
   conversions, controller cache/replay work, packet allocations/bytes, empty
   prepared owners, sorted owners, commands and retained-frame high-water marks.
2. Extend existing presentation/order/lifetime/paused-visibility/channel-cache/
   compact-paired fixtures with the candidate's exact boundary: same-frame pose
   mutation; reentrant register/remove/close; patch and consumed pulse replay;
   dormant detonation and camera re-entry; callback counter retirement; equal
   distances/mixed null sources; held old packed packets and caller mutation;
   GPU resize/MSAA, hidden middle ranges, color/fog/material changes and chunks.
   Compare full private state, exact f32/vertex words, RNG draws/order, provider
   traces, diagnostics, vertex coverage and original sort order.
3. After correctness, Root may schedule copied isolated baseline/candidate runs
   on the **same** retained complete local scene/resources/settings/camera/input,
   with identical source/build/asset hashes. Use repeated ABBA windows, separate
   cold/warm loading and deterministic active effects; record p50/p95/p99/worst
   wall times, owner phases, allocation/capacity, draw counts and explicit missing
   assets. Verify equal live effect/pool counts at matched logical time, not
   asynchronous end-of-run totals. Keep profiler settings equal; additionally
   compare profiling-disabled runs to quantify observation cost.
4. Only after that, separately authorized actual pixels/state/lifecycle/local
   protocol checks are needed for changed publication/batching. Retain all failed
   runs and source pins. No public-server performance test is implied. Report a
   gain only with its matched evidence; otherwise reject or keep the candidate
   diagnostic-only. Whole-scene playability and 60 FPS remain separate acceptance.

The companion NEW report pins the files read. Those are a source-audit snapshot,
not proof that the open process loaded a DLL built from every reviewed byte.
