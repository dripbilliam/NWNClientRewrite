# Godot/native room lighting comparison — 2026-10-31

This is a captured investigation, not an accepted lighting correction or a
matched FPS benchmark. The user manually brought both clients into the room.
Both characters are Drow, confirmed by the user. Both sessions are preserved;
no input, camera changes, process writes, public joins or chat were automated.

The original and replacement screenshots show a substantial discrepancy:
original stonework has broad pale illumination; the replacement is much darker,
with narrow colored lamp pools. Cameras, window sizes and viewing angles differ.
Those images establish a visible problem, not a quantitative pixel comparison.

## Received and effective area light

The replacement's complete private-loopback observations identify area
2147564222 (`thehorror`), tileset `tic01`, 16×16 tiles, generation 4. There were
10 complete lighting observations with no TCP gaps. The subsequent raw-world
lighting-only observation also has no TCP gaps. No raw traffic is retained.

The replacement has actually applied ambient RGB (12,16,48), directional RGB
(95,33,33), both energy 1. Permanent night is enabled. Fog RGB is (15,2,2),
depth begin approximately 10.095, end 45. This is not a missing area-light packet
or an absent DirectionalLight3D. Reports:
`godot-client/reports/native-particle-current-lighting-v1.json` and
`native-room-world-lighting-v1.json`.

The running Steam original is the mapped binary, SHA-256
`3b7cb1252e0edb2ce22d7971f333aade027039ae30a45b4bc64732c3e6bec73a`.
Only verified renderer globals were read, using QUERY_INFORMATION|VM_READ.
The current parameters are gamma-correction 1, fragment-lighting 1, shader
quality 2, range multiplier 2, intensity-at-range 0.2 and maximum intensity 1.5.
This confirms actual runtime parameters, rather than assuming saved settings.

Repeated native area-light samples include the complete stable world state:
ambient linear (0.0012017492,0.0022629448,0.0253711883), diffuse linear
(0.1139209121,0.0111261252,0.0111261252), direction
(0.4332242906,0.4873773158,0.7581425309). These agree with the transmitted
colors converted by the original power-2.2 path. GUI rendering temporarily
clears those globals. Individual non-atomic polls can contain partially updated
fields; they must not be interpreted as separate world-light configurations.
The headlight flag also changes during rendering. Its sampled value does not
prove a Darkvision lighting policy or justify adding an unconditional headlight.
Reports: `native-room-lighting-globals-v1.json`, `-v2.json`,
`native-room-lighting-globals-sampled-v1.json`, `native-room-lighting-rea-v1.json`.

REA independently locates GLRender area ambient storage at 0x1414087a0,
diffuse at 0x1414087b0 and diffuse direction at 0x1414087c0, through setters
0x1400b67e0 and 0x1400b6840. Headlight properties are not an area ambient
substitute. The retained dossiers include setter assembly and provenance.

## Confirmed implementation differences

* `systems/native_render/model_point_light.gd` uses authored radius directly,
  multiplier as energy, and Godot's ordinary attenuation. Original enhanced
  SetLightGL uses adjusted radius/color and its rational finite-range falloff.
  The live range multiplier is 2. See `native-enhanced-lighting-policy.md` for
  original call sites/equations. Merely doubling the Godot radius would not
  reproduce the remaining falloff/intensity/color behavior.
* Godot's model parsers discard separate mesh ambient color. The material pool
  feeds diffuse into a StandardMaterial3D albedo, thereby using it for ambient
  response as well. Original shaders separately multiply material ambient and
  diffuse. Some actual visible cached room parts have different values, including
  ambient-only material pairs. This is a real fidelity defect, not proof that
  it accounts for the whole room discrepancy.
* Ambient-only model lights are explicitly incomplete in the port. Of the 102
  authored light nodes in the 52 inspected unique tile models, none are marked
  ambient-only. Do not claim that missing ambient-only **tile** lamps explains
  this room. Placeable/creature/effect light models were not included in that
  count, and remain to inspect.
* A controlled-character Darkvision/Low-Light Vision rendering consumer was not
  found in the inspected Godot renderer. Both characters being Drow rules out
  a difference in innate race vision, but does not prove the replacement applies
  the same visual adaptation. Its exact original render policy remains open.

Godot internally multiplies nonphysical light energy by PI before its diffuse
BRDF division by PI. Therefore the shader's 1/PI alone is **not** evidence for
increasing all light energies by PI. No such speculative correction was made.

The first installed-only SET inspection correctly failed: the server uses
tile IDs 179/202/257 beyond the installed SET's 179 entries. The inspection was
then rerun against the two already-cached NWSync catalogs, requiring unanimous
resource hashes. It inspected 52 unique tile MDLs with verified content hashes,
including only visible meshes when identifying visible material differences.
No network was used. Loose/Workshop override precedence and active-manifest
selection are not established by this offline helper; those limits are in the
report. `native-room-cached-model-lighting-v2.json` retains resource hashes,
material pairs and authored light properties, not resource payloads.

## Diagnostics and next acceptance

Follow-up component work also establishes original-compatible shared particle
raw color/fog and CPU emitter tint. The CPU calculation agrees exactly with all
297 retained original instruction cases; real GPU comparisons and an actual
world registry/admission fixture pass. Adjacent same-state batching preserves
exact pixels and hidden-source gaps. This remains a research carrier, with no
full gameplay-world activation. A fog-enabled Godot flat background was found
to publish its linear fog color into the candidate's gamma-space framebuffer.
The subsequent actual-area fixture now verifies raw background/world-fog
publication across day/night/dawn/dusk and safe successor retirement: 109 checks,
32 GPU samples, maximum display-channel error 0.002356. Particle fallbacks also
pass the original-code comparison. The sky shader adds a separate 66-check
comparison, including original pre-interpolated vertex-color conversion and
raw horizon-color parameters. These component receipts do not establish full
native sky-resource loading or show this room fixed. See the correction document
for receipts, preserved failures, bounded cost results and open soft-depth,
material-map, vision and postprocess work. No public connection was made.

Further read-only tracing verifies that Scene::SetBlindLights restricts native
lighting by exact physical Gob identity, fades independent area-light channels
and changes geometry fog to black without changing the clear/sky color. Its
native Godot API path now passes 38 actual-world/GPU/ownership checks. The
ordinary non-null gameplay caller remains unproven and is not guessed from a
race or visual-effect family. The headlight's debug/GUI callers also do not
justify an unconditional gameplay light. These results must not be presented
as this room's corrected Darkvision or brightness acceptance. Bounded evidence:
`godot-client/reports/native-retail-blind-headlight-dossiers-v1.json`.

The original adaptive contrast/vibrance/Gamma/tonemap color chain now also has
a native scene candidate. Its 428-check original-shader comparison and 40-check
actual-world binding pass; one midpoint GPU invocation handles up to 128 admitted
lights. Isolated 1080p cost grows by about 0.02–0.05 ms GPU and 0.14–0.32 ms scene
input CPU. Full-world activation, spatial postprocessing and this room's matched
appearance/settings/FPS are still unproven. The correction document retains
receipt names, exact scope and failed fixture iterations.

`scripts/read-native-lighting-parameters.py` reads only pinned renderer fields;
it verifies process name/image SHA and image base. `inspect-room-model-lighting.mjs`
is an offline research tool, not a JS runtime rendering dependency.
`extract-native-lighting-stream.mjs` accepts tshark sequence/payload fields,
reassembles complete messages and whitelists retained lighting data. Its four
tests pass: split/reordered/retransmitted data, sequence wrap, missing segment,
and exclusion of object/account/chat/pin data. The initial area summary was too
broad; it was narrowed to an explicit whitelist, and the generated report was
rewritten to remove unrelated area metadata.

The sender already emits `area_lighting`; the host timing recorder previously
dropped that field. It now retains it for subsequent launches. Host syntax
validation passes. The current packaged user session is not restarted, altered
or accepted as a clean benchmark; the logging change takes effect next launch.

A real correction needs an offline/matched fixture with the same resources,
camera, colors and character vision, followed by original-compatible material
and local-light behavior. Do not declare lighting fixed, boost exposure, or
promote an approximate attenuation curve based only on these screenshots.

## First correction implemented later on 2026-10-31

Later retail-profile research found that the active installed shader includes
come from `data/ovr.bif`, overriding the older base-shader includes. The candidate
now verifies those resource hashes and implements ordinary fragment-lit material
GGX/environment response plus native SET-selected 2D environment loading. A
colored-environment GPU oracle exposed and corrected the earlier revision
assumption. Final receipts pass 94 GPU/material checks, 15 environment/retirement
checks, and 39/39 authoritative localhost actions/images with the new profile
actually enabled. These are bounded component/gameplay tests, not a matched
comparison of this room. Retail final color-correction/fog ordering, mapped/cube
materials, remaining vision/light bindings and dense-room acceptance remain
open. Detailed limitations and receipt names are in the correction document.

An opt-in native Godot material/light correction is now implemented. The normal
default is unchanged. See `../godot-client/NATIVE-LIGHTING-CORRECTION.md` for
launch/rollback commands, original-equation mapping, guarded CPU/GPU receipts,
the matched localhost effects comparison (37/39 in both modes, same two existing
particle-image failures), and explicit remaining vision/fog/performance work.
No autonomous public connection was used to build or test the correction.

## Follow-up: verified collection/history, still a separate experiment

Native light sphere collection, priority/sort and retained fades now have an
independent unchanged-instruction oracle and a native implementation. Main-world
collection is `SetupLightsForThisPositionAndRadius(focus,max(45,fogEnd))` before
priority; it is not just camera-visible lamps or GetNearestLights. The candidate
publishes raw-color fade before power conversion and shares admitted fades with
the CPU vision sample. CPU corpora, actual GPU pixels and the authoritative
localhost effects suite pass; the final local run verifies that history actually
activated, rather than merely recording its requested flag.

This is separately opt-in and not accepted as room parity. Original static-only
lights use baked vertex lighting; the experiment retains their existing renderer
contribution pending that port. Special native clipping, area/headlight/blindness
integration, full material response/output order and matched dense-room visuals
and frame distributions are still required. See the current detailed acceptance
and receipts in `../godot-client/NATIVE-LIGHTING-CORRECTION.md`.
