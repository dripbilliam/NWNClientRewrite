'use strict';
// Freeze the same normal client twice for a bounded staged-vs-sync entry test.
// No accepted executable, DLL, project source, or user preferences are changed.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../..'),scope=path.join(root,'.cache/nwn61/current-entry-pair-a');
const referenceFile=path.join(root,'.cache/native-presentation-parity/production-replay/nwn62-completion-tail-c/production-selection.json');
const sha=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
async function main(){
 assert(!fs.existsSync(scope),'Preserve previous NWN-61 pair');
 const reference=JSON.parse(fs.readFileSync(referenceFile));
 assert(reference.complete&&reference.production&&!reference.options.some(x=>x.startsWith('--entry-commit=')));
 const seeds={version:1,expected:reference.preferences.expected,description:'NWN-61 current-source matched entry-commit modes'};
 for(const name of ['render','layout'])seeds[name]={file:reference.preferences[name].source,sha256:reference.preferences[name].sha256};
 const helper=require(path.join(root,'tools/native-production-selection.cjs'));
 const identity=require(path.join(root,'tools/native-feature-manifest.cjs')).sourceIdentity;
 const before=identity(root).sha256,rows={};
 for(const mode of ['staged','sync']){
  const staged=await helper.stageProductionSelection({project:root,label:'nwn61-current-entry-'+mode+'-a',argv:[...reference.options,'--entry-commit='+mode],preferenceSeeds:seeds,env:{}});
  const selection=staged.selection;
  assert(selection.flags.includes('--entry-commit='+mode));
  assert.equal(selection.profiling,'false');
  assert.equal(selection.runtime.executableSha256,reference.runtime.executableSha256);
  await helper.readProductionSelection(staged.file,staged.sha256);
  rows[mode]={file:staged.file,sha256:staged.sha256,sourceIdentity:selection.mainSourceIdentity.sha256,flags:selection.flags,engineSha256:selection.runtime.executableSha256,pins:selection.pins.length};
 }
 assert.equal(identity(root).sha256,before,'Production source changed while staging');
 assert.equal(rows.staged.sourceIdentity,rows.sync.sourceIdentity,'Pair source differs');
 assert.deepEqual(rows.staged.flags.map(x=>x.replace('entry-commit=staged','entry-commit=sync')),rows.sync.flags);
 const capture=JSON.parse(fs.readFileSync(path.join(root,'.cache/nwn64/animation-snapshot-client-pair-a/staged.json')));
 assert.equal(sha(path.join(capture.capture,'recording.json')),capture.recordingSha256);
 fs.mkdirSync(scope,{recursive:true});
 const receipt={version:1,issue:'NWN-61',private:true,acceptedArtifactsChanged:false,sourceIdentity:before,referenceSelection:{file:referenceFile,sha256:sha(referenceFile)},capture:capture.capture,recordingSha256:capture.recordingSha256,engineSha256:reference.runtime.executableSha256,selections:rows,scope:'Same current frozen normal client, accepted engine/DLL, recording and preferences; only explicit bounded or synchronous entry-commit selector differs. No FPS or Arelith claim.'};
 const file=path.join(scope,'staged.json');fs.writeFileSync(file,JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({file,sha256:sha(file),sourceIdentity:before,pins:rows.staged.pins,selections:Object.fromEntries(Object.entries(rows).map(([mode,row])=>[mode,row.sha256]))}));
}
main().catch(error=>{console.error(error.stack);process.exitCode=1;});
