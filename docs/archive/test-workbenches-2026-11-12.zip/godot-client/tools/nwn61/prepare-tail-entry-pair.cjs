'use strict';
// Stage the revised NWN-61 ACK/menu tail against its already reviewed 61-only
// entry source. This prepares immutable normal-runtime inputs; it never runs a
// client, changes the accepted engine/DLL, or mixes in the 62 experiment.
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../..');
const label=process.argv[2];
assert(/^[a-z0-9][a-z0-9-]{0,39}$/.test(label??''),'Fresh safe label required');
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const read=file=>fs.readFileSync(file);
const hash=file=>sha(read(file));
const parentFile=path.join(root,'.cache/nwn62/entry-pairs/entry61-pair-b/pair.json');
const parentSHA='570064e7702d74f04a7535d26033abe57a9d9cdefc673ebf41e19095b9e1a89f';
assert.equal(hash(parentFile),parentSHA,'Reviewed 61 parent manifest changed');
const parent=JSON.parse(read(parentFile));
const oldReportFile=path.join(root,'reports/nwn61-entry-pair-c-candidate.json');
assert.equal(hash(oldReportFile),'33eafbe0aa9432556f4962380a433cc4be1e1e18aadcfdab0f5fd7e76298c575','Old normal-entry report changed');
const oldReport=JSON.parse(read(oldReportFile));
const controlSelection=oldReport.productionSelection;
assert.equal(controlSelection.sourceProject,path.join(parent.candidate,'.cache/native-presentation-parity/production-replay/entry61-pair-b-candidate/project'));
assert.equal(hash(controlSelection.file),controlSelection.sha256);
assert.equal(controlSelection.sourceSignature,parent.identities.candidate);
assert.equal(controlSelection.engineSha256,'753b3e188068efaf865bda3abd6322ebe44e3a98ef2f5d199c8af1a78624c98b');
assert.equal(controlSelection.particleSha256,'485741af15f0581a3c60c0f9a8ae738888eba08716c7a5c2c2d1bd550828963d');
assert.deepEqual(parent.argv,['--performance-runtime=verified-native','--render-profile=gameplay','--detailed-profiling=off']);
assert.equal(hash(parent.preferences.file),parent.preferences.sha256);
const expected=new Map();
for(const row of [...parent.baseline.pins,parent.commonInfrastructure,...parent.review61.overlayPins,...parent.testOnlyOriginalFixtures])expected.set(row.file,row.sha256);
const overlays=[
 {file:'native_session_world.gd',old:'74029b6ca730ebee057d833a3a804bfd42f1f289c46a414b98237ade3e72f705',current:'8cb77c208d16a847729af03284a637f1fd2bb4a8fcb0986f058e054fd724e009'},
 {file:'systems/native_main_menu.gd',old:'10133773c3785c9e18f8a7cc11a31395218b37e4314c5f67f0aa6702fd6d0225',current:'1da44e892d94ada1ffebd3dc2426d69ec9c0d01c24158aa9c5c80f957389df01'},
 {file:'systems/native_client_menu_style.gd',old:'4de80e1172923f2814f319258eeda96f40649b6bb5b87f22b16be75f70a78c16',current:'a52dd6002b18fa8357bf4abb63b87ec3039fbda51434f225b38793f9fd2f52dd'}
];
for(const row of overlays){assert.equal(expected.get(row.file),row.old,'Reviewed parent '+row.file+' changed');assert.equal(hash(path.join(root,row.file)),row.current,'Current '+row.file+' changed');}
const out=path.join(root,'.cache/nwn61',label);
assert(!fs.existsSync(out),'Fresh output required');
const input=path.join(out,'candidate-input');
fs.mkdirSync(input,{recursive:true});
let hardlinks=0;
for(const [relative,digest] of expected){
 assert(!path.isAbsolute(relative)&&!relative.split(/[\\/]/).includes('..'),'Unsafe input path');
 const source=path.join(parent.candidate,relative),bytes=read(source);
 assert.equal(sha(bytes),digest,'Reviewed source changed: '+relative);
 const target=path.join(input,relative);fs.mkdirSync(path.dirname(target),{recursive:true});
 if(/\.(exe|dll)$/i.test(relative)){fs.linkSync(source,target);hardlinks++;}
 else fs.writeFileSync(target,bytes,{flag:'wx'});
}
for(const row of overlays)fs.writeFileSync(path.join(input,row.file),read(path.join(root,row.file)));
const seeds=JSON.parse(read(parent.preferences.file));
const selectionHelper=require(path.join(input,'tools/native-production-selection.cjs'));
selectionHelper.stageProductionSelection({project:input,label:label+'-candidate',argv:parent.argv,preferenceSeeds:seeds,env:{}}).then(async receipt=>{
 const control=await selectionHelper.readProductionSelection(controlSelection.file,controlSelection.sha256);
 const candidate=await selectionHelper.readProductionSelection(receipt.file,receipt.sha256);
 assert.equal(control.runtime.executableSha256,candidate.runtime.executableSha256);
 assert.equal(control.profiling,'false');assert.equal(candidate.profiling,'false');
 assert.deepEqual(control.options,candidate.options);
 assert.deepEqual(control.preferences.expected,candidate.preferences.expected);
 const changed=[];
 const before=new Map(control.pins.map(row=>[row.relative,row.sha256]));
 for(const row of candidate.pins)if(before.get(row.relative)!==row.sha256)changed.push(row.relative);
 assert.deepEqual(changed.sort(),overlays.map(row=>row.file).sort(),'Unexpected staged-source difference');
 const manifest={schema:'nwn61-revised-tail-entry-pair-v1',label,created:new Date().toISOString(),parent:{file:parentFile,sha256:parentSHA,sourceIdentity:parent.identities.candidate},control:{file:controlSelection.file,sha256:controlSelection.sha256,sourceProject:control.sourceProject,sourceIdentity:control.mainSourceIdentity.sha256},candidate:{file:receipt.file,sha256:receipt.sha256,sourceProject:candidate.sourceProject,sourceIdentity:candidate.mainSourceIdentity.sha256},overlays,changed,hardlinks,argv:parent.argv,preferenceSeeds:{file:parent.preferences.file,sha256:parent.preferences.sha256},engineSha256:control.runtime.executableSha256,profiling:false,scope:'Normal Core E and accepted CPU kernel, 61-only prior staged-entry control; candidate changes session ACK telemetry, main-menu continuation and entry-only staged theme publication. Source selection only; no FPS or load-time claim.'};
 const file=path.join(out,'pair.json');fs.writeFileSync(file,JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({file,sha256:hash(file),changed,candidate:receipt.file,selectionSHA:receipt.sha256}));
}).catch(error=>{console.error(error);process.exitCode=1;});
