'use strict';
// Freeze comparable 4/6/8 ms staged-entry selections only when source work is
// quiet. This prepares inputs; it never launches a graphical client.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../..');
const label=process.argv.find(value=>value.startsWith('--label='))?.slice(8)??'a';
assert(/^[a-z]$/.test(label),'Use one lowercase letter for an immutable stage label');
const scope=path.join(root,'.cache/nwn61/current-entry-budget-matrix-'+label);
const referenceFile=path.join(root,'.cache/native-presentation-parity/production-replay/nwn62-completion-tail-c/production-selection.json');
const sha=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
async function main(){
 assert(!fs.existsSync(scope),'Preserve prior NWN-61 budget matrix');
 const reference=JSON.parse(fs.readFileSync(referenceFile));
 assert(reference.complete&&reference.production&&reference.profiling==='false');
 assert(!reference.options.some(value=>value.startsWith('--entry-commit=' )||value.startsWith('--entry-commit-budget=')));
 const seeds={version:1,expected:reference.preferences.expected,description:'NWN-61 current-source staged entry budget matrix'};
 for(const name of ['render','layout'])seeds[name]={file:reference.preferences[name].source,sha256:reference.preferences[name].sha256};
 const helper=require(path.join(root,'tools/native-production-selection.cjs'));
 const identity=require(path.join(root,'tools/native-feature-manifest.cjs')).sourceIdentity;
 const before=identity(root).sha256;
 const rows={};
 for(const budget of ['4ms','6ms','8ms']){
  const staged=await helper.stageProductionSelection({project:root,label:'nwn61-current-entry-budget-'+budget+'-'+label,argv:[...reference.options,'--entry-commit=staged','--entry-commit-budget='+budget],preferenceSeeds:seeds,env:{}});
  const selection=staged.selection;
  assert(selection.flags.includes('--entry-commit=staged')&&selection.flags.includes('--entry-commit-budget='+budget));
  assert.equal(selection.profiling,'false');
  assert.equal(selection.runtime.executableSha256,reference.runtime.executableSha256);
  await helper.readProductionSelection(staged.file,staged.sha256);
  rows[budget]={file:staged.file,sha256:staged.sha256,sourceIdentity:selection.mainSourceIdentity.sha256,engineSha256:selection.runtime.executableSha256,pins:selection.pins.length,flags:selection.flags};
 }
 assert.equal(identity(root).sha256,before,'Production source changed while staging');
 assert(rows['4ms'].sourceIdentity===rows['6ms'].sourceIdentity&&rows['4ms'].sourceIdentity===rows['8ms'].sourceIdentity,'Budget source differs');
 const capture=JSON.parse(fs.readFileSync(path.join(root,'.cache/nwn64/animation-snapshot-client-pair-a/staged.json')));
 assert.equal(sha(path.join(capture.capture,'recording.json')),capture.recordingSha256);
 fs.mkdirSync(scope,{recursive:true});
 const receipt={version:1,issue:'NWN-61',private:true,acceptedArtifactsChanged:false,sourceIdentity:before,referenceSelection:{file:referenceFile,sha256:sha(referenceFile)},capture:capture.capture,recordingSha256:capture.recordingSha256,engineSha256:reference.runtime.executableSha256,selections:rows,scope:'Same normal client, original generation-2 recording and preferences; only explicit staged-entry budget differs. No FPS or loading result.'};
 const file=path.join(scope,'staged.json');fs.writeFileSync(file,JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({file,sha256:sha(file),sourceIdentity:before,pins:rows['4ms'].pins,selections:Object.fromEntries(Object.entries(rows).map(([budget,row])=>[budget,row.sha256]))}));
}
main().catch(error=>{console.error(error.stack);process.exitCode=1;});
