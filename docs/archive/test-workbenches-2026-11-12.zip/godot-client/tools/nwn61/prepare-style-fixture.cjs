'use strict';
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../..'),label=process.argv[2];
assert(/^[a-z0-9-]+$/.test(label??''));
const out=path.join(root,'.cache/nwn61/style-'+label);assert(!fs.existsSync(out));
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex'),pins=[];
function put(relative,bytes){const file=path.join(out,relative);fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,bytes,{flag:'wx'});pins.push({file:relative,sha256:sha(bytes)});}
for(const file of ['systems/native_client_menu_style.gd','systems/draggable_panel.gd','systems/native_menu_builder.gd','tests/nwn61_style_publication_test.gd'])put(file,fs.readFileSync(path.join(root,file)));
put('project.godot',Buffer.from('config_version=5\n[application]\nconfig/name="NWN61 Style Publication"\n'));
put('.godot/global_script_class_cache.cfg',Buffer.from('list=[]\n'));
put('manifest.json',Buffer.from(JSON.stringify({schema:'nwn61-style-publication-fixture-v1',pins,scope:'Actual style and draggable window source with authored fake painter, headless only.'},null,2)+'\n'));
console.log(JSON.stringify({out,manifest:path.join(out,'manifest.json'),sha256:sha(fs.readFileSync(path.join(out,'manifest.json')))}));
