'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict'),{spawn,execFile}=require('node:child_process');
const root=path.resolve(__dirname,'../..'),run='nwn61-ready-phase-b-gen5',out=path.join(root,'.cache/nwn61/ready-phase-a');
const selection=path.join(root,'.cache/native-presentation-parity/production-replay/nwn61-ready-phase-a/production-selection.json');
const sha=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const pins={
 'tools/replay-native-loading.mjs':'edf88a0ac03a7446b275e182f45f941817c805471d084ee9bc82ef059a3f184c',
 '.cache/native-presentation-parity/production-replay/nwn61-ready-phase-a/production-selection.json':'adff6623d1eb86911f0ac370a7daab00786d51c948eb79a9fdb9841b90043c9c',
 '.cache/loading-benchmark-worlds/arelith-archive-shaders-v1/recording.json':'1922ba3b82b44d1982978850a7d0ef3f67a24d56130ec3f859a689ff77affe20',
 '.tools/native-core/Godot_native_core_e_win64.exe':'753b3e188068efaf865bda3abd6322ebe44e3a98ef2f5d199c8af1a78624c98b'
};
for(const [relative,wanted] of Object.entries(pins))assert.equal(sha(path.join(root,relative)),wanted,'Pinned input changed: '+relative);
const args=[path.join(root,'tools/replay-native-loading.mjs'),'--capture=.cache/loading-benchmark-worlds/arelith-archive-shaders-v1','--generation=5','--production-selection='+selection,'--production-selection-sha256='+pins['.cache/native-presentation-parity/production-replay/nwn61-ready-phase-a/production-selection.json'],'--engine=production-selection','--headless','--profiling=true','--observe-profile=true','--duration-ms=30000','--run='+run];
if(process.argv.includes('--verify-only'))args.push('--verify-only');
if(!process.argv.includes('--verify-only'))for(const suffix of ['.json','.native.json','.performance.jsonl','.engine.log'])assert(!fs.existsSync(path.join(root,'reports',run+suffix)),'Fresh report required: '+suffix);
console.log(JSON.stringify({run,args,pins,limitMs:240000,limitBytes:8*1024**3,scope:'Headless CPU/load attribution only; no FPS claim'}));
const log=path.join(out,run+'.driver.log'),receipt=path.join(out,run+'.receipt.json');
if(!process.argv.includes('--verify-only'))assert(!fs.existsSync(log)&&!fs.existsSync(receipt),'Fresh private output required');
const child=spawn(process.execPath,args,{cwd:root,windowsHide:true,stdio:['ignore','pipe','pipe']}),chunks=[];
for(const stream of [child.stdout,child.stderr])stream.on('data',b=>chunks.push(b));
let peak=0,halt='',checking=false;const began=Date.now();
const stop=reason=>{if(halt)return;halt=reason;execFile('taskkill',['/PID',String(child.pid),'/T','/F'],{windowsHide:true},()=>{});};
const monitor=setInterval(()=>{if(Date.now()-began>240000)return stop('240-second timeout');if(checking)return;checking=true;execFile('pwsh',['-NoProfile','-Command',"$p=Get-Process Godot_native_core_e_win64 -ErrorAction SilentlyContinue; if($p){[long](($p|Measure-Object -Property PrivateMemorySize64 -Sum).Sum)}else{0}"],{windowsHide:true,timeout:6000},(error,stdout)=>{checking=false;if(error)return stop('Memory guard unavailable: '+error.message);const bytes=Number(stdout.trim())||0;peak=Math.max(peak,bytes);if(bytes>8*1024**3)stop('8 GiB Godot private-memory limit');});},2000);
child.once('error',error=>{console.error(error);process.exitCode=1;});
child.once('exit',code=>{clearInterval(monitor);const output=Buffer.concat(chunks).toString();if(process.argv.includes('--verify-only')){console.log(output.slice(-4000));if(code!==0)process.exitCode=1;return;}fs.writeFileSync(log,output,{flag:'wx'});const reportFile=path.join(root,'reports',run+'.json'),nativeFile=path.join(root,'reports',run+'.native.json');const result={exit:code,halt,peakPrivateBytes:peak,reportSha256:fs.existsSync(reportFile)?sha(reportFile):null,nativeSha256:fs.existsSync(nativeFile)?sha(nativeFile):null,success:fs.existsSync(reportFile)?JSON.parse(fs.readFileSync(reportFile)).success:false,elapsedMs:Date.now()-began,pins};fs.writeFileSync(receipt,JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));if(code!==0||halt||!result.success)process.exitCode=1;});
