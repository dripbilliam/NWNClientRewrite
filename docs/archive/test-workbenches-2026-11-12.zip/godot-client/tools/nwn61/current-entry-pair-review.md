# NWN-61 current-source entry comparison, 2026-11-12

Four original-recording generation-2 graphical replays used the same accepted engine, native module, source snapshot, capture, settings, and 15-second settled window. Only `--entry-commit=staged|sync` changed, in staged/sync/sync/staged order. The pinned selections are recorded in `.cache/nwn61/current-entry-pair-a/staged.json`; the raw reports are `reports/nwn61-current-entry-{a-staged,b-sync,c-sync,d-staged}.json`.

| Run | First playable (ms) | First known complete base (ms) | Settled mean (ms/frame) | Settled p95 | Settled p99 | Staged max entry unit |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| staged A | 4715.895 | 18471.485 | 7.3215 | 7.983 | 17.000 | 5.655 ms |
| sync B | 4399.464 | 17513.112 | 7.2579 | 8.036 | 16.770 | — |
| sync C | 3571.947 | 16641.689 | 7.0740 | 7.668 | 16.911 | — |
| staged D | 3768.685 | 17711.313 | 7.1517 | 7.690 | 17.129 | 5.426 ms |

Mode averages: staged reached first playable **256.585 ms later** and first known complete base scenery **1013.999 ms later**. The paired loading differences have the same sign in both bookends. Settled mean frame time was 7.2366 ms staged versus 7.1659 ms sync; this is too small and confounded to claim an FPS effect. The settled windows do not measure the entry hitch itself, and the synchronous path has no equivalent per-step receipt in these profiling-off runs.

All runs reached area 2147618622, playable and object-visual complete, with 1784/1784 known base objects resolved and zero pending. All reports say source and runtime unchanged. All four have the same captured engine-diagnostic fingerprint and the replay's `success=false`/`Native engine/lifetime diagnostics observed` verdict. These are bounded comparative observations, not clean production acceptance. The staged path remains In Progress: reduce its loading penalty and independently measure the synchronous entry stall before promoting or changing the default.

The staged ACK receipts separate work from waiting. A recorded 109.740 ms of outer commit-phase CPU spans 1004.410 ms wall in staged A; 105.072 ms spans 746.015 ms in staged D. Core work is 84.256/84.913 ms, entity API work 17.164/14.557 ms, and ACK tail work 8.174/5.435 ms. The outer commit advances 170/169 units with maximum units 5.655/5.426 ms, respectively. These totals point to budgeted scheduling as the main source of the staged ACK latency; they do not prove the 6 or 8 ms setting is safe or faster in a matched client run. The next comparison must measure both entry latency and maximum displayed-frame hitch, since a larger budget trades one against the other.

After this frozen pair, the staged fresh-world receiver was changed to skip calls that are provably redundant: non-placeable light rows with no earlier light of the same ID, and static-draw invalidation when the required instance map is empty. Its population pass also stops comparing rows once the single changed flag is set, while still performing the final desired-world publication. The first draft skipped that publication and failed the World fixture, so it was corrected before acceptance. The corrected real World fixture passed 230 checks; the session/backlog/cancellation fixture passed 19 checks. These post-pair edits have no new loading or FPS result.

An explicit `--entry-commit-budget=6ms|8ms` option is prepared for a later matched loading/hitch test. The absent flag retains the existing 4 ms budget. Host option validation passed both focused entry tests, and the default session continuation still passed 19 checks. Neither larger budget has been measured or promoted.
`tools/nwn61/stage-current-entry-budget-matrix.cjs` froze all three selections under `.cache/nwn61/current-entry-budget-matrix-a/staged.json` (SHA-256 `b2c621a914bba3972ffdb27a99577d42871766b0966231ea2f47deb8f6f5f959`). They share source identity `7d5e7b219c2c6e77f4d0fe060ea979f830c3248c7dc3af8419ad2b43eababe0b`, accepted engine and recording, with 2,489 source pins apiece. Each replay `--verify-only` reported 5,704 events, one catalog and zero network connections. No graphical client or FPS measurement was launched for this matrix.
The three selected flag vectors were also compared after replacing only the budget value; they are otherwise identical.
After this freeze, NWN-62 integrated the narrow lazy model-cell fallback into `drive_collision_indexed.gd`. The budget matrix is still internally matched, but its source identity is no longer the latest workspace. Restage from the final shared source before using its result as current-client acceptance.

The current-source replacement is `.cache/nwn61/current-entry-budget-matrix-b/staged.json` (SHA-256 `3659970c122df40d6ac57388e3db47d4132b6273ee52ab571c1179a4340331c`). Its 4/6/8 ms selections share source identity `57db91e3d51dbd6529ca07ce11b9d4cee298e361e058bc3e3246d5d79ebcfb0c`, accepted engine `753b3e18...`, original generation-2 recording, and 2,504 source pins apiece. The flag vectors are identical after normalizing the one budget value. All three no-launch `--verify-only` checks passed with 5,704 events, one catalog, and zero network connections. This refreshes the input pins; it supplies no new loading or FPS measurement.

## Current-source 4/6/8 ms budget test

After the NWN-63 default-off keyboard admission wiring, the latest source was frozen again in `.cache/nwn61/current-entry-budget-matrix-c/staged.json` (SHA-256 `6a97ff2883062a32021de64f9482506860ff8e04acd71c7aae11080074375be6`, identity `e2b0aa425105b9a2f1889a92cd4769db279dc865d9642d5e8e01fcca10908d20`). The six graphical normal-client replays ran 4/6/8/8/6/4 ms, with the same original generation-2 capture, accepted engine, preferences, camera policy, and 15-second settled window. Full receipts and raw report hashes are in `.cache/nwn61/current-entry-budget-matrix-c/matrix-review.json` (SHA-256 `d6af8f86189093a62da66a0739dfcc45e11feddb4549a451e3eb5e0ad334e5f8`). All six reached playable/full known BASE, with 1784 resolved and zero pending. Their only engine errors were the same shader-cache-folder and root-certificate environment diagnostics; driver exits were 1 for those diagnostics, so this is a conditional comparison, not strict acceptance.

| Budget | ACK latency, two runs (ms) | First playable, mean (ms) | Full known BASE, mean (ms) | Settled mean (ms/frame) | p95 / p99 (ms) | Largest commit unit, two runs (ms) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 4 ms | 793 / 664 | 3790 | 17583 | 7.523 | 8.201 / 17.301 | 19.509 / 12.553 |
| 6 ms | 994 / 554 | 3986 | 17568 | 7.569 | 8.241 / 17.384 | 16.826 / 8.486 |
| 8 ms | 778 / 489 | 4117 | 17617 | 7.620 | 8.263 / 17.283 | 9.151 / 8.237 |

The 8 ms budget reduced mean ACK latency by about 95 ms against 4 ms in this small sample, but its two ACK legs differed by 289 ms and the 6 ms legs differed by 441 ms. First playable and full BASE did not improve reliably; the settled frame means differ by at most about 0.10 ms and drift with run order. Larger budgets did not establish a worthwhile whole-client speedup or an accepted hitch reduction. Retain the 4 ms default and the explicit 6/8 ms switches for further controlled entry-stall study. The 4 ms runs still contained 12.6–19.5 ms individual commit units, proving that a budget checked only between units does not bound the largest unit.
