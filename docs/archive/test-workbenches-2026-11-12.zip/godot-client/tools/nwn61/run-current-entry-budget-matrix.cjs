'use strict';
// Exclusive performance lease only. Original scene, current source, symmetric
// 4/6/8/8/6/4 ms entry-budget comparison with all other work quiesced.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {spawn}=require('node:child_process');
const root=path.resolve(__dirname,'../..');
const stageFile=path.join(root,'.cache/nwn61/current-entry-budget-matrix-c/staged.json');
const stage=JSON.parse(fs.readFileSync(stageFile));
const hash=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const order=['4ms','6ms','8ms','8ms','6ms','4ms'];
async function verify(){
 assert.equal(hash(stageFile),'6a97ff2883062a32021de64f9482506860ff8e04acd71c7aae11080074375be6');
 assert.equal(hash(path.join(stage.capture,'recording.json')),stage.recordingSha256);
 assert.equal(require(path.join(root,'tools/native-feature-manifest.cjs')).sourceIdentity(root).sha256,stage.sourceIdentity,'Workspace changed after test freeze');
 const helper=require(path.join(root,'tools/native-production-selection.cjs'));
 const selections={};
 for(const budget of ['4ms','6ms','8ms']){
  const pinned=stage.selections[budget];
  const selection=await helper.readProductionSelection(pinned.file,pinned.sha256);
  assert.equal(selection.mainSourceIdentity.sha256,stage.sourceIdentity);
  assert.equal(selection.runtime.executableSha256,stage.engineSha256);
  assert.equal(selection.profiling,'false');
  assert(selection.flags.includes('--entry-commit=staged'));
  assert(selection.flags.includes('--entry-commit-budget='+budget));
  selections[budget]=selection;
 }
 const normalized=Object.values(selections).map(selection=>selection.flags.map(value=>value.startsWith('--entry-commit-budget=')?'--entry-commit-budget=*':value));
 assert(normalized.every(value=>JSON.stringify(value)===JSON.stringify(normalized[0])),'Only budget may vary');
 return {stageSha256:hash(stageFile),sourceIdentity:stage.sourceIdentity,engineSha256:stage.engineSha256,recordingSha256:stage.recordingSha256,selections:Object.fromEntries(Object.entries(stage.selections).map(([budget,selection])=>[budget,selection.sha256])),order,steadyMs:15000};
}
function summarize(run,budget,driverExit){
 const reportFile=path.join(root,'reports',run+'.json');
 const report=JSON.parse(fs.readFileSync(reportFile));
 assert.equal(report.exit,0,'Native client failed');
 assert(report.sourceUnchanged&&report.runtimeUnchanged&&report.driverUnchanged,'Pinned sources/runtime changed');
 assert.equal(report.productionFeatures?.verification?.status,'observed');
 assert.equal(report.productionFeatures?.worldVerification?.status,'observed');
 assert.equal(report.productionCameraVerification?.status,'observed');
 assert.equal(report.productionWindowVerification?.status,'observed');
 assert.equal(report.native?.world?.area_id,2147618622);
 assert(report.native?.performance_window?.steady&&report.native.performance_window.elapsed_ms>=15000);
 assert(report.native?.playable&&report.native?.object_visuals_complete&&report.native?.protocol_finish_ack);
 const scenery=report.native.world.base_scenery;
 assert(scenery?.known_base_complete&&scenery.pending===0&&scenery.failed===0&&scenery.resolved===scenery.expected);
 assert.equal(report.native.entry_commit_entries?.length,1);
 const entry=report.native.entry_commit_entries[0];
 assert.equal(entry.budget_us,parseInt(budget,10)*1000);
 const engineLog=fs.readFileSync(path.join(root,'reports',run+'.engine.log'),'utf8');
 const errors=engineLog.split(/\r?\n/).filter(line=>line.startsWith('ERROR: '));
 const allowed=new Set(["ERROR: Can't create shader cache folder, no shader caching will happen: user://",'ERROR: Failed to read the root certificate store.']);
 assert(errors.every(line=>allowed.has(line)),'Unexpected engine diagnostic');
 assert(!/(SCRIPT ERROR|FATAL|leaked|still in use)/i.test(engineLog),'Engine script/lifetime error');
 assert(driverExit===0||driverExit===1&&errors.length>0,'Unexpected driver exit');
 const frame=report.native.frame_intervals;
 return {run,budget,driverExit,report:reportFile,reportSha256:hash(reportFile),conditionalEnvironmentDiagnostic:errors,entry:{ackLatencyMs:entry.ack_latency_ms,maxStepUs:entry.maximum_step_us,coreMaxUnitUs:entry.core_maximum_unit_us,outerSteps:entry.steps,phaseCpuUs:Object.values(entry.phase_us).reduce((a,b)=>a+b,0)},loading:{playableMs:report.native.world.playable_ms,baseKnownCompleteMs:scenery.first_known_complete_ms},scene:{expected:scenery.expected,resolved:scenery.resolved},frame:{meanMs:frame.average_ms,medianMs:frame.median_ms,p95Ms:frame.p95_ms,p99Ms:frame.p99_ms,worstMs:frame.worst_ms,count:frame.count}};
}
async function leg(budget,index){
 const run=`nwn61-entry-budget-c-${index+1}-${budget}`;
 const reportFile=path.join(root,'reports',run+'.json'),logFile=path.join(root,'.cache/nwn61/current-entry-budget-matrix-c',run+'.driver.log');
 assert(!fs.existsSync(reportFile)&&!fs.existsSync(logFile),'Preserve earlier run');
 const selected=stage.selections[budget];
 const args=[path.join(root,'tools/replay-native-loading.mjs'),'--capture='+stage.capture,'--generation=2','--production-selection='+selected.file,'--production-selection-sha256='+selected.sha256,'--engine=production-selection','--profiling=false','--steady-ms=15000','--preview','--run='+run];
 const log=fs.createWriteStream(logFile,{flags:'wx'});
 const child=spawn(process.execPath,args,{cwd:root,windowsHide:true,stdio:['ignore','pipe','pipe']});
 for(const stream of [child.stdout,child.stderr])stream.on('data',chunk=>log.write(chunk));
 const exit=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('exit',resolve);});
 await new Promise(resolve=>log.end(resolve));
 const result=summarize(run,budget,exit);
 console.log(JSON.stringify({completed:run,driverExit:exit,entry:result.entry,loading:result.loading,frame:result.frame}));
 return result;
}
async function main(){const plan=await verify();if(process.argv.includes('--verify-only')){console.log(JSON.stringify({...plan,clientStarts:0}));return;}
 const runs=[],scope=path.join(root,'.cache/nwn61/current-entry-budget-matrix-c');
 for(let i=0;i<order.length;i++){
  runs.push(await leg(order[i],i));
  fs.writeFileSync(path.join(scope,'matrix-partial.json'),JSON.stringify({plan,runs},null,2)+'\n');
  assert.equal(require(path.join(root,'tools/native-feature-manifest.cjs')).sourceIdentity(root).sha256,stage.sourceIdentity,'Source changed during exclusive measurement');
 }
 const file=path.join(scope,'matrix-review.json');
 fs.writeFileSync(file,JSON.stringify({issue:'NWN-61',success:true,plan,runs,scope:'Six current-source original-scene graphical replays; conditional environment diagnostics retained; no Arelith visual acceptance.'},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({file,sha256:hash(file),success:true}));
}
main().catch(error=>{console.error(error.stack);process.exitCode=1;});
