'use strict';
// Freeze a source-only NWN-61 API-batch candidate against the reviewed D
// continuation. The accepted engine, kernel, original assets and replay are
// identical. This script never launches a client or modifies accepted files.
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../..');
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const hash=file=>sha(fs.readFileSync(file));
const label=process.argv[2];
assert(/^[a-z0-9][a-z0-9-]{0,39}$/.test(label??''),'fresh safe label required');
const priorFile=path.join(root,'.cache/nwn61/tail-entry-d/pair.json');
assert.equal(hash(priorFile),'22857a7694a09ad668f3b0dd9f095aed834c903663e0a82089685e44e7e977b1');
const prior=JSON.parse(fs.readFileSync(priorFile));
const controlFile=prior.candidate.file;
assert.equal(hash(controlFile),prior.candidate.sha256);
const control=JSON.parse(fs.readFileSync(controlFile));
const expected=new Map(control.pins.map(row=>[row.relative,row.sha256]));
const files=['native_session_world.gd','systems/client_api/native_binding.gd','systems/client_api/entities.gd'];
assert.equal(expected.get(files[0]),'8cb77c208d16a847729af03284a637f1fd2bb4a8fcb0986f058e054fd724e009');
assert.equal(expected.get(files[1]),'40417e9c630d5493076a6da466a23e938a6727f58d0388faa99e7204bd887b0e');
assert.equal(expected.get(files[2]),'e70c7212eb3138021c9f8609bf54d4ebec235b6ce41296e0c8db52d596a5a1e6');
const source=file=>fs.readFileSync(path.join(control.sourceProject,file),'utf8');
function one(value,before,after,label){assert.equal(value.split(before).length,2,label+' seam changed');return value.replace(before,after);}
const session=one(one(source(files[0]),
 '\t\t\tvar result: Dictionary=entity_api_binding.entry_commit_step()\n',
 '\t\t\tvar result: Dictionary=entity_api_binding.entry_commit_steps(deadline_usec) if entity_api_binding.has_method("entry_commit_steps") else entity_api_binding.entry_commit_step()\n\t\t\tstate.api_calls=int(state.get("api_calls",0))+1\n\t\t\tstate.api_steps=int(state.get("api_steps",0))+int(result.get("steps",1))\n','session API'),
 '\t\t\tstate.receipt=receipt\n',
 '\t\t\treceipt.api_calls=int(state.get("api_calls",0));receipt.api_steps=int(state.get("api_steps",0))\n\t\t\tstate.receipt=receipt\n','session receipt');
const binding=one(source(files[1]),
 'func entry_commit_step() -> Dictionary:return _entities._entry_boundary_step()\n',
 'func entry_commit_step() -> Dictionary:return _entities._entry_boundary_step()\nfunc entry_commit_steps(deadline_usec: int,max_steps: int=64) -> Dictionary:return _entities._entry_boundary_steps(deadline_usec,max_steps)\n','binding API');
const entityAddition='\n# Keep the same one-row state machine and observer order while avoiding a\n# session/native-binding round trip for every metadata row. The deadline is\n# checked after each row so an observer can cancel the boundary immediately.\nfunc _entry_boundary_steps(deadline_usec: int,max_steps: int=64) -> Dictionary:\n\tvar result: Dictionary={"done":false}\n\tvar steps:=0\n\twhile steps<max_steps:\n\t\tresult=_entry_boundary_step()\n\t\tsteps+=1\n\t\tif result.get("done",false) or Time.get_ticks_usec()>=deadline_usec:break\n\tresult["steps"]=steps\n\treturn result\n';
const entities=one(source(files[2]),'\nfunc _cancel_entry_boundary() -> void:',entityAddition+'\nfunc _cancel_entry_boundary() -> void:','entity batch');
const overlays=new Map([[files[0],session],[files[1],binding],[files[2],entities]]);
for(const [file,text] of overlays)if(file!==files[0])assert.equal(sha(Buffer.from(text)),hash(path.join(root,file)),'working candidate changed: '+file);
const out=path.join(root,'.cache/nwn61',label);
assert(!fs.existsSync(out),'fresh output required');
const input=path.join(out,'candidate-input');fs.mkdirSync(input,{recursive:true});
let hardlinks=0;
for(const pin of control.pins){
 const relative=pin.relative;
 assert(!path.isAbsolute(relative)&&!relative.split(/[\\/]/).includes('..'),'unsafe pin');
 const from=path.join(control.sourceProject,relative),data=fs.readFileSync(from);
 assert.equal(sha(data),pin.sha256,'frozen source changed: '+relative);
 const to=path.join(input,relative);fs.mkdirSync(path.dirname(to),{recursive:true});
 if(overlays.has(relative))fs.writeFileSync(to,overlays.get(relative),{flag:'wx'});
 else if(/\.(exe|dll)$/i.test(relative)){fs.linkSync(from,to);hardlinks++;}
 else fs.writeFileSync(to,data,{flag:'wx'});
}
for(const relative of ['.tools/native-core/Godot_native_core_e_win64.exe','.tools/native-core/accepted-core-e.json']){
 const from=path.join(control.originalProject,relative),to=path.join(input,relative);
 fs.mkdirSync(path.dirname(to),{recursive:true});
 if(relative.endsWith('.exe')){assert.equal(hash(from),control.runtime.executableSha256);fs.linkSync(from,to);hardlinks++;}
 else fs.writeFileSync(to,fs.readFileSync(from),{flag:'wx'});
}
const selectionHelper=require(path.join(input,'tools/native-production-selection.cjs'));
const seeds=JSON.parse(fs.readFileSync(prior.preferenceSeeds.file,'utf8'));
selectionHelper.stageProductionSelection({project:input,label:label+'-candidate',argv:prior.argv,preferenceSeeds:seeds,env:{}}).then(async receipt=>{
 const candidate=await selectionHelper.readProductionSelection(receipt.file,receipt.sha256);
 const changed=candidate.pins.filter(pin=>expected.get(pin.relative)!==pin.sha256).map(pin=>pin.relative).sort();
 assert.deepEqual(changed,[...files].sort(),'unexpected source difference');
 assert.equal(candidate.runtime.executableSha256,control.runtime.executableSha256);
 assert.deepEqual(candidate.options,control.options);
 assert.deepEqual(candidate.preferences.expected,control.preferences.expected);
 const manifest={schema:'nwn61-entry-api-batch-pair-v1',label,control:{file:controlFile,sha256:prior.candidate.sha256,sourceProject:control.sourceProject},candidate:{file:receipt.file,sha256:receipt.sha256,sourceProject:candidate.sourceProject},changed,overlays:files.map(file=>({file,old:expected.get(file),candidate:sha(Buffer.from(overlays.get(file)))})),hardlinks,engineSha256:control.runtime.executableSha256,argv:prior.argv,scope:'Source-only matched original-entry pair; D continuation plus bounded session entity-API batching. The D session baseline predates later movement-window source. No timing or graphical claim.'};
 const file=path.join(out,'pair.json');fs.writeFileSync(file,JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({file,sha256:hash(file),changed,candidate:receipt.file,selectionSha256:receipt.sha256}));
}).catch(error=>{console.error(error);process.exitCode=1;});
