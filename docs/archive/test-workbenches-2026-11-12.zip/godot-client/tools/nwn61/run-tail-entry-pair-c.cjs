'use strict';
// Execute only after the coordinator grants an exclusive performance lease.
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const assert=require('node:assert/strict');
const {spawn}=require('node:child_process');
const root=path.resolve(__dirname,'../..');
const sha=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const pairFile=path.join(root,'.cache/nwn61/tail-entry-c/pair.json');
assert.equal(sha(pairFile),'0ebb388cc7acea5f3c88bd8341065d18a0eb0ab39df4759860c68856ef94425c');
const pair=JSON.parse(fs.readFileSync(pairFile));
const expectedDriver=new Map([
 ['tools/replay-native-loading.mjs','bc1f64c0469b055e565d6de92b5da1a2e1b079b7372451167a10ce929e4f6324'],
 ['tools/native-replay-diagnostics.mjs','a991e65b43b0b76c9d840bb73c30bd7f5d33720b10744b8ea07cdd486ca14506'],
 ['tools/native-replay-camera-evidence.mjs','224d678c30ed81894c0c57ae969f3488b3559cc590cdb06b5d2c1a3e284f5b31'],
 ['tools/native-loading-recording.mjs','3d1e1c31564a4bf4109d8c2130e3b13b5bca5ba022f944aa8dbc8c64461e66b8'],
 ['tools/native-loading-selection.mjs','cc3da02f36d40090291ae3ab8ab061d7fcef354d609e90a297d9e93d7a7d5e87']
]);
for(const [file,digest]of expectedDriver)assert.equal(sha(path.join(root,file)),digest,'Driver changed: '+file);
const capture=path.join(root,'.cache/loading-benchmark-worlds/arelith-archive-shaders-v1/recording.json');
assert(fs.existsSync(capture),'Sealed original capture is missing');
async function run(mode){
 const selected=pair[mode],name='nwn61-tail-entry-c-'+mode;
 assert.equal(sha(selected.file),selected.sha256,'Selection changed');
 const reportFile=path.join(root,'reports',name+'.json');
 assert(!fs.existsSync(reportFile),'Never overwrite an earlier run');
 const logFile=path.join(root,'.cache/nwn61/tail-entry-c',name+'.driver.log');
 const log=fs.createWriteStream(logFile,{flags:'wx'});
 const argv=[path.join(root,'tools/replay-native-loading.mjs'),'--capture=.cache/loading-benchmark-worlds/arelith-archive-shaders-v1','--generation=4','--production-selection='+selected.file,'--production-selection-sha256='+selected.sha256,'--engine=production-selection','--headless','--profiling=false','--observe-profile=false','--duration-ms=20000','--run='+name];
 console.log(JSON.stringify({starting:mode,report:reportFile,selection:selected.sha256}));
 const child=spawn(process.execPath,argv,{cwd:root,windowsHide:true,stdio:['ignore','pipe','pipe']});let tail='';
 for(const stream of [child.stdout,child.stderr])stream.on('data',bytes=>{log.write(bytes);tail=(tail+bytes.toString('utf8')).slice(-12000);});
 const timer=setTimeout(()=>child.kill(),180000);
 const code=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('exit',resolve);});
 clearTimeout(timer);await new Promise(resolve=>log.end(resolve));
 if(code!==0){console.error(tail);throw Error(mode+' driver failed '+code);}
 const report=JSON.parse(fs.readFileSync(reportFile));
 for(const field of ['success','sourceUnchanged','driverUnchanged','runtimeUnchanged'])assert.equal(report[field],true,mode+' '+field);
 assert.equal(report.engineOrLifetimeError,false);
 assert.equal(report.productionSelection.sha256,selected.sha256);
 return {mode,run:name,report:reportFile,sha256:sha(reportFile),selection:selected.sha256};
}
(async()=>{
 const results=[];
 for(const mode of ['control','candidate']){results.push(await run(mode));console.log(JSON.stringify({finished:mode,report:results.at(-1).sha256}));}
 const output=path.join(root,'.cache/nwn61/tail-entry-c/run-receipt.json');
 fs.writeFileSync(output,JSON.stringify({schema:'nwn61-revised-tail-entry-run-v1',pairSha256:sha(pairFile),results,scope:'Serial matched 20s original-recorded generation4 normal Core E headless runs. Collects loading and frame data; no graphical/Arelith acceptance.'},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({output,sha256:sha(output)}));
})().catch(error=>{console.error(error);process.exitCode=1;});
