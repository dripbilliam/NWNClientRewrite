extends SceneTree

const Current=preload("res://systems/network_motion.gd")
const Before=preload("res://.cache/nwn72/path-traversal-20261112a/before.gd")

var checks:=0
var failures: Array[String]=[]

func equal_state(label: String,left: Variant,right: Variant) -> void:
	checks+=1
	if var_to_bytes(left)!=var_to_bytes(right):failures.append(label)

func run() -> void:
	var paths: Array=[[],[Vector3(1.0,2.0,3.0)],[Vector3(1.0,2.0,3.0),Vector3(2.5,2.5,3.0),Vector3(4.0,3.0,3.0)]]
	for path_index in paths.size():
		var path: Array=paths[path_index]
		for cursor in [-5,-1,0,1,2,3,5]:
			for script in [0,1]:
				for dt in [0,16,100,500]:
					var input: Dictionary={"position":Vector3(0.5,1.0,3.0),"render":Vector3(0.5,1.0,3.0),"orientation":Vector3(0,1,0),"path":path,"cursor":cursor,"animation":2,"walkRate":120.0,"runRate":240.0,"script":script,"factor":1.25,"acceleration":0.5,"newPath":0}
					var old_state: Dictionary=input.duplicate(true)
					var new_state: Dictionary=input.duplicate(true)
					var old_distance: Dictionary=Before.distance(old_state,dt)
					var new_distance: Dictionary=Current.distance(new_state,dt)
					var label: String="path=%d cursor=%d script=%d dt=%d" % [path_index,cursor,script,dt]
					equal_state(label+" distance",old_distance,new_distance)
					equal_state(label+" distance state",old_state,new_state)
					if path.is_empty() or cursor<0 or cursor>=path.size():continue
					var old_motion=Before.new()
					var new_motion=Current.new()
					var old_step: Dictionary=old_motion.step_path(old_state,float(old_distance.distance))
					var new_step: Dictionary=new_motion.step_path(new_state,float(new_distance.distance))
					equal_state(label+" step",old_step,new_step)
					equal_state(label+" step state",old_state,new_state)
					for amount in [0.0,0.005,0.5,1.5,5.0]:
						var old_amount_state: Dictionary=input.duplicate(true)
						var new_amount_state: Dictionary=input.duplicate(true)
						var old_amount_motion=Before.new()
						var new_amount_motion=Current.new()
						equal_state(label+" amount=%f step" % amount,old_amount_motion.step_path(old_amount_state,amount),new_amount_motion.step_path(new_amount_state,amount))
						equal_state(label+" amount=%f state" % amount,old_amount_state,new_amount_state)
	var result: Dictionary={"passed":failures.is_empty(),"checks":checks,"failures":failures,"before_sha256":FileAccess.get_sha256("res://.cache/nwn72/path-traversal-20261112a/before.gd"),"current_sha256":FileAccess.get_sha256("res://systems/network_motion.gd"),"scope":"Exact distance and step result/state over path, cursor, script, dt and amount branches. No FPS claim."}
	print(JSON.stringify(result))
	quit(0 if failures.is_empty() else 1)

func _initialize() -> void:call_deferred("run")
