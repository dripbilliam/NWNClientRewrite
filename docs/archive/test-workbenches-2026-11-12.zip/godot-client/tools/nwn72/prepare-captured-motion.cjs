// Pure captured-data projection. No game/client/model/asset process is launched.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const arg=n=>process.argv.find(x=>x.startsWith('--'+n+'='))?.slice(n.length+3);
const capture=path.resolve(arg('capture')??'.cache/loading-benchmark-worlds/arelith-archive-v1');
const out=path.resolve(arg('out')??'.cache/nwn72/captured-entries-a.json');
const timeline=path.join(capture,'timeline.jsonl'),stat=fs.statSync(timeline);
if(stat.size>256*1024*1024)throw Error('Captured timeline exceeds existing256MiB bound');
const bytes=fs.readFileSync(timeline),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const recording=JSON.parse(fs.readFileSync(path.join(capture,'recording.json')));
if(recording.complete!==true||sha(bytes)!==recording.timelineSha256)throw Error('Sealed capture checksum differs');
let active=null;const entries=[],events=[];const fullStream=process.argv.includes('--full-stream');
for(const line of bytes.toString('utf8').split(/\r?\n/)){
 if(!line)continue;const record=JSON.parse(line);if(record.kind!=='frame')continue;const m=record.value;
 if(m.kind==='session-reset')events.push({kind:'reset',at:record.at});
 if(m.kind==='raw-world-begin')active=fullStream||m.data?.bridgeMode!=='delta'?{generation:m.generation,area:m.data.area.id,count:m.count,objects:[],controlled:m.data.controlledId,mode:m.data?.bridgeMode??'full',removed:m.data?.removedObjectIds??[]}:null;
 else if(m.kind==='raw-world-chunk'&&active)active.objects.push(...m.objects.map(o=>({id:o.id,areaId:o.areaId,objectType:o.objectType,nativeLifetime:o.nativeLifetime,clientKnownLifetime:o.clientKnownLifetime,replicationRemoved:o.replicationRemoved??false,replicated:o.replicated??{}})));
 else if(m.kind==='raw-world-end'&&active){if(active.objects.length!==active.count)throw Error('Incomplete captured full boundary');if(fullStream)events.push({kind:'snapshot',at:record.at,value:active});else entries.push(active);active=null;}
 else if(fullStream&&m.kind==='movement')events.push({kind:'movement',at:record.at,generation:m.generation,area:m.areaId,records:m.records});
}
fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,JSON.stringify({capture,timelineSha256:sha(bytes),scope:fullStream?'Captured ordered snapshot/movement inputs; no live temporal/combat mix claim':'Initial full captured motion inputs only; no live temporal/combat mix claim',entries,...(fullStream?{events}:{})}),{flag:'wx'});
console.log(JSON.stringify({file:out,sha256:sha(fs.readFileSync(out)),events:events.length,entries:entries.map(x=>({generation:x.generation,area:x.area,rows:x.count,creatures:x.objects.filter(o=>o.objectType===5&&!o.replicationRemoved&&o.areaId===x.area).length}))}));
