extends SceneTree
const Motion=preload("res://systems/network_motion.gd")
var before
var checks:=0
var failures: Array=[]
var output:=""
func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.trim_prefix("--report=")
	call_deferred("run")
func check(value: bool,label: String) -> void:
	checks+=1
	if not value and failures.size()<30:failures.append(label);push_error(label)
func snapshot(motion) -> PackedByteArray:
	return var_to_bytes([motion.objects,motion.remainder_ms,motion.next_lifetime,motion.last_delta_ms,motion._position_scope,motion._position_update,motion._position_next_token])
func entry(direction: Vector3,animation: int=0) -> Dictionary:
	return {"position":Vector3.ZERO,"orientation":direction,"animation":animation,"walkRate":2,"runRate":4}
func clean(motion) -> void:
	motion.facing_target_query=Callable();motion.height_query=Callable();motion.support_query=Callable()
	for binding in motion.positions_changed.get_connections():motion.positions_changed.disconnect(binding.callable)
func run() -> void:
	if output.is_empty() or FileAccess.file_exists(output):quit(2);return
	before=load("res://tools/nwn72/no_request_facing/network_motion_before.gd")
	var directions: Array=[Vector3(1,0,0),Vector3(0,1,0),Vector3(0.6,0.8,0),Vector3(0.70710677,0.70710677,0),Vector3(-1,-0.0,0),Vector3(-0.0,-1,0),Vector3.ZERO,Vector3(0.99,0.01,0.2),Vector3(1e20,1,0)]
	var eligible:=0;var full:=0
	for direction in directions:
		for animation in [0,1,2,4,53,54,80,109]:
			var original=before.new();var candidate:=Motion.new()
			var source:=entry(direction,animation)
			original.ensure(1,source);candidate.ensure(1,source)
			for seconds in [0.0,0.0004,0.0007,0.001,0.016,0.017,0.25,0.5]:
				for motion in [original,candidate]:motion.objects[1].correctionCue={"animation":26};motion.objects[1].facingTurn=81
				original.update(seconds);candidate.update(seconds)
				check(snapshot(original)==snapshot(candidate),"bit-exact stationary f32 orientation/cues animation%s direction%s dt%s"%[animation,direction,seconds])
			eligible+=int(candidate.evaluation_stats.stationary_settled);full+=int(candidate.evaluation_stats.facing_steps)
			clean(original);clean(candidate)
	# The cardinal algebra must preserve signed zeros and the ignored target
	# Z without assuming a normalized old vector or masking non-finite input.
	for vectors in [[Vector3(1,7,2),Vector3(1,-0.0,INF)],[Vector3(-9,-1,0),Vector3(-0.0,-1,NAN)],[Vector3(1,INF,0),Vector3(1,0,0)],[Vector3(NAN,1,0),Vector3(0,1,0)]]:
		var original=before.new();var candidate:=Motion.new()
		for motion in [original,candidate]:motion.ensure(1,entry(Vector3(1,0,0)));motion.objects[1].orientation=vectors[0];motion.objects[1].targetOrientation=vectors[1]
		original.update(0.016);candidate.update(0.016)
		check(snapshot(original)==snapshot(candidate),"cardinal signed-zero/non-finite behavior remains bit-exact")
		clean(original);clean(candidate)
	# A target can move, vanish, reappear or replace the source while its
	# observer remains stationary. The query must still run each frame.
	var original=before.new();var candidate:=Motion.new();var point: Array=[Vector3(2,0,0)];var calls: Array=[0,0]
	for motion in [original,candidate]:
		motion.ensure(1,entry(Vector3(1,0,0)));motion.objects[1].facingTarget=2
	original.facing_target_query=func(_id):calls[0]+=1;return point[0]
	candidate.facing_target_query=func(_id):calls[1]+=1;return point[0]
	for frame in 180:
		if frame==20:point[0]=Vector3(0,2,0)
		if frame==40:point[0]=null
		if frame==60:point[0]=Vector3(0,-3,7)
		if frame==80:
			for motion in [original,candidate]:motion.observe(1,{"orientation":[-1,0,0],"animation":53})
		if frame==100:
			for motion in [original,candidate]:motion.objects[1].visualAnimation=54;motion.objects[1].restingBase=1
		if frame==120:
			for motion in [original,candidate]:motion.observe(1,{"position":[2,1,0],"animation":0,"orientation":[0.6,0.8,0]},true)
		if frame==140:
			for motion in [original,candidate]:motion.objects[1].facingTarget=2
		original.update(0.016);candidate.update(0.016)
		check(snapshot(original)==snapshot(candidate),"moving/removed target, turn, visual animation, correction and source replacement frame"+str(frame))
	check(calls[0]==calls[1] and calls[1]>=120,"stationary fast path never suppresses target resolution")
	clean(original);clean(candidate)
	# Active prediction/path completion and reentrant immediate notifications.
	original=before.new();candidate=Motion.new();var logs: Array=[[],[]]
	for index in 2:
		var motion=original if index==0 else candidate
		motion.observe(1,{"position":[0,0,0],"path":[[0,0,0],[4,0,0]],"animation":2,"walkRate":2,"runRate":4},true)
		motion.positions_changed.connect(func(rows):
			var accepted: Array=[]
			for row in rows:accepted.append([row.native_position,motion.position_change_is_current(row)])
			logs[index].append(accepted)
			if logs[index].size()==3:motion.objects[1]=motion.objects[1].duplicate(true))
	for frame in 180:
		original.update(0.016);candidate.update(0.016)
		for motion in [original,candidate]:motion.finish_frame(1)
		check(snapshot(original)==snapshot(candidate),"active path and notification replacement frame"+str(frame))
	check(logs[0]==logs[1] and not logs[0].is_empty(),"immediate position notification batches and freshness match original")
	for motion in [original,candidate]:motion.configure([]);motion.configure([{"id":8,"state":entry(Vector3(0,1,0),1)}])
	original.update(0.017);candidate.update(0.017)
	check(snapshot(original)==snapshot(candidate),"area configure clears and wakes a new ordinary motion lifetime")
	clean(original);clean(candidate)
	var file:=FileAccess.open(output,FileAccess.WRITE);file.store_string(JSON.stringify({"checks":checks,"failures":failures,"passed":failures.is_empty(),"stationary_eligible":eligible,"full_facing_steps":full,"scope":"Frozen original bit-exact motion state and reentrant notification semantics; authored rows, no FPS or live-population claim"},"\t"));file.close();quit(0 if failures.is_empty() else 1)
