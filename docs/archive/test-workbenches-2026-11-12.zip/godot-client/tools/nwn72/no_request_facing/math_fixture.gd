extends SceneTree
const Current=preload("res://tools/nwn72/no_request_facing/network_motion_before.gd")
const Candidate=preload("res://systems/network_motion.gd")
var checks:=0
var failures: Array=[]
var output:=""
func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.trim_prefix("--report=")
	call_deferred("run")
func check(ok: bool,label: String) -> void:
	checks+=1
	if not ok and failures.size()<20:failures.append(label);push_error(label)
func run() -> void:
	if output.is_empty() or FileAccess.file_exists(output):quit(2);return
	var directions: Array=[Vector3(1,0,0),Vector3(0,1,0),Vector3(0.6,0.8,0),Vector3(-1,-0.0,0),Vector3(-0.0,-1,0),Vector3.ZERO,Vector3(0.99,0.01,0.2),Vector3(1e20,1,0),Vector3(NAN,1,0)]
	var animations: Array=[2,3,4,5,78,79,80,81,82,83,84,85,86,87,109]
	for old in directions:
		for target in directions:
			for animation in animations:
				for dt in [0,1,16,17,100,1000]:
					var result: Dictionary=Current.facing_step(old,target,animation,dt,{"modelType":1,"restored":1})
					var direct: Vector3=Candidate.facing_orientation_no_request(old,target,animation,dt)
					check(result.requests.is_empty() and var_to_bytes(result.orientation)==var_to_bytes(direct),"f32 orientation and request parity %s/%s/%s/%s"%[old,target,animation,dt])
	var file:=FileAccess.open(output,FileAccess.WRITE);file.store_string(JSON.stringify({"passed":failures.is_empty(),"checks":checks,"failures":failures,"scope":"Exact f32 no-request animation branch incl non-finite and signed zero; no FPS or original-scene claim"},"\t"));file.close();quit(0 if failures.is_empty() else 1)
