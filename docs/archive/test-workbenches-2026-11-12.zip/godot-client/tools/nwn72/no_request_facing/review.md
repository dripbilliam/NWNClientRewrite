# NWN-72 no-request facing branch, 2026-11-12

`systems/network_motion.gd` now computes orientation directly for animations outside 0, 1, 53 and 54. Those four keep the original `facing_step()` and turn-request ordering. The direct path copies the original binary32 rounding and trig sequence but avoids allocating a result Dictionary, requests Array and options Dictionary for animations that cannot request a turn. Normal detailed diagnostics still count an evaluated full facing step. The preceding source is frozen as `network_motion_before.gd` (SHA256 `9818d4bf7f7aab474c21609ffa802115bbe2d576026dafd7380255d148bae18d`); current source and the private candidate are byte-identical (SHA256 `7b943610ba9765c8052e22fccdeaf2ca0e33f27eb86917db8ac44be5ab1d0762`).

After integration, exact checks against the frozen preceding source passed:

- 7,290 binary32 orientation and empty-request cases covering 15 non-request animation IDs, signed zeros, non-finite vectors and multiple delta times.
- 943 facing and motion cases covering turn-request animations, moved/removed facing targets, external edits, active path, notification reentry and area reset.
- 12,196 ordered captured full/delta/movement, pose and gait checks across 8,688 creature-row observations, with zero state differences.

Quiet same-process captured-state ABBA component medians were **30/29/29/30 µs** for 13 creatures and **471/454/452/472 µs** for an explicit 16×, 208-creature scale (control/candidate/candidate/control). All final state digests matched. The synthetic scale is not a live population or FPS result. p95 varied, and this modest component saving does not explain the full busy-world callback. Raw reports: `.cache/nwn72/no-request-{math,facing,captured,component}-integrated-a.json` and the expanded pose/gait replay `.cache/nwn72/no-request-captured-integrated-b.json`.

No engine binary or native module was changed. NWN-72 remains In Progress pending busy live weighting, matched normal-client frame intervals and visual/effects acceptance.
