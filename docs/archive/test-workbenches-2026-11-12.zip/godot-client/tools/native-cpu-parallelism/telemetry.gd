extends Node
# Private-project optional autoload. Render/worker callbacks bind only immutable
# integer coordinates to the native bounded buffer; GDScript state stays main.
var probe: RefCounted
var path:=""
var end_us:=0
var next_us:=0
var drain_us:=0
var stopping:=false
var stopped:=false
var marker:=false
var tasks: Array[int]=[]
var rows: Array=[]
var overhead_us: Array=[]
var dropped:=0
var frequency:=0
func _ready() -> void:
	var args: Dictionary={}
	for arg in OS.get_cmdline_user_args():
		var pair:=arg.trim_prefix("--").split("=",true,1)
		if pair.size()==2:args[pair[0]]=pair[1]
	if args.get("nwn-cpu-probe","")!="on" or not args.has("nwn-cpu-report") or not ClassDB.class_exists("NwnCpuProbe"):set_process(false);return
	path=str(args["nwn-cpu-report"])
	if FileAccess.file_exists(path):push_error("NWN73 telemetry report already exists");set_process(false);return
	probe=ClassDB.instantiate("NwnCpuProbe");var now:=Time.get_ticks_usec();end_us=now+clampi(int(args.get("nwn-cpu-seconds",20)),1,60)*1000000;next_us=now;drain_us=now+1000000
	process_priority=10000
func drain() -> void:
	var packet: Dictionary=probe.call("take");rows.append_array(packet.samples);dropped+=int(packet.dropped);frequency=int(packet.qpc_frequency)
	for row in packet.samples:
		if int(row.channel)==3:marker=true
func _process(_delta: float) -> void:
	if probe==null or stopped:return
	for task in tasks.duplicate():
		if WorkerThreadPool.is_task_completed(task):WorkerThreadPool.wait_for_task_completion(task);tasks.erase(task)
	var now:=Time.get_ticks_usec()
	if not stopping and now>=end_us:
		stopping=true;RenderingServer.call_on_render_thread(Callable(probe,"capture").bind(3,probe.call("stamp")))
	if not stopping and now>=next_us:
		next_us=now+200000
		var began:=Time.get_ticks_usec();probe.call("capture",0,probe.call("stamp"));overhead_us.append(Time.get_ticks_usec()-began)
		RenderingServer.call_on_render_thread(Callable(probe,"capture").bind(1,probe.call("stamp")))
		if tasks.size()<2:tasks.append(WorkerThreadPool.add_task(Callable(probe,"capture").bind(2,probe.call("stamp")),false,"NWN73 sparse CPU placement sample"))
	if now>=drain_us or stopping:drain();drain_us=now+1000000
	if stopping and marker and tasks.is_empty():
		drain();stopped=true;set_process(false)
		var report:={"issue":"NWN-73","samples":rows,"qpcFrequency":frequency,"dropped":dropped,"mainCaptureOverheadUs":overhead_us,"separateRenderSetting":ProjectSettings.get_setting("rendering/driver/threads/thread_model"),"renderMethod":RenderingServer.get_current_rendering_method(),"pid":OS.get_process_id(),"godotMainThreadInternalId":OS.get_main_thread_id(),"intervalUs":200000,"scope":"Private sparse5Hz actualCPU/WindowsTID/cycles/priority/QoS and enqueue delay samples on main/render/worker callbacks. Samples are point observations, not continuous execution residency. Main capture overhead measured; native buffer shared only through its own mutex. No process policy/global changes, no frame/FPS measurement; disable for final FPS or match both sides."}
		var file:=FileAccess.open(path,FileAccess.WRITE)
		if file!=null:file.store_string(JSON.stringify(report,"\t"));file.close()
		probe=null
