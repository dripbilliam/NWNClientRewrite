'use strict';
// Source-only OFF/ON pair. No build, engine launch, credentials or asset copy.
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto'), assert = require('node:assert/strict');
const project = path.resolve(__dirname, '../..');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const read = file => fs.readFileSync(file);
const safe = value => typeof value === 'string' && /^[a-z0-9][a-z0-9-]{0,59}$/.test(value);
const helperPath = 'systems/native_data/raster_upload_preparation.gd';
const helperSHA = 'f54fdd3e77706bf1abb2b55a34d7bda7825317dd97b8a148a930b6df8327330c';
const setting = 'nwn/private/raster_upload_preparation';
function target(root, relative) {
  assert(relative && !path.isAbsolute(relative) && !relative.split(/[\\/]/).some(value => !value || value === '.' || value === '..'));
  const file = path.resolve(root, relative);
  assert(!path.relative(root, file).startsWith('..'));
  return file;
}
function put(root, relative, bytes) {
  const file = target(root, relative); fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, bytes);
  return { file: relative, bytes: bytes.length, sha256: sha(bytes) };
}
function functions(bytes) {
  const text = bytes.toString(), matches = [...text.matchAll(/^(?:static )?func\s+(\w+)\(/gm)], result = new Map();
  for (let index = 0; index < matches.length; index++) {
    result.set(matches[index][1], sha(Buffer.from(text.slice(matches[index].index, matches[index + 1]?.index ?? text.length))));
  }
  return result;
}
function proveFunctions(before, after, intentionallyChanged) {
  const original = functions(before), changed = functions(after), rows = [];
  for (const [name, digest] of original) {
    assert(changed.has(name), 'Original method disappeared: ' + name);
    if (!intentionallyChanged.includes(name)) assert.equal(changed.get(name), digest, 'Unrelated method changed: ' + name);
    rows.push({ name, beforeSHA256: digest, afterSHA256: changed.get(name), intentionallyChanged: intentionallyChanged.includes(name), byteExact: digest === changed.get(name) });
  }
  return rows;
}
function withSetting(bytes, enabled) {
  let text = bytes.toString(); assert(!text.includes('private/raster_upload_preparation='));
  const eol = text.includes('\r\n') ? '\r\n' : '\n';
  if (text.includes('[nwn]' + eol)) text = text.replace('[nwn]' + eol, '[nwn]' + eol + 'private/raster_upload_preparation=' + enabled + eol);
  else text += eol + '[nwn]' + eol + 'private/raster_upload_preparation=' + enabled + eol;
  return Buffer.from(text);
}
function verifyPair(pair) {
  assert.equal(sha(read(pair.parent.file)), pair.parent.sha256, 'Parent manifest changed');
  const difference = [];
  for (const leg of ['off', 'on']) {
    const allowed = new Set(pair.pins[leg].map(row => row.file));
    for (const row of pair.pins[leg]) {
      const bytes = read(target(pair[leg], row.file)); assert.equal(sha(bytes), row.sha256, 'Input changed: ' + leg + '/' + row.file); assert.equal(bytes.length, row.bytes);
    }
    function walk(relative = '') {
      for (const item of fs.readdirSync(path.join(pair[leg], relative), { withFileTypes: true })) {
        const name = path.posix.join(relative, item.name); assert(!item.isSymbolicLink(), 'Unexpected symlink: ' + name);
        if (item.isDirectory()) walk(name); else assert(allowed.has(name), 'Unexpected input: ' + name);
      }
    }
    walk();
    const actual = require(path.join(pair[leg], 'tools/native-feature-manifest.cjs')).sourceIdentity(pair[leg]).sha256;
    assert.equal(actual, pair.identities[leg]);
  }
  assert.equal(pair.pins.off.length, pair.pins.on.length);
  for (const row of pair.pins.off) if (sha(read(target(pair.on, row.file))) !== row.sha256) difference.push(row.file);
  assert.deepEqual(difference, ['project.godot'], 'OFF/ON must differ only by the pinned private project boolean');
  return { verified: true, difference, assertions: pair.assertions, identities: pair.identities };
}
function buildPair(label, parentLabel = 'entry62-v4-pair-a') {
  assert(safe(label) && safe(parentLabel));
  const parentFile = path.join(project, '.cache/nwn62/entry-pairs', parentLabel, 'pair.json'), parentBytes = read(parentFile), parent = JSON.parse(parentBytes);
  require('../nwn62/entry-pair.cjs').verifyPair(parent);
  assert(parent.review62?.snapshot === 'review-small-native-v4', 'Use the frozen default3ms V4 algorithm, not an entry-budget experiment');
  assert(parent.review62.assetServiceCompletionOnly.workerDecoderSemanticsUnchanged && parent.assertions.workerDecodeFunctionsByteExactPre70);
  const input = parent.candidate, original = new Map(parent.baseline.pins.map(row => [row.file, row]));
  original.set(parent.commonInfrastructure.file, { file: parent.commonInfrastructure.file, sha256: parent.commonInfrastructure.sha256 });
  for (const row of [...parent.overlayPins, ...parent.testOnlyOriginalFixtures]) original.set(row.file, row);
  const helperBytes = read(path.join(project, helperPath)); assert.equal(sha(helperBytes), helperSHA);
  assert(!original.has(helperPath), 'Parent unexpectedly includes a previous73 helper');
  const directory = path.join(project, '.cache/nwn73/entry-pairs', label); assert(!fs.existsSync(directory));
  const off = path.join(directory, 'off-input'), on = path.join(directory, 'on-input'), pins = { off: [], on: [] }, overlay = [], functionProof = {};
  const { transform } = require('./prepare-raster-adapters.cjs');
  const replacements = new Map();
  for (const relative of ['systems/native_data/asset_service.gd', 'systems/native_render/resource_pool.gd']) {
    const before = read(target(input, relative)), after = transform(relative, before); replacements.set(relative, after);
    functionProof[relative] = proveFunctions(before, after, relative.endsWith('asset_service.gd') ? ['request', 'publish_result', '_profile_process'] : ['texture', 'prepare_texture', 'snapshot', 'clear']);
    overlay.push({ file: relative, beforeSHA256: sha(before), afterSHA256: sha(after), bytes: after.length });
  }
  // Validate all parent bytes before making the new pair. Native hardlinks are
  // immutable inputs only; no code in this factory writes them after linking.
  for (const [relative, row] of original) assert.equal(sha(read(target(input, relative))), row.sha256, 'Audited parent changed: ' + relative);
  fs.mkdirSync(directory, { recursive: true });
  for (const [relative, row] of original) {
    const source = target(input, relative), before = read(source), bytes = replacements.get(relative) ?? before;
    for (const [leg, root] of [['off', off], ['on', on]]) {
      if (/\.(exe|dll)$/.test(relative)) {
        const file = target(root, relative); fs.mkdirSync(path.dirname(file), { recursive: true }); fs.linkSync(source, file);
        pins[leg].push({ file: relative, bytes: before.length, sha256: row.sha256, kind: 'immutable-native-hardlink' });
      } else pins[leg].push(put(root, relative, relative === 'project.godot' ? withSetting(bytes, leg === 'on') : bytes));
    }
  }
  for (const [leg, root] of [['off', off], ['on', on]]) pins[leg].push(put(root, helperPath, helperBytes));
  const identities = {};
  for (const [leg, root] of [['off', off], ['on', on]]) identities[leg] = require(path.join(root, 'tools/native-feature-manifest.cjs')).sourceIdentity(root).sha256;
  const pair = {
    version: 1, ticket: 'NWN-73', kind: 'source-only-raster-upload-entry-pair', directory, off, on,
    parent: { file: parentFile, sha256: sha(parentBytes), leg: 'candidate', source: input, snapshot: parent.review62.snapshot, assetServiceCompletionOnly: parent.review62.assetServiceCompletionOnly },
    setting: { name: setting, off: false, on: true, absentDefault: false, ingress: 'Explicit pinned private project setting only; no CLI/env/registry override' },
    helper: { file: helperPath, sha256: helperSHA, revision: 'raster-upload-v2', minimumTransformPixels: 256 * 256, originalFallbackPreserved: true },
    overlay, functionProof, pins, identities, preferences: parent.preferences, argv: parent.argv,
    infrastructure: { transformFile: 'tools/native-cpu-parallelism/prepare-raster-adapters.cjs', transformSHA256: sha(read(__filename.replace('prepare-raster-entry.cjs', 'prepare-raster-adapters.cjs'))), factoryFile: 'tools/native-cpu-parallelism/prepare-raster-entry.cjs', factorySHA256: sha(read(__filename)) },
    assertions: { sameApplicationCodeBothLegs: true, onlyProjectBooleanDiffers: true, allPre70WorkerDecodeFunctionsByteExactExceptExplicitPublishAdapter: true, all62ActorRigWorldConstructionSourcesByteExact: true, ordinaryPublicationBudgetUs: 3000, noMixed70Or72Overlay: true, noGlobalProjectOrAcceptedArtifactWrites: true, noOriginalAssetsOrCredentialsCopied: true, noBuildsStagingOrLaunches: true },
  };
  verifyPair(pair);
  const file = path.join(directory, 'pair.json'); fs.writeFileSync(file, JSON.stringify(pair, null, 2) + '\n', { flag: 'wx' });
  return { file, sha256: sha(read(file)), off, on, filesPerLeg: pins.off.length, overlay, identities };
}
module.exports = { buildPair, verifyPair };
if (require.main === module) {
  const [operation, label, parentLabel] = process.argv.slice(2);
  try {
    const result = operation === 'prepare' ? buildPair(label, parentLabel) : operation === 'verify' && safe(label) ? verifyPair(JSON.parse(read(path.join(project, '.cache/nwn73/entry-pairs', label, 'pair.json')))) : (() => { throw Error('Use prepare|verify label [parentLabel]'); })();
    console.log(JSON.stringify(result));
  } catch (error) { console.error(error.stack); process.exitCode = 1; }
}
