'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const project=path.resolve(__dirname,'../..'),[label,buildLabel]=process.argv.slice(2),sha=b=>crypto.createHash('sha256').update(b).digest('hex');assert(/^[a-z0-9-]+$/.test(label??''));assert(/^probe-[a-z0-9-]+$/.test(buildLabel??''));
const stage=path.join(project,'.cache/nwn73',label),view=path.join(stage,'project');assert(!fs.existsSync(stage));fs.mkdirSync(view,{recursive:true});const pins=[];
function put(relative,bytes){const target=path.join(view,relative);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,bytes,{flag:'wx'});pins.push({relative,bytes:bytes.length,sha256:sha(bytes)});}
const receiptFile=path.join(project,'.cache/nwn73',buildLabel,'probe-build/build-receipt.json'),receiptBytes=fs.readFileSync(receiptFile),receipt=JSON.parse(receiptBytes.toString().replace(/^\uFEFF/,''));assert(receipt.success);
const binary=fs.readFileSync(receipt.binary);assert.equal(sha(binary),receipt.binarySha256);put('.cache/nwn-cpu-probe.dll',binary);
for(const relative of ['tests/nwn73_probe_test.gd','tools/native-cpu-parallelism/telemetry.gd'])put(relative,fs.readFileSync(path.join(project,relative)));
put('project.godot',Buffer.from('config_version=5\n[application]\nconfig/name="NWN73 private CPU probe"\n[display]\nwindow/size/viewport_width=640\nwindow/size/viewport_height=360\nwindow/size/no_focus=true\nwindow/vsync/vsync_mode=0\n[rendering]\nrenderer/rendering_method="gl_compatibility"\ndriver/threads/thread_model=2\n'));
put('cpu_probe.gdextension',Buffer.from('[configuration]\nentry_symbol="nwn_cpu_probe_init"\ncompatibility_minimum="4.7"\nreloadable=false\n[libraries]\nwindows.x86_64="res://.cache/nwn-cpu-probe.dll"\n'));
put('.godot/extension_list.cfg',Buffer.from('res://cpu_probe.gdextension\n'));put('.godot/global_script_class_cache.cfg',Buffer.from('list=[]\n'));
const manifest={version:1,issue:'NWN-73',project:view,sourceBuildReceipt:{file:receiptFile,sha256:sha(receiptBytes)},privateBinarySha256:receipt.binarySha256,files:pins,scope:'Private actual CPU/TID probe correctness project; explicit separate-render setting verified by actual callback samples, never inferred from headless mode.'};
const file=path.join(stage,'manifest.json');fs.writeFileSync(file,JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({file,sha256:sha(fs.readFileSync(file)),project:view,binarySha256:receipt.binarySha256}));
