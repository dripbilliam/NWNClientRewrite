'use strict';
const fs = require('node:fs'), crypto = require('node:crypto'), assert = require('node:assert/strict');
const [output, ...inputs] = process.argv.slice(2); assert(output && inputs.length >= 2 && !fs.existsSync(output));
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
function summary(file) {
  const bytes = fs.readFileSync(file), r = JSON.parse(bytes), w = r.native.world, p = w.pool;
  assert(r.success && r.profilingRequested === false && r.sourceUnchanged && r.driverUnchanged && r.runtimeUnchanged && !r.engineOrLifetimeError && r.exit === 0);
  const phase = { coverage: 'PARTIAL retained creature model/table job phases; excludes unretained area/object jobs', retainedJobs: 0, phaseJobs: 0, prepared: 0, declinedTiny: 0, declinedNoTransform: 0, unsupported: 0, workerUs: 0, threads: [] };
  const actors = [];
  for (const batch of w.batches) {
    if (batch.jobs) actors.push({ models: batch.jobs.map(job => job.model).sort(), creatures: batch.rendered_creatures, items: batch.rendered_items, meshes: batch.meshes });
    for (const field of ['jobs', 'table_jobs']) for (const job of Array.isArray(batch[field]) ? batch[field] : []) {
      phase.retainedJobs++; const v = job.phases?.raster_upload_preparation; if (!v) continue;
      phase.phaseJobs++; phase.prepared += v.prepared; phase.declinedTiny += v.tiny; phase.declinedNoTransform += v.no_transform; phase.unsupported += v.unsupported; phase.workerUs += v.cpu_ms * 1000;
      if (!phase.threads.includes(v.thread)) phase.threads.push(v.thread);
    }
  }
  const output = { area: w.area_id, controlled: w.controlled_id, desired: w.desired, entities: w.entities, knownBaseExpected: w.base_scenery.expected, knownBaseResolved: w.base_scenery.resolved, knownBaseComplete: w.base_scenery.known_base_complete, unknownPlaceables: w.base_scenery.unknown_placeables, renderedTiles: w.terrain.rendered_tiles, actorJobs: actors, skinMeshes: w.actor_rigs.skin_meshes, missingClips: w.actor_rigs.missing_requested_clips, errors: w.errors, objectErrors: w.object_errors, gamma: r.native.gamma.gamma, cameraStatus: r.productionCameraVerification.status, cleanExit: r.native.clean_exit, workers: r.native.workers_remaining };
  return { file, sha256: hash(bytes), enabled: p.raster_upload_preparation.enabled, measurement: r.measurement, output, pool: p.raster_upload_preparation, retainedPhases: phase,
    timings: { firstPlayMs: r.measurement.playableAtMs, knownBaseCompleteMs: w.base_scenery_first_known_complete_ms, firstTileMs: w.terrain.first_tile_ms, completeTilesMs: w.terrain.complete_ms, maxTilePublicationMs: w.terrain.max_tile_publish_ms, maxTerrainPublicationMs: w.terrain.max_publish_ms, terrainPublicationMs: w.terrain.publish_ms, terrainTemplateMs: w.terrain.template_ms, actorPublicationMs: w.batches.filter(batch => batch.jobs).map(batch => batch.publication_ms), actorMaxPublicationMs: w.batches.filter(batch => batch.jobs).map(batch => batch.max_publication_ms) },
    cumulativeResources: { templates: p.templates_created, meshes: p.meshes_created, textures: p.textures_created, materials: p.materials_created },
    timingDependentWaves: w.batches.filter(batch => !batch.jobs).map(batch => ({ planned: batch.planned, rendered: batch.rendered, modelJobs: batch.model_jobs })),
  };
}
const rows = inputs.map(summary);
for (const row of rows) assert.deepEqual(row.output, rows[0].output, 'Logical end-state or retained actor model sets differ');
const result = { issue: 'NWN-73', success: true, logicalOutputMatches: true, rows,
  limitations: ['Headless bounded entry observation, not a completed20s or graphical/FPS acceptance.', 'Source/key byte invariants are proven by actual corpus integration and unchanged key-code/data boundaries; actual entry cache-key lists and pixel buffers are not retained.', 'Cumulative resource counts and wave scheduling differ; this is not exact transient-output or bitwise animation-frame parity.', 'OFF bookend drift exceeds any total loading improvement. Main completion/texture timers are absent with normal profiling=false; retained terrain/actor publication diagnostics are partial.'],
  verdict: 'Useful off-main work and correct logical output are demonstrated; dependable total entry latency/FPS benefit is unproven. Keep default OFF and private ON unpromoted pending balanced graphical review.',
};
fs.writeFileSync(output, JSON.stringify(result, null, 2) + '\n', { flag: 'wx' }); console.log(JSON.stringify({ output, sha256: hash(fs.readFileSync(output)), logicalOutputMatches: true, timings: rows.map(row => ({ enabled: row.enabled, ...row.timings })), resources: rows.map(row => row.cumulativeResources), phases: rows.map(row => row.retainedPhases) }));
