'use strict';
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto'), assert = require('node:assert/strict');
const project = path.resolve(__dirname, '../..'), [label, mode = 'wrapped'] = process.argv.slice(2);
assert(/^raster-localization-[a-z0-9-]+$/.test(label || ''));
assert(['wrapped', 'plain'].includes(mode));
const from = path.join(project, '.cache/nwn73/raster-integration-corpus-f');
const origin = fs.readFileSync(path.join(from, 'manifest.json')), manifest = JSON.parse(origin);
const out = path.join(project, '.cache/nwn73', label), view = path.join(out, 'project');
assert(!fs.existsSync(out)); fs.mkdirSync(view, { recursive: true });
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const pins = [];
for (const pin of manifest.pins) {
  const original = fs.readFileSync(path.join(manifest.project, pin.relative));
  assert.equal(sha(original), pin.sha256);
  let bytes = original;
  if (pin.relative === 'tests/nwn73_raster_asset_corpus_test.gd') {
    let source = original.toString();
    source = source.replace('var corpus_rows: Array=[]', 'func _initialize() -> void:\n\tprint("NWN73_LOCAL child initialize")\n\tcall_deferred("run")\nvar corpus_rows: Array=[]');
    source = source.replace('func run() -> void:\n', 'func run() -> void:\n\tprint("NWN73_LOCAL run begins")\n');
    source = source.replace('\tvar enabled:=mode!=', '\tprint("NWN73_LOCAL leg begins ",row.name," ",mode)\n\tvar enabled:=mode!=');
    source = source.replace('\tvar pool:=TimedPool.new();', '\tprint("NWN73_LOCAL before TimedPool.new")\n\tvar pool:=TimedPool.new();');
    source = source.replace('\tvar service:=Assets.new();', '\tprint("NWN73_LOCAL before Assets.new")\n\tvar service:=Assets.new();');
    source = source.replace('\tawait wait_task(service,id)', '\tprint("NWN73_LOCAL await task ",id)\n\tawait wait_task(service,id)\n\tprint("NWN73_LOCAL task completed")');
    source = source.replace('var texture: Texture2D=pool.texture(result)', 'var texture: Texture2D=pool.texture(result)');
    source = source.replace('\t\tvar callback_began:=', '\t\tprint("NWN73_LOCAL completion callback")\n\t\tvar callback_began:=');
    source = source.replace('\tservice.close();scope.free();pool.clear()', '\tprint("NWN73_LOCAL closing leg")\n\tservice.close();scope.free();pool.clear()');
    if (mode === 'plain') {
      source = source.replace('var pool:=TimedPool.new()', 'var pool:=Pool.new()');
      source = source.replaceAll('pool.adopt_us', '0');
      source = source.replace('\t\tvar texture_began:=', '\t\tprint("NWN73_LOCAL result keys ",result.keys())\n\t\tprint("NWN73_LOCAL source keys ",result.value.keys())\n\t\tprint("NWN73_LOCAL source mip type ",typeof(result.value.get("mips")))\n\t\tprint("NWN73_LOCAL source mip count ",result.value.mips.size())\n\t\tvar texture_began:=');
    }
    bytes = Buffer.from(source);
  }
  if (pin.relative === 'systems/native_render/resource_pool.gd') {
    let source = original.toString();
    source = source.replace('func texture(record: Dictionary) -> Texture2D:\n', 'func texture(record: Dictionary) -> Texture2D:\n\tprint("NWN73_LOCAL Pool.texture enter")\n');
    source = source.replace('func prepare_texture(record: Dictionary) -> Texture2D:\n', 'func prepare_texture(record: Dictionary) -> Texture2D:\n\tprint("NWN73_LOCAL Pool.prepare_texture enter")\n');
    source = source.replace('\tvar data: Dictionary = record.value; var mips: Array = data.mips', '\tprint("NWN73_LOCAL Pool before source data")\n\tvar data: Dictionary = record.value; var mips: Array = data.mips');
    source = source.replace('\t\timage = Image.create_from_data(width,height,mips.size()>1,image_format,bytes)', '\t\tprint("NWN73_LOCAL Pool before Image create ",width,"x",height," bytes=",bytes.size())\n\t\timage = Image.create_from_data(width,height,mips.size()>1,image_format,bytes)\n\t\tprint("NWN73_LOCAL Pool after Image create")');
    source = source.replace('\tvar result := ImageTexture.create_from_image(image)', '\tprint("NWN73_LOCAL Pool before texture create")\n\tvar result := ImageTexture.create_from_image(image)\n\tprint("NWN73_LOCAL Pool after texture create")');
    source = source.replace('\tretain("texture",textures,key,result,maximum_textures); stats.textures_created += 1', '\tprint("NWN73_LOCAL Pool before retain")\n\tretain("texture",textures,key,result,maximum_textures); stats.textures_created += 1\n\tprint("NWN73_LOCAL Pool after retain")');
    bytes = Buffer.from(source);
  }
  const target = path.join(view, pin.relative); fs.mkdirSync(path.dirname(target), { recursive: true }); fs.writeFileSync(target, bytes, { flag: 'wx' });
  pins.push({ relative: pin.relative, sha256: sha(bytes), originalSha256: pin.sha256 });
}
const receipt = { issue: 'NWN-73', originalManifestSha256: sha(origin), source: from, project: view, pins, scope: 'Untimed fixture-only breadcrumbs; exact frozen F project except declared test script override. Helper/adapter/accepted DLL unchanged.' };
fs.writeFileSync(path.join(out, 'manifest.json'), JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ project: view, label, manifestSha256: sha(fs.readFileSync(path.join(out, 'manifest.json'))) }));
