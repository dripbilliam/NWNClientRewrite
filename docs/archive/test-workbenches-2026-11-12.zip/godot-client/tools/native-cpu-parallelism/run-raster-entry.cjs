'use strict';
// Root invokes only under an exclusive native-test lease. No public connection.
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto'), { spawn } = require('node:child_process'), assert = require('node:assert/strict');
const project = path.resolve(__dirname, '../..'), [label, runLabel = 'nwn73-entry-a', mode = 'headless', only = 'all'] = process.argv.slice(2);
assert(/^[a-z0-9][a-z0-9-]{0,59}$/.test(label || '') && /^[a-z0-9][a-z0-9-]{0,59}$/.test(runLabel)); assert(['headless', 'visual'].includes(mode)); assert(['all', 'off', 'on'].includes(only));
const directory = path.join(project, '.cache/nwn73/entry-pairs', label), stagedFile = path.join(directory, 'staged.json'), stagedBytes = fs.readFileSync(stagedFile), staged = JSON.parse(stagedBytes);
const sha = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
function census(report) {
  const out = { coverage: 'PARTIAL: only retained creature batch model/table job phase records. Area/object streams do not retain every phase; this is not a complete source/job census.', retainedJobs: 0, phaseJobs: 0, preparedRows: 0, declinedRows: 0, tiny: 0, noTransform: 0, unsupported: 0, bytes: 0, helperWorkerMs: 0, threads: [] };
  for (const batch of report.native?.world?.batches || []) for (const field of ['jobs', 'table_jobs']) {
    for (const job of Array.isArray(batch[field]) ? batch[field] : []) {
      out.retainedJobs++; const row = job.phases?.raster_upload_preparation; if (!row) continue;
      out.phaseJobs++; out.preparedRows += row.prepared || 0; out.declinedRows += row.declined || 0; out.tiny += row.tiny || 0;
      out.noTransform += row.no_transform || 0; out.unsupported += row.unsupported || 0; out.bytes += row.bytes || 0; out.helperWorkerMs += row.cpu_ms || 0;
      if (!out.threads.includes(row.thread)) out.threads.push(row.thread);
    }
  }
  return out;
}
(async () => {
  const output = path.join(directory, runLabel + '-runs.json'); assert(!fs.existsSync(output), 'Retain prior run evidence');
  assert.equal(sha(staged.pair), staged.pairSHA256); const results = [];
  for (const selected of staged.selections) {
    if (only !== 'all' && selected.mode !== only) continue;
    assert.equal(sha(selected.file), selected.sha256); assert.equal(selected.profiling, 'false');
    const run = runLabel + '-' + selected.mode, reportFile = path.join(project, 'reports', run + '.json'); assert(!fs.existsSync(reportFile));
    const args = [path.join(project, 'tools/replay-native-loading.mjs'), '--capture=.cache/loading-benchmark-worlds/arelith-archive-shaders-v1', '--generation=4', '--production-selection=' + selected.file, '--production-selection-sha256=' + selected.sha256, '--engine=production-selection', '--profiling=false', '--observe-profile=false', '--run=' + run];
    if (mode === 'headless') args.push('--headless', '--duration-ms=20000'); else args.push('--preview', '--steady-ms=10000', '--settle-ms=5000');
    const log = fs.createWriteStream(path.join(directory, run + '.driver.log'), { flags: 'wx' });
    console.log(JSON.stringify({ starting: selected.mode, mode, run, selectionSHA256: selected.sha256 }));
    const child = spawn(process.execPath, args, { cwd: project, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] }); let tail = '';
    for (const stream of [child.stdout, child.stderr]) stream.on('data', bytes => { log.write(bytes); tail = (tail + bytes.toString()).slice(-12000); });
    const code = await new Promise((resolve, reject) => { child.on('error', reject); child.on('exit', resolve); }); await new Promise(resolve => log.end(resolve));
    if (code !== 0) { console.error(tail); throw Error(selected.mode + ' replay driver failed ' + code); }
    const report = JSON.parse(fs.readFileSync(reportFile));
    assert(report.success && report.profilingRequested === false && report.engineOrLifetimeError === false && report.sourceUnchanged && report.driverUnchanged && report.runtimeUnchanged && report.exit === 0, 'Strict replay acceptance failed');
    const result = { mode: selected.mode, run, report: reportFile, reportSHA256: sha(reportFile), success: report.success, profiling: report.profilingRequested, measurement: report.measurement, pool: report.native?.world?.pool?.raster_upload_preparation ?? null, retainedJobPhases: census(report), settledAt: report.settledAt, milestones: report.milestones };
    results.push(result); fs.writeFileSync(output, JSON.stringify({ issue: 'NWN-73', mode, only, stagedFile, stagedSHA256: sha(stagedFile), results, scope: 'Original recorded generation4 entry with strict default-off/on private selection and ordinary profiling=false. Full pool cold counters plus explicitly partial retained-job phase census. measurement.completed=false is a bounded loading observation, not a completed20s window. No live Arelith acceptance or performance conclusion implied by successful replay.' }, null, 2) + '\n');
    console.log(JSON.stringify({ finished: selected.mode, run, success: result.success, pool: result.pool, retainedJobPhases: result.retainedJobPhases }));
  }
})().catch(error => { console.error(error.stack); process.exitCode = 1; });
