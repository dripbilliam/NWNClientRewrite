param(
 [Parameter(Mandatory=$true)][int]$ClientPid,
 [Parameter(Mandatory=$true)][string]$Engine,
 [Parameter(Mandatory=$true)][ValidatePattern('^[a-f0-9]{64}$')][string]$EngineSha,
 [Parameter(Mandatory=$true)][int]$MainTid,
 [Parameter(Mandatory=$true)][int]$RenderTid,
 [Parameter(Mandatory=$true)][ValidateSet('baseline','performance-critical')][string]$Mode,
 [Parameter(Mandatory=$true)][ValidateRange(1,60)][int]$Seconds,
 [Parameter(Mandatory=$true)][string]$Report
)
$ErrorActionPreference='Stop'
$placementProject=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'));$placementReport=[IO.Path]::GetFullPath($Report)
$placementAllowed=[IO.Path]::GetFullPath((Join-Path $placementProject '.cache/nwn73/')).TrimEnd('\')+'\'
if(-not$placementReport.StartsWith($placementAllowed,[StringComparison]::OrdinalIgnoreCase)){throw 'Use private nwn73 output'}
if(Test-Path -LiteralPath $placementReport){throw 'Preserve previous placement receipt'}
Add-Type -Path (Join-Path $PSScriptRoot 'WindowsCpu.cs')
$placementEngine=[IO.Path]::GetFullPath($Engine);$placementProcess=Get-Process -Id $ClientPid
if(-not$placementProcess.Path.Equals($placementEngine,[StringComparison]::OrdinalIgnoreCase)-or(Get-FileHash -LiteralPath $placementEngine).Hash.ToLowerInvariant()-ne$EngineSha){throw 'Target is not the pinned client'}
$placementStarted=$placementProcess.StartTime.ToUniversalTime().ToFileTimeUtc()
$placementTopology=[NwnCpuParallelism.WindowsCpu]::Topology($placementProcess.Handle)
$placementClasses=@($placementTopology|Select-Object -ExpandProperty EfficiencyClass -Unique)
if($placementClasses.Count-lt2-and$Mode-ne'baseline'){throw 'No heterogeneous topology; no policy justified'}
$placementFastest=($placementClasses|Measure-Object -Maximum).Maximum
$placementIds=[uint32[]]@($placementTopology|Where-Object {$_.EfficiencyClass-eq$placementFastest-and(($_.Flags-band2)-eq0-or($_.Flags-band4)-ne0)}|Select-Object -ExpandProperty Id)
if($placementIds.Count-eq0){throw 'No available performance CPU sets'}
$placementRows=@();foreach($placementTid in @($MainTid,$RenderTid)|Select-Object -Unique){$placementPolicy=[NwnCpuParallelism.WindowsCpu]::InspectThread($placementTid);if($placementPolicy.ProcessId-ne$ClientPid){throw 'Probe thread does not belong to target client'};$placementRows+=@{id=$placementTid;creation=$placementPolicy.CreationFileTime;beforeSets=$placementPolicy.SelectedCpuSets;applied=$false;restored=$false;retired=$false}}
$placementState=@{version=1;issue='NWN-73';mode=$Mode;pid=$ClientPid;processCreation=$placementStarted;engine=$placementEngine;engineSha256=$EngineSha;beforePolicy=[NwnCpuParallelism.WindowsCpu]::InspectProcess($placementProcess.Handle,$ClientPid);performanceCpuSets=$placementIds;threads=$placementRows;startedUtc=[DateTime]::UtcNow.ToString('o');seconds=$Seconds;success=$false;scope='Bounded reversible per-client experiment. Only verified main/render thread selected CPU sets may change. Worker policies, process affinity/priority/QoS, global power plan and OS settings untouched. Exact original CPU sets restored in finally for the same process/thread lifetime.'}
New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($placementReport)) -Force|Out-Null
function Save-Placement {$placementState|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $placementReport -Encoding utf8}
Save-Placement
try{
 if($Mode-eq'performance-critical'){foreach($placementRow in $placementRows){[NwnCpuParallelism.WindowsCpu]::ChangeThreadCpuSets($placementRow.id,$ClientPid,$placementRow.creation,$placementIds);$placementRow.applied=$true;Save-Placement}}
 $placementState.activeUtc=[DateTime]::UtcNow.ToString('o');Save-Placement
 Start-Sleep -Seconds $Seconds
 $placementState.success=$true
}finally{
 foreach($placementRow in $placementRows){
  if(-not$placementRow.applied){continue}
  try{$placementCurrent=Get-Process -Id $ClientPid -ErrorAction Stop;if($placementCurrent.StartTime.ToUniversalTime().ToFileTimeUtc()-ne$placementStarted){throw 'Process identity changed'};$placementThread=[NwnCpuParallelism.WindowsCpu]::InspectThread($placementRow.id);if($placementThread.ProcessId-ne$ClientPid-or$placementThread.CreationFileTime-ne$placementRow.creation){throw 'Thread identity changed'};[NwnCpuParallelism.WindowsCpu]::ChangeThreadCpuSets($placementRow.id,$ClientPid,$placementRow.creation,[uint32[]]$placementRow.beforeSets);$placementAfter=[NwnCpuParallelism.WindowsCpu]::InspectThread($placementRow.id);if(($placementAfter.SelectedCpuSets-join',')-ne($placementRow.beforeSets-join',')){throw 'Original selected CPU sets did not restore'};$placementRow.restored=$true}catch{if(-not(Get-Process -Id $ClientPid -ErrorAction SilentlyContinue)){$placementRow.retired=$true}else{$placementRow.restoreError=$_.Exception.Message;$placementState.success=$false}}
 }
 $placementState.finishedUtc=[DateTime]::UtcNow.ToString('o');Save-Placement
}
$placementState|ConvertTo-Json -Depth 8
