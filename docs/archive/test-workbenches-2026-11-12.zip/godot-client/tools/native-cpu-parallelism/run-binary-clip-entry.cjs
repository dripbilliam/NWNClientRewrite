'use strict';
// Prepared original generation-4 entry. --verify-only is source-only. Actual
// replay requires coordinator's quiet lease; no graphical/FPS measurements.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict'),{spawn}=require('node:child_process');
const root=path.resolve(__dirname,'../..'),label=process.argv[2],verifyOnly=process.argv.includes('--verify-only');
assert(/^[a-z0-9-]+$/.test(label??''));
const directory=path.join(root,'.cache/nwn73',label),stagedFile=path.join(directory,'staged.json');
const staged=JSON.parse(fs.readFileSync(stagedFile)),sha=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const replayDriver=path.join(root,'tools/replay-native-loading.mjs');
const replayDriverSha256='872e3e8098a6f6f1c011ef48b725a03420f51007db7efeb62fa17f11b91d5920';
// The sandboxed Windows engine cannot read the system CA store. This exact
// startup diagnostic is the only permitted exception, as in the existing
// NWN-61 original-entry review; no script, lifetime, or other engine error is
// waived. The raw replay report retains failure and the full stderr.
const caDiagnostic=/ERROR: Failed to read the root certificate store\.\r?\n\s+at: get_system_ca_certificates \(platform\\windows\\os_windows\.cpp:2582\)/g;
function diagnosticAssessment(report){
 const errors=String(report.errors??'');
 const withoutCa=errors.replace(caDiagnostic,'');
 const caCount=(errors.match(caDiagnostic)??[]).length;
 const otherError=/SCRIPT ERROR|^ERROR:|ObjectDB.*leak|resources still in use/m.test(withoutCa);
 return {caCount,otherError,allowed:caCount===1&&!otherError&&report.failure==='Native engine/lifetime diagnostics observed'&&report.engineOrLifetimeError===true};
}
function verify(){
 assert(staged.private&&!staged.accepted&&!staged.production);
 assert.equal(sha(replayDriver),replayDriverSha256,'Shared replay driver pin changed');
 assert.equal(sha(staged.baseSelection),staged.baseSelectionSha256);
 for(const pin of staged.pins)assert.equal(sha(path.join(staged.input,pin.relative)),pin.sha256,'Private input changed '+pin.relative);
 const helper=require(path.join(staged.input,'tools/native-production-selection.cjs'));
 for(const selected of staged.selections){
  assert.equal(sha(selected.file),selected.sha256);
  const value=JSON.parse(fs.readFileSync(selected.file));helper.validatePins(value);helper.validatePreferencePins(value);
  assert.equal(value.featureSelection['binary-clips'].value,selected.mode);
  assert(value.featureSelection['binary-clips'].explicit&&value.flags.includes('--binary-clips='+selected.mode));
  assert.equal(value.mainSourceIdentity.sha256,selected.sourceIdentity);
  assert.equal(value.runtime.executableSha256,'753b3e188068efaf865bda3abd6322ebe44e3a98ef2f5d199c8af1a78624c98b');
  assert.equal(value.renderCore.nativeKernelSha256,'485741af15f0581a3c60c0f9a8ae738888eba08716c7a5c2c2d1bd550828963d');
 }
 assert.equal(staged.selections[0].sourceIdentity,staged.selections[1].sourceIdentity);
 return {verified:true,pins:staged.pins.length,selections:staged.selections.map(row=>({mode:row.mode,file:row.file,sha256:row.sha256})),noLaunches:true};
}
async function main(){
 const verified=verify();if(verifyOnly){console.log(JSON.stringify(verified));return;}
 const runs=[];const capture=path.join(root,'.cache/loading-benchmark-worlds/arelith-archive-shaders-v1');
 for(const [index,mode] of ['off','parallel','parallel','off'].entries()){
  verify();const selected=staged.selections.find(row=>row.mode===mode),run=`${label}-${index+1}-${mode}`;
  const reportFile=path.join(root,'reports',run+'.json');assert(!fs.existsSync(reportFile),'Preserve prior replay');
  const args=[path.join(root,'tools/replay-native-loading.mjs'),'--capture='+capture,'--generation=4','--production-selection='+selected.file,'--production-selection-sha256='+selected.sha256,'--engine=production-selection','--headless','--profiling=false','--observe-profile=false','--duration-ms=20000','--run='+run];
  const log=fs.createWriteStream(path.join(directory,run+'.driver.log'),{flags:'wx'});
  const child=spawn(process.execPath,args,{cwd:root,windowsHide:true,stdio:['ignore','pipe','pipe']});let tail='';
  for(const stream of [child.stdout,child.stderr])stream.on('data',bytes=>{log.write(bytes);tail=(tail+bytes.toString()).slice(-12000);});
  const code=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('exit',resolve);});await new Promise(resolve=>log.end(resolve));
  assert(fs.existsSync(reportFile),'Replay report missing '+run);
  const report=JSON.parse(fs.readFileSync(reportFile));
  const diagnostic=diagnosticAssessment(report);
  assert.equal(sha(replayDriver),replayDriverSha256,'Shared replay driver changed during '+run);
  assert(report.sourceUnchanged&&report.driverUnchanged&&report.runtimeUnchanged&&report.exit===0,'Original-entry source/runtime pin failed '+run);
  assert((code===0&&report.success&&report.engineOrLifetimeError===false)||
    (code===1&&report.success===false&&diagnostic.allowed),
    'Unaccepted original-entry diagnostic '+run+' '+JSON.stringify({code,diagnostic,failure:report.failure,tail}));
  assert.equal(report.productionSelection.sha256,selected.sha256);
  const helper=report.native?.binary_clip_helper;
  assert(helper&&helper.active===0&&helper.enabled===(mode==='parallel'),'Actual binary clip helper report missing '+run);
  if(mode==='parallel')assert(helper.started>0,'Selected route never engaged '+run);
  const native=report.native??{};
  const orderedMilestones=report.milestones.map(row=>[row.kind,row.generation??0,row.serial??0]);
  const milestoneIdentity=crypto.createHash('sha256').update(JSON.stringify(orderedMilestones)).digest('hex');
  runs.push({mode,run,selection:selected.sha256,report:reportFile,reportSha256:sha(reportFile),helper,milestoneIdentity,playable:native.playable,received:native.received_snapshots,objectVisualsComplete:native.object_visuals_complete,protocolFinishAck:native.protocol_finish_ack,completeWorld:report.measurement?.completeWorld,milestones:report.milestones,peakStaticBytes:native.presentation_state?.static_memory_bytes??null,diagnostic});
  fs.writeFileSync(path.join(directory,'runs-partial.json'),JSON.stringify({issue:'NWN-73',runs},null,2)+'\n');
  verify();
 }
 assert(runs.every(row=>row.milestoneIdentity===runs[0].milestoneIdentity&&row.playable===true&&row.received===runs[0].received&&row.objectVisualsComplete===true&&row.protocolFinishAck===true&&row.completeWorld===true),'Original-entry ordered milestones/completion mismatch');
 const result={issue:'NWN-73',success:true,stagedFile,stagedSha256:sha(stagedFile),replayDriverSha256,runs,scope:'Same frozen Core E/source/assets/preferences original generation-4 headless OFF/ON/ON/OFF. Strict selection/source/driver/output and actual helper engagement. Only the exact sandbox Windows CA-store diagnostic is allowed; raw replay receipts remain failed. Loading milestones only; no graphical/FPS or Arelith acceptance.'};
 const file=path.join(directory,'review.json');fs.writeFileSync(file,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({file,sha256:sha(file),runs:runs.map(row=>({mode:row.mode,helper:row.helper.started,playable:row.playable,milestones:row.milestones.length}))}));
}
main().catch(error=>{console.error(error.stack);process.exitCode=1;});
