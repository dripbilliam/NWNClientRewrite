'use strict';
// Coordinator-scheduled, headless original-source component ABBA only.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict'),cp=require('node:child_process');
const project=path.resolve(__dirname,'../..'),label=process.argv[2];
assert(/^[a-z0-9-]+$/.test(label??''),'Fresh safe label required');
const out=path.join(project,'.cache/nwn73',label);assert(!fs.existsSync(out));fs.mkdirSync(out,{recursive:true});
const sha=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const engine=path.join(project,'.tools/native-core/Godot_native_core_e_win64.exe');
const actor=path.join(project,'systems/native_data/actor_model.gd');
const fixture=path.join(project,'tests/nwn73_binary_clip_overlap_test.gd');
const expected={engine:'753b3e188068efaf865bda3abd6322ebe44e3a98ef2f5d199c8af1a78624c98b',actor:'54ffff532c74a161ca2525228ce7c78a5377abbdff88e47c128c1e83e29a9a1a'};
assert.equal(sha(engine),expected.engine);assert.equal(sha(actor),expected.actor);
const fixtureSha=sha(fixture),rows=[];
for(const [index,mode] of ['off','on','on','off'].entries()){
 const stem=`${index+1}-${mode}`,file=path.join(out,stem+'.json');
 const args=['--headless','--path',project,'--script','res://tests/nwn73_binary_clip_overlap_test.gd','--','--report='+file];
 if(mode==='on')args.push('--binary-clips=parallel');
 const run=cp.spawnSync(engine,args,{cwd:project,windowsHide:true,encoding:'utf8',timeout:30000,maxBuffer:1024*1024});
 fs.writeFileSync(path.join(out,stem+'.log'),(run.stdout??'')+(run.stderr??''),{flag:'wx'});
 assert.equal(run.status,0,stem+' engine failed '+run.error+' '+run.stderr);
 assert(fs.existsSync(file),stem+' report missing, check script parse/log error');
 const report=JSON.parse(fs.readFileSync(file));assert(report.success&&report.selected===(mode==='on'));
 assert.equal(report.actor_source_sha256,expected.actor);assert.equal(report.rows.length,3);
 assert.equal(report.sources[0].sha256,'a38c9f0de00a7e401419d1e668ad1b9d825cfc9635712cdb9ae63e840104ee2b');
 assert.equal(report.sources[1].sha256,'c95e0587de016d97379e5ed5ebc5b3a093d2f7e66af1ab86d9ff28cf993447b3');
 rows.push({mode,file,sha256:sha(file),report});
}
for(const pair of [0,1,2,3])for(let sample=0;sample<3;++sample)for(const source of ['a','b'])assert.equal(rows[pair].report.rows[sample][source].digest,rows[0].report.rows[0][source].digest,'Exact original decoded source changed');
assert.equal(sha(engine),expected.engine);assert.equal(sha(actor),expected.actor);assert.equal(sha(fixture),fixtureSha);
const quantiles=values=>{values.sort((a,b)=>a-b);return {median_us:values[Math.floor(values.length/2)],p95_us:values[Math.ceil(values.length*.95)-1],min_us:values[0],max_us:values.at(-1)};};
const summary=rows.map(({mode,file,sha256,report})=>({mode,file,sha256,wall:quantiles(report.rows.map(row=>row.wall_us)),a:quantiles(report.rows.map(row=>row.a.elapsed_us)),b:quantiles(report.rows.map(row=>row.b.elapsed_us)),helpers:report.helpers}));
const review={issue:'NWN-73',success:true,sourcePins:{engine:expected.engine,actor:expected.actor,fixture:fixtureSha},rows:summary,scope:'Same frozen original a_ba/a_dfa bytes, two concurrent WorkerThreadPool actor decodes, 3 repetitions x OFF/ON/ON/OFF fresh processes. Exact parsed model digests across all modes. Headless component timing only; no original entry, visual, FPS or totalCPU claim.'};
const reviewFile=path.join(out,'review.json');fs.writeFileSync(reviewFile,JSON.stringify(review,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({file:reviewFile,sha256:sha(reviewFile),rows:summary.map(row=>({mode:row.mode,wall:row.wall,helpers:row.helpers.started}))}));
