# NWN-73 snapshot metadata worker priority, 2026-11-12

Read-only triage of the existing `--world-snapshot-preparation=workers` option. The current ordinary generation-2 replay (`reports/nwn61-current-entry-a-staged.json`) used the default script path: metadata worker submitted/completed zero tasks and `received_metadata.prepared_rows` was zero. The worker option is implemented, with a two-task cap, ordered 512-row packets, verified source borrowing and a scoped admission barrier; this note adds no new concurrency or flag.

Three saved original-entry runs with worker preparation actually engaged each admitted 2,017 metadata rows:

| Report | Completed tasks | Worker CPU total | Largest task | Peak concurrent tasks | First playable |
| --- | ---: | ---: | ---: | ---: | ---: |
| `nwn73-height-movement-k3-off-1` | 6 | 39.828 ms | 12.323 ms | 2 | 4046.145 ms |
| `nwn73-height-movement-k3-worker-2` | 23 | 36.898 ms | 3.765 ms | 2 | 3716.897 ms |
| `nwn64-epoch-off-a2` | 6 | 41.813 ms | 14.631 ms | 2 | 4421.100 ms |

These are different runs/settings, not a matched A/B. The worker CPU total is the most the main thread could recover by perfect overlap if the corresponding script work cost were equal. Tens of milliseconds are useful for entry, but cannot explain multi-second loading or recurring frame losses here. Existing worker jobs already reached the configured two-task cap. Prior asset-job queue audit found a very short Godot worker-pool queue (median 0.013 ms) and a longer asset-service queue (median about 15 ms); that is a different owner and does not imply metadata workers need a larger pool.

Rank below the measured world-commit and publication tails, and below recurring particle/movement work. Do not change the default or increase worker count from these snapshots. A future matched original-entry pair may isolate worker metadata latency and memory when a clean PC window is available.
