'use strict';
// Stage one current-source production selection per mode. No client launch.
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../..');
const hash=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const baseFile=path.join(root,'.cache/native-presentation-parity/production-replay/nwn62-drive-reindex-control-c/production-selection.json');
const base=JSON.parse(fs.readFileSync(baseFile,'utf8'));
const helper=require('../native-production-selection.cjs');
assert(base.complete&&base.production&&base.version===3);
assert.equal(base.renderCore.engineSha256,'753b3e188068efaf865bda3abd6322ebe44e3a98ef2f5d199c8af1a78624c98b');
assert.equal(base.renderCore.nativeKernelSha256,'485741af15f0581a3c60c0f9a8ae738888eba08716c7a5c2c2d1bd550828963d');
assert.equal(base.profiling,'false');
assert.equal(hash(path.join(root,'systems/native_render/drive_collision_indexed.gd')),'f3c2b35e783dd7d0dec24a1978a6f47edc2e3024ef2f37d8b158b6a8cfaca928');
const seeds={version:1,expected:base.preferences.expected,description:'NWN-73 current-source preview worker surface-cache pair'};
for(const name of ['render','layout'])seeds[name]={file:path.join(path.dirname(baseFile),base.preferences[name].relative),sha256:base.preferences[name].sha256};
const capture='C:/Users/Niflheim/AppData/Roaming/nwn-model-viewer-research/native-loading-recordings/capture-YaH3xf';
const recordingFile=path.join(capture,'recording.json');
assert.equal(hash(recordingFile),'1913892cd42db0f68dfa1b0edbdd37be4c380bdda50c95c178dc4ca2ba38a463');
const recording=JSON.parse(fs.readFileSync(recordingFile,'utf8'));
assert.equal(recording.timelineSha256,'6ce44bfe52a7bd8c3b08e936206360847cd3bb1ec1713bd1d21c7304882d3920');
assert.equal(recording.metadata.movementTiming,true);
const label=process.argv[2];
assert(/^[a-z0-9][a-z0-9-]{0,40}$/.test(label??''),'Fresh short label required');
const output=path.join(root,'.cache/nwn73',label);
assert(!fs.existsSync(output),'Refuse to overwrite pair receipt');
const common=[...base.options,'--drive-collision=indexed','--drive-preview-worker=on'];
const stable=rows=>JSON.stringify(rows.map(({relative,sha256})=>[relative,sha256]).sort((a,b)=>a[0].localeCompare(b[0])));
(async()=>{
 const selections=[];
 for(const mode of ['off','on']){
  const row=await helper.stageProductionSelection({project:root,label:label+'-'+mode,argv:[...common,'--drive-preview-surface-cache='+mode],preferenceSeeds:seeds,env:{}});
  const selection=row.selection;
  assert.equal(selection.featureSelection['drive-preview-worker'].value,'on');
  assert.equal(selection.featureSelection['drive-preview-surface-cache'].value,mode);
  assert.equal(selection.featureSelection['drive-preview-surface-cache'].explicit,true);
  assert(selection.flags.includes('--drive-preview-surface-cache='+mode));
  assert.equal(selection.renderCore.engineSha256,base.renderCore.engineSha256);
  assert.equal(selection.renderCore.nativeKernelSha256,base.renderCore.nativeKernelSha256);
  assert.equal(selection.profiling,'false');
  selections.push({mode,file:row.file,sha256:row.sha256,sourceProject:selection.sourceProject,sourceIdentity:selection.mainSourceIdentity.sha256,pins:selection.pins.length,flags:selection.flags,renderCore:selection.renderCore,pinDigest:crypto.createHash('sha256').update(stable(selection.pins)).digest('hex')});
 }
 assert.equal(selections[0].sourceIdentity,selections[1].sourceIdentity,'Source changed between modes');
 assert.equal(selections[0].pinDigest,selections[1].pinDigest,'Pinned source differs between modes');
 assert.deepEqual(selections[0].renderCore,selections[1].renderCore);
 const a=selections[0].flags.filter(x=>!x.startsWith('--drive-preview-surface-cache='));
 const b=selections[1].flags.filter(x=>!x.startsWith('--drive-preview-surface-cache='));
 assert.deepEqual(a,b,'Other runtime flags differ');
 for(const row of selections){
  const loaded=await helper.readProductionSelection(row.file,row.sha256);
  assert.equal(loaded.mainSourceIdentity.sha256,row.sourceIdentity);
 }
 fs.mkdirSync(output,{recursive:true});
 const plan={issue:'NWN-73',version:1,status:'staged-no-launch',accepted:false,productionPair:true,baseSelection:baseFile,baseSelectionSha256:hash(baseFile),capture,recordingSha256:hash(recordingFile),timelineSha256:recording.timelineSha256,expectedMovementInputs:360,selections:selections.map(({renderCore,...row})=>row),scope:'Same source, engine, preferences and original-input capture. Both legs select the existing whole-preview worker; only detached surface packet cache differs. No FPS, launch or Arelith claim.',nextGate:'Exclusive OFF/ON/ON/OFF normal-client movement replay: strict source/runtime/milestone/path packet acceptance; worker admission/stale/busy counts, snapshot/worker/blocked keyboard tails, frame median/p95/p99/worst, first playable/full base and peak memory. Reject if caching does not lower the frame-critical path.'};
 const file=path.join(output,'plan.json');fs.writeFileSync(file,JSON.stringify(plan,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({file,sha256:hash(file),sourceIdentity:selections[0].sourceIdentity,pins:selections[0].pins,recordingSha256:plan.recordingSha256,flags:selections.map(x=>x.flags.filter(f=>f.startsWith('--drive-preview')))}));
})().catch(error=>{console.error(error.stack);process.exitCode=1;});
