'use strict';
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto'), assert = require('node:assert/strict');
const project = path.resolve(__dirname, '../..'), sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
async function stage(label) {
  assert(/^[a-z0-9][a-z0-9-]{0,59}$/.test(label || ''));
  const pairFile = path.join(project, '.cache/nwn73/entry-pairs', label, 'pair.json'), bytes = fs.readFileSync(pairFile), pair = JSON.parse(bytes);
  const output = path.join(pair.directory, 'staged.json'); assert(!fs.existsSync(output), 'Preserve prior staging');
  for (const [file, expected] of [[pair.infrastructure.factoryFile, pair.infrastructure.factorySHA256], [pair.infrastructure.transformFile, pair.infrastructure.transformSHA256]]) {
    assert.equal(sha(fs.readFileSync(path.join(project, file))), expected, 'Source-only factory changed since preparation');
  }
  require('./prepare-raster-entry.cjs').verifyPair(pair);
  const parent = JSON.parse(fs.readFileSync(pair.parent.file)), selectionPath = 'tools/native-production-selection.cjs';
  assert.equal(sha(fs.readFileSync(path.join(project, selectionPath))), parent.commonInfrastructure.sha256, 'Use unchanged audited production helper');
  assert.equal(sha(fs.readFileSync(pair.preferences.file)), pair.preferences.sha256);
  const seeds = JSON.parse(fs.readFileSync(pair.preferences.file)), helper = require(path.join(project, selectionPath));
  const selections = [];
  for (const mode of ['off', 'on']) {
    const row = await helper.stageProductionSelection({ project: pair[mode], label: label + '-' + mode, argv: pair.argv, preferenceSeeds: seeds, env: {} });
    assert.equal(row.selection.profiling, 'false');
    const settings = fs.readFileSync(path.join(row.selection.sourceProject, 'project.godot'), 'utf8');
    assert(settings.includes('private/raster_upload_preparation=' + (mode === 'on')));
    selections.push({ mode, file: row.file, sha256: row.sha256, source: row.selection.sourceProject, engine: row.selection.engine, profiling: row.selection.profiling });
  }
  // Staging creates only the known private output subtree. Every original
  // prepared source and its comparable identity must still match afterward.
  for (const mode of ['off', 'on']) {
    for (const pin of pair.pins[mode]) assert.equal(sha(fs.readFileSync(path.join(pair[mode], pin.file))), pin.sha256, 'Input changed during staging');
    assert.equal(require(path.join(pair[mode], 'tools/native-feature-manifest.cjs')).sourceIdentity(pair[mode]).sha256, pair.identities[mode]);
  }
  const result = { pair: pairFile, pairSHA256: sha(bytes), selections, noLaunches: true, noBuilds: true, acceptedArtifactWrites: false, sourceInputsUnchanged: true, helperSHA256: parent.commonInfrastructure.sha256, scope: 'Source-only staging through the unchanged production selector. Same frozen V4/pre70 implementation plus optional73 raster worker sidecar; only pinned private OFF/ON project boolean differs. No entry/performance acceptance yet.' };
  fs.writeFileSync(output, JSON.stringify(result, null, 2) + '\n', { flag: 'wx' }); return { file: output, sha256: sha(fs.readFileSync(output)), ...result };
}
module.exports = { stage };
if (require.main === module) stage(process.argv[2]).then(result => console.log(JSON.stringify(result))).catch(error => { console.error(error.stack); process.exitCode = 1; });
