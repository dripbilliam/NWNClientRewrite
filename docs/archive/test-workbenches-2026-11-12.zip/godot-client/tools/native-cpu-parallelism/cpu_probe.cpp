// Private read-only placement telemetry. No scheduling, affinity, scene or
// renderer mutation; each retained RefCounted owns a bounded local buffer.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <Windows.h>
#include "gdextension_interface.h"
#include <array>
#include <cstdint>
#include <mutex>
#include <stdexcept>
#include <vector>
namespace {
GDExtensionClassLibraryPtr library;
GDExtensionInterfaceVariantNewNil new_nil;GDExtensionInterfaceVariantNewCopy new_copy;GDExtensionInterfaceVariantDestroy destroy;
GDExtensionInterfaceVariantGetType get_type;GDExtensionInterfaceGetVariantFromTypeConstructor from_type;GDExtensionInterfaceGetVariantToTypeConstructor to_type;
GDExtensionInterfaceVariantConstruct construct;GDExtensionInterfaceVariantSetKeyed set_keyed;GDExtensionInterfaceVariantCall variant_call;
GDExtensionInterfaceStringNameNewWithUtf8Chars name_new;GDExtensionInterfaceVariantGetPtrDestructor destructor;
GDExtensionInterfaceStringNewWithUtf8Chars string_new;
GDExtensionInterfaceClassdbRegisterExtensionClass6 register_class;GDExtensionInterfaceClassdbRegisterExtensionClassMethod register_method;
GDExtensionInterfaceClassdbUnregisterExtensionClass unregister_class;GDExtensionInterfaceClassdbConstructObject3 construct_object;GDExtensionInterfaceObjectSetInstance set_instance;
GDExtensionVariantFromTypeConstructorFunc integer_from,name_from,object_from;GDExtensionTypeFromVariantConstructorFunc integer_to;
struct Name {alignas(8) uint8_t data[8];explicit Name(const char* value){name_new(data,value);}~Name(){destructor(GDEXTENSION_VARIANT_TYPE_STRING_NAME)(data);}Name(const Name&)=delete;};
struct Var {
 alignas(8) uint8_t data[24];Var(){new_nil(data);}~Var(){destroy(data);}Var(const Var& value){new_copy(data,value.data);}Var& operator=(const Var&)=delete;
 static Var integer(int64_t value){Var out;destroy(out.data);integer_from(out.data,&value);return out;}
 static Var container(GDExtensionVariantType type){Var out;destroy(out.data);GDExtensionCallError error{};construct(type,out.data,nullptr,0,&error);if(error.error!=GDEXTENSION_CALL_OK)throw std::runtime_error("Private probe packet construction failed");return out;}
};
void field(Var& row,const char* label,int64_t value){Name name(label);Var key;destroy(key.data);name_from(key.data,name.data);auto scalar=Var::integer(value);GDExtensionBool valid=false;set_keyed(row.data,key.data,scalar.data,&valid);if(!valid)throw std::runtime_error("Private probe packet field failed");}
void append(Var& array,const Var& value){Name name("append");const GDExtensionConstVariantPtr args[]={value.data};Var result;destroy(result.data);GDExtensionCallError error{};variant_call(array.data,name.data,args,1,result.data,&error);if(error.error!=GDEXTENSION_CALL_OK)throw std::runtime_error("Private probe packet append failed");}
struct Sample {int64_t sequence=0,channel=0,submitted=0,qpc=0,cycles=0,pid=0,tid=0,group=0,cpu=0,priority=0,power_control=0,power_state=0,power_error=0;};
struct Owner {
 static constexpr size_t capacity=4096;std::mutex mutex;std::vector<Sample> samples;uint64_t sequence=0,dropped=0;
 Owner(){samples.reserve(capacity);}
 void capture(int64_t channel,int64_t submitted){
  Sample sample;sample.channel=channel;sample.submitted=submitted;PROCESSOR_NUMBER processor{};GetCurrentProcessorNumberEx(&processor);sample.group=processor.Group;sample.cpu=processor.Number;sample.tid=GetCurrentThreadId();sample.pid=GetCurrentProcessId();
  LARGE_INTEGER now{};QueryPerformanceCounter(&now);sample.qpc=now.QuadPart;ULONG64 cycles=0;if(QueryThreadCycleTime(GetCurrentThread(),&cycles))sample.cycles=static_cast<int64_t>(cycles);sample.priority=GetThreadPriority(GetCurrentThread());
  THREAD_POWER_THROTTLING_STATE power{};power.Version=THREAD_POWER_THROTTLING_CURRENT_VERSION;if(GetThreadInformation(GetCurrentThread(),ThreadPowerThrottling,&power,sizeof(power))){sample.power_control=power.ControlMask;sample.power_state=power.StateMask;}else sample.power_error=GetLastError();
  std::lock_guard<std::mutex> lock(mutex);sample.sequence=static_cast<int64_t>(++sequence);if(samples.size()<capacity)samples.push_back(sample);else ++dropped;
 }
 Var take(){
  std::vector<Sample> pending;pending.reserve(capacity);uint64_t lost=0;{std::lock_guard<std::mutex> lock(mutex);pending.swap(samples);lost=dropped;dropped=0;}
  auto out=Var::container(GDEXTENSION_VARIANT_TYPE_DICTIONARY),rows=Var::container(GDEXTENSION_VARIANT_TYPE_ARRAY);LARGE_INTEGER frequency{};QueryPerformanceFrequency(&frequency);field(out,"qpc_frequency",frequency.QuadPart);field(out,"dropped",static_cast<int64_t>(lost));field(out,"capacity",capacity);
  for(const auto& sample:pending){auto row=Var::container(GDEXTENSION_VARIANT_TYPE_DICTIONARY);
#define FIELD(member) field(row,#member,sample.member)
   FIELD(sequence);FIELD(channel);FIELD(submitted);FIELD(qpc);FIELD(cycles);FIELD(pid);FIELD(tid);FIELD(group);FIELD(cpu);FIELD(priority);FIELD(power_control);FIELD(power_state);FIELD(power_error);
#undef FIELD
   append(rows,row);
  }
  Name name("samples");Var key;destroy(key.data);name_from(key.data,name.data);GDExtensionBool valid=false;set_keyed(out.data,key.data,rows.data,&valid);if(!valid)throw std::runtime_error("Private probe sample publication failed");return out;
 }
};
GDExtensionObjectPtr create(void*,GDExtensionBool notify){Name base("RefCounted"),name("NwnCpuProbe");auto object=construct_object(base.data);auto* owner=new Owner();set_instance(object,name.data,owner);if(notify){Var value;destroy(value.data);object_from(value.data,&object);Name notification("notification");auto zero=Var::integer(0);const GDExtensionConstVariantPtr args[]={zero.data};Var result;destroy(result.data);GDExtensionCallError error{};variant_call(value.data,notification.data,args,1,result.data,&error);}return object;}
void free(void*,GDExtensionClassInstancePtr value){delete static_cast<Owner*>(value);}
void call(void* operation,GDExtensionClassInstancePtr instance,const GDExtensionConstVariantPtr* args,GDExtensionInt count,GDExtensionVariantPtr result,GDExtensionCallError* error){
 error->error=GDEXTENSION_CALL_OK;const auto op=reinterpret_cast<uintptr_t>(operation);const int64_t expected=op==0?2:0;
 if(count!=expected){error->error=count<expected?GDEXTENSION_CALL_ERROR_TOO_FEW_ARGUMENTS:GDEXTENSION_CALL_ERROR_TOO_MANY_ARGUMENTS;error->expected=static_cast<int32_t>(expected);new_nil(result);return;}
 try{if(op==0){if(get_type(args[0])!=GDEXTENSION_VARIANT_TYPE_INT||get_type(args[1])!=GDEXTENSION_VARIANT_TYPE_INT){error->error=GDEXTENSION_CALL_ERROR_INVALID_ARGUMENT;new_nil(result);return;}int64_t channel=0,submitted=0;integer_to(&channel,const_cast<void*>(args[0]));integer_to(&submitted,const_cast<void*>(args[1]));static_cast<Owner*>(instance)->capture(channel,submitted);new_nil(result);}else if(op==1){auto out=static_cast<Owner*>(instance)->take();new_copy(result,out.data);}else{LARGE_INTEGER now{};QueryPerformanceCounter(&now);auto out=Var::integer(now.QuadPart);new_copy(result,out.data);}}
 catch(const std::exception&){new_nil(result);}
}
void initialize(void*,GDExtensionInitializationLevel level){
 if(level!=GDEXTENSION_INITIALIZATION_SCENE)return;Name name("NwnCpuProbe"),base("RefCounted"),empty(""),channel("channel"),submitted("submitted");GDExtensionClassCreationInfo6 info{};info.is_exposed=true;info.is_runtime=true;info.create_instance_func=create;info.free_instance_func=free;register_class(library,name.data,base.data,&info);alignas(8) uint8_t hint[8];string_new(hint,"");
 const auto property=[&](GDExtensionVariantType type,Name& field){GDExtensionPropertyInfo out{};out.type=type;out.name=field.data;out.class_name=empty.data;out.hint_string=hint;out.usage=6;return out;};
 GDExtensionPropertyInfo args[]={property(GDEXTENSION_VARIANT_TYPE_INT,channel),property(GDEXTENSION_VARIANT_TYPE_INT,submitted)};GDExtensionClassMethodArgumentMetadata metadata[2]{};
 for(uintptr_t op=0;op<3;++op){Name method(op==0?"capture":op==1?"take":"stamp");auto ret=property(op==1?GDEXTENSION_VARIANT_TYPE_DICTIONARY:GDEXTENSION_VARIANT_TYPE_INT,empty);GDExtensionClassMethodInfo definition{};definition.name=method.data;definition.method_userdata=reinterpret_cast<void*>(op);definition.call_func=call;definition.method_flags=GDEXTENSION_METHOD_FLAG_NORMAL;definition.has_return_value=op!=0;definition.return_value_info=op!=0?&ret:nullptr;definition.argument_count=op==0?2:0;definition.arguments_info=op==0?args:nullptr;definition.arguments_metadata=op==0?metadata:nullptr;register_method(library,name.data,&definition);}
 destructor(GDEXTENSION_VARIANT_TYPE_STRING)(hint);
}
void deinitialize(void*,GDExtensionInitializationLevel level){if(level==GDEXTENSION_INITIALIZATION_SCENE){Name name("NwnCpuProbe");unregister_class(library,name.data);}}
}
extern "C" __declspec(dllexport) GDExtensionBool nwn_cpu_probe_init(GDExtensionInterfaceGetProcAddress address,GDExtensionClassLibraryPtr lib,GDExtensionInitialization* init){
 library=lib;
#define API(target,type,symbol) target=reinterpret_cast<type>(address(symbol));if(!target)return false
 API(new_nil,GDExtensionInterfaceVariantNewNil,"variant_new_nil");API(new_copy,GDExtensionInterfaceVariantNewCopy,"variant_new_copy");API(destroy,GDExtensionInterfaceVariantDestroy,"variant_destroy");API(get_type,GDExtensionInterfaceVariantGetType,"variant_get_type");API(from_type,GDExtensionInterfaceGetVariantFromTypeConstructor,"get_variant_from_type_constructor");API(to_type,GDExtensionInterfaceGetVariantToTypeConstructor,"get_variant_to_type_constructor");API(construct,GDExtensionInterfaceVariantConstruct,"variant_construct");API(set_keyed,GDExtensionInterfaceVariantSetKeyed,"variant_set_keyed");API(variant_call,GDExtensionInterfaceVariantCall,"variant_call");API(name_new,GDExtensionInterfaceStringNameNewWithUtf8Chars,"string_name_new_with_utf8_chars");API(destructor,GDExtensionInterfaceVariantGetPtrDestructor,"variant_get_ptr_destructor");API(register_class,GDExtensionInterfaceClassdbRegisterExtensionClass6,"classdb_register_extension_class6");API(register_method,GDExtensionInterfaceClassdbRegisterExtensionClassMethod,"classdb_register_extension_class_method");API(unregister_class,GDExtensionInterfaceClassdbUnregisterExtensionClass,"classdb_unregister_extension_class");API(construct_object,GDExtensionInterfaceClassdbConstructObject3,"classdb_construct_object3");API(set_instance,GDExtensionInterfaceObjectSetInstance,"object_set_instance");
#undef API
 string_new=reinterpret_cast<GDExtensionInterfaceStringNewWithUtf8Chars>(address("string_new_with_utf8_chars"));if(!string_new)return false;
 integer_from=from_type(GDEXTENSION_VARIANT_TYPE_INT);integer_to=to_type(GDEXTENSION_VARIANT_TYPE_INT);name_from=from_type(GDEXTENSION_VARIANT_TYPE_STRING_NAME);object_from=from_type(GDEXTENSION_VARIANT_TYPE_OBJECT);
 init->minimum_initialization_level=GDEXTENSION_INITIALIZATION_SCENE;init->initialize=initialize;init->deinitialize=deinitialize;init->userdata=nullptr;return true;
}
