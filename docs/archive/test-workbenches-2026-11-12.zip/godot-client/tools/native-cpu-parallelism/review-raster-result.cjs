'use strict';
const fs = require('node:fs');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const [input, output] = process.argv.slice(2);
assert(input && output && !fs.existsSync(output), 'Fresh output and existing input required');
const bytes = fs.readFileSync(input);
const data = JSON.parse(bytes);
assert(data.success && data.checks === 221 && data.failures.length === 0);
const rows = data.originals.map(row => ({
  name: row.name, family: row.kind, width: row.width, height: row.height,
  inputFormat: row.input_format, inputTypes: [...new Set(row.input_types)], inputMips: row.input_mips,
  generatesMips: row.needs_mip_generation, decodesEtc: row.needs_etc_decode,
  originalMainUs: Object.values(row.baseline_cpu_phases).reduce((a, b) => a + b, 0),
  readyProofAndImageMainUs: row.ready_image_main_us,
  workerUs: row.whole_worker_us, retainedBytes: row.proof_plus_prepared_bytes,
  textureSubmitMainUs: row.texture_submit_main_us, outputDigest: row.digest,
}));
function total(list) {
  const result = { count: list.length, originalMainUs: 0, readyProofAndImageMainUs: 0, workerUs: 0,
    retainedBytes: 0, textureSubmitMainUs: 0 };
  for (const row of list) for (const key of Object.keys(result).filter(key => key !== 'count')) result[key] += row[key];
  result.mainUsRemoved = result.originalMainUs - result.readyProofAndImageMainUs;
  result.totalCpuUsAdded = result.workerUs - result.mainUsRemoved;
  return result;
}
const families = {};
for (const family of new Set(rows.map(row => row.family))) families[family] = total(rows.filter(row => row.family === family));
const review = {
  version: 1, issue: 'NWN-73', input, inputSha256: crypto.createHash('sha256').update(bytes).digest('hex'),
  checks: data.checks, scope: 'Single diagnostic decomposition, not matched entry latency, GPU elapsed time or FPS. Both byte proof and ready Image reconstruction are included; AssetService/ResourcePool adapter adoption and memo lookup are not included. Worker whole cost includes proof/schema/packet work. The standalone polling fixture wall time is not production admission behavior.',
  all: total(rows), families,
  largeTransformSubset: total(rows.filter(row => row.width * row.height >= 256 * 256 && (row.generatesMips || row.decodesEtc))),
  rows,
};
fs.writeFileSync(output, JSON.stringify(review, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ output, inputSha256: review.inputSha256, all: review.all, families: review.families, largeTransformSubset: review.largeTransformSubset }));
