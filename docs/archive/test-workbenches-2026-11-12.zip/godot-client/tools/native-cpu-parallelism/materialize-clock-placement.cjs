'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const project=path.resolve(__dirname,'../..'),[label,runtimeLabel]=process.argv.slice(2),sha=b=>crypto.createHash('sha256').update(b).digest('hex');assert(/^[a-z0-9-]+$/.test(label??''));assert(['clock-runtime-g','clock-runtime-accepted-g'].includes(runtimeLabel));
const sourceRoot=path.join(project,'.cache/nwn64',runtimeLabel),base=JSON.parse(fs.readFileSync(path.join(sourceRoot,'manifest.json'))),extra=JSON.parse(fs.readFileSync(path.join(sourceRoot,'clock-manifest.json')));
const stage=path.join(project,'.cache/nwn73',label),view=path.join(stage,'project');assert(!fs.existsSync(stage));fs.mkdirSync(view,{recursive:true});const pins=[];
function put(relative,bytes){const target=path.join(view,relative);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,bytes,{flag:'wx'});pins.push({relative,bytes:bytes.length,sha256:sha(bytes)});}
function one(s,from,to){assert.equal(s.split(from).length-1,1,from.slice(0,80));return s.replace(from,to);}
for(const row of [...base.files,...extra.added]){
 let bytes=fs.readFileSync(path.join(base.project,row.relative));assert.equal(sha(bytes),row.sha256,'Frozen fixture changed '+row.relative);
 if(row.relative==='project.godot')bytes=Buffer.from(bytes.toString()+'driver/threads/thread_model=2\n');
 if(row.relative==='.godot/extension_list.cfg')bytes=Buffer.from(bytes.toString()+'res://cpu_probe.gdextension\n');
 if(row.relative==='tests/nwn64_shared_clock_test.gd'){
  let s=bytes.toString();s=one(s,'var frames:=240 if benchmark else 120','var warmup_frames:=clampi(int(args.get("warmup-frames",1200)),80,6000);var sample_frames:=clampi(int(args.get("sample-frames",600)),80,3000);var frames:=warmup_frames+sample_frames if benchmark else 120');
  s=one(s,'if benchmark and frame>=80:','if benchmark and frame>=warmup_frames:');s=one(s,'if diagnostic and frame>=80:','if diagnostic and frame>=warmup_frames:');
  s=one(s,'\tfor frame in frames:','\tvar probe: RefCounted=ClassDB.instantiate("NwnCpuProbe");var next_cpu_us:=0;var cpu_tasks: Array[int]=[];var probe_overhead: Array=[]\n\tfor frame in frames:\n\t\tvar cpu_now:=Time.get_ticks_usec()\n\t\tif cpu_now>=next_cpu_us:\n\t\t\tnext_cpu_us=cpu_now+200000;var cpu_began:=Time.get_ticks_usec();probe.call("capture",0,probe.call("stamp"));probe_overhead.append(Time.get_ticks_usec()-cpu_began)\n\t\t\tRenderingServer.call_on_render_thread(Callable(probe,"capture").bind(1,probe.call("stamp")))\n\t\t\tcpu_tasks.append(WorkerThreadPool.add_task(Callable(probe,"capture").bind(2,probe.call("stamp")),false,"NWN73 CPU placement"))');
  s=one(s,'\tvar scalar_last: Dictionary=last.duplicate();scalar_last.erase("phases")','\tfor cpu_task in cpu_tasks:\n\t\twhile not WorkerThreadPool.is_task_completed(cpu_task):await process_frame\n\t\tWorkerThreadPool.wait_for_task_completion(cpu_task)\n\tawait process_frame\n\tvar cpu_packet: Dictionary=probe.call("take");probe=null\n\tvar scalar_last: Dictionary=last.duplicate();scalar_last.erase("phases")');
  s=one(s,'"sources":source_count,','"warmup_frames":warmup_frames,"sample_frames":sample_frames,"placement":cpu_packet,"probe_main_capture_us":probe_overhead,"separate_render_setting":ProjectSettings.get_setting("rendering/driver/threads/thread_model"),"sources":source_count,');
  bytes=Buffer.from(s);
 }
 put(row.relative,bytes);
}
const receiptPath=path.join(project,'.cache/nwn73/probe-a/probe-build/build-receipt.json'),receipt=JSON.parse(fs.readFileSync(receiptPath,'utf8').replace(/^\uFEFF/,'')),binary=fs.readFileSync(receipt.binary);assert(receipt.success&&sha(binary)===receipt.binarySha256);
put('.cache/nwn-cpu-probe.dll',binary);put('cpu_probe.gdextension',Buffer.from('[configuration]\nentry_symbol="nwn_cpu_probe_init"\ncompatibility_minimum="4.7"\nreloadable=false\n[libraries]\nwindows.x86_64="res://.cache/nwn-cpu-probe.dll"\n'));
const manifest={version:1,issue:'NWN-73',project:view,sourceRuntime:sourceRoot,sourceManifestSha256:sha(fs.readFileSync(path.join(sourceRoot,'manifest.json'))),clockManifestSha256:sha(fs.readFileSync(path.join(sourceRoot,'clock-manifest.json'))),kernelSha256:base.nativeBinarySha256,probeSha256:receipt.binarySha256,pins,scope:'Private derivative of frozen64G shared1750-source CPU component. Actual placement samples5Hz outside measured calls, explicit separate-render setting; fixed1200warmup+600samples by default to test startup/core-placement drift. No clock/native64 source edits or accepted/default selection. Still synthetic component, no renderer/FPS or live-client claim.'};
const file=path.join(stage,'manifest.json');fs.writeFileSync(file,JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({file,sha256:sha(fs.readFileSync(file)),project:view}));
