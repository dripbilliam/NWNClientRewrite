'use strict';
const fs = require('node:fs'), crypto = require('node:crypto'), assert = require('node:assert/strict');
const [input, output] = process.argv.slice(2);
assert(input && output && !fs.existsSync(output));
const bytes = fs.readFileSync(input), data = JSON.parse(bytes);
assert(data.success && data.checks === 481 && data.failures.length === 0 && data.corpus.length === 39);
const fields = ['pool_texture_main_us', 'adoption_main_us', 'main_completion_drain_us', 'worker_ms'];
function total(rows) {
  const out = { rows: rows.length, prepared: 0, consumed: 0, declinedTiny: 0, helperWorkerUs: 0 };
  for (const field of fields) out[field] = 0;
  for (const row of rows) {
    for (const field of fields) out[field] += row[field];
    out.prepared += row.worker_preparation.prepared || 0;
    out.consumed += row.pool.counts.consumed;
    out.declinedTiny += row.worker_preparation.tiny || 0;
    out.helperWorkerUs += (row.worker_preparation.cpu_ms || 0) * 1000;
  }
  return out;
}
const all = {}, large = {}, tiny = {};
for (const mode of ['off', 'cold', 'memo']) {
  const rows = data.corpus.filter(row => row.mode === mode);
  all[mode] = total(rows);
  large[mode] = total(rows.filter(row => row.width * row.height >= 256 * 256));
  tiny[mode] = total(rows.filter(row => row.width * row.height < 256 * 256));
}
const names = [...new Set(data.corpus.map(row => row.name))];
for (const name of names) {
  const rows = data.corpus.filter(row => row.name === name);
  assert.equal(rows.length, 3);
  assert(rows.every(row => row.source_sha256 === rows[0].source_sha256 && row.decoded_digest === rows[0].decoded_digest));
}
const result = {
  issue: 'NWN-73', input, inputSha256: crypto.createHash('sha256').update(bytes).digest('hex'), checks: data.checks,
  scope: 'Single ordered OFF/cold/memo diagnostic in one process. Actual AssetService and ResourcePool including main adoption, byte proof, ImageTexture CPU submission and completed-task drain. Sources and decoded digests match. Main drain excludes validation hashes/assertions/snapshots. OFF worker decode is colder than later legs, so whole-worker totals do not establish total-CPU improvement. No matched entry latency, GPU elapsed or FPS claim.',
  all, largeTransforms: large, intentionallyDeclinedTiny: tiny,
  largeMainDrainUsRemoved: { cold: large.off.main_completion_drain_us - large.cold.main_completion_drain_us, memo: large.off.main_completion_drain_us - large.memo.main_completion_drain_us },
};
fs.writeFileSync(output, JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(result));
