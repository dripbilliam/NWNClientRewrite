'use strict';
// Original-entry headless correctness and loading gate, never an FPS review.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict'),{spawn}=require('node:child_process');
const root=path.resolve(__dirname,'../..'),label=process.argv[2],directory=path.join(root,'.cache/nwn73',label);
assert(/^[a-z0-9-]+$/.test(label??''));
const stagedFile=path.join(directory,'staged.json'),staged=JSON.parse(fs.readFileSync(stagedFile));
const sha=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const driver=path.join(root,'tools/replay-native-loading.mjs'),driverSha=sha(driver);
const caDiagnostic=/ERROR: Failed to read the root certificate store\.\r?\n\s+at: get_system_ca_certificates \(platform\\windows\\os_windows\.cpp:2582\)/g;
function checkDiagnostic(report){
 const errors=String(report.errors??''),withoutCa=errors.replace(caDiagnostic,'');
 const caCount=(errors.match(caDiagnostic)??[]).length;
 const otherError=/SCRIPT ERROR|^ERROR:|ObjectDB.*leak|resources still in use/m.test(withoutCa);
 return {caCount,otherError,allowed:caCount===1&&!otherError&&report.failure==='Native engine/lifetime diagnostics observed'&&report.engineOrLifetimeError===true};
}
function verify(){
 assert.equal(sha(stagedFile),staged.stagedSha256??sha(stagedFile));
 assert.equal(sha(staged.baseSelection),staged.baseSelectionSha256);
 assert.equal(sha(driver),driverSha);
 for(const mode of ['control','candidate']){
  const selection=staged.selections[mode];assert.equal(sha(selection.file),selection.sha256);
  const value=JSON.parse(fs.readFileSync(selection.file));
  const helper=require(path.join(staged.inputs[mode],'tools/native-production-selection.cjs'));
  helper.validatePins(value);helper.validatePreferencePins(value);
  assert(value.flags.includes('--world-snapshot-preparation=workers'));
  assert.equal(value.renderCore.engineSha256,'753b3e188068efaf865bda3abd6322ebe44e3a98ef2f5d199c8af1a78624c98b');
  assert.equal(value.renderCore.nativeKernelSha256,'485741af15f0581a3c60c0f9a8ae738888eba08716c7a5c2c2d1bd550828963d');
  for(const pin of staged.pins[mode])assert.equal(sha(path.join(staged.inputs[mode],pin.relative)),pin.sha256,'Input changed: '+mode+' '+pin.relative);
 }
}
async function main(){
 verify();const runs=[];
 for(const [index,mode] of ['control','candidate','candidate','control'].entries()){
  verify();const selected=staged.selections[mode],run=`${label}-${index+1}-${mode}`,reportFile=path.join(root,'reports',run+'.json');
  assert(!fs.existsSync(reportFile),'Preserve prior replay');
  const args=[driver,'--capture='+path.join(root,staged.originalCapture),'--generation=4','--production-selection='+selected.file,'--production-selection-sha256='+selected.sha256,'--engine=production-selection','--headless','--profiling=false','--observe-profile=false','--duration-ms=12000','--run='+run];
  const log=fs.createWriteStream(path.join(directory,run+'.driver.log'),{flags:'wx'});
  const child=spawn(process.execPath,args,{cwd:root,windowsHide:true,stdio:['ignore','pipe','pipe']});let tail='';
  for(const stream of [child.stdout,child.stderr])stream.on('data',bytes=>{log.write(bytes);tail=(tail+bytes.toString()).slice(-10000);});
  const code=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('exit',resolve);});await new Promise(resolve=>log.end(resolve));
  assert(fs.existsSync(reportFile),'Replay report missing '+run);
  const report=JSON.parse(fs.readFileSync(reportFile)),diagnostic=checkDiagnostic(report);
  assert(report.sourceUnchanged&&report.driverUnchanged&&report.runtimeUnchanged&&report.exit===0,'Original-entry source/runtime pin failed '+run);
  assert((code===0&&report.success&&report.engineOrLifetimeError===false)||(code===1&&!report.success&&diagnostic.allowed),'Unaccepted diagnostic '+run+' '+JSON.stringify({code,diagnostic,failure:report.failure,tail}));
  assert.equal(report.productionSelection.sha256,selected.sha256);
  const native=report.native??{},preparation=native.snapshot_preparation?.worker?.stats??{},received=native.world?.received_metadata??{};
  assert(preparation.completed>0&&received.prepared_boundaries>0&&received.prepared_rows>0&&received.rejected===0,'Actual worker metadata not admitted '+run);
  const ordered=report.milestones.map(row=>[row.kind,row.generation??0,row.serial??0]);
  const milestoneIdentity=crypto.createHash('sha256').update(JSON.stringify(ordered)).digest('hex');
  runs.push({mode,run,selection:selected.sha256,report:reportFile,reportSha256:sha(reportFile),milestoneIdentity,playable:native.playable,receivedSnapshots:native.received_snapshots,objectVisualsComplete:native.object_visuals_complete,protocolFinishAck:native.protocol_finish_ack,completeWorld:report.measurement?.completeWorld,prepared:preparation,received,diagnostic,milestones:report.milestones.map(row=>({kind:row.kind,generation:row.generation,serial:row.serial,elapsedMs:row.elapsedMs}))});
  fs.writeFileSync(path.join(directory,'runs-partial.json'),JSON.stringify({issue:'NWN-73',runs},null,2)+'\n');verify();
 }
 assert(runs.every(row=>row.milestoneIdentity===runs[0].milestoneIdentity&&row.playable===true&&row.receivedSnapshots===runs[0].receivedSnapshots&&row.objectVisualsComplete===true&&row.protocolFinishAck===true&&row.completeWorld===true),'Original entry milestone or completion mismatch');
 const result={issue:'NWN-73',success:true,stagedFile,stagedSha256:sha(stagedFile),driverSha256:driverSha,runs,scope:'Frozen Core E workers-enabled original generation-4 headless ABBA. Strict source/runtime/worker-engagement/order/completion gate. Only exact sandbox CA-store diagnostic allowed. No graphical/FPS or Arelith claim.'};
 const file=path.join(directory,'review.json');fs.writeFileSync(file,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({file,sha256:sha(file),runs:runs.map(row=>({mode:row.mode,workers:row.prepared.completed,metadataRows:row.received.prepared_rows,playable:row.playable,milestones:row.milestones.length}))}));
}
main().catch(error=>{console.error(error.stack);process.exitCode=1;});
