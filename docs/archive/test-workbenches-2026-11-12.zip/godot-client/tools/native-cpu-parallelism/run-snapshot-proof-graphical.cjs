'use strict';
// Invoke only after the coordinator grants an exclusive global FPS lease.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict'),{spawn}=require('node:child_process');
const root=path.resolve(__dirname,'../..'),[label,prefix]=process.argv.slice(2);
assert(/^[a-z0-9-]+$/.test(label??'')&&/^[a-z0-9-]+$/.test(prefix??''));
const directory=path.join(root,'.cache/nwn73',label),stagedFile=path.join(directory,'staged.json'),staged=JSON.parse(fs.readFileSync(stagedFile));
const sha=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const driver=path.join(root,'tools/replay-native-loading.mjs'),driverSha=sha(driver),watcher=path.join(root,'tools/native-cpu-parallelism/watch-proof-client.ps1'),watcherSha=sha(watcher);
function knownEnvironmentErrors(report){
 const lines=String(report.errors??'').split(/\r?\n/).filter(line=>/^ERROR:|^SCRIPT ERROR:/.test(line));
 return report.failure==='Native engine/lifetime diagnostics observed'&&report.engineOrLifetimeError===true&&lines.length===2&&lines.includes("ERROR: Can't create shader cache folder, no shader caching will happen: user://")&&lines.includes('ERROR: Failed to read the root certificate store.');
}
function verify(){
 assert.equal(sha(staged.baseSelection),staged.baseSelectionSha256);
 assert.equal(sha(driver),driverSha);assert.equal(sha(watcher),watcherSha);
 const helper=require(path.join(staged.input,'tools/native-production-selection.cjs'));
 for(const mode of ['off','on']){
  const row=staged.selections[mode];assert.equal(sha(row.file),row.sha256);
  const selection=JSON.parse(fs.readFileSync(row.file));helper.validatePins(selection);helper.validatePreferencePins(selection);
  assert.equal(selection.mainSourceIdentity.sha256,staged.selections.off.sourceIdentity);
  assert(selection.flags.includes('--world-snapshot-preparation=workers')&&selection.flags.includes('--world-snapshot-verified-packet='+mode));
  assert.equal(selection.runtime.executableSha256,row.engineSha256);assert.equal(selection.renderCore.nativeKernelSha256,row.particleSha256);
 }
 assert.equal(staged.selections.off.sourceIdentity,staged.selections.on.sourceIdentity);
}
function launch(command,args,logFile){
 const log=fs.createWriteStream(logFile,{flags:'wx'}),child=spawn(command,args,{cwd:root,windowsHide:true,stdio:['ignore','pipe','pipe']});let tail='';
 for(const stream of [child.stdout,child.stderr])stream.on('data',bytes=>{log.write(bytes);tail=(tail+bytes.toString()).slice(-12000);});
 return {child,tail:()=>tail,finished:new Promise((resolve,reject)=>{child.on('error',reject);child.on('exit',code=>log.end(()=>resolve(code)));})};
}
async function main(){
 verify();const runs=[];
 for(const [index,mode] of ['off','on','on','off'].entries()){
  verify();const run=`${prefix}-${index+1}-${mode}`,selection=staged.selections[mode];
  const reportFile=path.join(root,'reports',run+'.json'),memoryFile=path.join(directory,run+'.memory.json');
  assert(!fs.existsSync(reportFile)&&!fs.existsSync(memoryFile),'Preserve prior run evidence');
  const watchArgs=['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',watcher,'-Run',run,'-Selection',selection.file,'-Output',memoryFile,'-IntervalMilliseconds','500','-MaximumSeconds','300'];
  const watch=launch('pwsh.exe',watchArgs,path.join(directory,run+'.watcher.log'));
  const replayArgs=[driver,'--capture='+path.join(root,staged.capture),'--generation=4','--production-selection='+selection.file,'--production-selection-sha256='+selection.sha256,'--engine=production-selection','--profiling=false','--observe-profile=false','--preview','--steady-ms=30000','--settle-ms=5000','--run='+run];
  const replay=launch(process.execPath,replayArgs,path.join(directory,run+'.driver.log'));
  console.log(JSON.stringify({starting:run,mode,selection:selection.sha256}));
  const [replayCode,watchCode]=await Promise.all([replay.finished,watch.finished]);
  assert.equal(watchCode,0,'Memory watcher failed '+run+' '+watch.tail());
  assert(fs.existsSync(reportFile)&&fs.existsSync(memoryFile),'Missing graphical or memory report '+run);
  const report=JSON.parse(fs.readFileSync(reportFile)),memory=JSON.parse(fs.readFileSync(memoryFile));
  const conditional=knownEnvironmentErrors(report);
  assert((replayCode===0&&report.success&&report.engineOrLifetimeError===false)||(replayCode===1&&!report.success&&conditional),'Unaccepted graphical replay diagnostic '+run+' '+replay.tail());
  assert(report.sourceUnchanged&&report.driverUnchanged&&report.runtimeUnchanged&&report.exit===0&&report.native?.clean_exit===true&&report.native?.workers_remaining===0,'Strict graphical source/runtime/exit failed '+run);
  assert(report.secondaryMonitorVerified&&report.profilingMatched&&report.native?.performance_window?.steady===true,'Nonsecondary/nonsteady graphical leg '+run);
  assert(memory.success&&memory.identity?.executable_sha256===selection.engineSha256&&memory.samples.length>=5,'Memory identity/coverage failed '+run);
  const native=report.native,metadata=native.world?.received_metadata??{},worker=native.snapshot_preparation?.worker?.stats??{};
  assert(worker.completed>0&&metadata.prepared_rows>0&&metadata.rejected===0,'Metadata worker path not engaged '+run);
  assert(metadata.verified_staged===(mode==='on'?metadata.prepared_boundaries:0),'Verified packet selection not engaged '+run);
  assert(metadata.full_staged===(mode==='off'?metadata.prepared_boundaries:0),'Old full validation selection not engaged '+run);
  const milestones=report.milestones.map(row=>[row.kind,row.generation??0,row.serial??0]);
  const identity=crypto.createHash('sha256').update(JSON.stringify(milestones)).digest('hex');
  const peakWorkingSet=Math.max(...memory.samples.map(row=>Number(row.peak_working_set_bytes))),peakPrivate=Math.max(...memory.samples.map(row=>Number(row.private_bytes)));
  const row={mode,run,selection:selection.sha256,report:reportFile,reportSha256:sha(reportFile),conditionalEnvironmentDiagnostic:conditional,memory:memoryFile,memorySha256:sha(memoryFile),milestoneIdentity:identity,milestoneCount:milestones.length,playable:native.playable,objectVisualsComplete:native.object_visuals_complete,protocolFinishAck:native.protocol_finish_ack,completeWorld:report.measurement?.completeWorld??native.performance_window?.steady,frame:native.frame_intervals,performanceWindow:{steady:native.performance_window.steady,elapsedMs:native.performance_window.elapsed_ms,startedAtMs:native.performance_window.started_at_ms},metadata,worker,peakWorkingSet,peakPrivate,watcherCpuMs:memory.watcher_cpu_ms,firstPlayableMs:report.measurement?.playableAtMs??native.entry_commit_entries?.[0]?.first_playable_ms,firstAreaReadyMs:report.milestones.find(entry=>entry.kind==='area-ready')?.elapsedMs,fullyLoadedMs:report.milestones.filter(entry=>entry.kind==='raw-world-accepted').at(-1)?.elapsedMs,entryRendererBeginUs:native.entry_commit_entries?.[0]?.core_phase_us?.renderer_begin,entryMaxUnitUs:native.entry_commit_entries?.[0]?.core_maximum_unit_us};
  runs.push(row);fs.writeFileSync(path.join(directory,prefix+'-partial.json'),JSON.stringify({issue:'NWN-73',runs},null,2)+'\n');verify();
  console.log(JSON.stringify({finished:run,mode,frame:row.frame,peakWorkingSet,firstAreaReadyMs:row.firstAreaReadyMs,fullyLoadedMs:row.fullyLoadedMs}));
 }
 assert(runs.every(row=>row.milestoneIdentity===runs[0].milestoneIdentity&&row.playable&&row.objectVisualsComplete&&row.protocolFinishAck&&row.completeWorld&&row.milestoneCount===runs[0].milestoneCount),'Graphical ordered/final state mismatch');
 const result={issue:'NWN-73',success:true,stagedFile,stagedSha256:sha(stagedFile),driverSha256:driverSha,watcherSha256:watcherSha,runs,scope:'Same immutable Core E source/engine/particle DLL/preference seeds, explicit worker metadata and only proof OFF/ON toggled; original generation-4 graphical secondary-monitor ABBA, 30-second steady windows, peak client working set/private bytes and loading milestones. Raw replay reports retain the two exact sandbox environment errors; this is conditional acceptance and no Arelith live-server claim.'};
 const file=path.join(directory,prefix+'-review.json');fs.writeFileSync(file,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({file,sha256:sha(file),runs:runs.map(row=>({mode:row.mode,frame:row.frame,peakWorkingSet:row.peakWorkingSet,metadata:row.metadata}))}));
}
main().catch(error=>{console.error(error.stack);process.exitCode=1;});
