'use strict';
// Private original-input replay stage. Copies only pinned proposal sources into
// an isolated project; never edits the accepted project or launches Godot.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../..'),label=process.argv[2];
assert(/^[a-z0-9][a-z0-9-]{0,50}$/.test(label??''),'Fresh short label required');
const dir=path.join(root,'.cache/nwn73',label),input=path.join(dir,'input');
assert(!fs.existsSync(dir),'Refuse to overwrite a stage');
const read=file=>fs.readFileSync(file),sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const baseFile=path.join(root,'.cache/native-presentation-parity/production-replay/nwn62-completion-tail-c/production-selection.json');
const base=JSON.parse(read(baseFile));
assert(base.complete&&base.production&&base.pins.length>2000);
assert.equal(base.renderCore.engineSha256,'753b3e188068efaf865bda3abd6322ebe44e3a98ef2f5d199c8af1a78624c98b');
assert.equal(base.renderCore.nativeKernelSha256,'485741af15f0581a3c60c0f9a8ae738888eba08716c7a5c2c2d1bd550828963d');
const overlays=[
 ['systems/native_keyboard.gd','systems/native_keyboard.gd','be9a113fcd29748486d2994aebe38b20d46774d11b57a44987134834a8915666'],
 ['systems/native_render/drive_collision_indexed.gd','systems/native_render/drive_collision_indexed.gd','76e72d0477c2bc78c4f4c3702931c00c75461d925e911ca9ed1a072666c8be33'],
 ['systems/native_render/drive_preview_worker.gd','systems/native_render/drive_preview_worker.gd','733dc7b6b45c4027e9b4ccd8a9ac4220ac725d0b3c950a8406b72de67a031c48'],
 ['systems/native_data/client_feature_registry.json','systems/native_data/client_feature_registry.json','d18c51e20ccf74eb6c0c68dad4b2825c1b02870de1a2db957541fadb049498b7'],
 ['tools/native-client-flags.cjs','tools/native-client-flags.cjs','cfd6ba5a2075218657be464c6bb2b1db73f7c034685932eb778d79da5e589aab'],
 ['systems/native_render/live_world.gd','.cache/nwn73/preview-worker-a/live_world-proposal.gd','3d61220a7d50c77b5910c39aa22c55a3459af11bc4aa5687afaf1e2df3d97134'],
 ['native_live_world.gd','.cache/nwn73/preview-worker-a/native_live_world-proposal.gd','7f3c53396f9dfda6f306156b1d3afa56bfdb6f9d2b1b884658d8c0ad0f5434bd'],
 ['native_session_world.gd','.cache/nwn73/preview-worker-a/native_session_world-proposal.gd','cb2d84b7a5e6a3e2bbace3c1755ece4f1deedb933882216a09cbee6c4dbd32e9']
];
const patch=new Map(overlays.map(([relative,source,expected])=>{
 const bytes=read(path.join(root,source));assert.equal(sha(bytes),expected,'Overlay source changed '+source);return [relative,bytes];
}));
function target(basePath,relative){
 assert(relative&&!path.isAbsolute(relative)&&!relative.split(/[\\/]/).some(part=>!part||part==='.'||part==='..'));
 const file=path.resolve(basePath,relative);assert(!path.relative(basePath,file).startsWith('..'));return file;
}
const capture='C:/Users/Niflheim/AppData/Roaming/nwn-model-viewer-research/native-loading-recordings/capture-YaH3xf';
assert.equal(sha(read(path.join(capture,'recording.json'))),'1913892cd42db0f68dfa1b0edbdd37be4c380bdda50c95c178dc4ca2ba38a463');
const recording=JSON.parse(read(path.join(capture,'recording.json')));
assert.equal(recording.timelineSha256,'6ce44bfe52a7bd8c3b08e936206360847cd3bb1ec1713bd1d21c7304882d3920');
assert.equal(recording.metadata.movementTiming,true);
fs.mkdirSync(input,{recursive:true});const pins=[];
for(const pin of base.pins){
 const from=target(base.sourceProject,pin.relative);assert.equal(sha(read(from)),pin.sha256,'Frozen base changed '+pin.relative);
 const dest=target(input,pin.relative);fs.mkdirSync(path.dirname(dest),{recursive:true});
 if(patch.has(pin.relative))fs.writeFileSync(dest,patch.get(pin.relative),{flag:'wx'});
 else fs.linkSync(from,dest);
 pins.push({relative:pin.relative,sha256:sha(read(dest))});
}
for(const [relative,bytes] of patch)if(!pins.some(pin=>pin.relative===relative)){
 const dest=target(input,relative);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,bytes,{flag:'wx'});pins.push({relative,sha256:sha(bytes)});
}
for(const [relative,expected] of [['.tools/native-core/Godot_native_core_e_win64.exe','753b3e188068efaf865bda3abd6322ebe44e3a98ef2f5d199c8af1a78624c98b'],['.tools/native-core/accepted-core-e.json','29b1c6adcdecb11eebc859730c770e879a108279dfaaf60792e4c11c00add78a']]){
 const from=target(root,relative);assert.equal(sha(read(from)),expected);const dest=target(input,relative);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.linkSync(from,dest);pins.push({relative,sha256:expected});
}
const seeds={version:1,expected:base.preferences.expected,description:base.preferences.description};
for(const name of ['render','layout'])seeds[name]={file:path.join(path.dirname(base.sourceProject),base.preferences[name].relative),sha256:base.preferences[name].sha256};
const helper=require(path.join(input,'tools/native-production-selection.cjs'));
(async()=>{
 const selections=[];
 for(const mode of ['off','on']){
  const argv=[...base.options,'--drive-preview-worker='+mode];
  const row=await helper.stageProductionSelection({project:input,label:'nwn73-'+label+'-'+mode,argv,preferenceSeeds:seeds,env:{}});
  assert(row.selection.featureSelection['drive-preview-worker'].explicit&&row.selection.featureSelection['drive-preview-worker'].value===mode);
  assert(row.selection.flags.includes('--drive-preview-worker='+mode));
  assert.equal(row.selection.renderCore.engineSha256,base.renderCore.engineSha256);
  assert.equal(row.selection.renderCore.nativeKernelSha256,base.renderCore.nativeKernelSha256);
  selections.push({mode,file:row.file,sha256:row.sha256,sourceIdentity:row.selection.mainSourceIdentity.sha256});
 }
 assert.equal(selections[0].sourceIdentity,selections[1].sourceIdentity,'OFF/ON source differs');
 for(const pin of pins)assert.equal(sha(read(target(input,pin.relative))),pin.sha256,'Input changed during staging: '+pin.relative);
 const result={issue:'NWN-73',private:true,accepted:false,production:false,baseSelection:baseFile,baseSelectionSha256:sha(read(baseFile)),input,pins,overlays:overlays.map(([relative,source,sha256])=>({relative,source,sha256})),selections,capture,recordingSha256:sha(read(path.join(capture,'recording.json'))),timelineSha256:recording.timelineSha256,expectedMovementInputs:360,scope:'Private exact Core E original-input OFF/ON pair. Both selections use the same snapshot of source, including a diagnostic-only recorded-input session adapter. No accepted project mutation, build, launch or FPS.'};
 const file=path.join(dir,'staged.json');fs.writeFileSync(file,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({file,sha256:sha(read(file)),pins:pins.length,selections}));
})().catch(error=>{console.error(error.stack);process.exitCode=1;});
