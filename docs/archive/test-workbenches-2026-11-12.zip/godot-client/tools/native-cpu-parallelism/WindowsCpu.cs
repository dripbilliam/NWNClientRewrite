using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;

namespace NwnCpuParallelism {
 public sealed class CpuSet {
  public uint Id; public ushort Group; public byte LogicalProcessor,Core,LastLevelCache,NumaNode,EfficiencyClass,Flags,SchedulingClass;
  public bool Parked {get{return (Flags&1)!=0;}}
 }
 public sealed class ThreadPolicy {
  public int Id; public string Name; public ulong Cycles; public uint[] SelectedCpuSets; public ushort IdealGroup; public byte IdealProcessor;
  public uint PowerControlMask,PowerStateMask; public int PowerQueryError,ProcessId;public long CreationFileTime;
 }
 public sealed class ProcessPolicy {public uint PowerControlMask,PowerStateMask;public int PowerQueryError,ForegroundPid;public uint ForegroundThread;public bool IsForeground;}
 public static class WindowsCpu {
  [StructLayout(LayoutKind.Sequential)] struct ProcessorNumber {public ushort Group; public byte Number,Reserved;}
  [StructLayout(LayoutKind.Sequential)] struct PowerState {public uint Version,ControlMask,StateMask;}
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetSystemCpuSetInformation(IntPtr buffer,uint length,out uint required,IntPtr process,uint flags);
  [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenThread(uint access,bool inherit,uint thread);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool CloseHandle(IntPtr handle);
  [DllImport("kernel32.dll")] static extern int GetThreadDescription(IntPtr thread,out IntPtr description);
  [DllImport("kernel32.dll")] static extern IntPtr LocalFree(IntPtr value);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool QueryThreadCycleTime(IntPtr thread,out ulong cycles);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetThreadIdealProcessorEx(IntPtr thread,out ProcessorNumber processor);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetThreadSelectedCpuSets(IntPtr thread,[Out] uint[] ids,uint count,out uint required);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool SetThreadSelectedCpuSets(IntPtr thread,uint[] ids,uint count);
  [DllImport("kernel32.dll",SetLastError=true)] static extern uint GetProcessIdOfThread(IntPtr thread);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetThreadTimes(IntPtr thread,out long creation,out long exit,out long kernel,out long user);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetProcessDefaultCpuSets(IntPtr process,[Out] uint[] ids,uint count,out uint required);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetThreadInformation(IntPtr thread,int information,ref PowerState value,uint size);
  [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetProcessInformation(IntPtr process,int information,ref PowerState value,uint size);
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr window,out uint process);
  public static ProcessPolicy InspectProcess(IntPtr process,int id){var result=new ProcessPolicy();var power=new PowerState {Version=1};if(GetProcessInformation(process,4,ref power,12)){result.PowerControlMask=power.ControlMask;result.PowerStateMask=power.StateMask;}else result.PowerQueryError=Marshal.GetLastWin32Error();uint foreground;result.ForegroundThread=GetWindowThreadProcessId(GetForegroundWindow(),out foreground);result.ForegroundPid=(int)foreground;result.IsForeground=result.ForegroundPid==id;return result;}
  public static CpuSet[] Topology(IntPtr process) {
   uint required;GetSystemCpuSetInformation(IntPtr.Zero,0,out required,process,0);if(required==0)throw new Win32Exception(Marshal.GetLastWin32Error());
   IntPtr buffer=Marshal.AllocHGlobal((int)required);
   try {
    uint actual;if(!GetSystemCpuSetInformation(buffer,required,out actual,process,0))throw new Win32Exception(Marshal.GetLastWin32Error());
    var rows=new List<CpuSet>();int at=0;
    while(at<actual){IntPtr item=IntPtr.Add(buffer,at);int size=Marshal.ReadInt32(item,0),type=Marshal.ReadInt32(item,4);if(size<8||size>actual-at)throw new InvalidOperationException("Invalid CPU-set record size");
     if(type==0){if(size<32)throw new InvalidOperationException("CPU-set ABI smaller than pinned SDK");rows.Add(new CpuSet {Id=(uint)Marshal.ReadInt32(item,8),Group=(ushort)Marshal.ReadInt16(item,12),LogicalProcessor=Marshal.ReadByte(item,14),Core=Marshal.ReadByte(item,15),LastLevelCache=Marshal.ReadByte(item,16),NumaNode=Marshal.ReadByte(item,17),EfficiencyClass=Marshal.ReadByte(item,18),Flags=Marshal.ReadByte(item,19),SchedulingClass=Marshal.ReadByte(item,20)});}at+=size;
    }return rows.ToArray();
   }finally{Marshal.FreeHGlobal(buffer);}
  }
  public static uint[] ProcessCpuSets(IntPtr process){uint required;bool ok=GetProcessDefaultCpuSets(process,null,0,out required);if(!ok&&Marshal.GetLastWin32Error()!=122)throw new Win32Exception(Marshal.GetLastWin32Error());if(required==0)return new uint[0];var ids=new uint[required];if(!GetProcessDefaultCpuSets(process,ids,required,out required))throw new Win32Exception(Marshal.GetLastWin32Error());return ids;}
  static uint[] ThreadCpuSets(IntPtr thread){uint required;bool ok=GetThreadSelectedCpuSets(thread,null,0,out required);if(!ok&&Marshal.GetLastWin32Error()!=122)throw new Win32Exception(Marshal.GetLastWin32Error());if(required==0)return new uint[0];var ids=new uint[required];if(!GetThreadSelectedCpuSets(thread,ids,required,out required))throw new Win32Exception(Marshal.GetLastWin32Error());return ids;}
  public static void ChangeThreadCpuSets(int threadId,int expectedProcess,long expectedCreation,uint[] ids){
   if(ids==null)ids=new uint[0];
   IntPtr thread=OpenThread(0x0C40,false,(uint)threadId);if(thread==IntPtr.Zero)throw new Win32Exception(Marshal.GetLastWin32Error());
   try{long creation,exit,kernel,user;if(GetProcessIdOfThread(thread)!=(uint)expectedProcess||!GetThreadTimes(thread,out creation,out exit,out kernel,out user)||creation!=expectedCreation)throw new InvalidOperationException("Target thread identity changed");if(!SetThreadSelectedCpuSets(thread,ids,(uint)ids.Length))throw new Win32Exception(Marshal.GetLastWin32Error());}finally{CloseHandle(thread);}
  }
  public static ThreadPolicy InspectThread(int id){
   IntPtr thread=OpenThread(0x0840,false,(uint)id);if(thread==IntPtr.Zero)throw new Win32Exception(Marshal.GetLastWin32Error());
   try {
    var result=new ThreadPolicy {Id=id,Name="",SelectedCpuSets=new uint[0],ProcessId=(int)GetProcessIdOfThread(thread)};long creation,exit,kernel,user;if(!GetThreadTimes(thread,out creation,out exit,out kernel,out user))throw new Win32Exception(Marshal.GetLastWin32Error());result.CreationFileTime=creation;IntPtr description;
    if(GetThreadDescription(thread,out description)==0&&description!=IntPtr.Zero){try{result.Name=Marshal.PtrToStringUni(description)??"";}finally{LocalFree(description);}}
    ulong cycles;if(QueryThreadCycleTime(thread,out cycles))result.Cycles=cycles;
    ProcessorNumber ideal;if(GetThreadIdealProcessorEx(thread,out ideal)){result.IdealGroup=ideal.Group;result.IdealProcessor=ideal.Number;}
    result.SelectedCpuSets=ThreadCpuSets(thread);
    var power=new PowerState {Version=1};if(GetThreadInformation(thread,3,ref power,12)){result.PowerControlMask=power.ControlMask;result.PowerStateMask=power.StateMask;}else result.PowerQueryError=Marshal.GetLastWin32Error();
    return result;
   }finally{CloseHandle(thread);}
  }
 }
}
