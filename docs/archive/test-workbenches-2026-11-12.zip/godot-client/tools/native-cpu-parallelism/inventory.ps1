param([Parameter(Mandatory=$true)][string]$Report,[int]$ClientPid=0)
$ErrorActionPreference='Stop'
$cpuProject=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$cpuReport=[IO.Path]::GetFullPath($Report)
$cpuAllowed=[IO.Path]::GetFullPath((Join-Path $cpuProject '.cache/nwn73/')).TrimEnd('\')+'\'
if(-not$cpuReport.StartsWith($cpuAllowed,[StringComparison]::OrdinalIgnoreCase)){throw 'Report must stay in private nwn73 cache'}
if(Test-Path -LiteralPath $cpuReport){throw 'Preserve previous inventory'}
Add-Type -Path (Join-Path $PSScriptRoot 'WindowsCpu.cs')
$cpuProcess=if($ClientPid-gt0){Get-Process -Id $ClientPid}else{Get-Process -Id $PID}
$cpuRows=[NwnCpuParallelism.WindowsCpu]::Topology($cpuProcess.Handle)
$cpuThreads=@();$cpuIssues=@()
if($ClientPid-gt0){
 foreach($cpuThread in $cpuProcess.Threads){try{$cpuPolicy=[NwnCpuParallelism.WindowsCpu]::InspectThread($cpuThread.Id);$cpuThreads+=@{id=$cpuThread.Id;description=$cpuPolicy.Name;totalCpuMs=$cpuThread.TotalProcessorTime.TotalMilliseconds;cycles=$cpuPolicy.Cycles;threadState=[string]$cpuThread.ThreadState;idealGroup=$cpuPolicy.IdealGroup;idealProcessor=$cpuPolicy.IdealProcessor;selectedCpuSets=$cpuPolicy.SelectedCpuSets;powerControlMask=$cpuPolicy.PowerControlMask;powerStateMask=$cpuPolicy.PowerStateMask;powerQueryError=$cpuPolicy.PowerQueryError}}catch{$cpuIssues+=@{thread=$cpuThread.Id;error=$_.Exception.Message}}}
}
$cpuBrand=[Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\HARDWARE\DESCRIPTION\System\CentralProcessor\0','ProcessorNameString','')
$cpuState=@{version=1;issue='NWN-73';utc=[DateTime]::UtcNow.ToString('o');processor=$cpuBrand;environmentProcessorCount=[Environment]::ProcessorCount;logicalCpuSets=$cpuRows.Length;physicalCores=@($cpuRows|Group-Object Group,Core).Length;efficiencyClasses=@($cpuRows|Group-Object EfficiencyClass|ForEach-Object{@{value=[int]$_.Name;logical=$_.Count;physical=@($_.Group|Group-Object Group,Core).Length}});cpuSets=$cpuRows;targetPid=$ClientPid;target=$null;threads=$cpuThreads;issues=$cpuIssues;collectorSha256=(Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'WindowsCpu.cs')).Hash.ToLowerInvariant();scope='Read-only Windows CPU-set topology and optional exact-client thread policy/CPU-time inventory. Ideal processor is a scheduling preference, NOT observed actual placement. No affinity, priorities, power, settings, registry or client changes.'}
if($ClientPid-gt0){$cpuState.target=@{pid=$cpuProcess.Id;path=$cpuProcess.Path;startedUtc=$cpuProcess.StartTime.ToUniversalTime().ToString('o');priorityClass=[string]$cpuProcess.PriorityClass;processorAffinity=$cpuProcess.ProcessorAffinity.ToInt64().ToString('x');defaultCpuSets=[NwnCpuParallelism.WindowsCpu]::ProcessCpuSets($cpuProcess.Handle);policy=[NwnCpuParallelism.WindowsCpu]::InspectProcess($cpuProcess.Handle,$cpuProcess.Id);totalCpuMs=$cpuProcess.TotalProcessorTime.TotalMilliseconds;workingSet=$cpuProcess.WorkingSet64}}
New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($cpuReport)) -Force|Out-Null
$cpuState|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $cpuReport -Encoding utf8
$cpuState|Select-Object processor,environmentProcessorCount,logicalCpuSets,physicalCores,efficiencyClasses,target|ConvertTo-Json -Depth 5
