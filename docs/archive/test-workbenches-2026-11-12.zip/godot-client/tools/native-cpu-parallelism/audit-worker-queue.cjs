'use strict';
// Read-only summary of existing replay worker queue delays. No client launch.
const fs = require('node:fs');
const path = require('node:path');
const file = path.resolve(process.argv[2] || '');
if (!fs.existsSync(file)) throw Error('Pass an existing report path');
const root = JSON.parse(fs.readFileSync(file, 'utf8'));
const rows = [];
function visit(value, trail = []) {
  if (Array.isArray(value)) { value.forEach((item, i) => visit(item, [...trail, i])); return; }
  if (!value || typeof value !== 'object') return;
  if (value.phases && typeof value.phases.worker_queue_ms === 'number') {
    rows.push({ path: trail.join('.'), name: value.name ?? value.model ?? value.resource_name ?? '', workerQueue: value.phases.worker_queue_ms, serviceQueue: value.phases.service_queue_ms, worker: value.worker_ms ?? value.phases.worker_ms ?? null });
  }
  for (const [key, item] of Object.entries(value)) if (key !== 'phases') visit(item, [...trail, key]);
}
visit(root);
const summarize = key => {
  const ordered = rows.map(row => row[key]).filter(Number.isFinite).sort((a,b) => a-b);
  const sum = ordered.reduce((a,b) => a+b, 0);
  return { count: ordered.length, total: sum, mean: sum / ordered.length, median: ordered[Math.floor((ordered.length-1)/2)] ?? null, p95: ordered[Math.ceil(ordered.length*.95)-1] ?? null, max: ordered.at(-1) ?? null };
};
console.log(JSON.stringify({file, rows: rows.length, workerQueue: summarize('workerQueue'), serviceQueue: summarize('serviceQueue'), worker: summarize('worker'), worst: rows.toSorted((a,b) => b.workerQueue-a.workerQueue).slice(0,10)}));
