'use strict';
// Source-only isolated original-entry pair, based on a frozen normal Core E
// selection. No Godot launch, accepted file mutation or DLL/engine build.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../..'),label=process.argv[2];
assert(/^[a-z0-9-]+$/.test(label??''));
const directory=path.join(root,'.cache/nwn73',label),input=path.join(directory,'input');
assert(!fs.existsSync(directory),'Fresh stage label required');
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex'),read=file=>fs.readFileSync(file);
const baseFile=path.join(root,'.cache/native-presentation-parity/production-replay/nwn62-completion-tail-c/production-selection.json');
const base=JSON.parse(read(baseFile));
assert(base.complete&&base.production&&base.sourceProject&&base.pins.length>2000);
assert.equal(base.renderCore.engineSha256,'753b3e188068efaf865bda3abd6322ebe44e3a98ef2f5d199c8af1a78624c98b');
assert.equal(base.renderCore.nativeKernelSha256,'485741af15f0581a3c60c0f9a8ae738888eba08716c7a5c2c2d1bd550828963d');
assert.deepEqual(base.options,['--performance-runtime=verified-native','--render-profile=gameplay','--detailed-profiling=off']);
const patch=new Map();
for(const [relative,expected] of [['systems/native_data/actor_model.gd','54ffff532c74a161ca2525228ce7c78a5377abbdff88e47c128c1e83e29a9a1a'],['systems/native_data/client_feature_registry.json','eac1bad82cdb18478df5cb8eed3b85f728b2bcaa2d3384ceadee05260a5d077f'],['tools/native-client-flags.cjs','d9de3ac4b348456234438ab26d888d65d9b01b432ed6720e6dbd838f972ed40e']]){
 const bytes=read(path.join(root,relative));assert.equal(sha(bytes),expected);if(relative!=='systems/native_data/actor_model.gd')patch.set(relative,bytes);
}
const live=read(path.join(base.sourceProject,'native_live_world.gd')).toString();
const needle='\treport.runtime_features=runtime_features_snapshot()\n\tif report.has("performance_window"):';
assert.equal(live.split(needle).length,2,'One final-report seam required');
patch.set('native_live_world.gd',Buffer.from(live.replace(needle,'\treport.runtime_features=runtime_features_snapshot()\n\treport.binary_clip_helper=preload("res://systems/native_data/actor_model.gd").binary_clip_helper_snapshot()\n\tif report.has("performance_window"):')));
function target(basePath,relative){assert(relative&&!path.isAbsolute(relative)&&!relative.split(/[\\/]/).some(part=>!part||part==='.'||part==='..'));const file=path.resolve(basePath,relative);assert(!path.relative(basePath,file).startsWith('..'));return file;}
fs.mkdirSync(input,{recursive:true});const pins=[];
for(const pin of base.pins){
 const from=target(base.sourceProject,pin.relative);assert.equal(sha(read(from)),pin.sha256,'Frozen base changed: '+pin.relative);
 const dest=target(input,pin.relative);fs.mkdirSync(path.dirname(dest),{recursive:true});
 if(patch.has(pin.relative))fs.writeFileSync(dest,patch.get(pin.relative),{flag:'wx'});
 else fs.linkSync(from,dest);
 pins.push({relative:pin.relative,sha256:sha(read(dest))});
}
for(const [relative,expected] of [['.tools/native-core/Godot_native_core_e_win64.exe','753b3e188068efaf865bda3abd6322ebe44e3a98ef2f5d199c8af1a78624c98b'],['.tools/native-core/accepted-core-e.json','29b1c6adcdecb11eebc859730c770e879a108279dfaaf60792e4c11c00add78a']]){
 const from=target(root,relative);assert.equal(sha(read(from)),expected);const dest=target(input,relative);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.linkSync(from,dest);pins.push({relative,sha256:expected});
}
const seeds={version:1,expected:base.preferences.expected,description:base.preferences.description};
for(const name of ['render','layout'])seeds[name]={file:path.join(path.dirname(base.sourceProject),base.preferences[name].relative),sha256:base.preferences[name].sha256};
const helper=require(path.join(input,'tools/native-production-selection.cjs'));
(async()=>{
 const selections=[];
 for(const mode of ['off','parallel']){
  const argv=[...base.options,'--binary-clips='+mode];
  const row=await helper.stageProductionSelection({project:input,label:'nwn73-'+label+'-'+mode,argv,preferenceSeeds:seeds,env:{}});
  assert(row.selection.featureSelection['binary-clips'].explicit&&row.selection.featureSelection['binary-clips'].value===mode);
  assert(row.selection.flags.includes('--binary-clips='+mode));
  assert.equal(row.selection.renderCore.engineSha256,base.renderCore.engineSha256);
  assert.equal(row.selection.renderCore.nativeKernelSha256,base.renderCore.nativeKernelSha256);
  selections.push({mode,file:row.file,sha256:row.sha256,source:row.selection.sourceProject,sourceIdentity:row.selection.mainSourceIdentity.sha256});
 }
 assert.equal(selections[0].sourceIdentity,selections[1].sourceIdentity,'Source must be identical across selections');
 for(const pin of pins)assert.equal(sha(read(target(input,pin.relative))),pin.sha256,'Input changed during stage: '+pin.relative);
 const result={issue:'NWN-73',private:true,accepted:false,production:false,baseSelection:baseFile,baseSelectionSha256:sha(read(baseFile)),input,pins,selections,originalCapture:'.cache/loading-benchmark-worlds/arelith-archive-shaders-v1',scope:'Source-only private Core E original-entry OFF/ON pair with exact same frozen source, accepted DLL, reviewed preferences, final-report parser helper proof. No client launch, normal default change or accepted artifact mutation.'};
 const file=path.join(directory,'staged.json');fs.writeFileSync(file,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({file,sha256:sha(read(file)),selections:selections.map(row=>({mode:row.mode,file:row.file,sha256:row.sha256})),pins:pins.length}));
})().catch(error=>{console.error(error.stack);process.exitCode=1;});
