'use strict';
// Private accepted-kernel original-source census stage; source only, no launch.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../..'),stageName=process.argv[2]??'particle-sim-a';
assert(['particle-sim-a','particle-sim-b'].includes(stageName),'Only pinned census stages are supported');
const dir=path.join(root,'.cache/nwn73',stageName),input=path.join(dir,'input');
assert(!fs.existsSync(dir),'Fresh private census stage required');
const read=p=>fs.readFileSync(p),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const baseFile=path.join(root,'.cache/native-presentation-parity/production-replay/nwn62-completion-tail-c/production-selection.json'),base=JSON.parse(read(baseFile));
assert(base.complete&&base.production&&base.pins.length>2000);
assert.equal(base.renderCore.engineSha256,'753b3e188068efaf865bda3abd6322ebe44e3a98ef2f5d199c8af1a78624c98b');
assert.equal(base.renderCore.nativeKernelSha256,'485741af15f0581a3c60c0f9a8ae738888eba08716c7a5c2c2d1bd550828963d');
const helperRelative='tools/native-cpu-parallelism/particle_callback_eligibility.gd',helperBytes=read(path.join(root,helperRelative));
const liveRelative='native_live_world.gd',original=read(path.join(base.sourceProject,liveRelative)).toString();
const needle='\tif is_instance_valid(world): report.world=world.snapshot()';
assert.equal(original.split(needle).length,2,'One final live-world census seam required');
const modified=original.replace(needle,'\tif is_instance_valid(world):\n\t\treport.private_nwn73_particle_census=preload("res://tools/native-cpu-parallelism/particle_callback_eligibility.gd").summarize(world.particle_stream_group)\n\t\treport.world=world.snapshot()');
function target(basePath,relative){assert(relative&&!path.isAbsolute(relative)&&!relative.split(/[\\/]/).some(x=>!x||x==='.'||x==='..'));const p=path.resolve(basePath,relative);assert(!path.relative(basePath,p).startsWith('..'));return p;}
const busy=stageName==='particle-sim-b';
const capture=path.join(root,busy?'.cache/nwn64/fog-recording-particles-a':'.cache/loading-benchmark-worlds/arelith-archive-shaders-v1'),recording=JSON.parse(read(path.join(capture,'recording.json')));
assert.equal(recording.timelineSha256,busy?'8e599c13ca1bcdcd22799e0364b20937a0ff0a02bca88eae635cb23aa5e7e334':'d955e6fef37015dc189ab480a76bb03b0cc2f44482bdee5a55b45561a23715ee');
fs.mkdirSync(input,{recursive:true});const pins=[];
for(const pin of base.pins){
 const from=target(base.sourceProject,pin.relative);assert.equal(sha(read(from)),pin.sha256,'Base source changed '+pin.relative);
 const dest=target(input,pin.relative);fs.mkdirSync(path.dirname(dest),{recursive:true});
 if(pin.relative===liveRelative)fs.writeFileSync(dest,modified,{flag:'wx'});else fs.linkSync(from,dest);
 pins.push({relative:pin.relative,sha256:sha(read(dest))});
}
const helperTarget=target(input,helperRelative);fs.mkdirSync(path.dirname(helperTarget),{recursive:true});fs.writeFileSync(helperTarget,helperBytes,{flag:'wx'});pins.push({relative:helperRelative,sha256:sha(helperBytes)});
for(const [relative,expected] of [['.tools/native-core/Godot_native_core_e_win64.exe','753b3e188068efaf865bda3abd6322ebe44e3a98ef2f5d199c8af1a78624c98b'],['.tools/native-core/accepted-core-e.json','29b1c6adcdecb11eebc859730c770e879a108279dfaaf60792e4c11c00add78a']]){
 const from=target(root,relative);assert.equal(sha(read(from)),expected);const dest=target(input,relative);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.linkSync(from,dest);pins.push({relative,sha256:expected});
}
fs.writeFileSync(path.join(dir,'native_live_world-census.gd'),modified,{flag:'wx'});
const seeds={version:1,expected:base.preferences.expected,description:base.preferences.description};for(const n of ['render','layout'])seeds[n]={file:path.join(path.dirname(base.sourceProject),base.preferences[n].relative),sha256:base.preferences[n].sha256};
const helper=require(path.join(input,'tools/native-production-selection.cjs'));
helper.stageProductionSelection({project:input,label:'nwn73-particle-callback-census-'+(busy?'b':'a'),argv:base.options,preferenceSeeds:seeds,env:{}}).then(row=>{
 assert.equal(row.selection.renderCore.engineSha256,base.renderCore.engineSha256);
 assert.equal(row.selection.renderCore.nativeKernelSha256,base.renderCore.nativeKernelSha256);
 const staged={issue:'NWN-73',private:true,baseSelection:baseFile,baseSelectionSha256:sha(read(baseFile)),input,pins,selection:{file:row.file,sha256:row.sha256,sourceIdentity:row.selection.mainSourceIdentity.sha256},capture,recordingSha256:sha(read(path.join(capture,'recording.json'))),timelineSha256:recording.timelineSha256,censusSourceSha256:sha(Buffer.from(modified)),helperSha256:sha(helperBytes),scope:'Accepted native kernel; one private report-only cold survey at shutdown. No simulation, clocks, geometry or accepted source changed.'};
 const file=path.join(dir,'staged.json');fs.writeFileSync(file,JSON.stringify(staged,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({file,sha256:sha(read(file)),selection:staged.selection,pins:pins.length}));
}).catch(e=>{console.error(e.stack);process.exitCode=1});
