'use strict';
// Default is source/capture verification only. --run needs an exclusive client lease.
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const assert=require('node:assert/strict');
const {spawn}=require('node:child_process');
const root=path.resolve(__dirname,'../..');
const label=process.argv.find(x=>x.startsWith('--label='))?.slice(8)??'nwn73-preview-cache-h';
assert(/^[a-z0-9][a-z0-9-]{0,40}$/.test(label));
const directory=path.join(root,'.cache/nwn73',label);
const file=path.join(directory,'plan.json');
const sha=name=>crypto.createHash('sha256').update(fs.readFileSync(name)).digest('hex');
const helper=require('../native-production-selection.cjs');
const order=['off','on','on','off'];
const digest=value=>crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
async function verify(){
 const plan=JSON.parse(fs.readFileSync(file,'utf8'));
 assert.equal(plan.issue,'NWN-73');assert.equal(plan.status,'staged-no-launch');
 assert.equal(sha(path.join(plan.capture,'recording.json')),plan.recordingSha256);
 assert.equal(plan.recordingSha256,'1913892cd42db0f68dfa1b0edbdd37be4c380bdda50c95c178dc4ca2ba38a463');
 const selections=[];
 for(const mode of ['off','on']){
  const row=plan.selections.find(x=>x.mode===mode);assert(row);
  const selected=await helper.readProductionSelection(row.file,row.sha256);
  assert.equal(selected.mainSourceIdentity.sha256,row.sourceIdentity);
  assert.equal(selected.runtime.executableSha256,'753b3e188068efaf865bda3abd6322ebe44e3a98ef2f5d199c8af1a78624c98b');
  assert.equal(selected.featureSelection['drive-preview-worker'].value,'on');
  assert.equal(selected.featureSelection['drive-preview-surface-cache'].value,mode);
  assert.equal(selected.featureSelection['drive-preview-surface-cache'].explicit,true);
  assert.equal(selected.profiling,'false');
  assert.equal(selected.pins.find(x=>x.relative==='systems/native_render/drive_collision_indexed.gd').sha256,'f3c2b35e783dd7d0dec24a1978a6f47edc2e3024ef2f37d8b158b6a8cfaca928');
  selections.push({mode,row,selected});
 }
 assert.equal(selections[0].selected.mainSourceIdentity.sha256,selections[1].selected.mainSourceIdentity.sha256);
 assert.deepEqual(selections[0].selected.pins,selections[1].selected.pins);
 assert.deepEqual(selections[0].selected.preferences.expected,selections[1].selected.preferences.expected);
 assert.deepEqual(selections[0].selected.renderCore,selections[1].selected.renderCore);
 assert.deepEqual(selections[0].selected.flags.filter(x=>!x.startsWith('--drive-preview-surface-cache=')),selections[1].selected.flags.filter(x=>!x.startsWith('--drive-preview-surface-cache=')));
 return {plan,selections};
}
function summarize(name,mode,exit){
 const reportFile=path.join(root,'reports',name+'.json');
 const report=JSON.parse(fs.readFileSync(reportFile,'utf8'));
 assert.equal(report.exit,0);assert(report.sourceUnchanged&&report.runtimeUnchanged);
 assert.equal(report.movementReplay?.inputs,360);assert.equal(report.movementReplay?.accepted,360);
 assert.equal(report.movementReplay?.rejected,0);assert.equal(report.movementReplay?.prediction?.verified,true);
 assert.equal(report.movementWindow?.verified,true,'Bounded movement window missing');
 assert.equal(report.native?.world?.area_id,2147618622);
 assert(report.native?.playable&&report.native?.object_visuals_complete&&report.native?.protocol_finish_ack);
 assert.equal(report.productionFeatures?.verification?.status,'observed');
 assert.equal(report.productionFeatures?.worldVerification?.status,'observed');
 const collision=report.native.world.drive_collision;
 assert(collision?.ready&&collision.pending===0&&collision.sources===1918);
 assert.equal(collision.static_entries,1908);assert.equal(collision.static_groups,463);
 if(mode==='on')assert(collision.preview_worker_surface_cache,'ON cache not observed');
 else assert(!collision.preview_worker_surface_cache,'OFF cache unexpectedly active');
 const worker=report.native.world.preview_worker;
 assert(worker?.requested&&worker.stats);
 const log=fs.readFileSync(path.join(root,'reports',name+'.engine.log'),'utf8');
 assert(!/(SCRIPT ERROR|FATAL|leaked|still in use)/i.test(log));
 const frame=report.native.frame_intervals,moving=report.native.movement_window.frame_intervals;
 const summary=value=>({mean:value.average_ms,median:value.median_ms,p95:value.p95_ms,p99:value.p99_ms,worst:value.worst_ms,count:value.count});
 return {name,mode,driverExit:exit,strictSuccess:report.success===true,report:reportFile,reportSha256:sha(reportFile),milestoneDigest:digest(report.milestones.map(x=>[x.kind,x.id,x.index])),protocolObjectsDigest:digest(report.native.protocol_objects),controlledDistance:report.native.controlled_distance,worker:worker.stats,cache:collision.preview_worker_surface_cache??null,movementFrame:summary(moving),quietFrame:summary(frame),entry:{playableMs:report.native.world.playable_ms,baseKnownCompleteMs:report.native.world.base_scenery?.first_known_complete_ms},diagnostics:report.nativeDiagnostics??null};
}
async function leg(plan,mode,index){
 const selected=plan.selections.find(x=>x.mode===mode);
 const name=`${label}-${index+1}-${mode}`;
 const reportFile=path.join(root,'reports',name+'.json');
 const logFile=path.join(directory,name+'.driver.log');
 assert(!fs.existsSync(reportFile)&&!fs.existsSync(logFile),'Preserve prior run');
 const args=[path.join(root,'tools/replay-native-loading.mjs'),'--capture='+plan.capture,'--generation=2','--movement-timing','--movement-window','--paced','--production-selection='+selected.file,'--production-selection-sha256='+selected.sha256,'--engine=production-selection','--profiling=false','--observe-profile=false','--preview','--steady-ms=5000','--run='+name];
 const output=fs.createWriteStream(logFile,{flags:'wx'});
 const child=spawn(process.execPath,args,{cwd:root,windowsHide:true,stdio:['ignore','pipe','pipe']});
 for(const stream of [child.stdout,child.stderr])stream.on('data',chunk=>output.write(chunk));
 const exit=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('exit',resolve)});
 await new Promise(resolve=>output.end(resolve));
 return summarize(name,mode,exit);
}
(async()=>{
 const {plan,selections}=await verify();
 if(!process.argv.includes('--run')){
  console.log(JSON.stringify({verified:true,clientStarts:0,plan:file,planSha256:sha(file),sourceIdentity:selections[0].row.sourceIdentity,pins:selections[0].row.pins,recordingSha256:plan.recordingSha256,order,flags:selections.map(x=>x.selected.flags.filter(f=>f.startsWith('--drive-preview')))},null,2));
  return;
 }
 assert.deepEqual(process.argv.slice(2).filter(x=>!x.startsWith('--label=')),['--run'],'Only explicit --run starts replay');
 const runs=[];
 for(let i=0;i<order.length;i++){
  runs.push(await leg(plan,order[i],i));
  fs.writeFileSync(path.join(directory,'matrix-partial.json'),JSON.stringify({order,runs},null,2)+'\n');
 }
 const receipt={issue:'NWN-73',order,strictAccepted:runs.every(x=>x.strictSuccess),equalMilestones:runs.every(x=>x.milestoneDigest===runs[0].milestoneDigest),equalProtocolObjects:runs.every(x=>x.protocolObjectsDigest===runs[0].protocolObjectsDigest),runs,scope:'Pinned original-input offline ABBA. Movement decisions are local and not live Arelith packet acceptance.'};
 const output=path.join(directory,'matrix-review.json');fs.writeFileSync(output,JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({file:output,sha256:sha(output),strictAccepted:receipt.strictAccepted}));
})().catch(error=>{console.error(error.stack);process.exitCode=1;});
