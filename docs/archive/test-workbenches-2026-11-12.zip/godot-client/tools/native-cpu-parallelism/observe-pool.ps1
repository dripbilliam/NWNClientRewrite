param([Parameter(Mandatory=$true)][ValidatePattern('^[a-z0-9-]+$')][string]$Label)
$ErrorActionPreference='Stop'
$poolProject=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'));$poolOut=Join-Path $poolProject ('.cache/nwn73/'+$Label)
if(Test-Path -LiteralPath $poolOut){throw 'Preserve earlier pool evidence'}
New-Item -ItemType Directory -Path (Join-Path $poolOut 'project/tests')|Out-Null
Copy-Item -LiteralPath (Join-Path $poolProject 'tests/nwn73_pool_inventory.gd') -Destination (Join-Path $poolOut 'project/tests/nwn73_pool_inventory.gd')
[IO.File]::WriteAllText((Join-Path $poolOut 'project/project.godot'),"config_version=5`n[application]`nconfig/name=`"NWN73 private pool inventory`"`n[rendering]`nrenderer/rendering_method=`"gl_compatibility`"`n")
$poolEngine=Join-Path $poolProject '.tools/native-core/Godot_native_core_e_win64.exe'
if((Get-FileHash -LiteralPath $poolEngine).Hash.ToLowerInvariant()-ne'753b3e188068efaf865bda3abd6322ebe44e3a98ef2f5d199c8af1a78624c98b'){throw 'Accepted E engine pin differs'}
$poolInfo=[Diagnostics.ProcessStartInfo]::new();$poolInfo.FileName=$poolEngine;$poolInfo.UseShellExecute=$false;$poolInfo.CreateNoWindow=$true;$poolInfo.WindowStyle='Hidden';$poolInfo.RedirectStandardOutput=$true;$poolInfo.RedirectStandardError=$true
foreach($poolArg in @('--headless','--verbose','--path',(Join-Path $poolOut 'project'),'--script','res://tests/nwn73_pool_inventory.gd','--',('--report='+(Join-Path $poolOut 'engine.json')))){$poolInfo.ArgumentList.Add($poolArg)}
$poolChild=[Diagnostics.Process]::new();$poolChild.StartInfo=$poolInfo
try {
 if(-not$poolChild.Start()){throw 'Owned idle engine did not start'}
 $poolStdout=$poolChild.StandardOutput.ReadToEndAsync();$poolStderr=$poolChild.StandardError.ReadToEndAsync()
 for($poolTry=0;$poolTry-lt100-and-not(Test-Path -LiteralPath (Join-Path $poolOut 'engine.json'));$poolTry++){Start-Sleep -Milliseconds 20}
 if(-not(Test-Path -LiteralPath (Join-Path $poolOut 'engine.json'))){throw 'Owned idle engine did not publish readiness'}
 & (Join-Path $PSScriptRoot 'inventory.ps1') -ClientPid $poolChild.Id -Report (Join-Path $poolOut 'windows.json')
 if(-not$poolChild.WaitForExit(15000)){throw 'Owned idle engine exceeded its lifetime'}
 [IO.File]::WriteAllText((Join-Path $poolOut 'stdout.log'),$poolStdout.GetAwaiter().GetResult());[IO.File]::WriteAllText((Join-Path $poolOut 'stderr.log'),$poolStderr.GetAwaiter().GetResult())
 if($poolChild.ExitCode-ne0){throw 'Owned idle engine failed'}
 $poolState=Get-Content -Raw -LiteralPath (Join-Path $poolOut 'windows.json')|ConvertFrom-Json
 @{engine=Get-Content -Raw -LiteralPath (Join-Path $poolOut 'engine.json')|ConvertFrom-Json;workerThreads=@($poolState.threads|Where-Object description -Like 'WorkerThread *').Count;target=$poolState.target;threadCount=$poolState.threads.Count}|ConvertTo-Json -Depth 6
}finally{if($poolChild.Id-gt0-and-not$poolChild.HasExited){$poolChild.Kill();[void]$poolChild.WaitForExit(5000)};$poolChild.Dispose()}
