extends RefCounted
# Cold original-scene survey; reads retained last-frame native state only.
# This cannot claim an emitter is thread safe from flags alone. In particular,
# standard() calls clear_hit for every moving active particle even without bounce.

static func summarize(group) -> Dictionary:
	if not is_instance_valid(group) or group.native==null:return {"success":false,"error":"native particle presentation absent"}
	var survey: Variant=group.native.call("dispatch",17,{})
	if not survey is Dictionary or survey.has("error") or not survey.get("rows",null) is Array:return {"success":false,"error":"cold native survey unavailable"}
	var rows: Array=survey.rows
	var result:={"success":true,"registered":int(survey.get("registered",-1)),"rows":rows.size(),"prepared":0,"unculled":0,"animation_invoked":0,"active_pool_emitters":0,"active_particles":0,"active_unculled_emitters":0,"active_unculled_particles":0,"empty_nonspawning_fountains":0,"wind_emitters":0,"bounce_emitters":0,"chunk_emitters":0,"kind_counts":{},"callback_free_active_proven":0,"proof":"Cold last-Step/source state only. Any moving active particle calls Godot hit-dictionary clear even without bounce; birth may call RNG/provider services. The survey lacks stopped-particle state and callback counts, so no active emitter is certified callback-free. Empty nonspawning fountains carry no useful simulation work."}
	for value in rows:
		if not value is Dictionary:result.success=false;continue
		var row: Dictionary=value
		if not bool(row.get("has_owner",false)):continue
		var kind: int=int(row.get("kind",-1))
		var flags: int=int(row.get("emitter_flags",0))
		var active: int=int(row.get("active",0))
		var prepared: bool=bool(row.get("prepared",false))
		var culled: bool=bool(row.get("current_culled",false))
		result.kind_counts[str(kind)]=int(result.kind_counts.get(str(kind),0))+1
		if prepared:result.prepared+=1
		if prepared and not culled:result.unculled+=1
		if bool(row.get("animation_invoked",false)):result.animation_invoked+=1
		if active>0:
			result.active_pool_emitters+=1;result.active_particles+=active
			if prepared and not culled:result.active_unculled_emitters+=1;result.active_unculled_particles+=active
		if kind==0 and active==0 and float(row.get("birth_rate",1.0))<=0:result.empty_nonspawning_fountains+=1
		if flags&4:result.wind_emitters+=1
		if flags&16:result.bounce_emitters+=1
		if bool(row.get("chunk",false)):result.chunk_emitters+=1
	if result.registered!=result.rows:result.success=false
	return result
