'use strict';
// Isolate the worker-verified metadata handoff against a frozen production
// source. Staging never launches the client or modifies accepted artifacts.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../..'),label=process.argv[2];
assert(/^[a-z0-9-]+$/.test(label??''));
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const read=file=>fs.readFileSync(file);
const baseFile=path.join(root,'.cache/native-presentation-parity/production-replay/nwn62-completion-tail-c/production-selection.json');
const base=JSON.parse(read(baseFile));
assert(base.complete&&base.production&&base.pins.length>2000);
assert.equal(base.renderCore.engineSha256,'753b3e188068efaf865bda3abd6322ebe44e3a98ef2f5d199c8af1a78624c98b');
assert.equal(base.renderCore.nativeKernelSha256,'485741af15f0581a3c60c0f9a8ae738888eba08716c7a5c2c2d1bd550828963d');
const changed=['systems/native_data/world_snapshot_metadata_job.gd','systems/native_data/world_snapshot_preparation.gd','systems/native_render/live_world.gd'];
const added='systems/native_data/world_snapshot_verified_packet.gd';
const directory=path.join(root,'.cache/nwn73',label);
assert(!fs.existsSync(directory),'Fresh stage label required');
function target(basePath,relative){
 assert(relative&&!path.isAbsolute(relative)&&!relative.split(/[\\/]/).some(part=>!part||part==='.'||part==='..'));
 const file=path.resolve(basePath,relative);assert(!path.relative(basePath,file).startsWith('..'));return file;
}
const inputs={};const pins={};
for(const mode of ['control','candidate']){
 const input=path.join(directory,mode+'-input');inputs[mode]=input;fs.mkdirSync(input,{recursive:true});pins[mode]=[];
 for(const pin of base.pins){
  const from=target(base.sourceProject,pin.relative);assert.equal(sha(read(from)),pin.sha256,'Frozen base changed: '+pin.relative);
  const dest=target(input,pin.relative);fs.mkdirSync(path.dirname(dest),{recursive:true});
  if(mode==='candidate'&&changed.includes(pin.relative))fs.writeFileSync(dest,read(target(root,pin.relative)),{flag:'wx'});
  else fs.linkSync(from,dest);
  pins[mode].push({relative:pin.relative,sha256:sha(read(dest))});
 }
 for(const relative of [...(mode==='candidate'?[added]:[]),'.tools/native-core/Godot_native_core_e_win64.exe','.tools/native-core/accepted-core-e.json']){
  const from=target(root,relative),dest=target(input,relative);fs.mkdirSync(path.dirname(dest),{recursive:true});
  if(relative===added)fs.writeFileSync(dest,read(from),{flag:'wx'});else fs.linkSync(from,dest);
  pins[mode].push({relative,sha256:sha(read(dest))});
 }
}
assert.equal(pins.candidate.filter(pin=>changed.includes(pin.relative)).length,changed.length);
const seeds={version:1,expected:base.preferences.expected,description:base.preferences.description};
for(const name of ['render','layout'])seeds[name]={file:path.join(path.dirname(base.sourceProject),base.preferences[name].relative),sha256:base.preferences[name].sha256};
const selector=require(path.join(inputs.control,'tools/native-production-selection.cjs'));
(async()=>{
 const selections={};const argv=[...base.options,'--world-snapshot-preparation=workers'];
 for(const mode of ['control','candidate']){
  const selected=await selector.stageProductionSelection({project:inputs[mode],label:'nwn73-'+label+'-'+mode,argv,preferenceSeeds:seeds,env:{}});
  assert.equal(selected.selection.renderCore.engineSha256,base.renderCore.engineSha256);
  assert.equal(selected.selection.renderCore.nativeKernelSha256,base.renderCore.nativeKernelSha256);
  assert(selected.selection.flags.includes('--world-snapshot-preparation=workers'));
  selections[mode]={file:selected.file,sha256:selected.sha256,sourceIdentity:selected.selection.mainSourceIdentity.sha256};
  for(const pin of pins[mode])assert.equal(sha(read(target(inputs[mode],pin.relative))),pin.sha256,'Input changed during stage: '+pin.relative);
 }
 const result={issue:'NWN-73',baseSelection:baseFile,baseSelectionSha256:sha(read(baseFile)),selections,inputs,pins,options:argv,changed:[...changed,added],originalCapture:'.cache/loading-benchmark-worlds/arelith-archive-shaders-v1',scope:'Private frozen source pair with workers explicitly selected in both legs; candidate differs only in three verified metadata handoff files plus one new proof helper. Same normal Core E engine/kernel/options and preference seeds. No launch or accepted artifact mutation.'};
 const file=path.join(directory,'staged.json');fs.writeFileSync(file,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({file,sha256:sha(read(file)),selections,pins:pins.control.length}));
})().catch(error=>{console.error(error.stack);process.exitCode=1;});
