'use strict';
// Propose shared adapters as private before/after files. The coordinator owns
// applying them; this tool never writes the shared AssetService/ResourcePool.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const project=path.resolve(__dirname,'../..'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
function one(s,a,b){assert.equal(s.split(a).length-1,1,a.slice(0,100));return s.replace(a,b);}
function transform(relative,before){
 assert(['systems/native_data/asset_service.gd','systems/native_render/resource_pool.gd'].includes(relative));let after=before.toString();
 if(relative.endsWith('asset_service.gd')){
  after=one(after,'const Raster = preload("res://systems/native_data/texture_data.gd")','const Raster = preload("res://systems/native_data/texture_data.gd")\nconst RasterUpload=preload("res://systems/native_data/raster_upload_preparation.gd")');
  after=one(after,'var shared_animation_preparation_enabled:=SharedAnimation.configured_enabled()','var shared_animation_preparation_enabled:=SharedAnimation.configured_enabled()\nvar raster_upload_preparation_enabled:=RasterUpload.configured_enabled()');
  after=one(after,'"requested_us":Time.get_ticks_usec(),"prework_write"','"requested_us":Time.get_ticks_usec(),"raster_upload_preparation":raster_upload_preparation_enabled and OS.get_thread_caller_id()==OS.get_main_thread_id() and completion_pool is Object and is_instance_valid(completion_pool) and completion_pool.has_method("raster_upload_preparation_active") and completion_pool.raster_upload_preparation_active(),"prework_write"');
  after=one(after,'func publish_result(job: Dictionary,result: Dictionary) -> void:\n\tif not job.status_only:','func publish_result(job: Dictionary,result: Dictionary) -> void:\n\tif not job.status_only and bool(job.get("raster_upload_preparation",false)) and str(result.get("error","")).is_empty():\n\t\tvar upload_began:=Time.get_ticks_usec();var sidecar:=RasterUpload.sidecar_on_worker(result)\n\t\tif not sidecar.get("rows",{}).is_empty():result._raster_upload_sidecar=sidecar\n\t\tvar upload_ms:=(Time.get_ticks_usec()-upload_began)/1000.0\n\t\tresult.worker_ms=float(result.get("worker_ms",0.0))+upload_ms\n\t\tvar upload_phases: Dictionary=result.get("phases",{}).duplicate();var upload_stats: Dictionary=sidecar.get("stats",{}).duplicate()\n\t\tupload_stats.merge({"enabled":true,"thread":OS.get_thread_caller_id(),"cpu_ms":upload_ms,"maximum_job_bytes":RasterUpload.MAX_JOB_BYTES});upload_phases.raster_upload_preparation=upload_stats;result.phases=upload_phases\n\tif not job.status_only:');
  after=one(after,'\t\tif not closed and int(result.get("epoch", -1)) == epoch:\n\t\t\tcompleted.emit(int(id), result);completion_stats.delivered+=1','\t\tif not closed and int(result.get("epoch", -1)) == epoch:\n\t\t\tvar upload_sidecar: Variant=result.get("_raster_upload_sidecar")\n\t\t\tresult.erase("_raster_upload_sidecar") # Never expose ready pixels to caller key/serialization/template code.\n\t\t\tif upload_sidecar is Dictionary and budget_owner is Object and is_instance_valid(budget_owner) and budget_owner.has_method("accept_raster_upload_sidecar"):budget_owner.accept_raster_upload_sidecar(upload_sidecar)\n\t\t\tupload_sidecar=null\n\t\t\tcompleted.emit(int(id), result);completion_stats.delivered+=1');
 }else{
  after=one(after,'const MeshPreparation=preload("res://systems/native_data/mesh_preparation.gd")','const MeshPreparation=preload("res://systems/native_data/mesh_preparation.gd")\nconst RasterUpload=preload("res://systems/native_data/raster_upload_preparation.gd")');
  after=one(after,'var use_prepared_geometry:=MeshPreparation.configured_enabled()','var use_prepared_geometry:=MeshPreparation.configured_enabled()\nvar use_raster_upload_preparation:=RasterUpload.configured_enabled()\nvar ready_raster_uploads: Dictionary={}\nvar ready_raster_order: Array[String]=[]\nvar ready_raster_bytes:=0\nvar raster_upload_counts:={"worker_jobs":0,"worker_rows":0,"worker_declined":0,"accepted":0,"consumed":0,"fallbacks":0,"cached_skips":0,"evictions":0,"invalid_sidecars":0,"invalid_packets":0,"peak_ready_bytes":0}\nvar raster_upload_threads: Array[int]=[]\nconst MAX_READY_RASTER_BYTES:=16*1024*1024');
  after=one(after,'func texture(record: Dictionary) -> Texture2D:',`func raster_upload_preparation_active() -> bool:return use_raster_upload_preparation
func accept_raster_upload_sidecar(sidecar: Dictionary) -> int:
	if not use_raster_upload_preparation or not main_thread():return 0
	if sidecar.get("revision")!=RasterUpload.REVISION or not sidecar.get("rows") is Dictionary or not sidecar.get("stats") is Dictionary or not sidecar.get("thread") is int or int(sidecar.thread)<=0 or int(sidecar.thread)==OS.get_main_thread_id():raster_upload_counts.invalid_sidecars+=1;return 0
	var rows: Dictionary=sidecar.rows
	if rows.size()>RasterUpload.MAX_RETAINED_ENTRIES:raster_upload_counts.invalid_sidecars+=1;return 0
	raster_upload_counts.worker_jobs+=1;raster_upload_counts.worker_rows+=rows.size();raster_upload_counts.worker_declined+=int(sidecar.stats.get("declined",0))
	if not raster_upload_threads.has(int(sidecar.thread)) and raster_upload_threads.size()<64:raster_upload_threads.append(int(sidecar.thread))
	var accepted:=0
	for key in rows:
		if not key is String or not rows[key] is Dictionary:raster_upload_counts.invalid_packets+=1;continue
		if textures.has(key):raster_upload_counts.cached_skips+=1;continue
		if ready_raster_uploads.has(key):continue
		var packet: Dictionary=rows[key]
		if packet.get("source_sha256")!=key or not RasterUpload.packet_supported(packet) or RasterUpload.retained_size(packet)>MAX_READY_RASTER_BYTES:raster_upload_counts.invalid_packets+=1;continue
		var bytes:=RasterUpload.retained_size(packet)
		while not ready_raster_order.is_empty() and (ready_raster_order.size()>=RasterUpload.MAX_RETAINED_ENTRIES or ready_raster_bytes+bytes>MAX_READY_RASTER_BYTES):_take_ready_raster(ready_raster_order[0]);raster_upload_counts.evictions+=1
		ready_raster_uploads[key]=packet;ready_raster_order.append(key);ready_raster_bytes+=bytes;accepted+=1
	raster_upload_counts.accepted+=accepted;raster_upload_counts.peak_ready_bytes=maxi(int(raster_upload_counts.peak_ready_bytes),ready_raster_bytes)
	return accepted
func _take_ready_raster(key: String) -> Dictionary:
	if not ready_raster_uploads.has(key):return {}
	var packet: Dictionary=ready_raster_uploads[key];ready_raster_bytes-=RasterUpload.retained_size(packet);ready_raster_uploads.erase(key);ready_raster_order.erase(key);return packet
func texture(record: Dictionary) -> Texture2D:`);
  after=one(after,'if textures.has(key): stats.texture_hits += 1; touch("texture",key); return textures[key]','if textures.has(key):\n\t\tstats.texture_hits += 1; touch("texture",key)\n\t\tif use_raster_upload_preparation:_take_ready_raster(key)\n\t\treturn textures[key]');
  const old=`	var bytes := PackedByteArray()
	for mip in mips: bytes.append_array(mip.data)
	var image := Image.create_from_data(width,height,mips.size()>1,image_format,bytes)
	if image == null or image.is_empty(): failure = "Native image construction failed"; return null
	# Native desktop fallback avoids an unsupported compressed-format readback.
	if image_format == Image.FORMAT_ETC:
		if image.decompress() != OK: failure = "Native ETC decompression failed"; return null
		stats.native_decompressions += 1
	if bool(data.get("generate_mips",false)) and image.generate_mipmaps() != OK: failure = "Native mip generation failed"; return null`;
  const changed=`	var image: Image=null
	if use_raster_upload_preparation:
		var packet:=_take_ready_raster(key)
		if not packet.is_empty():image=RasterUpload.image(record,packet)
	if image==null:
		if use_raster_upload_preparation:raster_upload_counts.fallbacks+=1
		var bytes := PackedByteArray()
		for mip in mips: bytes.append_array(mip.data)
		image = Image.create_from_data(width,height,mips.size()>1,image_format,bytes)
		if image == null or image.is_empty(): failure = "Native image construction failed"; return null
		# Native desktop fallback avoids an unsupported compressed-format readback.
		if image_format == Image.FORMAT_ETC:
			if image.decompress() != OK: failure = "Native ETC decompression failed"; return null
			stats.native_decompressions += 1
		if bool(data.get("generate_mips",false)) and image.generate_mipmaps() != OK: failure = "Native mip generation failed"; return null
	else:
		raster_upload_counts.consumed+=1
		stats["prepared_raster_uses"]=int(stats.get("prepared_raster_uses",0))+1
		if image_format==Image.FORMAT_ETC:stats.native_decompressions+=1`;
  after=one(after,old,changed);
  after=one(after,'\tstate.scope="Cumulative immutable GPU/template cache bindings; not live draw counts or a hard VRAM budget"','\tstate.raster_upload_preparation={"enabled":use_raster_upload_preparation,"counts":raster_upload_counts.duplicate(),"threads":raster_upload_threads.duplicate(),"ready_entries":ready_raster_uploads.size(),"ready_bytes":ready_raster_bytes,"maximum_ready_bytes":MAX_READY_RASTER_BYTES,"memo":RasterUpload.snapshot()}\n\tstate.scope="Cumulative immutable GPU/template cache bindings; not live draw counts or a hard VRAM budget"');
  after=one(after,'func clear() -> void:\n','func clear() -> void:\n\tready_raster_uploads.clear();ready_raster_order.clear();ready_raster_bytes=0\n');
 }
 return Buffer.from(after);
}
function prepare(label){
 assert(/^raster-adapter-[a-z0-9-]+$/.test(label??''));const out=path.join(project,'.cache/nwn73',label);assert(!fs.existsSync(out));fs.mkdirSync(out,{recursive:true});
 const rows=[];
 for(const relative of ['systems/native_data/asset_service.gd','systems/native_render/resource_pool.gd']){
  const before=fs.readFileSync(path.join(project,relative)),candidate=transform(relative,before);
  for(const [folder,bytes]of [['before',before],['after',candidate]]){const file=path.join(out,folder,relative);fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,bytes,{flag:'wx'});}
  rows.push({relative,beforeSha256:sha(before),afterSha256:sha(candidate),beforeBytes:before.length,afterBytes:candidate.length});
 }
 const helper=fs.readFileSync(path.join(project,'systems/native_data/raster_upload_preparation.gd'));const manifest={version:1,issue:'NWN-73',privateProposalOnly:true,files:rows,helperSha256:sha(helper),projectSetting:{name:'nwn/private/raster_upload_preparation',enabledValue:true,defaultWhenAbsent:false,noCliOrEnvironmentBypass:true},scope:'Optional existing-worker CPU sidecar; main completion current-epoch handoff to compatible bound ResourcePool, then erase before emit. Original rasters/headers/key bytes and persistent bundle content untouched. No new task/poll/frame barrier; no accepted runtime/default changes.',budgets:{memoBytes:64*1024*1024,maximumMemoEntries:256,jobSidecarBytes:16*1024*1024,poolReadyBytes:16*1024*1024}};fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});return manifest;
}
module.exports={transform,prepare};
if(require.main===module)console.log(JSON.stringify(prepare(process.argv[2])));
