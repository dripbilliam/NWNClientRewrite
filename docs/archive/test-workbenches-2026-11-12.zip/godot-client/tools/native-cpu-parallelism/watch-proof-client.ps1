param(
  [Parameter(Mandatory=$true)][ValidatePattern('^[a-z0-9-]+$')][string]$Run,
  [Parameter(Mandatory=$true)][string]$Selection,
  [Parameter(Mandatory=$true)][string]$Output,
  [ValidateRange(250,1000)][int]$IntervalMilliseconds=500,
  [ValidateRange(30,600)][int]$MaximumSeconds=300,
  [switch]$Preflight
)
# Read-only exact-client memory observation. Start before the corresponding
# replay driver; never inspect a user's unrelated game process.
$ErrorActionPreference='Stop'
$watchProject=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$watchOutput=[IO.Path]::GetFullPath($Output)
if(-not $watchOutput.StartsWith(([IO.Path]::GetFullPath((Join-Path $watchProject '.cache/nwn73'))+[IO.Path]::DirectorySeparatorChar),[StringComparison]::OrdinalIgnoreCase)){throw 'Memory report must stay under .cache/nwn73'}
if(Test-Path -LiteralPath $watchOutput){throw 'Memory report already exists'}
$watchSelection=Get-Content -LiteralPath $Selection -Raw | ConvertFrom-Json
$watchExecutable=[IO.Path]::GetFullPath([string]$watchSelection.runtime.executable)
$watchExecutableHash=[string]$watchSelection.runtime.executableSha256
if((Get-FileHash -LiteralPath $watchExecutable -Algorithm SHA256).Hash.ToLowerInvariant() -ne $watchExecutableHash){throw 'Selected engine hash differs'}
if($Preflight){
  $watchSelfProbe=Get-Process -Id $PID
  $watchCandidates=@(Get-Process -Name 'Godot_native_core_e_win64' -ErrorAction SilentlyContinue)
  [pscustomobject]@{success=($watchSelfProbe.PeakWorkingSet64 -gt 0 -and $watchSelfProbe.WorkingSet64 -gt 0);selected_engine=$watchExecutable;selected_sha256=$watchExecutableHash;current_peak_bytes=$watchSelfProbe.PeakWorkingSet64;candidate_count=$watchCandidates.Count} | ConvertTo-Json -Compress
  return
}
$watchNativeReport=Join-Path $watchProject ('reports/'+$Run+'.native.json')
$watchFinalReport=Join-Path $watchProject ('reports/'+$Run+'.json')
$watchSelf=[Diagnostics.Process]::GetCurrentProcess();$watchCpuStart=$watchSelf.TotalProcessorTime.TotalMilliseconds
$watchDeadline=[DateTime]::UtcNow.AddSeconds($MaximumSeconds)
$watchClient=$null;$watchIdentity=$null;$watchSamples=[Collections.Generic.List[object]]::new();$watchFailure=$null
try{
  while([DateTime]::UtcNow -lt $watchDeadline -and -not $watchClient){
    if(Test-Path -LiteralPath $watchFinalReport){throw 'Replay finished before exact client was observed'}
    $watchMatches=[Collections.Generic.List[object]]::new()
    foreach($watchCandidate in @(Get-Process -Name 'Godot_native_core_e_win64' -ErrorAction SilentlyContinue)){
      try{$watchImage=[IO.Path]::GetFullPath([string]$watchCandidate.Path)}catch{continue}
      if($watchImage -ne $watchExecutable){continue}
      $watchMatches.Add($watchCandidate)
    }
    if($watchMatches.Count -gt 1){throw 'Multiple clients use the exact staged engine path'}
    foreach($watchObserved in $watchMatches){
      if((Get-FileHash -LiteralPath $watchExecutable -Algorithm SHA256).Hash.ToLowerInvariant() -ne $watchExecutableHash){throw 'Observed engine hash changed'}
      $watchClient=$watchObserved
      $watchIdentity=@{pid=$watchClient.Id;start_utc=$watchClient.StartTime.ToUniversalTime().ToString('o');executable=$watchExecutable;executable_sha256=$watchExecutableHash;native_report=$watchNativeReport}
      break
    }
    if(-not $watchClient){Start-Sleep -Milliseconds $IntervalMilliseconds}
  }
  if(-not $watchClient){throw 'Exact client did not appear before deadline'}
  while(-not $watchClient.HasExited -and [DateTime]::UtcNow -lt $watchDeadline){
    $watchClient.Refresh()
    $watchSamples.Add(@{utc=[DateTime]::UtcNow.ToString('o');working_set_bytes=$watchClient.WorkingSet64;peak_working_set_bytes=$watchClient.PeakWorkingSet64;private_bytes=$watchClient.PrivateMemorySize64;cpu_ms=$watchClient.TotalProcessorTime.TotalMilliseconds})
    Start-Sleep -Milliseconds $IntervalMilliseconds
  }
  if(-not $watchClient.HasExited){throw 'Observation deadline reached; client left running'}
  if($watchSamples.Count -lt 5){throw 'Too few memory samples'}
}catch{$watchFailure=$_.Exception.Message}
$watchSelf.Refresh()
$watchResult=[ordered]@{success=($null -eq $watchFailure);failure=$watchFailure;run=$Run;selection=$Selection;identity=$watchIdentity;interval_ms=$IntervalMilliseconds;watcher_cpu_ms=$watchSelf.TotalProcessorTime.TotalMilliseconds-$watchCpuStart;samples=$watchSamples.ToArray();scope='Exact owned Godot process peak working set, private bytes and CPU time; sampling every 500 ms. PeakWorkingSet64 is the OS lifetime high-water mark, not GPU memory or per-system allocations.'}
[IO.File]::WriteAllText($watchOutput,($watchResult|ConvertTo-Json -Depth 8)+[Environment]::NewLine)
if(-not $watchResult.success){throw ('Memory observation failed: '+$watchFailure)}
Write-Output (@{success=$true;report=$watchOutput;samples=$watchSamples.Count}|ConvertTo-Json -Compress)
