'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../..'),capture=path.join(root,'.cache/loading-benchmark-worlds/arelith-archive-shaders-v1'),out=path.join(root,'.cache/nwn73/api-phase-a');
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const manifestBytes=fs.readFileSync(path.join(capture,'recording.json'));
assert.equal(hash(manifestBytes),'1922ba3b82b44d1982978850a7d0ef3f67a24d56130ec3f859a689ff77affe20');
const manifest=JSON.parse(manifestBytes),timeline=fs.readFileSync(path.join(capture,'timeline.jsonl'));
assert.equal(hash(timeline),manifest.timelineSha256);
const rows=[];let active=false,serial=-1,area=-1;
for(const line of timeline.toString('utf8').split('\n')){
 if(!line)continue;const event=JSON.parse(line),m=event.value||{};
 if(m.kind==='raw-world-begin'){
  active=m.generation===5&&m.data?.bridgeMode==='full';
  if(active){serial=m.serial;area=m.data.area?.id;assert.equal(m.count,2832);}
 }else if(active&&m.kind==='raw-world-chunk')rows.push(...m.objects);
 else if(active&&m.kind==='raw-world-end'){assert.equal(m.serial,serial);active=false;break;}
}
assert.equal(rows.length,2832);assert(Number.isSafeInteger(area));
fs.mkdirSync(out,{recursive:true});const file=path.join(out,'original-g5-objects.json'),receipt=path.join(out,'input-receipt.json');
assert(!fs.existsSync(file)&&!fs.existsSync(receipt),'Preserve existing fixture');
const bytes=Buffer.from(JSON.stringify({area,serial,rows})+'\n');fs.writeFileSync(file,bytes,{flag:'wx'});
const result={captureManifestSha256:hash(manifestBytes),timelineSha256:manifest.timelineSha256,file,sha256:hash(bytes),rows:rows.length,serial,area,bytes:bytes.length,scope:'Exact original received JSON rows; phase component timing excludes file/JSON parse and scene admission'};
fs.writeFileSync(receipt,JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));
