# NWN-73 current-source preview packet cache checkpoint

Status: source and light headless verification complete. The worker and its detached surface cache remain default off. No original-input replay, graphical test, FPS timing, Arelith acceptance or accepted engine build was run in this checkpoint. NWN-73 stays In Progress.

## Selection and source

- `systems/native_render/drive_collision_indexed.gd` SHA-256 `f3c2b35e783dd7d0dec24a1978a6f47edc2e3024ef2f37d8b158b6a8cfaca928` contains the previously implemented detached tile/mesh/triangle/table packet cache and the raw `--drive-preview-surface-cache=on` selector. This assignment did not edit the collision implementation.
- The normal feature registry now declares `drive-preview-surface-cache=off|on`, default `off`, requiring indexed collision and `drive-preview-worker=on`. SHA-256 `0fc4862c7c29265dec61d6de6db3ed345152e06940436cc33ac914f10726ef95`.
- `tools/native-client-flags.cjs` forwards an **explicit** cache selection through the normal native performance argument route; an absent option remains unforwarded and off. SHA-256 `dcbfcaf16043b65ab7e9e41a70ddd4508f70cfb03bfd6e68003db097dea5573a`.
- Accepted Core E executable SHA-256 `753b3e188068efaf865bda3abd6322ebe44e3a98ef2f5d199c8af1a78624c98b` was read only.

## Light gates

`node tools/native-cpu-parallelism/check-preview-surface-flag.cjs` passed 19 assertions: default off, absent flag unforwarded, explicit OFF/ON forwarded, worker/indexed dependencies, invalid/repeated option rejection, and equal render core. Existing `tests/nwn73_preview_worker_flag.test.cjs` passed 21/21.

Actual headless SceneTree packet fixture `tests/nwn73_preview_surface_cache_test.gd` passed 408/408 on the current collision source; report `.cache/nwn73/reusable-preview-current-g.json` SHA-256 `f80b6e002a47a6048120bde373b588dd7759464c6a88590d01ca94d44b5c2d52`. The 1,153-face synthetic ABBA snapshot medians were OFF 2.654/2.719 ms, ON 1.657/1.622 ms over 48 calls per leg. Packet bytes, 38-probe paths/reasons, concurrent worker read, in-place source edits, same-ID replacement, bounded cache reset and area supersession all matched. The before-reset detached cache retained 484,692 serialized bytes. These are component timings, not whole-client FPS.

The 74 original WOK corpus passed 300/300 checks, including exact worker/main path bytes and ordered probes, report `.cache/nwn73/preview-cache-original-h.json` SHA-256 `4b193f0ec0df831254d41b9ef200852d572253068f5da8fee7804cf4a0485e4c`. The indexed adapter fixture passed 213/213, report `.cache/nwn73/preview-cache-spatial-h.json` SHA-256 `b85368d9d0a1d8073795a8b17498232d67212a76fea2b04557e64b3e6df29498`. Existing accepted Core E produced the same known sandbox log/root-certificate diagnostics and exited zero for these fixtures.

## Pinned movement replay, not launched

`tools/native-cpu-parallelism/stage-preview-cache-pair.cjs` created `.cache/nwn73/nwn73-preview-cache-h/plan.json`, SHA-256 `a6e211584b72f6c15d2ecae980636cbe01208dbc3288d5d97583717f35462ad7`. Both production selections pin the same 2,507 source files and source identity `f649aa31937b94206003c67adfe43da44751cccf2335ecd289b8b82c47b08867`, Core E, native kernel, original generation-2 `capture-YaH3xf` recording SHA-256 `1913892cd42db0f68dfa1b0edbdd37be4c380bdda50c95c178dc4ca2ba38a463`, preferences, camera policy and all other runtime flags. Both select the existing whole-preview worker ON; only `--drive-preview-surface-cache=off|on` differs. `tools/native-cpu-parallelism/run-preview-cache-pair.cjs` without `--run` revalidated selection pins, source identity, options and capture with zero client starts. It is staged for OFF/ON/ON/OFF with `--movement-window`, which separates moving-frame intervals from the later quiet steady window. The runner accepts `--run` only during a coordinator-granted exclusive PC lease.

The prior whole-preview worker replay admitted only 8 of 35 jobs, with 31 busy fallbacks and 27 stale pose/serial completions. Packet-copy savings cannot be promoted on component timing alone. The pending replay must compare exact 360 movement decisions, final path/packet/camera state, ordered milestones, worker admissions/fallbacks, moving-frame median/p95/p99/worst, quiet frame intervals, first playable/full known BASE, peak memory and diagnostics. A live Arelith acceptance remains separate. Do not infer a whole-client gain or change defaults until those gates pass.
