'use strict';
// Read-only NWN-63 normal-client acceptance pin check. Does not launch a client.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../..'),pins={
 'join-native.ps1':'64d6d4a8c8a5e004b7f2b3751726891be413bf97635b01c8a241a46e8390ada7',
 'tools/native-performance-runtime.cjs':'50f0140b7cc4c0047fb107ad7d0ea4887a2f9c968c961220f4086fc2d9a5a57b',
 'tools/native-client-flags.cjs':'cfd6ba5a2075218657be464c6bb2b1db73f7c034685932eb778d79da5e589aab',
 'systems/native_data/client_feature_registry.json':'d18c51e20ccf74eb6c0c68dad4b2825c1b02870de1a2db957541fadb049498b7',
 'systems/native_render/drive_collision_indexed.gd':'76e72d0477c2bc78c4f4c3702931c00c75461d925e911ca9ed1a072666c8be33',
 'systems/native_render/drive_height_index.gd':'bcdadfe5a573116c0a5fe5e5d3f9d617051574eab2ba9a45d3982e481c3a507f',
 'systems/native_render/drive_spatial_index.gd':'33864b13f75604548e7bbe1e1263536a6d4ff2db24b3e59b8b7882cc6673e209',
 'systems/native_render/live_world.gd':'b4258d1267627d3f9ba8cdf3115e2489b5ea3d4979da03e296a1b79bf8f9051c',
 'systems/world_input.gd':'7fb1d26e034368e7bb39ad4d4c2f08e0edf6ee90cf0f60e3f3330be2372f5da4',
 'systems/native_keyboard.gd':'be9a113fcd29748486d2994aebe38b20d46774d11b57a44987134834a8915666',
 '.tools/native-core/Godot_native_core_e_win64.exe':'753b3e188068efaf865bda3abd6322ebe44e3a98ef2f5d199c8af1a78624c98b',
 '.cache/native-kernel/nwn-particle-kernel.dll':'485741af15f0581a3c60c0f9a8ae738888eba08716c7a5c2c2d1bd550828963d',
 '.tools/native-core/accepted-core-e.json':'29b1c6adcdecb11eebc859730c770e879a108279dfaaf60792e4c11c00add78a'};
const sha=f=>crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');for(const [name,expected] of Object.entries(pins))assert.equal(sha(path.join(root,name)),expected,'NWN-63 acceptance pin changed: '+name);
const registry=JSON.parse(fs.readFileSync(path.join(root,'systems/native_data/client_feature_registry.json'))),rows=registry.features??registry;const option=rows.find(x=>x.name==='drive-preview-height-index');assert(option);assert.equal(option.default,'off');assert.equal(option.requires['drive-collision'],'indexed');assert.equal(option.requires['drive-height-plan'],'off');
const modes=['off','on','on','off'];const commands=modes.map((m,i)=>`pwsh -NoProfile -File .\\join-native.ps1 -Run nwn63-live-height-${'abcd'[i]}-${m} -PerformanceRuntime verified-native -DriveCollision indexed -DriveHeightPlan off -DrivePreviewHeightIndex ${m} -DetailedProfiling on -Profile`);
console.log(JSON.stringify({verified:true,scope:'Read-only pinned normal Core E/DLL/source preflight; no client launched, no FPS result',pins,order:'OFF/ON/ON/OFF',commands,estimatedMinutes:'16–24 including four logins and two 45-second movement segments per leg'},null,2));
