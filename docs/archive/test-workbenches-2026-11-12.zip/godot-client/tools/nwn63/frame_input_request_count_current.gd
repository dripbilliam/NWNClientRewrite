extends "res://tools/nwn63/frame_input_admission_current.gd"

# Actual SubViewport OS-key events with frozen pose and scene revision.
# The original-style admitted tick may collapse the equivalent echo burst.
func run()->void:
	var destination:=""
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--report="):destination=argument.trim_prefix("--report=")
	if destination.is_empty() or FileAccess.file_exists(destination):quit(2);return
	var legs: Array=[]
	for admission in [false,true]:
		var f:=input_fixture(admission)
		var effective: Array=[]
		var scene_revision:=17
		f.input.predict=func(id: int,flags: int,heading: int)->Dictionary:
			effective.append([id,flags,heading,f.state.position,f.state.render,f.state.orientation,int(f.state.lifetime),scene_revision])
			return {"target":Vector3(3,3,0),"factor":1.0}
		for index in 64:push_key(f,KEY_W,true,index>0)
		if admission:f.input.flush_input_frame(1,1000)
		var repeated:=effective.size()==64 and effective.all(func(row):return var_to_bytes(row)==var_to_bytes(effective[0])) if not admission else effective.size()==1
		check(repeated,"Equivalent frozen-pose/revision W echoes become one admitted prediction")
		check(f.sent.size()==(1 if admission else 64),"Packet count follows selected admitted scheduler")
		if admission:
			check(f.input.stats.admission_events==64 and f.input.stats.admission_coalesced_events==63,"All 64 OS echoes are admitted and 63 same-cycle repeats are coalesced")
		var signature:=var_to_bytes(effective[0]).hex_encode() if not effective.is_empty() else ""
		legs.append({"admission":admission,"os_events":64,"requests":f.sent.size(),"predictions":effective.size(),"effective_signature":signature,"admitted":f.input.stats.admission_events,"coalesced":f.input.stats.admission_coalesced_events})
		dispose_input(f)
	check(legs[0].effective_signature==legs[1].effective_signature,"One admitted prediction has the same effective collision inputs as every control echo")
	var report:={"passed":failures.is_empty(),"checks":checks,"failures":failures,"legs":legs,"scope":"Actual OS key echo admission at a fixed actor pose and fixed synthetic scene revision. This proves equivalent local prediction inputs for this burst, not equivalence across live geometry, click movement, or FPS."}
	var file:=FileAccess.open(destination,FileAccess.WRITE);file.store_string(JSON.stringify(report,"  "));file.close();quit(0 if failures.is_empty() else 1)
