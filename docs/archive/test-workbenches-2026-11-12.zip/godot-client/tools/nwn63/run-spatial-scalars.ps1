param(
    [Parameter(Mandatory=$true)][ValidatePattern('^[a-z0-9-]+$')][string]$Label,
    [ValidateRange(32,256)][int]$Samples=96
)
$ErrorActionPreference='Stop'
$taskProject=(Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$taskManifest=Get-Content -LiteralPath (Join-Path $taskProject '.cache/nwn63/spatial-scalars-a/inputs.json') -Raw | ConvertFrom-Json
foreach ($taskInput in $taskManifest.inputs) {
    $taskActual=(Get-FileHash -LiteralPath (Join-Path $taskProject $taskInput.relative) -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($taskActual -ne $taskInput.sha256) {throw "Frozen source changed: $($taskInput.relative)"}
}
$taskReport=Join-Path $taskProject ".cache/nwn63/spatial-scalars-a/$Label.json"
$taskEngineLog=Join-Path $taskProject ".cache/nwn63/spatial-scalars-a/$Label.engine.log"
$taskLog=Join-Path $taskProject ".cache/nwn63/spatial-scalars-a/$Label.log"
foreach ($taskOutput in @($taskReport,$taskEngineLog,$taskLog)) {if (Test-Path -LiteralPath $taskOutput) {throw "Output exists: $taskOutput"}}
$taskFlags=$taskManifest.flags
& (Join-Path $taskProject '.tools/native-core/Godot_native_core_e_win64.exe') --headless --path $taskProject --log-file $taskEngineLog --script res://tests/nwn63_spatial_scalars_benchmark.gd -- @taskFlags "--report=$taskReport" "--samples=$Samples" 2>&1 | Tee-Object -FilePath $taskLog
if ($LASTEXITCODE -ne 0) {throw "Headless component failed: $LASTEXITCODE"}
$taskText=(Get-Content -LiteralPath $taskLog -Raw)+(Get-Content -LiteralPath $taskEngineLog -Raw)
if ($taskText -match 'SCRIPT ERROR|(?:^|\s)ERROR:|Parse Error|ObjectDB instances leaked|resources still in use') {throw 'Engine diagnostics failed'}
$taskResult=Get-Content -LiteralPath $taskReport -Raw | ConvertFrom-Json
if (-not $taskResult.success -or $taskResult.failures.Count -ne 0) {throw 'Component correctness failed'}
foreach ($taskInput in $taskManifest.inputs) {
    $taskActual=(Get-FileHash -LiteralPath (Join-Path $taskProject $taskInput.relative) -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($taskActual -ne $taskInput.sha256) {throw "Source changed during component: $($taskInput.relative)"}
}
$taskResult | ConvertTo-Json -Depth 20
