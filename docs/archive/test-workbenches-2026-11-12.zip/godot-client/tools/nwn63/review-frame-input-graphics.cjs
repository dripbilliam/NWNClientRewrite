'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../..'),folder=path.join(root,'.cache/nwn63/frame-input-live-graphics-e');
const read=file=>fs.readFileSync(file),json=file=>JSON.parse(read(file));
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const pairs=[];
for(const suffix of ['b','c']){
 const row={suffix};
 for(const leg of ['control','candidate']){
  const run='nwn63-frame-input-e-'+leg+'-'+suffix;
  const reportFile=path.join(root,'reports',run+'.json'),resultFile=path.join(folder,run+'.result.json'),invocationFile=path.join(folder,run+'.invocation.json');
  const report=json(reportFile),result=json(resultFile),invocation=json(invocationFile),probe=report.native?.nwn63_os_input_probe;
  assert.equal(result.exit,0,run+' exit');assert.equal(result.success,true,run+' runner');
  assert.equal(report.success,true,run+' report');assert.equal(report.engineOrLifetimeError,false,run+' engine');assert.equal(report.sourceUnchanged,true,run+' source');
  assert.equal(report.movementReplay.inputs,360,run+' movement');assert.equal(report.movementReplay.accepted,360,run+' accepted');
  assert.equal(report.productionCameraVerification.status,'observed',run+' camera');
  assert.equal(report.productionWindowVerification.status,'observed',run+' window');
  assert.equal(report.productionPreferences.verification.status,'observed',run+' preferences');
  assert.equal(report.replayDisplay.screen,1,run+' screen');assert.equal(report.replayDisplay.primary,2,run+' primary');
  assert.equal(report.replayDisplay.policy,'current-largest-nonprimary',run+' display policy');
  assert.equal(report.steadyCompleted,true,run+' steady');assert.equal(report.steadyDurationMs,10000,run+' duration');
  assert.equal(probe.world_ready,true,run+' world');assert.equal(probe.state_restored,true,run+' restoration');
  assert.equal(probe.frame_intervals,60,run+' burst frames');assert.equal(probe.frame_admission,leg==='candidate',run+' route');
  assert.equal(invocation.screen,null,run+' no screen override');
  row[leg]={run,report:reportFile,reportSha256:sha(read(reportFile)),resultSha256:sha(read(resultFile)),invocationSha256:sha(read(invocationFile)),burst:{medianMs:probe.median_ms,p95Ms:probe.p95_ms,maxMs:probe.max_ms,frames:probe.frame_intervals},steady:{averageMs:report.native.frame_intervals.average_ms,p95Ms:report.native.frame_intervals.p95_ms,p99Ms:report.native.frame_intervals.p99_ms,count:report.native.frame_intervals.count},counts:{admitted:probe.stats_after.admission_events,coalesced:probe.stats_after.admission_coalesced_events,previews:probe.stats_after.previews,packets:probe.packets}};
 }
 pairs.push(row);
}
const average=(values)=>values.reduce((a,b)=>a+b,0)/values.length;
const aggregate={};for(const leg of ['control','candidate'])aggregate[leg]={burstMedianMs:average(pairs.map(row=>row[leg].burst.medianMs)),burstP95Ms:average(pairs.map(row=>row[leg].burst.p95Ms)),steadyAverageMs:average(pairs.map(row=>row[leg].steady.averageMs))};
const improvement={burstMedianMs:aggregate.control.burstMedianMs-aggregate.candidate.burstMedianMs,burstMedianPercent:100*(aggregate.control.burstMedianMs-aggregate.candidate.burstMedianMs)/aggregate.control.burstMedianMs,burstP95Ms:aggregate.control.burstP95Ms-aggregate.candidate.burstP95Ms,burstP95Percent:100*(aggregate.control.burstP95Ms-aggregate.candidate.burstP95Ms)/aggregate.control.burstP95Ms,steadyAverageMs:aggregate.control.steadyAverageMs-aggregate.candidate.steadyAverageMs,steadyAveragePercent:100*(aggregate.control.steadyAverageMs-aggregate.candidate.steadyAverageMs)/aggregate.control.steadyAverageMs,previewCallsSaved:59,packetsSaved:59};
const normalCheckpoint=path.join(root,'.cache/nwn63/frame-input-live-e/checkpoint.json');
const previousRunner=path.join(folder,'run-graphics-root-only-v1.cjs'),currentRunner=path.join(folder,'run-graphics-root-only.cjs');
assert.equal(sha(read(previousRunner)),json(normalCheckpoint).runner.sha256,'Historical runner preserved');
const output={version:1,issue:'NWN-63',order:['control-b','candidate-b','candidate-c','control-c'],checkpoint:{file:normalCheckpoint,sha256:sha(read(normalCheckpoint))},pairs,aggregate,improvement,runner:{historicalSha256:sha(read(previousRunner)),currentFile:currentRunner,currentSha256:sha(read(currentRunner)),fix:'Remove optional --screen argument; automatic current-largest-nonprimary display selection remains'},interpretation:'Repeatable gain in a 60-frame synthetic W echo burst in the original recorded graphical area. The full 10-second steady average changes little. Burst injects two echoes every frame, far denser than the 22 extra previews across 627 preview-containing intervals in newesttrace. Synthetic packets are locally sunk and the initial motion state restored; this is not live Arelith or click-to-move acceptance.',remaining:['Matched manual keyboard and click-to-move on Arelith with the normal staged pair, accepted Core E/kernel and same resolution/view/settings','Compare median, p95 and p99 frame intervals, actual preview calls, collision/path CPU and loading latency','Exercise dynamic blockers, doors, elevation, overlapping surfaces, server correction, focus loss and area transition','Review visual parity and normal packet/ACK behavior before promoting private default-off adapter']};
const file=path.join(folder,'abba-review-b.json');
if(fs.existsSync(file))assert.deepEqual(json(file),output,'Review drift');
else fs.writeFileSync(file,JSON.stringify(output,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({file,sha256:sha(read(file)),improvement,runnerSha256:output.runner.currentSha256}));
