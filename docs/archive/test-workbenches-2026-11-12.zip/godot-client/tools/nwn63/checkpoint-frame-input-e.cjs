'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../..'),base=path.join(root,'.cache/nwn63');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),read=f=>fs.readFileSync(f),json=f=>JSON.parse(read(f));
const normal=path.join(base,'frame-input-live-e'),graphics=path.join(base,'frame-input-live-graphics-e');
const pair=json(path.join(normal,'pair.json')),staged=json(path.join(normal,'staged.json'));
const graphicPair=json(path.join(graphics,'pair.json')),graphicStaged=json(path.join(graphics,'staged.json'));
assert.equal(sha(read(path.join(normal,'pair.json'))),staged.pairSha256);
assert.equal(sha(read(path.join(graphics,'pair.json'))),graphicStaged.pairSha256);
assert.equal(pair.engineSha256,graphicPair.engineSha256);assert.equal(pair.kernelSha256,graphicPair.kernelSha256);
const sourceFiles=['native_live_world.gd','systems/native_keyboard.gd','systems/native_render/drive_collision_indexed.gd','systems/native_render/drive_spatial_index.gd'];
for(const leg of ['control','candidate']){
 for(const file of sourceFiles)assert.equal(sha(read(path.join(pair[leg],file))),sha(read(path.join(graphicPair[leg],file))),leg+'/'+file);
 for(const pin of pair.pins[leg])assert.equal(sha(read(path.join(pair[leg],pin.relative))),pin.sha256,leg+'/'+pin.relative);
 for(const pin of graphicPair.pins[leg])assert.equal(sha(read(path.join(graphicPair[leg],pin.relative))),pin.sha256,leg+'/'+pin.relative);
 const protocol=json(path.join(normal,'protocol-a-'+leg+'.json'));
 assert.equal(protocol.success,true);assert.equal(protocol.checks,34);assert.deepEqual(protocol.failures,[]);
 const selection=staged.selections.find(row=>row.leg===leg),graphicSelection=graphicStaged.selections.find(row=>row.leg===leg);
 assert.equal(sha(read(selection.file)),selection.sha256);assert.equal(sha(read(graphicSelection.file)),graphicSelection.sha256);
 const report=json(path.join(root,'reports','nwn63-os-probe-headless-e-'+leg+'-a.json'));
 assert.equal(report.success,true);assert.equal(report.engineOrLifetimeError,false);
 assert.equal(report.gameNetworkConnections,0);assert.equal(report.movementReplay.inputs,360);assert.equal(report.movementReplay.accepted,360);
 assert.equal(report.productionCameraVerification.status,'observed');
 const probe=report.native.nwn63_os_input_probe;
 assert.equal(probe.state_restored,true);assert.equal(probe.world_ready,true);assert.equal(probe.frame_intervals,60);
 assert.equal(probe.frame_admission,leg==='candidate');
 if(leg==='candidate')assert(probe.stats_after.admission_coalesced_events>0);
}
const receipt=json(path.join(base,'driver-os-b/receipt.json'));
assert.equal(sha(read(receipt.original)),receipt.originalSha256);
assert.equal(sha(read(receipt.driver)),receipt.driverSha256);
const runner=path.join(graphics,'run-graphics-root-only.cjs');
const legs={};for(const leg of ['control','candidate']){
 const reportFile=path.join(root,'reports','nwn63-os-probe-headless-e-'+leg+'-a.json'),report=json(reportFile),probe=report.native.nwn63_os_input_probe;
 legs[leg]={protocolChecks:34,headlessReport:reportFile,headlessReportSha256:sha(read(reportFile)),recordedInputs:360,recordedAccepted:360,camera:report.productionCameraVerification.status,probe:{admitted:probe.stats_after.admission_events,coalesced:probe.stats_after.admission_coalesced_events,previews:probe.stats_after.previews,packets:probe.packets,frames:probe.frame_intervals,stateRestored:probe.state_restored}};
}
const output={version:1,issue:'NWN-63',status:'private default-off candidate, no FPS acceptance',normalPair:{file:path.join(normal,'pair.json'),sha256:staged.pairSha256,staged:path.join(normal,'staged.json'),stagedSha256:sha(read(path.join(normal,'staged.json')))},graphicalPair:{file:path.join(graphics,'pair.json'),sha256:graphicStaged.pairSha256,staged:path.join(graphics,'staged.json'),stagedSha256:sha(read(path.join(graphics,'staged.json')))},driver:{file:receipt.driver,sha256:receipt.driverSha256},runner:{file:runner,sha256:sha(read(runner)),lease:'NWN63_FPS_LEASE=root-exclusive; coordinator pauses all workers before FPS'},acceptedEngineSha256:pair.engineSha256,acceptedKernelSha256:pair.kernelSha256,legs,comparison:{previewsSaved:legs.control.probe.previews-legs.candidate.probe.previews,packetsSaved:legs.control.probe.packets-legs.candidate.probe.packets,scope:'Headless functional original recorded world plus synthetic same-frame W echoes. No FPS claim; later graphical run requires exclusive lease and visual review.'},limitation:'Offline recorded movement bypasses OS input and disables keyboard. Graphical probe injects actual viewport events only during steady, sinks synthetic packets locally and restores pre-probe state; live Arelith keyboard/click acceptance remains outstanding.'};
const file=path.join(normal,'checkpoint.json');
if(fs.existsSync(file))assert.deepEqual(json(file),output,'Checkpoint drift');
else fs.writeFileSync(file,JSON.stringify(output,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({file,sha256:sha(read(file)),normalPair:output.normalPair.sha256,graphicalPair:output.graphicalPair.sha256,previewsSaved:output.comparison.previewsSaved,packetsSaved:output.comparison.packetsSaved}));
