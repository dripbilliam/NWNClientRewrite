const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const root = process.cwd();
const sha = value => crypto.createHash('sha256').update(value).digest('hex');
const pin = file => ({path: file, sha256: sha(fs.readFileSync(file))});
const output = '.cache/nwn63/frame-admission-source-a';
if (fs.existsSync(output)) throw new Error('Existing proposal retained; use a new revision rather than overwrite.');
fs.mkdirSync(path.join(output, 'baseline'), {recursive: true});
const production = ['systems/native_keyboard.gd', 'native_live_world.gd', 'native_session_world.gd',
  'systems/network_motion.gd', 'systems/native_render/live_world.gd',
  'systems/native_render/drive_collision_indexed.gd', 'systems/native_render/drive_spatial_index.gd'];
const pins = production.map(file => {
  const bytes = fs.readFileSync(file), destination = path.join(output, 'baseline', file);
  fs.mkdirSync(path.dirname(destination), {recursive: true}); fs.writeFileSync(destination, bytes);
  return {path: file, sha256: sha(bytes)};
});
const retained = ['../backups/animations/native-drive-input-timing-v1.json',
  '../backups/animations/native-input-frame-order-metadata-v1.json',
  '../backups/animations/rea-current-input-tick-callers-v1.json',
  '../backups/animations/native-drive-refresh-v1.json',
  '../backups/animations/native-frame-input-origin-v1.json'];
const original = JSON.parse(fs.readFileSync(retained[0]));
const callersContainer = JSON.parse(fs.readFileSync(retained[2]));
const callers = callersContainer.structuredContent;
const report = {
  issue: 'NWN-63',
  phase: 'Architecture proposal; coordinator queue-drain proof pending. No production edits or runtime acceptance.',
  actualNewTrace: pin('.cache/nwn61/newesttrace-crossreview-a.json'),
  productionPins: pins,
  retainedOriginalPins: retained.map(pin),
  original: {targetSha256: original.target, oracleCases: original.cases.length,
    repeatedEvents: original.repeatedEvents,
    oracleLimits: original.limits,
    schedulerIncomingEvidence: {evidenceId: callers.evidence_id, relationshipCoverage: callers.relationship_coverage,
      externalDirectCalls: callers.normalized_result.references.filter(row => row.kind.call && row.source_procedure?.address !== '0x1406f1e40').map(row => ({from: row.source_address, procedure: row.source_procedure.address, kind: row.kind.type}))},
    pendingProof: 'Inspect exact original coordinator 0x1406f14e0. Confirm queue-drain and held-key tick order and whether an event loop or back edge repeats that tick before changing observable wire counts.'},
  observations: [
    {location: 'systems/native_keyboard.gd:62,89,101-104', fact: 'Every admitted pressed event, including echo, sets input_pending and immediately calls update_input. changed=true forces wire send and synchronous prediction regardless of periodic timers.'},
    {location: 'systems/native_keyboard.gd:144', fact: 'Periodic scheduling uses idle _process, not _physics_process. It is an additional entry into update_input.'},
    {location: 'native_live_world.gd:156,464', fact: 'Both keyboard creation sites bind predict directly to World.preview_drive.'},
    {location: 'native_live_world.gd:623-643', fact: 'NativeLive dispatches received protocol messages then flushes protocol output before Node._process. Moving keyboard work only into Node._process can add an outgoing frame of latency.'},
    {location: '.cache/native-tracy/engine-msvc-a/source/platform/windows/os_windows.cpp:2352', fact: 'OS_Windows::run processes Windows input before Main::iteration.'},
    {location: '.cache/native-tracy/engine-msvc-a/source/platform/windows/display_server_windows.cpp:4471-4492', fact: 'Discrete messages drain, key events are processed, then buffered Input events dispatch before the iteration.'},
    {location: 'native_live_world.gd:792-819', fact: 'Ordinary click movement stops keyboard state and sends a walk request. It does not directly call full keyboard preview; server waypoint repair is separate.'}
  ],
  recommendedArchitectureIfNativeProofPasses: {
    name: 'Native event admission followed by one pre-motion held-input tick',
    ownership: 'Worker owns NativeKeyboard/tests/tools only. Coordinator applies the exact NativeLive adapter after review. Collision 527/338 stays frozen.',
    eventAdmission: 'OS _input admits key/binding/focus events and updates held/physical/walk state plus a dirty bit. Echo events remain admitted and dirty; no blanket echo rejection. Capture the admitted owner identity so a world/actor lifetime replacement cannot inherit pending input.',
    explicitBoundary: 'Normal NativeLive drives one keyboard flush after current protocol messages are applied and immediately before the existing flush_protocol_output, before World.motion.update. Disable only the externally driven keyboard idle polling so the same held tick cannot run twice.',
    scheduling: 'Retain current update_input 250/500 ms timers, bit flags, heading/position packet shape, partial-path resend timestamp math and sequence/ACK guards. Call them once at the proven original coordinator boundary. Programmatic synchronous key()/update_input() entry points keep their existing default behavior.',
    invalidation: 'stop, focus-out, text/binding capture, close, click-to-walk, lost readiness and identity/lifetime transition clear pending admission immediately. No queued event can rearm a stopped or replacement owner.',
    geometry: 'No scene/collision snapshot cache, geometry suppression, worker result or changed collision algorithm. The one tick queries current ready geometry, doors, blockers, dimensions, support and motion after current received changes.',
    observableChange: 'A burst of admitted OS events before one original-style coordinator boundary can produce fewer local drive requests than the current per-event implementation. This is acceptable only if the original queue-drain proof confirms it. Request IDs remain ordered among actual requests; do not pretend the old per-event wire count is unchanged.',
    limits: 'This caps repeated event-batch work; it does not bound one expensive path solve or solve click/server-repair costs. New trace has only 22 preview calls beyond one per main-start interval, so whole-session gains may be modest even if the worst 34 ms interval improves.'
  },
  coordinatorAdapterProposal: {
    setupBothSites: 'After binding context/transmit/predict/end_prediction: configure the privately selected frame-driven admission mode; preserve synchronous fallback when disabled.',
    singleTickSeam: 'After dispatch_protocol_messages and connection failure handling, immediately before flush_protocol_output(): if keyboard is valid and externally frame-driven, call keyboard.flush_frame(). It revalidates readiness, snapshot-transition context and admitted scope itself.',
    policy: 'Privately pinned candidate first; no default setting or accepted artifact promotion from source-only evidence.'
  },
  correctnessPlan: [
    'Original reference: distinguish per-event admission from per-coordinator tick. Existing 192 timing cases and repeat oracle remain authoritative at a tick, but do not establish a whole event-loop wire count.',
    'Engage real _input through SubViewport.push_input/InputEventKey bursts. Do not accept only synchronous key() fixtures that bypass the candidate route.',
    'Compare exact held/physical/walk state, requests, transmit flags, sequence ownership, prediction count and stop ordering for zero/one/many repeats; W+S; W+A; opposing-key release; Shift; mapped aliases; control-arrow/UI/text focus; blocked capture; focus loss; click cancellation.',
    'Exercise actual frame gaps, current-world/lifetime replacement and transitions after admission but before flush. No stale held input, ACK or callback may command a replacement actor.',
    'Preserve 250/500 ms boundaries, turn-only requests, partial resendFraction timing, sent versus preview-only ACK sequence tracking and stale idle/path corrections. Test reentrant stop/retire/transmit callbacks.',
    'Integrate a real World fixture with door changes, moving creatures, overlapping/elevated floor, finite radii and correction between event admission and flush; the current geometry must win.',
    'Prove one external flush per frame and protocol enqueue before output flush, with no duplicate Node._process tick or extra wire latency.',
    'After correctness and source review only: root leases one matched graphical movement interval test with actual event batching and counters. Report start-to-start frame periods including Windows dispatch, not only Main::iteration or a favorable microbenchmark.'
  ],
  rejectedShortcuts: [
    'Dropping event.echo conflicts with observed original dirty-input behavior.',
    'Caching a result against mutable world geometry without a complete immutable witness is unsafe.',
    'Naively queueing a whole worker solve changes resend timing and usually becomes stale as controlled/moving blocker positions advance. Snapshot/commit semantics need a separate design.',
    'Moving synchronous solves into _process by itself changes accounting location and may add protocol latency; that is not a performance improvement.'
  ],
  runtimeStarts: 0, builds: 0, productionEdits: 0
};
fs.writeFileSync(path.join(output, 'proposal.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({output: path.join(output, 'proposal.json'), sha256: sha(fs.readFileSync(path.join(output, 'proposal.json'))), productionEdits: 0, runtimeStarts: 0}));
