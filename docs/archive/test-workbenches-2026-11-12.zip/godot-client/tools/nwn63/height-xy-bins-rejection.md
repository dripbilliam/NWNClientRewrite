# NWN-63 high-face XY bins — rejected

The accepted default-off height index remains unchanged at SHA-256 `bcdadfe5a573116c0a5fe5e5d3f9d617051574eab2ba9a45d3982e481c3a507f`; indexed collision remains at SHA-256 `e7543de4cfdda0b4d5f54a7523ab2b0a63b6dc74468319bb502f0da2966044e2`. Candidate source and fixtures are archived in `.cache/nwn63/rejected-xy-bins/`.

The prototype prepared an 8×8 conservative XY face-bin list once per blocked preview while retaining original face order and the original bounds/material/edge/plane tests. It passed 4,041 original WOK direct-height checks across eight selected meshes and four rotations, including in-place vertex edit fallback (`.cache/nwn63/height-xy-bins-original-b.json`). The blocked 38-probe path preserved all results, probe order and blocker reasons in 1,009 checks (`.cache/nwn63/height-xy-bins-path-b.json`).

The direct repeated-height component saved roughly 8–20% on the four 90–122-face assets. The full 38-probe path showed no repeatable improvement after bin construction: 122-face median 3.754/3.763 ms without bins versus 3.950/3.937 ms with bins; 94-face cases were approximately flat. The test is a headless component on authored original-WOK placements, not live Arelith or FPS. The added index work outweighs saved face visits, so no production change was retained.
