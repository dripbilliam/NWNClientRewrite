'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const project=path.resolve(__dirname,'../..'),label=process.argv[2];
assert(/^frame-input-check-[a-z0-9-]+$/.test(label||''));
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const baseline=path.join(project,'.cache/native-live-review/reviewed-arelith-b/project');
const collision=path.join(project,'.cache/native-tracy/live/frametime-20261110-off-a/project');
const frozen='.cache/nwn63/frame-admission-source-a/baseline/systems/native_keyboard.gd';
assert.equal(sha(fs.readFileSync(path.join(project,frozen))),'6bbe3dfca76cb3c7da2dc6be5117bc66bd575109650ed8301ea729ea3b73f279');
const acceptedBytes=fs.readFileSync(path.join(project,'.tools/native-core/accepted-core-e.json')),accepted=JSON.parse(acceptedBytes);
assert.equal(sha(acceptedBytes),'29b1c6adcdecb11eebc859730c770e879a108279dfaaf60792e4c11c00add78a');
const engine=path.join(project,'.tools/native-core/Godot_native_core_e_win64.exe');
assert.equal(sha(fs.readFileSync(engine)),accepted.engineSha256);
const out=path.join(project,'.cache/nwn63',label),view=path.join(out,'project');assert(!fs.existsSync(out));fs.mkdirSync(view,{recursive:true});
const pinnedCollision=new Map([['systems/native_render/drive_collision_indexed.gd','527d9bf0361a1a699930a76250fa1ec61dae7e5a580c61e3b61cc62a8e93c732'],['systems/native_render/drive_spatial_index.gd','33864b13f75604548e7bbe1e1263536a6d4ff2db24b3e59b8b7882cc6673e209']]);
const pins=[],copied=new Set();
function put(relative,bytes,origin){const target=path.join(view,relative);assert(target.startsWith(view+path.sep));fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,bytes,{flag:'wx'});pins.push({relative,sha256:sha(bytes),bytes:bytes.length,origin});}
function copy(relative){
 if(copied.has(relative))return;assert(!relative.includes('..')&&!path.isAbsolute(relative));copied.add(relative);
 const origin=relative==='systems/native_keyboard.gd'||relative===frozen||relative.startsWith('tests/')?project:pinnedCollision.has(relative)?collision:baseline;
 const bytes=fs.readFileSync(path.join(origin,relative));if(pinnedCollision.has(relative))assert.equal(sha(bytes),pinnedCollision.get(relative));
 put(relative,bytes,origin===project?'ticket candidate/test or frozen original API':origin===collision?'frozen current reviewed collision527/338':'immutable reviewed B source');
 if(!relative.endsWith('.gd'))return;
 for(const match of bytes.toString().matchAll(/(?:preload|load)\("res:\/\/([^"\n]+)"\)|extends\s+"res:\/\/([^"\n]+)"/g))copy(match[1]||match[2]);
 for(const match of bytes.toString().matchAll(/["']res:\/\/([^"'\n]+\.(?:json|gdshader))["']/g))if(fs.existsSync(path.join(origin,match[1])))copy(match[1]);
}
copy('tests/nwn63_frame_input_admission_test.gd');copy('systems/client_api/client_api.gd');copy('native/particle_kernel.gdextension');
const dll=fs.readFileSync(path.join(project,'.cache/native-kernel/nwn-particle-kernel.dll'));assert.equal(sha(dll),accepted.nativeKernelSha256);put('.cache/native-kernel/nwn-particle-kernel.dll',dll,'unchanged accepted485 kernel');
put('accepted-runtime.json',Buffer.from(JSON.stringify({engineSha256:accepted.engineSha256,nativeKernelSha256:accepted.nativeKernelSha256,fullFunctionalFlags:accepted.fullFunctionalFlags})),'accepted descriptor subset');
put('project.godot',Buffer.from('config_version=5\n[application]\nconfig/name="NWN63 isolated input correctness"\n[autoload]\nClientAPI="*res://systems/client_api/client_api.gd"\n[display]\nwindow/size/viewport_width=640\nwindow/size/viewport_height=480\nwindow/size/no_focus=true\n[rendering]\nrenderer/rendering_method="gl_compatibility"\n'),'isolated preferences; no private live setting or default promotion');
put('.godot/global_script_class_cache.cfg',Buffer.from('list=[]\n'),'isolated script cache');put('.godot/extension_list.cfg',Buffer.from('res://native/particle_kernel.gdextension\n'),'isolated accepted extension list');
const userData=path.join(out,'user-data'),localData=path.join(out,'local-data');fs.mkdirSync(userData);fs.mkdirSync(localData);
const manifest={version:1,issue:'NWN-63',project:view,engine,engineSha256:accepted.engineSha256,kernelSha256:accepted.nativeKernelSha256,descriptorSha256:sha(acceptedBytes),flags:accepted.fullFunctionalFlags,userData,localData,pins,scope:'Source-only isolated headless correctness view. Immutable reviewed B source, exact current collision527/338, ticket keyboard/test and frozen pre-edit original API. No installed originals, current mixed NWN61/62/65/73 source or accepted user preferences copied; no runtime launch.'};
const manifestFile=path.join(out,'manifest.json');fs.writeFileSync(manifestFile,JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});
const runner=path.join(out,'run-root-only.cjs');
fs.writeFileSync(runner,`'use strict';\nconst fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict'),cp=require('node:child_process');\nconst m=require('./manifest.json'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');\nassert.equal(sha(fs.readFileSync(m.engine)),m.engineSha256);for(const p of m.pins)assert.equal(sha(fs.readFileSync(path.join(m.project,p.relative))),p.sha256);\nconst report=path.join(__dirname,'correctness-a.json');assert(!fs.existsSync(report));\nconst args=['--headless','--path',m.project,'--script','res://tests/nwn63_frame_input_admission_test.gd','--',...m.flags,'--report='+report];\nconst result=cp.spawnSync(m.engine,args,{env:{...process.env,APPDATA:m.userData,LOCALAPPDATA:m.localData},encoding:'utf8',timeout:30000,maxBuffer:4*1024*1024,windowsHide:true});\nfs.writeFileSync(path.join(__dirname,'correctness-a.log'),(result.stdout||'')+(result.stderr||''),{flag:'wx'});console.log(JSON.stringify({status:result.status,signal:result.signal,error:result.error?.message,report,log:path.join(__dirname,'correctness-a.log')}));process.exitCode=result.status===0?0:1;\n`,{flag:'wx'});
console.log(JSON.stringify({manifestFile,sha256:sha(fs.readFileSync(manifestFile)),runner,files:pins.length,sourceOnly:true}));
