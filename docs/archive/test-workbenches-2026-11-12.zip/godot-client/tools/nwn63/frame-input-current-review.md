# NWN-63 current-source request admission checkpoint

## Proven repeated keyboard work

The native client source review retained in the ticket places one held-key scheduler tick after the Windows event queue drain. Our default NativeKeyboard OS `_input` path still marks each key-down/echo dirty and immediately enters `update_input()`, which sends one local drive request and calls `World.preview_drive()`. The saved Newesttrace has 649 preview calls in 627 preview-containing intervals, but it contains no request argument identity. Those 22 excess calls alone do not prove duplicates.

The focused actual SubViewport OS-input fixture `frame-input-request-count-current-a.json` holds actor pose, lifetime and synthetic scene revision fixed across 64 W key-down/echo events. Default OFF produced 64 requests and 64 predictions, all with the same effective collision inputs. Admitted ON processed all 64 events, coalesced 63 within the one input cycle, and produced one request and one prediction with the same effective input signature. Its 6 checks passed. This is a bounded echo-burst proof, not a live movement or FPS result.

## Opt-in wiring and behavior gates

`native_live_world.gd` now reads the private boolean ProjectSettings key `nwn/private/keyboard_frame_admission` at both keyboard creation sites. The missing key defaults to false. With the key true, the existing NativeKeyboard implementation admits OS events, then the root tick calls `flush_input_frame()` once after current protocol messages are applied and before the existing protocol output flush. Programmatic `key()` and `update_input()` remain synchronous. Stop, focus, text/binding capture, loss of readiness, actor lifetime change, area transition, reentrant callbacks, deadlines, ACK ownership and current geometry are handled by the existing admission fences.

The current-source headless admission fixture `frame-input-admission-current-a.json` passed 89/89. The inherited NativeLive protocol fixture passed 16/16 OFF (`frame-input-protocol-current-off-a.json`) and 16/16 ON (`frame-input-protocol-current-on-a.json`). ON observed dispatch → request/enqueue → prediction → output flush in the same root tick, used the post-dispatch pose, and suppressed stale requests after transition and lifetime replacement. OFF retained its immediate pre-dispatch request shape. No graphical client, FPS timing or normal host session was started.

Frozen pre-wiring `native_live_world.gd` SHA256: `81d399e2bbcebba2aaf62eae48ffe06e53ff956f0bca9a2748326256b09d4264`. Current SHA256: `71f28f596249e70d0278420c126064a31ec5efb764fd071f3383c4727a83d257`. The inherited `systems/native_keyboard.gd` source is unchanged, SHA256 `be9a113fcd29748486d2994aebe38b20d46774d11b57a44987134834a8915666`. `systems/world_input.gd` is unchanged, SHA256 `7fb1d26e034368e7bb39ad4d4c2f08e0edf6ee90cf0f60e3f3330be2372f5da4`.

## Click route and remaining acceptance

The click route is `WorldInput._unhandled_input → _pointer_step → NativeLive.world_action`. Each accepted click sends one `walk` packet and stops keyboard drive. It does not call `World.preview_drive()`. Later `LiveWorld.observe_movement` performs path repair once for each accepted path-bearing movement revision. There is no proven equivalent duplicate click preview to coalesce. Suppressing repeated clicks or correction revisions would alter observable request/correction order without further evidence.

The opt-in admission change reduces a burst of equivalent OS echoes but does not shorten one expensive collision solve. It is OFF in the accepted project and has not been measured during matched live keyboard/click movement. NWN-63 remains In Progress for normal-client behavior, original WOK/door/elevation/blocker acceptance, and matched preview median/tail and whole-frame FPS evidence. The earlier private graphical ABBA showed a 60-frame synthetic echo-burst median improvement from about 12.1 to 10.5 ms, while the full ten-second steady frame mean changed about 0.12 ms; that result is not current-source acceptance.
