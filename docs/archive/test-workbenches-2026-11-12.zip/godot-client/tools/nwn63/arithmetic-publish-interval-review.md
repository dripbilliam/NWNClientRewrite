# NWN-63 arithmetic hot loop checkpoint

`drive_preview_arithmetic.gd` now publishes its four counters without constructing two Arrays and four profiler metric-name strings after every clearance. It preserves counter update order, negative deltas, external ledger edits, and the peak-byte write. The pre-edit source is saved at `.cache/nwn63/arithmetic-publish-a/before.gd` (SHA-256 `03e50e7c1e32f3b31b54c81c89e154732db59e026d7b4914ad8b66f62f89b6ee`).

The repeated `TileTerms.interval` calculation now inlines the original `cross(edge, to-point)` expression with typed intermediate values. A dense authored 38-probe blocked path made 21,827 reused interval calls, each with three cross-function invocations. All 38 endpoints were distinct, so exact endpoint memoization would save nothing in that path.

Headless checks:

* Frozen/current counter-publication ABBA passed 9/9 in all four legs with identical ledger, private publication state and profiler totals. Medians for 10,000 publications were 17.886 and 18.353 ms before, 10.463 and 10.314 ms after, about 43% less component time. This operation is small: roughly 0.8 microseconds saved per publication in this fixture.
* Frozen/current interval ABBA passed 43,778 checks, including 43,776 exact `Vector2` byte comparisons and matching prepared/reuse counters. Warm 43,776-call legs were 35.589 and 35.411 ms before, 31.525 and 31.320 ms after, about 11% less component time. Triangles and 38 endpoints are authored.
* Current-source complete blocked preview passed 9/9 checks on 2-face and 1,152-face authored floors: both paths still made 38 probes, with one initial collection and 37 reused clears, no fallback; result and blocker transcript matched the ordinary route. The clean duplicate-probe fixture passed 2/2 and found 38 unique exact endpoints at each density.

Godot printed ambient `user://logs` and root-certificate-store startup errors in the headless component runs. One intermediate duplicate-probe attempt also coincided with a temporary parse error in another agent's `model_template.gd`; the owner fixed it and the two complete preview fixtures were rerun cleanly. No graphical/FPS test or native server input was run. Original WOK and live keyboard/click acceptance remain outstanding; neither component percentage is a whole-preview or FPS claim.
