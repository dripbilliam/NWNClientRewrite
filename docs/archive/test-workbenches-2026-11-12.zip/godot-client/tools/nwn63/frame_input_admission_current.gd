extends "res://tests/native_drive_preview_lazy_fixture_test.gd"
const Keyboard=preload("res://systems/native_keyboard.gd")
const FrozenKeyboard=preload("res://.cache/nwn63/frame-admission-source-a/baseline/systems/native_keyboard.gd")
var native_proof: Dictionary={}
var library: Resource
class TimedKeyboard:
	extends Keyboard
	func update_input(now_ms: float=-1)->void:super.update_input(1000.0 if now_ms<0 else now_ms)
class TimedFrozenKeyboard:
	extends FrozenKeyboard
	func update_input(now_ms: float=-1)->void:super.update_input(1000.0 if now_ms<0 else now_ms)
class TestBindings:
	extends Node
	signal changed
	signal capture_changed(active: bool)
	var capturing:=false
	var actions:={KEY_I:90,KEY_J:90,KEY_K:89,KEY_L:93}
	func blocked()->bool:return capturing
	func physical(event: InputEventKey)->int:return int(event.physical_keycode)
	func action(event: InputEventKey,_allowed: Array,_repeat: bool)->int:return int(actions.get(physical(event),0))
func input_fixture(candidate: bool=true,original: bool=false)->Dictionary:
	var surface:=SubViewport.new();surface.size=Vector2i(640,480);root.add_child(surface)
	var state:={"position":Vector3(2,3,0),"render":Vector3(2,3,0),"orientation":Vector3.RIGHT,"lifetime":11}
	var holder: Array=[{"id":1,"identity":"connection/3/1/11","state":state}]
	var sent: Array=[];var predictions: Array=[];var endings: Array=[]
	# Freeze only the lower timer provider, as in the original native oracle.
	# The actual inherited _input/_update_from_event/flush logic still executes.
	var input=TimedFrozenKeyboard.new() if original else TimedKeyboard.new();surface.add_child(input);input.set_process(false);input.require_focus=false
	input.context_query=func():return holder[0]
	input.transmit=func(value):sent.append(value.duplicate(true))
	input.predict=func(id,flags,heading):predictions.append([id,flags,heading]);return {"target":Vector3(3,3,0),"factor":1.0}
	input.end_prediction=func(id):endings.append(id)
	if candidate:input.set_frame_input_admission(true)
	return {"surface":surface,"input":input,"holder":holder,"state":state,"sent":sent,"predictions":predictions,"endings":endings}
func input_event(code: int,pressed: bool=true,echo: bool=false,shift: bool=false)->InputEventKey:
	var event:=InputEventKey.new();event.physical_keycode=code;event.keycode=code;event.pressed=pressed;event.echo=echo;event.shift_pressed=shift;return event
func push_key(f: Dictionary,code: int,pressed: bool=true,echo: bool=false,shift: bool=false)->void:
	f.surface.push_input(input_event(code,pressed,echo,shift),true)
func dispose_input(f: Dictionary)->void:
	f.input.context_query=Callable();f.input.transmit=Callable();f.input.predict=Callable();f.input.end_prediction=Callable()
	f.surface.free()
func off_projection(f: Dictionary)->Dictionary:
	var input=f.input;var counts: Dictionary={}
	for key in ["drive","stop","turn","stale_scopes","previews","preview_ticks","acks","stale_acks"]:counts[key]=input.stats[key]
	return {"sent":f.sent,"predictions":f.predictions,"endings":f.endings,"state":f.state,"held":input.held,"physical":input.physical_held,"walk_forward":input.walk_forward_held,"walking":input.walking,"moving":input.moving,"last_flags":input.last_flags,"request_serial":input.request_serial,"accepted_serial":input.accepted_serial,"minimum_serial":input.minimum_serial,"stats":counts}
func default_off_differential()->void:
	var old:=input_fixture(false,true);var current:=input_fixture(false)
	for row in [[KEY_W,true,false,false],[KEY_W,true,true,false],[KEY_Q,true,false,false],[KEY_SHIFT,true,false,true],[KEY_S,true,false,true],[KEY_Q,false,false,true],[KEY_S,false,false,true],[KEY_W,false,false,true],[KEY_SHIFT,false,false,false],[KEY_A,true,false,false],[KEY_A,true,true,false],[KEY_A,false,false,false]]:
		push_key(old,row[0],row[1],row[2],row[3]);push_key(current,row[0],row[1],row[2],row[3])
		check(var_to_bytes(off_projection(old))==var_to_bytes(off_projection(current)),"Default-OFF actual OS route preserves original requests/state/sequence/counters after event "+str(row))
	for f in [old,current]:
		f.input.key(KEY_W,true);f.input.last_sent=1000;f.input.preview_at=1000;f.input.input_pending=false
	for now in [1249.0,1250.0,1499.0,1500.0]:
		old.input.update_input(now);current.input.update_input(now)
		check(var_to_bytes(off_projection(old))==var_to_bytes(off_projection(current)),"Default-OFF exact timer request/state parity at "+str(now))
	dispose_input(old);dispose_input(current)
func event_batches()->void:
	var control:=input_fixture(false)
	push_key(control,KEY_W);push_key(control,KEY_W,true,true)
	check(control.sent.size()==2 and control.predictions.size()==2,"Default-off actual OS event path remains synchronous and accepts echo")
	dispose_input(control)
	for count in [1,2,64]:
		var f:=input_fixture()
		for index in count:push_key(f,KEY_W,true,index>0)
		check(f.sent.is_empty() and f.predictions.is_empty(),"OS burst performs no wire request or path solve before explicit boundary: "+str(count))
		check(f.input.held.has(KEY_W) and int(f.input.stats.admission_events)==count,"Every admitted echo retains held/dirty input: "+str(count))
		f.input.flush_input_frame(1,1000)
		check(f.sent.size()==1 and f.predictions.size()==1 and f.sent[0].transmit,"One native held tick follows the whole admitted burst: "+str(count))
		check(int(f.input.stats.admission_flush_events)==count and int(f.input.stats.admission_coalesced_events)==count-1,"Admission counters reconcile all events without pretending all were wire requests")
		f.input.flush_input_frame(1,2000);f.input._profile_process(0)
		check(f.sent.size()==1 and f.predictions.size()==1,"Repeated external flush and idle callback cannot perform a second held tick")
		push_key(f,KEY_W,true,true);f.input.flush_input_frame(1,2100)
		check(f.sent.size()==1,"A later event after this frame's boundary remains pending")
		f.input.flush_input_frame(2,2100)
		check(f.sent.size()==2 and f.predictions.size()==2,"An admitted repeat in the next native input cycle still refreshes immediately at that cycle")
		dispose_input(f)
func release_and_focus()->void:
	var f:=input_fixture();push_key(f,KEY_W);push_key(f,KEY_W,false)
	check(f.sent.is_empty() and f.predictions.is_empty() and f.input.held.is_empty(),"Press/release before the held tick cannot invent a movement request")
	f.input.flush_input_frame(1,1000);check(f.sent.is_empty(),"Cancelled pending press never resurrects at the boundary")
	push_key(f,KEY_W);f.input.flush_input_frame(2,1100);push_key(f,KEY_W,false)
	check(f.sent[-1].operation=="stop" and not f.input.moving and f.input.held.is_empty(),"Release of admitted moving input sends stop and ends prediction immediately")
	var stopped: int=f.sent.size();f.input.flush_input_frame(3,1150)
	check(f.sent.size()==stopped,"Release cannot schedule a second drive/stop at the next boundary")
	push_key(f,KEY_W);f.input._notification(Node.NOTIFICATION_WM_WINDOW_FOCUS_OUT);f.input.flush_input_frame(4,1200)
	check(f.sent.size()==stopped and f.input.held.is_empty(),"Focus loss cancels pending input without commanding movement")
	push_key(f,KEY_W)
	var entry:=LineEdit.new();f.surface.add_child(entry);entry.grab_focus();f.input.flush_input_frame(5,1300)
	check(f.sent.size()==stopped and f.input.held.is_empty(),"Text focus acquired between event admission and flush cancels pending input")
	entry.release_focus();f.input.flush_input_frame(6,1400)
	check(f.sent.size()==stopped,"Leaving text focus cannot resurrect swallowed input")
	push_key(f,KEY_W);f.input.stop();f.input.flush_input_frame(7,1500)
	check(f.sent.size()==stopped,"Click-to-walk's existing stop cancels pending keyboard drive")
	dispose_input(f)
func flags_and_mapped_aliases()->void:
	var f:=input_fixture();push_key(f,KEY_W);push_key(f,KEY_S)
	check(f.sent.is_empty() and f.input.held.size()==2,"Opposing keys cancel before tick while retaining both physical directions")
	push_key(f,KEY_S,false);f.input.flush_input_frame(1,1000)
	check(f.sent.size()==1 and f.sent[-1].flags==3,"Releasing an opposed key admits the surviving direction")
	push_key(f,KEY_A);push_key(f,KEY_SHIFT,true,false,true);f.input.flush_input_frame(2,1100)
	check(f.sent[-1].flags==17,"Final walk/forward/turn combination reaches the native tick")
	f.input.stop();push_key(f,KEY_A);f.input.flush_input_frame(3,1200)
	check(f.sent[-1].operation=="turn" and not f.input.moving,"Turn-only batching retains original request form")
	f.input.stop();var bindings:=TestBindings.new();f.surface.add_child(bindings);f.input.set_key_bindings(bindings)
	push_key(f,KEY_I);push_key(f,KEY_K);f.input.flush_input_frame(4,1300)
	check(f.sent[-1].flags==1 and f.input.walk_forward_held.size()==1,"Mapped run/walk-forward aliases preserve explicit walking ownership")
	push_key(f,KEY_K,false);f.input.flush_input_frame(5,1400)
	check(f.sent[-1].flags==3 and f.input.physical_held.has(KEY_I),"Releasing walk-forward resumes the surviving mapped run key")
	push_key(f,KEY_J);f.input.flush_input_frame(6,1500)
	var count: int=f.sent.size();push_key(f,KEY_J,false);f.input.flush_input_frame(7,1501)
	check(f.sent.size()==count and f.input.held.has(KEY_W),"Releasing an equivalent physical alias does not force an unchanged dirty wire tick")
	push_key(f,KEY_I,true,true);bindings.capturing=true;bindings.capture_changed.emit(true);f.input.flush_input_frame(8,1600)
	check(not f.input.moving and f.input.held.is_empty() and f.sent[-1].operation=="stop","Binding capture cancels pending and active input immediately")
	dispose_input(f)
func timers_sequences_and_sync_api()->void:
	var f:=input_fixture();push_key(f,KEY_W);f.input.flush_input_frame(1,1000)
	f.input.flush_input_frame(2,1249);check(f.sent.size()==1,"No premature local tick below 250 ms")
	f.input.flush_input_frame(3,1250);check(f.sent.size()==2 and not f.sent[-1].transmit,"Native 250 ms preview tick still reserves an unsent sequence")
	f.input.flush_input_frame(4,1499);check(f.sent.size()==2,"Wire refresh remains below the 500 ms threshold")
	f.input.flush_input_frame(5,1500);check(f.sent.size()==3 and f.sent[-1].transmit,"Native 500 ms wire refresh remains exact")
	for index in f.sent.size():check(f.sent[index].requestId==index+1 and f.sent[index].lifetime==11,"Actual request IDs/lifetimes remain ordered after batching")
	f.input.result({"actorId":1,"lifetime":11,"requestId":3,"sequence":91,"sent":true})
	f.input.result({"actorId":1,"lifetime":11,"requestId":4,"sequence":92,"sent":false})
	check(f.state.driveSequence==92 and f.state.driveSentSequence==91,"Preview-only ACK cannot replace the last wire-owned sequence")
	var before: int=f.sent.size();f.input.key(KEY_Q,true)
	check(f.sent.size()==before+1 and f.sent[-1].flags==7,"Programmatic key API stays synchronous even in the explicitly frame-driven candidate")
	dispose_input(f)
	f=input_fixture();f.input.predict=func(_id,_flags,_heading):return {"resendFraction":0.5}
	push_key(f,KEY_W);f.input.flush_input_frame(1,1000)
	check(f.input.last_sent==750,"Partial-path resend timestamp is calculated from the held tick timestamp")
	f.input.flush_input_frame(2,1249);check(f.sent.size()==1,"Partial path does not refresh the wire before its native deadline")
	f.input.flush_input_frame(3,1250);check(f.sent.size()==2 and f.sent[-1].transmit,"Partial path can bring the next wire tick forward to 250 ms")
	dispose_input(f)
func scope_and_reentrant_callbacks()->void:
	var f:=input_fixture();push_key(f,KEY_W);f.holder[0]=f.holder[0].duplicate(true);f.holder[0].identity="connection/4/1/12";f.holder[0].state.lifetime=12
	f.input.flush_input_frame(1,1000)
	check(f.sent.is_empty() and f.predictions.is_empty() and f.input.held.is_empty(),"New area/lifetime between admission and flush cannot inherit old input")
	check(int(f.input.stats.admission_stale_scopes)==1,"Stale admitted scope is observable")
	dispose_input(f)
	f=input_fixture();push_key(f,KEY_W);f.holder[0]={};f.input.flush_input_frame(1,1000)
	check(f.sent.is_empty() and f.predictions.is_empty(),"Lost readiness between admission and flush cannot execute preview")
	dispose_input(f)
	for reason in ["empty","identity","focus"]:
		f=input_fixture();push_key(f,KEY_W);f.input.flush_input_frame(7,1000);push_key(f,KEY_W,true,true)
		var entry: LineEdit
		if reason=="empty":f.holder[0]={}
		elif reason=="identity":f.holder[0]=f.holder[0].duplicate(true);f.holder[0].identity="replacement/4/1/12"
		else:entry=LineEdit.new();f.surface.add_child(entry);entry.grab_focus()
		f.input.flush_input_frame(7,1100)
		check(not f.input.moving and f.input.held.is_empty() and f.input._admitted_events==0,"Same-frame no-solve guard cannot postpone cancellation for "+reason)
		check(f.predictions.size()==1 and f.sent.filter(func(row):return row.operation=="drive").size()==1,"Same-frame invalidation cannot run another stale solve/request for "+reason)
		dispose_input(f)
	f=input_fixture();var input=f.input;var sent: Array=f.sent
	input.transmit=func(value):
		sent.append(value.duplicate(true))
		if value.operation=="drive":input.stop(false)
	push_key(f,KEY_W);input.flush_input_frame(1,1000)
	check(f.predictions.is_empty() and not input.moving and input.held.is_empty(),"Reentrant cancellation during transmit cannot start a stale local preview")
	dispose_input(f)
	f=input_fixture();input=f.input;sent=f.sent;var holder: Array=f.holder
	input.transmit=func(value):
		sent.append(value.duplicate(true));holder[0]={}
	push_key(f,KEY_W);input.flush_input_frame(1,1000)
	check(f.predictions.is_empty() and not input.moving,"Reentrant world retirement during transmit fences prediction")
	dispose_input(f)
	f=input_fixture();input=f.input;var predictions: Array=f.predictions
	input.predict=func(id,flags,heading):
		predictions.append([id,flags,heading]);input.flush_input_frame(1,2000);input.stop(false);return {"resendFraction":0.25}
	push_key(f,KEY_W);input.flush_input_frame(1,1000)
	check(f.sent.size()==1 and predictions.size()==1 and not input.moving and input.last_flags==0 and input.last_sent==-INF,"Reentrant flush/stop cannot double tick, rearm, or publish a cancelled resend timer")
	dispose_input(f)
	for code in [KEY_W,KEY_Q]:
		f=input_fixture();input=f.input;sent=f.sent;var surface: SubViewport=f.surface
		input.transmit=func(value):
			sent.append(value.duplicate(true))
			if int(value.requestId)==1:surface.push_input(input_event(code,true,true),true)
		push_key(f,KEY_W);input.flush_input_frame(1,1000)
		check(sent.size()==1 and input.input_pending,"Event admitted reentrantly by transmit keeps its dirty bit after the old flush")
		input.flush_input_frame(1,1050);check(sent.size()==1,"Reentrant admission does not bypass the same-frame guard")
		input.flush_input_frame(2,1100)
		check(sent.size()==2 and sent[-1].flags==(3 if code==KEY_W else 7) and sent[-1].transmit,"Reentrant repeat/direction is consumed once in the next input cycle")
		dispose_input(f)
func current_geometry_after_real_frame_gap()->void:
	var setup:=fixture();var world=setup.world;var collision=setup.collision
	var f:=input_fixture();var state: Dictionary=world.motion.objects[1]
	state.position=Vector3(8,1.5,0);state.render=state.position;state.orientation=Vector3.RIGHT
	f.holder[0]={"id":1,"identity":"geometry/3/1/"+str(state.lifetime),"state":state}
	var observations: Array=[]
	f.input.predict=func(id,flags,heading):
		var facing: Vector3=Plan.wire_facing(heading) if heading>=0 else state.orientation
		var plan: Dictionary=Plan.plan(state.position,facing,float(state.walkRate),float(state.runRate),flags)
		var result: Dictionary=Plan.path(state.position,plan.target,state.render,collision.query_preview(id,state.position,plan.target,state.render))
		observations.append({"from":state.position,"target":plan.target,"result":result});return result
	var old_plan:=Plan.plan(state.position,state.orientation,float(state.walkRate),float(state.runRate),3)
	check(not collision.query(1).call(state.position,old_plan.target),"Original closed door really blocks this admitted input")
	push_key(f,KEY_W)
	await process_frame;await process_frame
	check(observations.is_empty() and f.sent.is_empty(),"Real frame gaps cannot advance an externally scheduled pending preview early")
	var door: Dictionary=world.desired[3].object.duplicate(true);door.replicated.doorOpenState=1;world.receive_delta([door],[],1)
	state.position=Vector3(8.1,1.5,0);state.render=state.position
	f.input.flush_input_frame(100,1000)
	check(observations.size()==1 and observations[0].from==Vector3(8.1,1.5,0),"Held tick uses the current corrected pose after the frame gap")
	check(observations[0].result.target==observations[0].target,"Door opening after admission is observed by current collision, not a frozen old answer")
	push_key(f,KEY_W,true,true)
	world.motion.objects[4].render=Vector3(8.8,1.5,0);collision.sync_motion_id(4)
	var next_plan:=Plan.plan(state.position,state.orientation,float(state.walkRate),float(state.runRate),3)
	var expected:=Plan.path(state.position,next_plan.target,state.render,collision.query(1))
	f.input.flush_input_frame(101,1100)
	check(observations.size()==2 and var_to_bytes(observations[1].result)==var_to_bytes(expected),"Moving creature after admission agrees with the unrestricted current-geometry path oracle")
	dispose_input(f);world.free()
func run()->void:
	var report:=""
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--report="):report=argument.trim_prefix("--report=")
	if report.is_empty() or FileAccess.file_exists(report):quit(2);return
	native_proof={"engine_sha256":FileAccess.get_sha256(OS.get_executable_path()),"source":"current workspace, headless"}
	default_off_differential();event_batches();release_and_focus();flags_and_mapped_aliases();timers_sequences_and_sync_api();scope_and_reentrant_callbacks()
	await current_geometry_after_real_frame_gap()
	await process_frame;await process_frame
	var result:={"success":failures.is_empty(),"checks":checks,"failures":failures,"native_proof":native_proof,"user_data_dir":OS.get_user_data_dir(),"scope":"Actual SubViewport OS input admission, default-off and synchronous API parity, one explicit native-style held tick, repeat/alias/walk/turn/cancellation, exact timer/ACK ownership, real frame gaps, scope/reentrant invalidation and current actual door/creature geometry. Untimed correctness; no FPS or live acceptance."}
	var file:=FileAccess.open(report,FileAccess.WRITE);file.store_string(JSON.stringify(result,"  "));file.close()
	print(JSON.stringify({"success":result.success,"checks":checks,"failures":failures}));quit(0 if result.success else 1)
