'use strict';
// Produce an immutable private replay driver with one script-selection change.
// The normal replay remains untouched. The probe itself is included in both
// staged source views and is never a candidate default.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../..'),source=path.join(root,'tools/replay-native-loading.mjs');
const label=process.argv[2]??'driver-os-b';assert(/^driver-os-[a-z]$/.test(label));
const destination=path.join(root,'.cache/nwn63',label,'replay-native-loading-os.mjs');
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const original=fs.readFileSync(source),text=original.toString();
const probe='res://tests/nwn63_frame_input_graphical_probe.gd';
assert.equal((text.match(/'--script','res:\/\/native_session_world\.gd'/g)||[]).length,1);
assert.equal((text.match(/const project=path\.resolve\(path\.dirname\(fileURLToPath\(import\.meta\.url\)\),'\.\.'\)/g)||[]).length,1);
let output=text.replaceAll("from './","from '../../../tools/")
  .replaceAll("require('./","require('../../../tools/")
  .replace("const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')","const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..')")
  .replace("'--script','res://native_session_world.gd'","'--script','"+probe+"'");
assert(output.includes("'--script','"+probe+"'"));
const parent=path.dirname(destination);fs.mkdirSync(parent,{recursive:true});
if(fs.existsSync(destination))assert.equal(fs.readFileSync(destination,'utf8'),output,'Private driver drift');
else fs.writeFileSync(destination,output,{flag:'wx'});
const receipt={version:1,issue:'NWN-63',original:source,originalSha256:sha(original),driver:destination,driverSha256:sha(Buffer.from(output)),probe,scope:'Private copy of the recorded replay driver; only relative imports/project root and --script selection differ. No game network connection, accepted driver edit or FPS run.'};
const file=path.join(parent,'receipt.json');
if(fs.existsSync(file))assert.deepEqual(JSON.parse(fs.readFileSync(file)),receipt,'Receipt drift');
else fs.writeFileSync(file,JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({file,driver:destination,sha256:receipt.driverSha256,originalSha256:receipt.originalSha256}));
