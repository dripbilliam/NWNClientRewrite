'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const variants=new Map([
  ['fbbafcfea1698cb428709ee2fd2ee0c2855370dfdd068b7f1464e14a93781682',1],
  ['51304ff6a0f7bb76007a5d75c30bf8d5016d1346556653093c0614ca84b8cd1e',2]
]);
// Coordinator-owned NativeLive is never edited by this helper. Both modes use
// exactly the same source; only an explicitly pinned private project setting
// may select the candidate. The old path is the absent/default-false route.
function frameInputLiveAdapter(bytes) {
  let text = bytes.toString();
  const sites=variants.get(sha(bytes));assert(sites,'Unreviewed NativeLive source variant');
  const eol=text.includes('\r\n')?'\r\n':'\n';
  const creation = /^(\t*)keyboard\.set_key_bindings\(gameplay_ui\.key_bindings\);[^\r\n]*/gm;
  const matches = [...text.matchAll(creation)];
  assert.equal(matches.length, sites, 'Expected exact pinned keyboard setup count');
  text = text.replace(creation, line => line + eol + line.match(/^\t*/)[0] + 'keyboard.set_frame_input_admission(bool(ProjectSettings.get_setting("nwn/private/keyboard_frame_admission",false)))');
  const seam = '\tflush_protocol_output()'+eol+'\tcreation_runtime_phase("frame:protocol-after")';
  assert.equal(text.split(seam).length - 1, 1, 'Expected one post-dispatch/pre-output frame seam');
  text = text.replace(seam, '\tif is_instance_valid(keyboard) and keyboard.frame_input_admission and keyboard.can_process():keyboard.flush_input_frame()'+eol + seam);
  const output=Buffer.from(text);
  assert(inverse(output).equals(bytes),'Adapter inverse must preserve exact original bytes');
  return output;
}
function inverse(bytes) {
  let text=bytes.toString();
  const setup=/\r?\n\t*keyboard\.set_frame_input_admission\(bool\(ProjectSettings\.get_setting\("nwn\/private\/keyboard_frame_admission",false\)\)\)/g;
  const count=[...text.matchAll(setup)].length;assert(count===1||count===2,'Exact private setup lines missing');
  text=text.replace(setup,'');
  const flush=/\tif is_instance_valid\(keyboard\) and keyboard\.frame_input_admission(?: and keyboard\.can_process\(\))?:keyboard\.flush_input_frame\(\)\r?\n/g;
  assert.equal([...text.matchAll(flush)].length,1,'Exact private flush line missing');
  text=text.replace(flush,'');
  const output=Buffer.from(text);assert.equal(variants.get(sha(output)),count,'Inverse did not restore a known pinned source');
  return output;
}
module.exports=frameInputLiveAdapter;
module.exports.inverse=inverse;
module.exports.variants=variants;
