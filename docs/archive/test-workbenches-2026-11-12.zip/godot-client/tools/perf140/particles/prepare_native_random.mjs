// Independent native visual-stream experiment. Frozen inputs and shared outputs
// are never modified; owner selection is explicit (--particle-random=native).
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {fileURLToPath} from 'node:url';
const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..'),[label,parentLabel='cold-particle-census-v2']=process.argv.slice(2),base=path.join(project,'.cache/native-140fps/particles-agent'),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
if(![label,parentLabel].every(v=>/^[a-z0-9-]+$/.test(v??'')))throw Error('Fresh native-random label and frozen parent required');
const parentFile=path.join(base,parentLabel,'candidate-built-sources.json'),parent=JSON.parse(fs.readFileSync(parentFile)),stage=path.join(base,label);if(fs.existsSync(stage))throw Error('Existing experiment preserved');
for(const pin of parent.sourcePins)if(hash(fs.readFileSync(path.join(parent.sourceProject,pin.relative)))!==pin.sha256)throw Error('Frozen parent differs');fs.mkdirSync(stage);
const once=(s,a,b)=>{if(s.split(a).length!==2)throw Error('Native random boundary differs: '+a.slice(0,110));return s.replace(a,b);};
for(const variant of ['baseline','candidate']){
 const copy=path.join(stage,variant),pins=[],overrides=variant==='candidate'?parent.overrides.map(row=>({...row})):[];fs.mkdirSync(copy);
 for(const pin of parent.sourcePins){const bytes=fs.readFileSync(path.join(parent.sourceProject,pin.relative)),destination=path.join(copy,pin.relative);fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,bytes);if(hash(fs.readFileSync(destination))!==pin.sha256)throw Error('Copy differs');pins.push({...pin});}
 const install=(relative,source,reason)=>{const destination=path.join(copy,relative);fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,source);const sha256=hash(fs.readFileSync(destination));let pin=pins.find(row=>row.relative===relative);if(!pin){pin={relative};pins.push(pin);}Object.assign(pin,{sha256,bytes:Buffer.byteLength(source)});let override=overrides.find(row=>row.relative===relative);if(!override){override={relative};overrides.push(override);}Object.assign(override,{sha256,reason});};
 if(variant==='candidate'){
  install('native/experimental/native_visual_random.hpp',fs.readFileSync(path.join(project,'tools/perf140/particles/native_visual_random.hpp')),'One shared native visual CRT stream with live exact callable/native object/no-script guards');
  let s=fs.readFileSync(path.join(copy,'native/particle_kernel.cpp'),'utf8').replaceAll('\r\n','\n');
  s=once(s,'#include "particle_resident.hpp"','namespace native_visual_random {bool try_draw(const Var&,int64_t&);}\n#include "particle_resident.hpp"');
  s=once(s,'#include "particle_upload.hpp"','#include "particle_upload.hpp"\n#include "experimental/native_visual_random.hpp"');
  s=once(s,' particle_upload::register_owner(property);',' native_visual_random::register_owner(property);\n particle_upload::register_owner(property);');
  s=once(s,'light_history::unregister_owner();','native_visual_random::unregister_owner();light_history::unregister_owner();');
  s=once(s,'#undef API',' API(native_visual_random::fixed_call,GDExtensionInterfaceObjectMethodBindCall,"object_method_bind_call");API(native_visual_random::register_property,GDExtensionInterfaceClassdbRegisterExtensionClassProperty,"classdb_register_extension_class_property");API(native_visual_random::operators,GDExtensionInterfaceVariantGetPtrOperatorEvaluator,"variant_get_ptr_operator_evaluator");\n#undef API');
  install('native/particle_kernel.cpp',s,'Private native stream class/API registration and dispatch guard declaration');
  s=fs.readFileSync(path.join(copy,'native/particle_resident.hpp'),'utf8').replaceAll('\r\n','\n');
  s=once(s,'direct_queries=0,direct_hits=0,wind_token=0;','direct_queries=0,direct_hits=0,wind_token=0,direct_random=0,opaque_random=0;');
  s=once(s,' auto callable=::get(*context->providers,name);std::vector<EngineVar> exported;',` auto callable=::get(*context->providers,name);if(std::strcmp(name,"random")==0){int64_t sampled=0;if(arguments.size()==0&&native_visual_random::try_draw(callable,sampled)){++context->direct_random;return Var::integer(sampled);}++context->opaque_random;}std::vector<EngineVar> exported;`);
  install('native/particle_resident.hpp',s,'Dispatch only exact live native RNG next calls; every other callable retains ordinary mutation barrier and errors');
  s=fs.readFileSync(path.join(copy,'native/particle_presentation.hpp'),'utf8').replaceAll('\r\n','\n');
  s=once(s,'uint64_t direct_queries=0,direct_hits=0;double controls_ms=','uint64_t direct_queries=0,direct_hits=0,direct_random=0,opaque_random=0;double controls_ms=');
  s=once(s,'direct_queries=direct_hits=0;controls_ms=','direct_queries=direct_hits=direct_random=opaque_random=0;controls_ms=');
  s=once(s,'direct_queries=ctx.direct_queries;direct_hits=ctx.direct_hits;collision_ms=','direct_queries=ctx.direct_queries;direct_hits=ctx.direct_hits;direct_random=ctx.direct_random;opaque_random=ctx.opaque_random;collision_ms=');
  s=once(s,'  std::array<double,7> phases{};','  uint64_t random_direct=0,random_opaque=0;\n  std::array<double,7> phases{};');
  s=once(s,'if(profile){const auto& state=entry.owner->compact_state;','if(profile){random_direct+=entry.step.direct_random;random_opaque+=entry.step.opaque_random;const auto& state=entry.owner->compact_state;');
  s=once(s,'   census[19]=','   ::set(measured,"count_particle_native_random_direct",EngineVar::integer(static_cast<int64_t>(random_direct)));::set(measured,"count_particle_native_random_opaque",EngineVar::integer(static_cast<int64_t>(random_opaque)));\n   census[19]=');
  install('native/particle_presentation.hpp',s,'Existing-loop profile counters distinguish exact native draws from retained opaque calls');
  s=fs.readFileSync(path.join(copy,'systems/native_render/particle_random.gd'),'utf8').replaceAll('\r\n','\n');
  s+='\nstatic func create() -> RefCounted:\n\tif (OS.get_cmdline_user_args().has("--particle-random=native") or OS.get_environment("NWN_PARTICLE_RANDOM")=="native") and ClassDB.class_exists("NwnVisualRandom"):\n\t\treturn ClassDB.instantiate("NwnVisualRandom")\n\treturn load("res://systems/native_render/particle_random.gd").new()\n';
  install('systems/native_render/particle_random.gd',s,'Explicit opt-in factory; existing GDScript owner/new/sequence unchanged as paired oracle');
  s=fs.readFileSync(path.join(copy,'systems/native_render/particle_emitter.gd'),'utf8').replaceAll('\r\n','\n');s=once(s,'var rng:=Random.new()','var rng=Random.create()');install('systems/native_render/particle_emitter.gd',s,'Native and fallback emitters share the same selected world owner, including compatible diagnostics');
  s=fs.readFileSync(path.join(copy,'systems/native_render/live_world.gd'),'utf8').replaceAll('\r\n','\n');s=once(s,'set_meta("native_particle_random",ParticleRandom.new())','set_meta("native_particle_random",ParticleRandom.create())');install('systems/native_render/live_world.gd',s,'Owned world visual stream choice only; no pose/session/authority changes');
 }
 const receipt={...parent,label,variant,sourceProject:copy,sourcePins:pins,overrides,parent:{file:parentFile,sha256:hash(fs.readFileSync(parentFile)),renderer:parent.sourceProject},sharedNativeBuilds:0,scope:'Independent opt-in native shared visual RNG on frozen census parent; default mode remains GDScript and custom/scripted callables remain opaque. No graphics acceptance.'};delete receipt.isolatedBuildFinalized;delete receipt.build;delete receipt.prebuildReceipt;fs.writeFileSync(path.join(stage,variant+'-sources.json'),JSON.stringify(receipt,null,2)+'\n');
}
console.log(JSON.stringify({success:true,label,stage,sharedNativeBuilds:0,mode:'--particle-random=native'}));
