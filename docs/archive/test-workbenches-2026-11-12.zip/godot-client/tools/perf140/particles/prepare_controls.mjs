// Independent controls-copy experiment. Never overwrite the pose candidate.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {fileURLToPath} from 'node:url';
const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..'),[label,parentLabel='frame-pose-epochs-v2']=process.argv.slice(2);
if(![label,parentLabel].every(v=>/^[a-z0-9-]+$/.test(v??'')))throw Error('Fresh controls label and frozen particle parent required');
const stage=path.join(project,'.cache/native-140fps/particles-agent',label),parentFile=path.join(project,'.cache/native-140fps/particles-agent',parentLabel,'baseline-sources.json'),parent=JSON.parse(fs.readFileSync(parentFile)),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
if(fs.existsSync(stage))throw Error('Existing private experiment preserved');
const once=(s,a,b)=>{if(s.split(a).length!==2)throw Error('Controls boundary differs: '+a.slice(0,90));return s.replace(a,b);};
for(const pin of parent.sourcePins)if(hash(fs.readFileSync(path.join(parent.sourceProject,pin.relative)))!==pin.sha256)throw Error('Frozen baseline differs: '+pin.relative);
fs.mkdirSync(stage,{recursive:true});
for(const variant of ['baseline','candidate']){
 const copy=path.join(stage,variant),pins=[];fs.mkdirSync(copy);const overrides=[];
 for(const pin of parent.sourcePins){const bytes=fs.readFileSync(path.join(parent.sourceProject,pin.relative)),destination=path.join(copy,pin.relative);fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,bytes);if(hash(fs.readFileSync(destination))!==pin.sha256)throw Error('Copy differs: '+pin.relative);pins.push({...pin});}
 if(variant==='candidate'){
  const relative='native/particle_presentation.hpp',file=path.join(copy,relative);let source=fs.readFileSync(file,'utf8').replaceAll('\r\n','\n');
  source=once(source,' bool enabled=true,source_animating=false;',' bool enabled=true,source_animating=false,reuse_controls=true;');
  source=once(source,'  if(::has(config,"enabled"))entry.enabled=::get(config,"enabled").boolean();','  if(::has(config,"reuse_controls"))entry.reuse_controls=::get(config,"reuse_controls").boolean();\n  if(::has(config,"enabled"))entry.enabled=::get(config,"enabled").boolean();');
  source=once(source,'entry.elapsed+=delta;auto next=entry.controls;','entry.elapsed+=delta;std::optional<Controls> copied_controls;auto& next=entry.reuse_controls?entry.controls:copied_controls.emplace(entry.controls);');
  source=once(source,'const auto& e=*found->second;::set(out,"fast",','const auto& e=*found->second;::set(out,"reuse_controls",EngineVar::boolean(e.reuse_controls));::set(out,"fast",');
  fs.writeFileSync(file,source);const sha256=hash(fs.readFileSync(file));Object.assign(pins.find(p=>p.relative===relative),{sha256,bytes:Buffer.byteLength(source)});overrides.push({relative,sha256,reason:'Default path removes one duplicated Controls copy; optional scratch preserves ordinary same-DLL oracle, Step retains its existing pre-clear copy'});
 }
 const receipt={...parent,label,variant,sourceProject:copy,sourcePins:pins,overrides,parent:{file:parentFile,sha256:hash(fs.readFileSync(parentFile)),renderer:parent.sourceProject},sharedNativeBuilds:0,scope:'Independent controls-copy elision only. No frame-pose sharing or ordinary native output changes.'};fs.writeFileSync(path.join(stage,variant+'-sources.json'),JSON.stringify(receipt,null,2)+'\n');
}
console.log(JSON.stringify({success:true,label,stage,sharedNativeBuilds:0,combined:false}));
