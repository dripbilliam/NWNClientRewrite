// Pure correctness/footprint oracle. No timing, engine, graphics or server.
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <unordered_map>
#include <vector>
#include "endpoint_frame_pose_cache.hpp"
#define nwn_frame_pose oracle_frame_pose
#include "oracle_frame_pose_cache.hpp"
#undef nwn_frame_pose

namespace {
std::uint64_t checks=0;
void require(bool value,const char* message){++checks;if(!value)throw std::runtime_error(message);}
struct Payload {std::array<float,12> values{};};
bool same(const Payload& a,const Payload& b){return std::memcmp(a.values.data(),b.values.data(),sizeof(a.values))==0;}
using Store=nwn_endpoint_slots::Slots<Payload>;
using Handle=nwn_endpoint_slots::Handle;
using Candidate=nwn_frame_pose::Cache<Payload>;
using Ordinary=oracle_frame_pose::Cache<Payload>;
Payload payload(std::uint64_t id,int frame){Payload value;for(std::size_t n=0;n<value.values.size();++n)value.values[n]=static_cast<float>(id)*0.125f+static_cast<float>(frame)+static_cast<float>(n)*0.03125f;return value;}
void storage_contract(){
 Store rows;Handle first;
 require(rows.find(7,&first)==nullptr&&first.cache==0,"missing lookup clears an unbound handle");
 rows.insert_or_assign(7,payload(7,0),&first);const auto original=first;
 require(rows.accepts(7,first)&&same(*rows.find(7,&first),payload(7,0)),"insert binds exact current row");
 for(std::uint64_t id=8;id<2790;++id)rows.insert_or_assign(id,payload(id,0));
 require(rows.accepts(7,original)&&same(*rows.find(7,&first),payload(7,0)),"map rehash and arena growth preserve the logical handle");
 require(!rows.accepts(8,first),"handle cannot resolve a different full ID");
 Handle forged=first;++forged.index;require(!rows.accepts(7,forged),"wrong slot index rejects");
 forged=first;++forged.generation;require(!rows.accepts(7,forged),"wrong slot generation rejects");
 forged=first;++forged.cache;require(!rows.accepts(7,forged),"wrong cache identity rejects");
 rows.insert_or_assign(7,payload(7,1));
 require(rows.accepts(7,first)&&same(*rows.find(7,&first),payload(7,1)),"replacement updates the same owned row without stale payload");
 const auto before=rows.arena.size();require(rows.erase(7),"erase retires a live row");
 require(!rows.accepts(7,original)&&rows.find(7,&first)==nullptr,"held index cannot resolve an erased row");
 require(!rows.erase(7),"repeated erase has no extra free slot");
 rows.insert_or_assign(7,payload(7,2),&first);
 require(rows.arena.size()==before&&first.generation!=original.generation,"full-ID reuse recycles capacity with a new lifetime generation");
 require(!rows.accepts(7,original)&&same(*rows.find(7,&first),payload(7,2)),"old lifetime cannot alias the re-added ID");
 const auto preclear=first;rows.clear();rows.insert_or_assign(7,payload(7,3),&first);
 require(!rows.accepts(7,preclear)&&first.cache!=preclear.cache,"clear rotates identity before slot zero is reused");
 Handle teardown;
 {Store prior;prior.insert_or_assign(7,payload(7,4),&teardown);}
 Store fresh;fresh.insert_or_assign(7,payload(7,5));
 require(!fresh.accepts(7,teardown),"cache teardown/recreation cannot resolve a previous cache's index");
 // Saturation fails closed without retaining a tombstone for each lifetime.
 auto& slot=rows.arena[static_cast<std::size_t>(first.index)];slot.generation=std::numeric_limits<std::uint64_t>::max();
 first.generation=slot.generation;require(rows.accepts(7,first),"saturation fixture starts from a valid final generation");
 rows.erase(7);rows.insert_or_assign(7,payload(7,6));
 require(!rows.handles_enabled&&!rows.accepts(7,first)&&same(*rows.find(7,&first),payload(7,6)),"generation exhaustion disables handles while exact ID fallback works");
 require(first.cache==0,"disabled handle route publishes no usable direct index");
 rows.clear();rows.insert_or_assign(7,payload(7,7),&first);
 require(rows.handles_enabled&&rows.accepts(7,first),"a fresh nonreused cache identity can safely reset exhausted storage");
}
void bounded_cohort(){
 constexpr std::size_t count=2782;Store rows;rows.reserve(count);std::vector<Handle> held(count);
 for(std::size_t n=0;n<count;++n)rows.insert_or_assign(static_cast<std::uint64_t>(n)+1,payload(n+1,0),&held[n]);
 const auto capacity=rows.arena.capacity();
 for(int round=1;round<=16;++round){
  for(std::size_t n=0;n<count;++n)rows.erase(static_cast<std::uint64_t>(n)+1);
  require(rows.size()==0&&rows.free.size()==count,"whole-cohort retirement retains only bounded reusable slots");
  bool stale_rejected=true;
  for(std::size_t n=0;n<count;++n){const auto id=static_cast<std::uint64_t>(n)+1;stale_rejected=stale_rejected&&!rows.accepts(id,held[n]);rows.insert_or_assign(id,payload(id,round),&held[n]);}
  require(stale_rejected,"all cohort stale lifetimes reject before reuse");
  require(rows.size()==count&&rows.arena.size()==count&&rows.arena.capacity()==capacity&&rows.free.empty(),"re-add cohort has no historical-ID retention growth");
 }
 for(std::size_t n=0;n<count;++n)require(same(*rows.find(n+1,&held[n]),payload(n+1,16)),"representative endpoint cohort preserves exact payloads");
}
void cache_oracle(){
 constexpr std::size_t count=2782;Ordinary ordinary;Candidate indexed;std::vector<Handle> handles(count);
 nwn_managed_pose::Scope scope;scope.identity=2;scope.owner_id=3;
 auto make_lease=[&](std::uint64_t identity){nwn_managed_pose::Lease lease;lease.identity=identity;lease.source_id=4;lease.placement_id=5;lease.scope=std::make_shared<nwn_managed_pose::Scope>(scope);return lease;};
 auto lease=make_lease(6);std::uint64_t ordinary_reads=0,indexed_reads=0;
 const auto convert=[](const std::array<float,12>& raw){return Payload{raw};};
 for(int frame=0;frame<4;++frame){
  ordinary.begin(count);indexed.begin(count,true);
  for(std::size_t n=0;n<count;++n){const auto id=static_cast<std::uint64_t>(n)+1;
   const auto a=ordinary.managed_read(id,lease,[&](){++ordinary_reads;return payload(id,frame).values;},convert);
   const auto b=indexed.managed_read(id,lease,[&](){++indexed_reads;return payload(id,frame).values;},convert,&handles[n]);
   require(same(a,b),"managed endpoint output matches original cache bit-for-bit");
  }
  require(ordinary.hits==indexed.hits&&ordinary.reads==indexed.reads&&ordinary.managed_hits==indexed.managed_hits&&ordinary.managed_refreshes==indexed.managed_refreshes,"cache reuse and source-read boundaries match");
  require(indexed.row_count()==count&&indexed.rows.empty(),"indexed mode has one owned row store, never a duplicate ordinary pose world");
 }
 require(ordinary_reads==count&&indexed_reads==ordinary_reads,"unchanged managed cohort keeps exactly the original source-read count");
 require(indexed.indexed_rows.direct_hits>=count&&indexed.indexed_rows.lookups==0,"settled cohort actually uses handles without ID-map fallback");
 // Existing callback policy, including throw/reentry, is preserved separately
 // from the storage handle. The original scopes invalidate the same global
 // managed mutation revision, and both row witnesses must refresh afterward.
 {nwn_frame_pose::CallbackBarrier barrier;require(!lease.usable(nwn_managed_pose::callbacks),"opaque callback cannot accept a managed witness during reentry");}
 ordinary.begin(count);indexed.begin(count,true);
 auto a=ordinary.managed_read(1,lease,[&](){++ordinary_reads;return payload(1,9).values;},convert);
 auto b=indexed.managed_read(1,lease,[&](){++indexed_reads;return payload(1,9).values;},convert,&handles[0]);
 require(same(a,b)&&same(b,payload(1,9)),"callback exit invalidates retained pose despite a valid direct slot");
 lease.revoke();lease=make_lease(7);
 a=ordinary.managed_read(1,lease,[&](){++ordinary_reads;return payload(1,10).values;},convert);
 b=indexed.managed_read(1,lease,[&](){++indexed_reads;return payload(1,10).values;},convert,&handles[0]);
 require(same(a,b),"new lease identity keeps the old cache's exact same-call epoch behavior");
 // Managed-read refresh can still reuse this call's already-read ordinary
 // pose; new storage must not silently read a later source earlier than old.
 require(same(b,payload(1,9)),"lease replacement does not invent an extra source read within the original call epoch");
 ordinary.erase(1);indexed.erase(1);
 a=ordinary.managed_read(1,lease,[&](){++ordinary_reads;return payload(1,11).values;},convert);
 b=indexed.managed_read(1,lease,[&](){++indexed_reads;return payload(1,11).values;},convert,&handles[0]);
 require(same(a,b)&&same(b,payload(1,11)),"erase/re-add invalidates both ordinary row and held direct index");
 indexed.begin(count,false);require(!indexed.indexed&&indexed.row_count()==0&&indexed.indexed_rows.size()==0,"ordinary mode switch clears indexed authority before fallback");
 const auto c=indexed.read(1,[&](){return payload(1,12).values;},convert,&handles[0]);
 require(same(c,payload(1,12))&&indexed.rows.size()==1&&indexed.indexed_rows.size()==0,"ordinary mode retains the original sole row store");
 indexed.begin(count,true);require(indexed.rows.empty()&&indexed.row_count()==0,"indexed re-enable starts from a fresh current cache generation");
 auto bad=payload(2,13).values;bad[0]=std::numeric_limits<float>::quiet_NaN();
 const auto nonfinite=indexed.read(2,[&](){return bad;},convert,&handles[1]);
 require(std::isnan(nonfinite.values[0])&&indexed.row_count()==0&&handles[1].cache==0,"nonfinite conversion output follows original uncached behavior");
 volatile bool fail_read=true;bool caught=false;
 try{indexed.read(3,[&]()->std::array<float,12>{if(fail_read)throw std::runtime_error("fixture read failure");return payload(3,14).values;},convert,&handles[2]);}catch(const std::runtime_error&){caught=true;}
 require(caught&&indexed.row_count()==0,"read failure creates no partial slot or retained payload");
 require(ordinary_reads==indexed_reads,"all compared source-read/lifetime boundaries remain identical");
}
}
int main(){
 try{storage_contract();bounded_cohort();cache_oracle();
  std::cout<<"{\"success\":true,\"checks\":"<<checks<<",\"cohort\":2782,\"timing\":false,\"engine\":false,\"footprint\":{\"handle_bytes\":"<<sizeof(Handle)<<",\"ordinary_row_bytes\":"<<sizeof(Ordinary::Row)<<",\"indexed_slot_bytes\":"<<sizeof(nwn_endpoint_slots::Slots<Candidate::Row>::Slot)<<",\"ordinary_map_value_bytes\":"<<sizeof(decltype(Ordinary::rows)::value_type)<<",\"indexed_map_value_bytes\":"<<sizeof(decltype(nwn_endpoint_slots::Slots<Candidate::Row>::index)::value_type)<<",\"note\":\"sizeof payloads only; allocator and bucket overhead not included\"}}\n";return 0;
 }catch(const std::exception& error){std::cout<<"{\"success\":false,\"checks\":"<<checks<<",\"error\":\""<<error.what()<<"\"}\n";return 1;}
}
