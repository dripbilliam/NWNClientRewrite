// Private engine-builtin consumer. Detached rows are valid only inside the
// current callback-free native presentation scope. No Node pointers are stored.
namespace particle_scene_snapshot {
using ABI=nwn_scene_snapshot_abi::View;
GDExtensionInterfaceObjectMethodBindCall fixed_call=nullptr;
GDExtensionInterfacePackedInt64ArrayOperatorIndex ids_write=nullptr;
GDExtensionInterfaceClassdbGetMethodBind lookup_method=nullptr;
GDExtensionMethodBindPtr class_exists=nullptr,class_call_static=nullptr;
GDExtensionPtrBuiltInMethod resize_ids=nullptr;
GDExtensionObjectPtr classdb=nullptr;
int availability=-1;
Var name_value(const char* text){Name name(text);Var out;destroy(out.data);from[GDEXTENSION_VARIANT_TYPE_STRING_NAME](out.data,name.data);return out;}
Var fixed(GDExtensionMethodBindPtr binding,std::initializer_list<Var> args){
 std::vector<GDExtensionConstVariantPtr> inputs;inputs.reserve(args.size());for(const auto& arg:args)inputs.push_back(arg.data);
 Var out;destroy(out.data);GDExtensionCallError error{};fixed_call(binding,classdb,inputs.data(),static_cast<GDExtensionInt>(inputs.size()),out.data,&error);
 if(error.error!=GDEXTENSION_CALL_OK)return Var();return out;
}
bool available(){
 if(availability>=0)return availability==1;
 availability=0;if(!fixed_call||!ids_write||!lookup_method)return false;
 Name service("ClassDB"),exists_name("class_exists"),call_name("class_call_static"),resize("resize");classdb=global_singleton(service.data);if(!classdb)return false;
 class_exists=lookup_method(service.data,exists_name.data,2619796661);class_call_static=lookup_method(service.data,call_name.data,3344196419);resize_ids=builtin_method(GDEXTENSION_VARIANT_TYPE_PACKED_INT64_ARRAY,resize.data,848867239);
 if(!class_exists||!class_call_static||!resize_ids)return false;
 const auto result=fixed(class_exists,{name_value("NwnParticleSceneSnapshot")});if(result.type()!=GDEXTENSION_VARIANT_TYPE_BOOL||!result.boolean())return false;
 const auto version=fixed(class_call_static,{name_value("NwnParticleSceneSnapshot"),name_value("abi_version")});if(version.type()!=GDEXTENSION_VARIANT_TYPE_INT||version.integer()!=nwn_scene_snapshot_abi::version)return false;
 availability=1;return true;
}
struct DirtyFlag {std::atomic<bool> value{true};};
template<class State>struct Observers {std::weak_ptr<State> state;std::vector<std::weak_ptr<DirtyFlag>> plans;};
std::mutex capability_mutex;
std::unordered_map<const nwn_managed_pose::Lease*,Observers<nwn_managed_pose::Lease>> lease_observers;
std::unordered_map<const nwn_managed_pose::Scope*,Observers<nwn_managed_pose::Scope>> scope_observers;
template<class State,class Map>void watch_state(Map& map,const std::shared_ptr<State>& state,const std::shared_ptr<DirtyFlag>& flag){
 if(!state)return;auto& entry=map[state.get()];if(entry.state.lock()!=state){entry={};entry.state=state;}
 for(auto it=entry.plans.begin();it!=entry.plans.end();){const auto current=it->lock();if(!current)it=entry.plans.erase(it);else{if(current==flag)return;++it;}}entry.plans.push_back(flag);
}
void watch(const std::shared_ptr<nwn_managed_pose::Lease>& lease,const std::shared_ptr<DirtyFlag>& flag){if(!lease)return;std::lock_guard<std::mutex> lock(capability_mutex);watch_state(lease_observers,lease,flag);watch_state(scope_observers,lease->scope,flag);}
template<class State,class Map>void notify_state(Map& map,const std::shared_ptr<State>& state){
 if(!state)return;const auto found=map.find(state.get());if(found==map.end())return;
 if(found->second.state.lock()==state)for(const auto& weak:found->second.plans)if(const auto flag=weak.lock())flag->value.store(true,std::memory_order_release);
 map.erase(found);
}
void revoked(const std::shared_ptr<nwn_managed_pose::Lease>& lease,const std::shared_ptr<nwn_managed_pose::Scope>& scope={}){std::lock_guard<std::mutex> lock(capability_mutex);notify_state(lease_observers,lease);notify_state(scope_observers,scope);}
struct Plan {
 struct Binding {uint64_t pose=0,source=0;std::weak_ptr<nwn_managed_pose::Lease> lease;};
 struct Slot {uint64_t id=0;std::array<uint32_t,2> uses{};uint32_t managed_uses=0;uint8_t roles()const{return static_cast<uint8_t>((uses[0]?nwn_scene_snapshot_abi::eligibility:0)|(uses[1]?nwn_scene_snapshot_abi::validate:0));}};
 std::vector<Slot> slots;std::vector<size_t> free_slots;std::unordered_map<uint64_t,size_t> indices;
 std::unordered_map<GDExtensionObjectPtr,Binding> owners;std::shared_ptr<DirtyFlag> capabilities=std::make_shared<DirtyFlag>();
 Var ids,roles;bool dirty=true;int packed_mode=0;uint64_t packs=0;
 void add(uint64_t id,uint8_t role){
  if(!id)return;auto found=indices.find(id);size_t index=0;
  if(found==indices.end()){if(free_slots.empty()){index=slots.size();slots.emplace_back();}else{index=free_slots.back();free_slots.pop_back();}slots[index].id=id;indices.emplace(id,index);}else index=found->second;
  const size_t field=role==nwn_scene_snapshot_abi::eligibility?0:1;++slots[index].uses[field];dirty=true;
 }
 void erase(uint64_t id,uint8_t role){
  auto found=indices.find(id);if(found==indices.end())return;auto& slot=slots[found->second];const size_t field=role==nwn_scene_snapshot_abi::eligibility?0:1;if(slot.uses[field])--slot.uses[field];
  if(!slot.roles()){const auto index=found->second;indices.erase(found);slot={};free_slots.push_back(index);}dirty=true;
 }
 void bind(GDExtensionObjectPtr owner,uint64_t pose,uint64_t source,const std::shared_ptr<nwn_managed_pose::Lease>& lease){owners.insert_or_assign(owner,Binding{pose,source,lease});capabilities->value.store(true,std::memory_order_release);watch(lease,capabilities);}
 void unbind(GDExtensionObjectPtr owner){owners.erase(owner);capabilities->value.store(true,std::memory_order_release);}
 void publish(GDExtensionObjectPtr owner,const std::shared_ptr<nwn_managed_pose::Lease>& lease){const auto found=owners.find(owner);if(found==owners.end())return;found->second.lease=lease;capabilities->value.store(true,std::memory_order_release);watch(lease,capabilities);}
 void clear(){slots.clear();free_slots.clear();indices.clear();owners.clear();ids=Var();roles=Var();dirty=true;packed_mode=0;capabilities->value.store(true,std::memory_order_release);}
 uint8_t role(size_t index,int mode)const{const auto& slot=slots[index];const auto base=slot.roles();return static_cast<uint8_t>(base|((mode==2&&(base&nwn_scene_snapshot_abi::validate)&&slot.managed_uses<slot.uses[1])?nwn_scene_snapshot_abi::transform:0));}
 void pack(int mode){
  const bool changed=capabilities->value.exchange(false,std::memory_order_acq_rel);if(!dirty&&!changed&&packed_mode==mode)return;++packs;
  // Recompute only after membership/canonical capability publication or mode
  // change. A shared source omits TRS only if EVERY validation user is leased.
  for(auto& slot:slots)slot.managed_uses=0;
  for(const auto& row:owners){const auto lease=row.second.lease.lock();if(!lease||!lease->usable(nwn_managed_pose::callbacks))continue;for(const auto endpoint:{row.second.pose,row.second.source}){const auto found=indices.find(endpoint);if(found!=indices.end())++slots[found->second].managed_uses;}}
  alignas(8) uint8_t raw[16];ptr_constructor(GDEXTENSION_VARIANT_TYPE_PACKED_INT64_ARRAY,0)(raw,nullptr);
  struct Guard{void* value;~Guard(){ptr_destructor(GDEXTENSION_VARIANT_TYPE_PACKED_INT64_ARRAY)(value);}}guard{raw};
  int64_t count=static_cast<int64_t>(slots.size()),error=-1;const GDExtensionConstTypePtr args[]={&count};resize_ids(raw,args,&error,1);if(error)throw std::runtime_error("Native scene snapshot request allocation failed");
  auto* output=count?ids_write(raw,0):nullptr;WritableBytes masks(slots.size());
  for(size_t n=0;n<slots.size();++n){std::memcpy(output+n,&slots[n].id,8);masks.data[n]=role(n,mode);}
  Var next;destroy(next.data);from[GDEXTENSION_VARIANT_TYPE_PACKED_INT64_ARRAY](next.data,raw);ids=next;roles=masks.publish();packed_mode=mode;dirty=false;
 }
};
void publish(std::vector<std::weak_ptr<Plan>>& plans,GDExtensionObjectPtr owner,const std::shared_ptr<nwn_managed_pose::Lease>& lease){for(auto it=plans.begin();it!=plans.end();){if(const auto plan=it->lock()){plan->publish(owner,lease);++it;}else it=plans.erase(it);}}
struct Stats {int mode=0,status=0;bool available=false,usable=false,invalidated=false,measured=false;double batch_ms=0;uint64_t request_generation=0,rows=0,transforms=0,eligible=0,eligibility_uses=0,validation_uses=0,transform_uses=0,live_fallbacks=0;};
struct Frame {
 Plan& plan;Stats& published;Stats stats;Var packet;alignas(8) uint8_t raw[16]{};bool raw_live=false;
 ABI view;nwn_frame_pose::Epoch* epoch=nullptr;uint64_t epoch_value=0,mutation=0;
 explicit Frame(Plan& next,int mode,Stats& target,bool profile=false):plan(next),published(target){
  stats.measured=profile;struct Timer{Stats& result;std::chrono::steady_clock::time_point began;explicit Timer(Stats& value):result(value),began(value.measured?std::chrono::steady_clock::now():std::chrono::steady_clock::time_point{}){}~Timer(){if(result.measured)result.batch_ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-began).count();}}timer(stats);
  stats.mode=mode;if(mode!=1&&mode!=2)return;
  stats.available=available();if(!stats.available)return;stats.status=nwn_scene_snapshot_abi::bad_request;
  if(!nwn_managed_pose::callbacks.reusable()||!nwn_frame_pose::active_epoch)return;
  epoch=nwn_frame_pose::active_epoch;epoch_value=epoch->value;mutation=nwn_managed_pose::callbacks.revision.value;
  plan.pack(mode);stats.request_generation=plan.packs;packet=fixed(class_call_static,{name_value("NwnParticleSceneSnapshot"),name_value("snapshot_nodes"),plan.ids,plan.roles});
  if(packet.type()!=GDEXTENSION_VARIANT_TYPE_PACKED_BYTE_ARRAY)return;
  const auto length=::size(packet);to[GDEXTENSION_VARIANT_TYPE_PACKED_BYTE_ARRAY](raw,packet.data);raw_live=true;
  const auto* bytes=length?packed_bytes_read(raw,0):nullptr;
  stats.usable=view.open(bytes,static_cast<size_t>(length))&&view.count==plan.slots.size();stats.status=view.status;stats.rows=view.count;stats.transforms=view.transforms;stats.eligible=view.eligible;
 }
 ~Frame(){current();published=stats;if(raw_live)ptr_destructor(GDEXTENSION_VARIANT_TYPE_PACKED_BYTE_ARRAY)(raw);}
 Frame(const Frame&)=delete;
 bool current(){
  if(!stats.usable)return false;
  if(epoch!=nwn_frame_pose::active_epoch||epoch->value!=epoch_value||epoch->wrapped||!nwn_managed_pose::callbacks.reusable()||nwn_managed_pose::callbacks.revision.value!=mutation){stats.usable=false;stats.invalidated=true;return false;}
  return true;
 }
 bool find(uint64_t id,uint8_t required,uint32_t& flags,std::array<float,12>* pose=nullptr){
  if(!current())return false;const auto found=plan.indices.find(id);if(found==plan.indices.end()){++stats.live_fallbacks;return false;}
  const auto role=plan.role(found->second,stats.mode);if(!(role&required)){++stats.live_fallbacks;return false;}
  if(!view.row(found->second,id,role,flags,pose)){stats.usable=false;++stats.live_fallbacks;return false;}
  if(required==nwn_scene_snapshot_abi::eligibility)++stats.eligibility_uses;else if(required!=nwn_scene_snapshot_abi::transform)++stats.validation_uses;if(pose&&(flags&nwn_scene_snapshot_abi::has_transform))++stats.transform_uses;return true;
 }
};
thread_local Frame* active=nullptr;
struct Scope {Frame* prior;explicit Scope(Frame& frame):prior(active){active=frame.stats.usable?&frame:nullptr;}~Scope(){active=prior;}};
bool row(uint64_t id,uint8_t role,uint32_t& flags,std::array<float,12>* pose=nullptr){return active&&active->find(id,role,flags,pose);}
std::optional<bool> eligible(uint64_t id){uint32_t flags=0;if(!row(id,nwn_scene_snapshot_abi::eligibility,flags))return std::nullopt;return (flags&(nwn_scene_snapshot_abi::exists|nwn_scene_snapshot_abi::node3d|nwn_scene_snapshot_abi::inside|nwn_scene_snapshot_abi::visible|nwn_scene_snapshot_abi::processable))==(nwn_scene_snapshot_abi::exists|nwn_scene_snapshot_abi::node3d|nwn_scene_snapshot_abi::inside|nwn_scene_snapshot_abi::visible|nwn_scene_snapshot_abi::processable);}
std::optional<bool> exists(uint64_t id){uint32_t flags=0;if(!row(id,nwn_scene_snapshot_abi::validate,flags))return std::nullopt;return (flags&nwn_scene_snapshot_abi::exists)!=0;}
Var inspect(const Stats& stats){auto out=Var::dictionary();const auto number=[&](const char* name,uint64_t value){::set(out,name,Var::integer(static_cast<int64_t>(value)));};number("mode",stats.mode);number("status",stats.status);number("request_generation",stats.request_generation);number("rows",stats.rows);number("transforms",stats.transforms);number("eligible",stats.eligible);number("eligibility_uses",stats.eligibility_uses);number("validation_uses",stats.validation_uses);number("transform_uses",stats.transform_uses);number("live_fallbacks",stats.live_fallbacks);::set(out,"available",Var::boolean(stats.available));::set(out,"usable",Var::boolean(stats.usable));::set(out,"invalidated",Var::boolean(stats.invalidated));::set(out,"batch_ms",stats.measured?Var::number(stats.batch_ms):Var());return out;}
} // namespace particle_scene_snapshot
