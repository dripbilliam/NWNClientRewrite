#include "typed_object_proof.hpp"
#include <iostream>
#include <stdexcept>
struct Object {bool node;};
int main(){
 int checks=0,lookups=0,casts=0;const auto check=[&](bool value){++checks;if(!value)throw std::runtime_error("Typed proof failure");};
 nwn_typed_object::Proof proof;Object a{true},b{true},wrong{false};Object* live=&a;
 const auto resolve=[&](std::uint64_t)->Object*{++lookups;return live;};
 const auto cast=[&](Object* object){++casts;return object->node;};
 const auto read=[&](std::uint64_t id){return proof.validate(id,resolve(id),cast);};
 check(read(5));check(read(5));check(lookups==2&&casts==1&&proof.hits==1);
 live=nullptr;check(!read(5));check(proof.identity==0&&proof.address==0);
 live=&wrong;check(!read(6));check(!read(6));check(proof.identity==0);
 live=&a;check(read(7));live=&b;check(read(7));check(proof.identity==7);
 // Reused address with a NEW lifetime must recast, even if the old witness
 // happened to represent a Node3D. Native type is immutable within a lifetime.
 live=&a;check(read(8));a.node=false;check(!read(9));a.node=true;check(read(10));
 const auto before=lookups;
 for(int frame=0;frame<10000;++frame){
  live=frame%3==0?nullptr:frame%3==1?&a:&wrong;
  const auto identity=static_cast<std::uint64_t>(frame+100);
  check(read(identity)==(live&&live->node));
  check(read(identity)==(live&&live->node));
 }
 check(lookups-before==20000);check(casts>0&&proof.casts==static_cast<std::uint64_t>(casts));
 std::cout<<"{\"success\":true,\"checks\":"<<checks<<",\"liveLookups\":"<<lookups<<",\"casts\":"<<casts<<",\"scope\":\"Pure typed ancestry proof; live lookup on every use, changed address/lifetime/null/wrong-type. No engine or FPS claim\"}\n";
}
