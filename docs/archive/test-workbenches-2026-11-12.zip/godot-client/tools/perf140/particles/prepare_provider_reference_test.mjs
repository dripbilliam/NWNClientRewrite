import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..');
let source=fs.readFileSync(path.join(project,'tests/native_perf140_particle_controls_test.gd'),'utf8');
const once=(a,b)=>{if(source.split(a).length!==2)throw Error('Provider oracle boundary differs: '+a);source=source.replace(a,b);};
once('var experiment_mode:="reuse_controls"','var experiment_mode:="borrow_providers"');
once('var experiment_scope:=','var experiment_scope:=');
once('"rejections":0,"reuse":reuse','"rejections":0,"reuse":reuse,"provider_replacements":0,"provider_consumptions":0');
once('func finish_experiment(_groups: Array) -> void:pass',`func finish_experiment(groups: Array) -> void:
	check(groups[0].provider_replacements>0 and groups[0].provider_replacements==groups[1].provider_replacements,"Both modes actually replace their provider callback during simulation")
	check(groups[0].provider_consumptions>0 and groups[0].provider_consumptions==groups[1].provider_consumptions,"Both modes actually invoke the replacement callback through the same live provider Dictionary")`);
// Keep the complete same-DLL 180-frame controls/state/geometry/RNG oracle.
// Each custom random callback also mutates the actual shared provider
// Dictionary before subsequent simulation callbacks use it.
once('group.events.append([index,observation.get("pending_patch"),observation.get("pending_detonate"),observation.get("elapsed"),observation.get("frames")])',`group.events.append([index,observation.get("pending_patch"),observation.get("pending_detonate"),observation.get("elapsed"),observation.get("frames")])
			group.services[index]["cosineDouble"]=func(angle):group.events.append(["live_replaced_cosine",index,angle]);return cos(angle)
			group.provider_replacements+=1
			group.services[index]["random"]=func():group.provider_consumptions+=1;group.events.append(["live_replaced_random",index]);return rng.next()
			group.services[index]["private_scratch"]=oracle_context.frame`);
const helpers=String.raw`
func provider_lifetime_case(scene: Node3D,borrow: bool) -> Dictionary:
	var node:=Node3D.new();scene.add_child(node)
	var seed:=make_owner(false,"single",0,false,false);seed.state.birthRate=1.0;seed.state.velocity=0.0;seed.state.randomVelocity=0.0;seed.state.mass=0.0
	var owner: RefCounted=ClassDB.instantiate("NwnParticleOwner")
	check(not owner.call("dispatch",0,{"state":seed.state,"update":"single","compactRecords":true,"typedEmitter":true,"poseId":node.get_instance_id(),"sourceId":node.get_instance_id()},{}).has("error"),"Lifetime provider owner configures")
	seed.providers.clear()
	var presentation: RefCounted=ClassDB.instantiate("NwnParticlePresentation");var events: Array=[]
	var sentinel:=RefCounted.new();var probe: WeakRef=weakref(sentinel)
	var callbacks: Variant={"sentinel":sentinel,"random":func():
		var commands: Array=[[3,{"id":node.get_instance_id()}],[0,{"id":node.get_instance_id(),"owner":owner,"providers":{}}],[5,{}],[1,{"delta":0.01,"view":view_packet(17000001,false)}],[6,{"ids":[node.get_instance_id()]}],[4,{"id":node.get_instance_id(),"enabled":false}]]
		for command: Array in commands:
			var rejection: Dictionary=presentation.call("dispatch",command[0],command[1]);check(rejection.has("error"),"Current callback cannot delete/reconfigure its Entry");events.append(rejection.get("error"))
		return 1,"cosineDouble":func(angle):return cos(angle)}
	sentinel=null
	check(not presentation.call("dispatch",0,{"id":node.get_instance_id(),"owner":owner,"providers":callbacks,"culling":false,"borrow_providers":borrow}).has("error"),"Entry owns provider Dictionary before either Step path")
	callbacks=null;check(probe.get_ref()!=null,"Entry alone retains provider members after caller releases Dictionary")
	check(presentation.call("dispatch",10,{"id":node.get_instance_id()}).borrow_providers==borrow,"Explicit Entry borrow mode readback is exact")
	var first: Dictionary=presentation.call("dispatch",1,{"delta":0.03125,"view":view_packet(17000002,false)})
	check(not first.has("error") and events.size()>=6,"Arbitrary callback unregister/readd/close/reentry attempts preserve active Entry lifetime")
	var bytes: PackedByteArray=presentation.call("dispatch",2,{}).buffer
	check(not presentation.call("dispatch",3,{"id":node.get_instance_id()}).has("error"),"Native removal proceeds at the next actual frame boundary")
	check(probe.get_ref()==null,"Removal releases final provider members with no lingering Step borrow/copy")
	# A failed provider may have changed particle state before its native error;
	# compare both complete states and error, then retry through a fresh Entry.
	var invalid:={"random":func():return "not a number","cosineDouble":func(angle):return cos(angle)}
	owner=ClassDB.instantiate("NwnParticleOwner")
	check(not owner.call("dispatch",0,{"state":seed.state,"update":"single","compactRecords":true,"typedEmitter":true,"poseId":node.get_instance_id(),"sourceId":node.get_instance_id()},{}).has("error"),"Failure fixture starts with a fresh uninitialized particle owner")
	check(not presentation.call("dispatch",0,{"id":node.get_instance_id(),"owner":owner,"providers":invalid,"culling":false,"borrow_providers":borrow}).has("error"),"Re-add creates a fresh provider binding")
	var failed: Dictionary=presentation.call("dispatch",1,{"delta":0.03125,"view":view_packet(17000003,false)})
	check(failed.has("error"),"Malformed random callback rejects at its original native conversion")
	var bad_state: Dictionary=without_ids(owner.call("dispatch",2,{},{}))
	presentation.call("dispatch",3,{"id":node.get_instance_id()});invalid.clear()
	var replacement:={"random":func():return 1,"cosineDouble":func(angle):return cos(angle)}
	check(not presentation.call("dispatch",0,{"id":node.get_instance_id(),"owner":owner,"providers":replacement,"culling":false,"borrow_providers":borrow}).has("error"),"Boundary replacement discards failed Step services")
	check(not presentation.call("dispatch",1,{"delta":0.03125,"view":view_packet(17000004,false)}).has("error"),"Retry uses the fresh provider binding after failure")
	var final_state: Dictionary=without_ids(owner.call("dispatch",2,{},{}));presentation.call("dispatch",5,{});replacement.clear();presentation=null;node.free()
	return {"events":events,"buffer":bytes,"failure":failed,"failed_state":bad_state,"final_state":final_state}

`;
once('func run() -> void:',helpers+'func run() -> void:');
once('var groups:=[controls_group(scene,false),controls_group(scene,true)]',`var lifetime_a:=provider_lifetime_case(scene,false);var lifetime_b:=provider_lifetime_case(scene,true)
	check(same(lifetime_a,lifetime_b).is_empty(),"Owned/borrowed provider lifetime, exceptions, retries and geometry are exact")
	var groups:=[controls_group(scene,false),controls_group(scene,true)]`);
source=source.replace('Independent intermediate Controls copy elision versus same-DLL ordinary scratch path.','Explicit Entry-owned provider reference versus ordinary Step-owned copy.');
once('finish_experiment(groups)\n\tfor group: Dictionary in groups:',`finish_experiment(groups)
	var provider_coverage: Array=[]
	for group: Dictionary in groups:provider_coverage.append({"borrowed":group.reuse,"replacements":group.provider_replacements,"replacement_invocations":group.provider_consumptions})
	for group: Dictionary in groups:`);
once('"scope":experiment_scope}','"scope":experiment_scope,"provider_mutation_coverage":provider_coverage}');
source=source.replace('# Paired same-DLL owners differ only in whether the intermediate Controls copy\n# exists. Step retains its own original pre-clear copy in both modes.','# Paired same-DLL provider ownership paths. Mutable callback contents remain\n# the same Dictionary; only redundant retained Variant copies are omitted.');
fs.writeFileSync(path.join(project,'tests/native_perf140_particle_provider_reference_test.gd'),source);
