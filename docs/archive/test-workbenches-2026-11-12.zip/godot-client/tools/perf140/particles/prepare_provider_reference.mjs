// Separate hypothesis: eliminate the per-Step copy of the stable Entry-owned
// provider Dictionary. No eligibility, timing, simulation or callback changes.
// Preparation performs a full private copy and must wait for Root's CPU grant.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {fileURLToPath} from 'node:url';
const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..'),label=process.argv[2],base=path.join(project,'.cache/native-140fps/particles-agent'),hash=b=>crypto.createHash('sha256').update(b).digest('hex');if(!/^[a-z0-9-]+$/.test(label??''))throw Error('Fresh provider-reference label required');
const parentFile=path.join(base,'managed-pose-leases-v1/candidate-built-sources.json'),parent=JSON.parse(fs.readFileSync(parentFile)),stage=path.join(base,label);if(fs.existsSync(stage))throw Error('Previous evidence preserved');for(const pin of parent.sourcePins)if(hash(fs.readFileSync(path.join(parent.sourceProject,pin.relative)))!==pin.sha256)throw Error('Frozen parent differs');fs.mkdirSync(stage);
const once=(s,a,b)=>{if(s.split(a).length!==2)throw Error('Provider boundary differs: '+a);return s.replace(a,b);};
for(const variant of ['baseline','candidate']){
 const copy=path.join(stage,variant),pins=[],overrides=variant==='candidate'?parent.overrides.map(row=>({...row})):[];fs.mkdirSync(copy);for(const pin of parent.sourcePins){const bytes=fs.readFileSync(path.join(parent.sourceProject,pin.relative)),destination=path.join(copy,pin.relative);fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,bytes);pins.push({...pin});}
 if(variant==='candidate'){
  const install=(relative,source,reason)=>{const destination=path.join(copy,relative);fs.writeFileSync(destination,source);const sha256=hash(fs.readFileSync(destination));Object.assign(pins.find(row=>row.relative===relative),{sha256,bytes:Buffer.byteLength(source)});let override=overrides.find(row=>row.relative===relative);if(!override){override={relative};overrides.push(override);}Object.assign(override,{sha256,reason});};
  const relative='native/particle_presentation.hpp';let source=fs.readFileSync(path.join(copy,relative),'utf8').replaceAll('\r\n','\n');
  source=once(source,'NativeOwner* owner=nullptr;EngineVar providers;Controls controls;EnginePose pose;','NativeOwner* owner=nullptr;EngineVar providers;const EngineVar* provider_view=nullptr;Controls controls;EnginePose pose;');
  source=once(source,'value.state=&owner->state;value.providers=&providers;','value.state=&owner->state;value.providers=provider_view;');
  const signature='void advance(NativeOwner& value,const Controls& next,const EngineVar& services,const std::optional<NativeOwner::View>& view,size_t& reject_plane){';
  source=once(source,signature,`// Ordinary/temporary services retain the original owned-copy path.
 ${signature}advance_bound(value,next,services,view,reject_plane,false);}
 // Only the embedded Entry call site uses this explicit shorter-lived borrow.
 void advance_entry(NativeOwner& value,const Controls& next,const EngineVar& services,const std::optional<NativeOwner::View>& view,size_t& reject_plane){advance_bound(value,next,services,view,reject_plane,true);}
 void advance_bound(NativeOwner& value,const Controls& next,const EngineVar& services,const std::optional<NativeOwner::View>& view,size_t& reject_plane,bool borrow){`);
  source=once(source,'owner=&value;providers=services;controls=next;','owner=&value;if(borrow)provider_view=&services;else{providers=services;provider_view=&providers;}controls=next;');
  source=once(source,'bool enabled=true,source_animating=false,reuse_controls=true,direct_animating=true;','bool enabled=true,source_animating=false,reuse_controls=true,direct_animating=true,borrow_providers=false;');
  source=once(source,'if(::has(config,"reuse_controls"))entry.reuse_controls=::get(config,"reuse_controls").boolean();','if(::has(config,"reuse_controls"))entry.reuse_controls=::get(config,"reuse_controls").boolean();\n  if(::has(config,"borrow_providers"))entry.borrow_providers=::get(config,"borrow_providers").boolean();');
  source=once(source,'entry.step.advance(*entry.owner,next,entry.providers,camera,reject_plane);','if(entry.borrow_providers)entry.step.advance_entry(*entry.owner,next,entry.providers,camera,reject_plane);else entry.step.advance(*entry.owner,next,entry.providers,camera,reject_plane);');
  source=once(source,'::set(out,"reuse_controls",EngineVar::boolean(e.reuse_controls));','::set(out,"borrow_providers",EngineVar::boolean(e.borrow_providers));::set(out,"reuse_controls",EngineVar::boolean(e.reuse_controls));');
  // services is the current Entry.providers lvalue. Entry outlives its Step,
  // simulation, geometry and errors; control/re-add/close during frame throw.
  // Dictionary mutations remain live aliases exactly as under the old copy.
  install(relative,source,'Explicit Entry-owned provider borrow only; original owned Step.advance fallback remains; same-DLL opt-in mode and detached mode readback');
  const group='systems/native_render/particle_stream_group.gd';source=fs.readFileSync(path.join(copy,group),'utf8').replaceAll('\r\n','\n');source=once(source,'var config:={"id":id,"enabled":emitter.particles_enabled}','var config:={"id":id,"enabled":emitter.particles_enabled,"borrow_providers":OS.get_cmdline_user_args().has("--particle-providers=borrowed") or OS.get_environment("NWN_PARTICLE_PROVIDERS")=="borrowed"}');install(group,source,'Publish explicit provider ownership mode at member registration only; ordinary owned-copy default retained');
 }
 const receipt={...parent,label,variant,sourceProject:copy,sourcePins:pins,overrides,parent:{file:parentFile,sha256:hash(fs.readFileSync(parentFile)),renderer:parent.sourceProject},scope:'Independent provider-reference hypothesis on frozen managed-pose-leases-v1. No scene-snapshot/capability draft, no clock/RNG/eligibility/simulation changes.',sharedNativeBuilds:0};delete receipt.isolatedBuildFinalized;delete receipt.build;delete receipt.prebuildReceipt;fs.writeFileSync(path.join(stage,variant+'-sources.json'),JSON.stringify(receipt,null,2)+'\n');
}
console.log(JSON.stringify({success:true,label,stage,sharedNativeBuilds:0}));
