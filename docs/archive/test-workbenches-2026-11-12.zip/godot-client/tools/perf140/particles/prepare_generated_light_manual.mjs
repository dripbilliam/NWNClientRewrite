// SOURCE ONLY while a live game is open. Do not run this project-copy preparer
// until Root grants a CPU slot. No kernel build is required by this GDS design.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url)),project=path.resolve(here,'../../..'),base=path.join(project,'.cache/native-140fps/particles-agent'),label=process.argv[2],hash=b=>crypto.createHash('sha256').update(b).digest('hex');if(!/^[a-z0-9-]+$/.test(label??''))throw Error('Fresh generated-light label required');
const parentFile=path.join(base,'managed-pose-leases-v1/candidate-built-sources.json'),parent=JSON.parse(fs.readFileSync(parentFile)),stage=path.join(base,label);if(fs.existsSync(stage))throw Error('Previous evidence retained');if(hash(fs.readFileSync(parentFile))!=='20fab7baae2500eb4e45a95e77da68a2f4f913b52fe252666e1f2fa81a1afd14')throw Error('Reviewed parent differs');for(const pin of parent.sourcePins)if(hash(fs.readFileSync(path.join(parent.sourceProject,pin.relative)))!==pin.sha256)throw Error('Frozen parent changed');fs.mkdirSync(stage);
const once=(s,a,b)=>{if(s.split(a).length!==2)throw Error('Generated manual boundary differs: '+a.slice(0,130));return s.replace(a,b);};
for(const variant of ['baseline','candidate']){
 const copy=path.join(stage,variant),pins=[],overrides=variant==='candidate'?parent.overrides.map(row=>({...row})):[];fs.mkdirSync(copy);for(const pin of parent.sourcePins){const bytes=fs.readFileSync(path.join(parent.sourceProject,pin.relative)),dst=path.join(copy,pin.relative);fs.mkdirSync(path.dirname(dst),{recursive:true});fs.writeFileSync(dst,bytes);pins.push({...pin});}
 const load=r=>fs.readFileSync(path.join(copy,r),'utf8').replaceAll('\r\n','\n');const install=(relative,text,reason)=>{const dst=path.join(copy,relative);fs.mkdirSync(path.dirname(dst),{recursive:true});fs.writeFileSync(dst,text);const record={relative,sha256:hash(fs.readFileSync(dst)),bytes:Buffer.byteLength(text)},pin=pins.find(row=>row.relative===relative);if(pin)Object.assign(pin,record);else pins.push(record);let override=overrides.find(row=>row.relative===relative);if(!override){override={relative};overrides.push(override);}Object.assign(override,{sha256:record.sha256,reason});};
 if(variant==='candidate'){
  install('systems/native_render/generated_light_manual_publication.gd',fs.readFileSync(path.join(here,'generated_light_manual_publication.gd'),'utf8'),'Explicit canonical fx_placeable01 manual publication ownership; identity-only, two original output warmup, no clock/follower skip');
  let s=load('systems/model_rigs.gd');
  s=once(s,'func configure(value, pivots: Dictionary, metadata: Dictionary) -> void:\n','func configure(value, pivots: Dictionary, metadata: Dictionary) -> void:\n\t_revoke_generated_manual_all("configure")\n');
  s=once(s,'func forget_entity(id: int) -> void:\n','func forget_entity(id: int) -> void:\n\trevoke_generated_manual(id,"forget")\n');
  s=once(s,'var entry: Dictionary = entities[id]\n\tfor attachment in entry.attachments:','var entry: Dictionary = entities[id]\n\tif not entry.attachments.is_empty():revoke_generated_manual(id,"attachment_publication")\n\tfor attachment in entry.attachments:');
  s=once(s,'func set_manual_pose(id: int, node: Node3D, position: Vector3, quaternion: Quaternion) -> bool:\n','func set_manual_pose(id: int, node: Node3D, position: Vector3, quaternion: Quaternion) -> bool:\n\trevoke_generated_manual(id,"manual_command")\n');
  s=once(s,'func play_native(id: int, model_index: int, clip: Variant, speed: float, flags: int, time: float) -> bool:\n','func play_native(id: int, model_index: int, clip: Variant, speed: float, flags: int, time: float) -> bool:\n\trevoke_generated_manual(id,"native_playback")\n');
  s=once(s,'func set_model_colour_scope(id: int,model_index: int,scope: int,rgb: Variant) -> bool:\n','func set_model_colour_scope(id: int,model_index: int,scope: int,rgb: Variant) -> bool:\n\trevoke_generated_manual(id,"native_colour_scope")\n');
  s=once(s,'func set_playback(id: int, animation: int, speed: float = 1.0, loop_override: Variant = null, restart: bool = false, side: int = -1) -> void:\n','func set_playback(id: int, animation: int, speed: float = 1.0, loop_override: Variant = null, restart: bool = false, side: int = -1) -> void:\n\trevoke_generated_manual(id,"authored_playback")\n');
  s=once(s,'func adopt_entities(source, ids: Array) -> void:\n\tfor id in ids:','func adopt_entities(source, ids: Array) -> void:\n\tfor id in ids:\n\t\trevoke_generated_manual(int(id),"adoption_target")\n\t\tif source.has_method("revoke_generated_manual"):source.revoke_generated_manual(int(id),"adoption_source")');
  s=once(s,'func _exit_tree() -> void:\n','func _exit_tree() -> void:\n\t_revoke_generated_manual_all("exit_tree")\n');
  s=once(s,'\t\tfor index in entry.manual_poses:\n\t\t\tvar manual: Dictionary = entry.manual_poses[index]','\t\tvar generated_manual: RefCounted=entry.get("generated_manual_publication")\n\t\tfor index in entry.manual_poses:\n\t\t\tif generated_manual!=null and generated_manual.omit(self,entry,int(index)):continue\n\t\t\tvar manual: Dictionary = entry.manual_poses[index]');
  s=once(s,'\t\t\tentry.nodes[index].scale = manual.scale\n','\t\t\tentry.nodes[index].scale = manual.scale\n\t\t\tif generated_manual!=null:generated_manual.published(self,entry,int(index))\n');
  const methods=`
func revoke_generated_manual(id: int,why: String) -> void:
	if not entities.has(id):return
	var entry: Dictionary=entities[id]
	var token: RefCounted=entry.get("generated_manual_publication")
	# No token has observed this record yet. Cold enrollment reads current
	# authored state; ordinary owners need no revision dictionary publication.
	if token==null:return
	entry.generated_manual_revision=int(entry.get("generated_manual_revision",0))+1
	token.revoke(why)
func _revoke_generated_manual_all(why: String) -> void:
	for id in entities:revoke_generated_manual(int(id),why)
func enroll_generated_manual(id: int,owner: Node3D,publisher: Node) -> bool:
	if not entities.has(id):return false
	var entry: Dictionary=entities[id]
	var old: RefCounted=entry.get("generated_manual_publication")
	if old!=null and old.same_owner(self,entry,owner,publisher):return true
	const Publication=preload("res://systems/native_render/generated_light_manual_publication.gd")
	if not Publication.configured():return false
	var token: RefCounted=Publication.create(self,entry,id,owner,publisher)
	entry.generated_manual_publication=token
	return bool(token.active)
func generated_manual_snapshot() -> Dictionary:
	var rows: Array=[]
	for id in entities:
		var token: RefCounted=entities[id].get("generated_manual_publication")
		if token==null:continue
		var row: Dictionary=token.snapshot();row.id=int(id);rows.append(row)
	return {"mode":"generated_identity_manual_publication","entries":rows}
`;
  s=once(s,'func _vec(value: Array) -> Vector3:',methods+'\nfunc _vec(value: Array) -> Vector3:');
  install('systems/model_rigs.gd',s,'Keep immediate setters/full first publications and all clocks; narrowly omit owned generated-light manual repeats after proof; revoke before canonical mutations');
  s=load('systems/native_render/effect_model.gd');
  s=once(s,'var p:=node.global_position; node.position=Vector3.ZERO; node.quaternion=Quaternion.IDENTITY','rigs.revoke_generated_manual(0,"temporary_orientation_reset")\n\tvar p:=node.global_position; node.position=Vector3.ZERO; node.quaternion=Quaternion.IDENTITY');
  s=once(s,'anchor_node=target; anchor_flags=flags; anchor_scale=scale; anchor_inherit_scale=inherit_scale','if anchor_node!=target or anchor_flags!=flags or anchor_inherit_scale!=inherit_scale:rigs.revoke_generated_manual(0,"follower_attachment_change")\n\tanchor_node=target; anchor_flags=flags; anchor_scale=scale; anchor_inherit_scale=inherit_scale');
  s=once(s,'func detach() -> void:\n\tanchor_node=null','func detach() -> void:\n\tif anchor_node!=null and is_instance_valid(rigs):rigs.revoke_generated_manual(0,"follower_detach")\n\tanchor_node=null');
  s=once(s,'func retire() -> void:\n','func retire() -> void:\n\tif is_instance_valid(rigs):rigs.revoke_generated_manual(0,"effect_retire")\n');
  install('systems/native_render/effect_model.gd',s,'Revoke before actual follower attachment, temporary local orientation and lifetime changes; follower processing and writes unchanged');
  s=load('systems/native_render/placeable_lights.gd');
  s=once(s,'\treturn true\nfunc erase(id: int) -> void:','\t# Only this canonical generated-light owner may request the narrow lease.\n\tmodel.rigs.enroll_generated_manual(0,model,self)\n\treturn true\nfunc erase(id: int) -> void:');
  install('systems/native_render/placeable_lights.gd',s,'Explicit enrollment after generated-light local/manual and ancestor placement are finalized; same plan keeps existing grant');
 }
 const receipt={...parent,label,variant,sourceProject:copy,sourcePins:pins,overrides,parent:{file:parentFile,sha256:hash(fs.readFileSync(parentFile)),renderer:parent.sourceProject},scope:'Separate source-only generated fx_placeable01 manual-publication prototype; identity-only enrollment and exact owned-writer revocation, two original warmup updates; ordinary default, clocks/following untouched. No typed-input/eligibility bundle.',sharedNativeBuilds:0};delete receipt.isolatedBuildFinalized;delete receipt.build;delete receipt.prebuildReceipt;fs.writeFileSync(path.join(stage,variant+'-sources.json'),JSON.stringify(receipt,null,2)+'\n');
}
console.log(JSON.stringify({success:true,label,stage,sharedNativeBuilds:0,requiresNativeBuild:false}));
