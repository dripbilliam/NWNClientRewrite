[CmdletBinding()]
param([Parameter(Mandatory)][ValidatePattern('^[a-z0-9-]+$')][string]$Label,[Parameter(Mandatory)][ValidatePattern('^[a-z0-9-]+$')][string]$Run)
$ErrorActionPreference='Stop'
$project=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$candidate=Join-Path $project ('.cache/native-140fps/particles-agent/'+$Label+'/candidate')
$stage=Join-Path $project ('.cache/native-140fps/particles-agent/checks/'+$Run)
if(Test-Path -LiteralPath $stage){throw 'Previous pure evidence preserved'}
New-Item -ItemType Directory -Path $stage|Out-Null
$source=Join-Path $project 'tests/native_perf140_particle_managed_lease_policy_test.cpp'
$policy=Join-Path $candidate 'native/experimental/managed_pose_lease_policy.hpp'
$header=Join-Path $candidate 'native/experimental/frame_pose_cache.hpp'
if((Get-FileHash -LiteralPath $policy).Hash-ne(Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'managed_pose_lease_policy.hpp')).Hash){throw 'Policy source differs from frozen candidate'}
$vswhere=Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio/Installer/vswhere.exe'
$vs=@(& $vswhere -all -prerelease -products '*' -property installationPath)|Where-Object{Test-Path -LiteralPath (Join-Path $_ 'VC/Auxiliary/Build/Microsoft.VCToolsVersion.default.txt')}|Select-Object -First 1
$version=(Get-Content -LiteralPath (Join-Path $vs 'VC/Auxiliary/Build/Microsoft.VCToolsVersion.default.txt') -Raw).Trim()
$tools=Join-Path $vs ('VC/Tools/MSVC/'+$version);$compiler=Join-Path $tools 'bin/Hostx64/x64/cl.exe'
$sdk=Join-Path ${env:ProgramFiles(x86)} 'Windows Kits/10'
$include=Get-ChildItem -LiteralPath (Join-Path $sdk 'Include') -Directory|Sort-Object Name -Descending|Where-Object{Test-Path -LiteralPath (Join-Path $_.FullName 'um/Windows.h')}|Select-Object -First 1
$oldInclude=$env:INCLUDE;$oldLib=$env:LIB
try{
 $env:INCLUDE=((Join-Path $tools 'include'),(Join-Path $include.FullName 'ucrt'),(Join-Path $include.FullName 'shared'),(Join-Path $include.FullName 'um'))-join';'
 $env:LIB=((Join-Path $tools 'lib/x64'),(Join-Path $sdk ('Lib/'+$include.Name+'/ucrt/x64')),(Join-Path $sdk ('Lib/'+$include.Name+'/um/x64')))-join';'
 $binary=Join-Path $stage 'managed-policy-test.exe'
 $arguments=@('/nologo','/O2','/fp:strict','/EHsc','/W4','/WX','/std:c++17','/MD',('/I'+(Join-Path $candidate 'native/experimental')),('/Fo'+(Join-Path $stage 'managed-policy-test.obj')),('/Fe'+$binary),$source,'/link','/INCREMENTAL:NO')
 $log=@(& $compiler @arguments 2>&1);$compileExit=$LASTEXITCODE
 [IO.File]::WriteAllText((Join-Path $stage 'compile.log'),($log-join[Environment]::NewLine))
 if($compileExit-ne0){throw 'Private managed policy compile failed'}
 $result=@(& $binary);$testExit=$LASTEXITCODE
 [IO.File]::WriteAllText((Join-Path $stage 'result.json'),($result-join[Environment]::NewLine))
 if($testExit-ne0){throw 'Private managed policy checks failed'}
 $proof=@{success=$true;test=($result-join[Environment]::NewLine)|ConvertFrom-Json;sourceSha256=(Get-FileHash -LiteralPath $source).Hash.ToLowerInvariant();policySha256=(Get-FileHash -LiteralPath $policy).Hash.ToLowerInvariant();frameHeaderSha256=(Get-FileHash -LiteralPath $header).Hash.ToLowerInvariant();binarySha256=(Get-FileHash -LiteralPath $binary).Hash.ToLowerInvariant();engineStarts=0;sharedBuilds=0;gpu=$false;serverConnections=0}
 [IO.File]::WriteAllText((Join-Path $stage 'checks.json'),($proof|ConvertTo-Json -Depth 5));$proof|ConvertTo-Json -Compress
}finally{$env:INCLUDE=$oldInclude;$env:LIB=$oldLib}
