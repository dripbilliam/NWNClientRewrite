// Dedicated fixture reuses the established scheduled oracle's source helpers.
// GDScript could not resolve the extra anonymous derived SceneTree class; keep
// one test class without modifying the established fixture or native sources.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {fileURLToPath} from 'node:url';
const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..'),destination=path.join(project,'tests/native_perf140_particle_endpoint_slot_test.gd');
const base=fs.readFileSync(path.join(project,'tests/native_perf140_particle_managed_lease_test.gd'));
if(crypto.createHash('sha256').update(base).digest('hex')!=='92c6c76a6399f846928c7b8714db3088c1e702ebc02abd2d0c368c0464bb30ad')throw Error('Reviewed fixture source differs');
const current=fs.readFileSync(destination,'utf8').replaceAll('\r\n','\n');
if(!current.startsWith('extends "res://tests/native_perf140_particle_managed_lease_test.gd"'))throw Error('Only initial private derived fixture may be converted');
const compare=current.slice(current.indexOf('func compare('));
let output=base.toString('utf8').replaceAll('\r\n','\n');
output=output.replace('func setup(scene: Node3D,managed: bool) -> Dictionary:\n','func setup(scene: Node3D,indexed: bool) -> Dictionary:\n\tvar managed:=true\n');
output=output.replace('"managed":managed,"owners":[]','"managed":managed,"indexed":indexed,"owners":[]');
const begin=output.indexOf('func compare('),end=output.indexOf('func close_rows(',begin);
if(begin<0||end<begin)throw Error('Reviewed compare boundary differs');output=output.slice(0,begin)+compare+'\n'+output.slice(end);
output=output.replace('"scope":"Actual canonical Placement,','"scope":"Same-DLL ordinary/indexed row storage with actual canonical Placement,');
fs.writeFileSync(destination,output);console.log(JSON.stringify({success:true,file:destination,sharedEdits:0,nativeChanges:0}));
