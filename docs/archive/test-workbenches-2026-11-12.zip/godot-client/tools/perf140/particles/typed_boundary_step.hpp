// Private source template. Included in particle_presentation's namespace by the
// guarded preparer; no standalone compile or shared-source promotion.
struct EntryConfig {
 int64_t source_flags=-1;bool culling=true,draw_enabled=true,original_admission=false;
 uint64_t wind_token=0;float explicit_radius=-1;
};
struct Controls:EntryConfig {
 std::string clip;float time=0,delta=0;bool detonate=false,profile=false,animate=true;
 uint64_t terrain_index=0,static_index=0;bool direct_scene=false;EngineVar patch;
};
struct FrameInput {
 std::optional<NativeOwner::View> camera;float delta=0;bool profile=false,direct_scene=false;
 uint64_t terrain_index=0,static_index=0,generation=0;bool active=false;
};
struct PendingCommands {std::optional<EngineVar> patch;bool detonate=false;};
struct StepResult {
 EnginePose pose;bool prepared=false,culled=false,checked=false,animation_invoked=false,updated=false;float radius=0;
 uint64_t direct_queries=0,direct_hits=0,direct_random=0,opaque_random=0;
 double controls_ms=0,pose_ms=0,admission_ms=0,simulation_ms=0,geometry_ms=0,collision_ms=0;
};
struct Step:StepResult {
 // Only the ordinary route writes these owned snapshots. In particular,
 // standalone/temporary providers never select the Entry-only borrow overload.
 NativeOwner* owner=nullptr;EngineVar providers;Controls controls;FrameInput owned_frame;
 struct ExecutionInput {
  const EntryConfig* config=nullptr;const FrameInput* frame=nullptr;const EngineVar* providers=nullptr;
  EngineVar* patch=nullptr;const std::string* clip=nullptr;
  uint64_t generation=0;float time=0;bool animate=true,detonate=false;
 } input;
 bool typed=false;std::string dynamic_clip;const std::string* static_clip=nullptr;
 std::optional<EngineVar> retained_patch;
 const std::string& clip_name()const{return typed?(static_clip?*static_clip:dynamic_clip):controls.clip;}
 const FrameInput& frame()const{
  if(!input.frame||!input.frame->active||input.generation!=input.frame->generation)throw std::runtime_error("Native typed presentation input outlived its frame");
  return *input.frame;
 }
 void context(resident::Context& value){
  const auto& current=frame();const auto& config=*input.config;
  value.state=&owner->state;value.providers=input.providers;value.allocations=&owner->allocations;value.camera=current.camera?&current.camera->position:nullptr;value.native_pose=&pose;
  value.profile=current.profile;value.missing_chunks=&owner->missing_chunks;value.wind_token=(owner->compact_state.flags&4)?config.wind_token:0;value.direct_scene=current.direct_scene;value.terrain_index=current.terrain_index;value.static_index=current.static_index;
 }
 void validate(NativeOwner& value){
  if(!value.configured||!value.compact_records||!value.typed_frame||!value.pose_id)throw std::runtime_error("Native presentation requires a configured typed owner with native poses");
 }
 // Retained owned fallback, including for a temporary providers expression.
 void advance(NativeOwner& value,const Controls& next,const EngineVar& services,const std::optional<NativeOwner::View>& view,size_t& reject_plane){
  validate(value);owner=&value;providers=services;controls=next;owned_frame.camera=view;
  owned_frame.delta=controls.delta;owned_frame.profile=controls.profile;owned_frame.direct_scene=controls.direct_scene;owned_frame.terrain_index=controls.terrain_index;owned_frame.static_index=controls.static_index;owned_frame.active=true;++owned_frame.generation;
  typed=false;retained_patch.reset();static_clip=nullptr;
  input={&controls,&owned_frame,&providers,controls.patch.nil()?nullptr:&controls.patch,&controls.clip,owned_frame.generation,controls.time,controls.animate,controls.detonate};
  execute(reject_plane);
 }
 // EntryConfig, providers and the shared frame outlive both synchronous passes.
 // pending remains observable until this complete call succeeds. Its retained
 // snapshot releases at the next Step setup, matching ordinary Controls.
 void advance_entry(NativeOwner& value,const EntryConfig& config,const PendingCommands& pending,const EngineVar& services,const FrameInput& current,const std::string& selected_clip,bool selected_static,float time,bool animate,size_t& reject_plane){
  validate(value);owner=&value;typed=true;
  if(selected_static)static_clip=&selected_clip;else{static_clip=nullptr;dynamic_clip=selected_clip;}
  if(pending.patch)retained_patch=*pending.patch;else retained_patch.reset();
  input={&config,&current,&services,retained_patch?&*retained_patch:nullptr,&clip_name(),current.generation,time,animate,pending.detonate};
  execute(reject_plane);
 }
 void execute(size_t& reject_plane){
  const auto& current=frame();const auto& config=*input.config;const auto& camera=current.camera;
  prepared=false;culled=false;checked=false;animation_invoked=false;updated=false;radius=0;direct_queries=direct_hits=direct_random=opaque_random=0;controls_ms=pose_ms=admission_ms=simulation_ms=geometry_ms=collision_ms=0;
  resident::FieldKeyScope fields(owner->field_keys);auto phase=current.profile?Clock::now():Clock::time_point{};
  const auto finish=[&](double& duration){if(current.profile){const auto now=Clock::now();duration=std::chrono::duration<double,std::milli>(now-phase).count();phase=now;}};
  owner->sample(*input.clip,input.time);finish(controls_ms);
  if(input.patch){
   auto names=::method(*input.patch,"keys");for(int64_t n=0;n<::size(names);++n){const auto name=engine_string(::at(names,n));resident::set(owner->state,name.c_str(),resident::Var(::get(*input.patch,name.c_str())));resident::compact_particle::apply_emitter_field(owner->compact_state,owner->state,{name.c_str(),resident::field_index(name.c_str())});}
  }
  if(owner->use_parameters&&resident::has(owner->parameters,"detonate")&&resident::i(owner->parameters,"detonate")!=0){resident::set(owner->state,particle_field::detonate108,resident::get(owner->parameters,"detonate"));owner->compact_state.detonate108=static_cast<int32_t>(resident::i(owner->parameters,"detonate"));resident::set_int(owner->parameters,"detonate",0);}
  if(input.detonate){resident::set_int(owner->state,particle_field::detonate108,1);owner->compact_state.detonate108=1;}
  pose=owner->read_pose();const auto source=owner->source_id==owner->pose_id?pose:owner->read_pose(true);
  auto& emitter=owner->compact_state;if(!emitter.source.present)throw std::runtime_error("Native owner record required");
  emitter.source.position=source.position;emitter.source.quaternion=source.quaternion;emitter.source.adjustedScale=source.scale;owner->typed_source_pose=true;
  if(std::abs(emitter.birthRate)>32768||owner->allocations>32768)throw std::runtime_error("Native particle instance exceeds explicit allocation limit");finish(pose_ms);
  resident::Context ctx;context(ctx);resident::ContextScope scope(ctx);
  if(emitter.flags&4){if(!config.wind_token)throw std::runtime_error("Native scene wind token is absent");scene_wind::owner(config.wind_token);}
  const auto* wind=ctx.wind_token?&scene_wind::owner(ctx.wind_token):nullptr;
  const bool known_wind=!wind||wind->points.empty();checked=known_wind&&!emitter.chunk&&camera&&config.culling&&config.source_flags>=0;
  if(checked){
   if(config.original_admission){
    radius=config.explicit_radius>=0?config.explicit_radius:owner->radius(config.source_flags,wind?wind->wind:V3{})*std::max(1.0f,pose.maximum_scale);
    if(std::isfinite(radius)&&radius>=0){const V3 point{pose.position[0],pose.position[2],-pose.position[1]};for(size_t n=0;n<6;++n){const auto index=(reject_plane+n)%6,at=index*4;const auto& p=camera->planes;const float distance=((point[0]*p[at]-p[at+3])+point[1]*p[at+1])+point[2]*p[at+2];if(distance-radius>0){culled=true;reject_plane=index;break;}}}
   }else culled=owner->culled(*camera,pose.position,config.source_flags,std::max(1.0f,pose.maximum_scale),radius,wind?wind->wind:V3{});
  }
  finish(admission_ms);
  if(!culled&&input.animate){
   animation_invoked=true;updated=!((emitter.source.present&&emitter.source.instance.present&&1>emitter.source.instance.fade)||(emitter.instance.present&&1>emitter.instance.fade));
   resident::compact_particle::Bridge bridge(owner->state,owner->compact_extras);
   resident::compact_particle::animate(emitter,owner->compact_pool,current.delta,pose.position,pose.quaternion,owner->kind,bridge);owner->typed_simulated=true;
  }
  finish(simulation_ms);direct_queries=ctx.direct_queries;direct_hits=ctx.direct_hits;direct_random=ctx.direct_random;opaque_random=ctx.opaque_random;collision_ms=ctx.collision_ms;prepared=true;
 }
 int64_t vertices()const{
  const auto& emitter=owner->compact_state;if(!prepared||culled||emitter.chunk||!input.config->draw_enabled)return 0;
  const auto count=static_cast<int64_t>(owner->compact_pool.active.size())-(emitter.renderMode1a8==3?1:0);
  const bool faded=(emitter.source.present&&emitter.source.instance.present&&1>emitter.source.instance.fade)||(emitter.instance.present&&1>emitter.instance.fade);
  if(count<1||emitter.lifeExp==0||faded)return 0;if(count>32768)throw std::runtime_error("Native compact vertex allocation limit");return count*6;
 }
 void geometry(::ParticleStreams::DirectRange& target,const V3& tint=V3{1,1,1}){
  if(!prepared||culled)throw std::runtime_error("Native presentation geometry requires an admitted update");
  const auto& current=frame();const auto& camera=current.camera;
  resident::FieldKeyScope fields(owner->field_keys);resident::Context ctx;context(ctx);resident::ContextScope scope(ctx);const auto began=current.profile?Clock::now():Clock::time_point{};
  if(owner->compact_state.chunk){resident::compact_particle::Bridge bridge(owner->state,owner->compact_extras);resident::compact_particle::render_chunks(owner->compact_state,owner->compact_pool,bridge);}
  else{
   const resident::compact_particle::Draw draw{owner->compact_state.source.adjustedScale,camera?camera->camera:Q4{1,0,0,0},tint};
   ::ParticleStreams::DirectScope range(owner->staging,target);resident::compact_particle::build(owner->compact_state,owner->compact_pool,draw,&owner->staging,0);
  }
  if(current.profile)geometry_ms=std::chrono::duration<double,std::milli>(Clock::now()-began).count();
 }
};
