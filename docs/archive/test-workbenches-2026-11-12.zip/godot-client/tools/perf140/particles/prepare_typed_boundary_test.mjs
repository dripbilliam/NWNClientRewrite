import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..');
let source=fs.readFileSync(path.join(project,'tests/native_perf140_particle_provider_reference_test.gd'),'utf8').replaceAll('\r\n','\n');
const once=(a,b)=>{if(source.split(a).length!==2)throw Error('Typed input fixture boundary differs: '+a.slice(0,100));source=source.replace(a,b);};
source=source.replaceAll('borrow_providers','typed_boundary');
once('func check_frame_output(_group: Dictionary,_output: Dictionary) -> void:pass',`func check_frame_output(group: Dictionary,_output: Dictionary) -> void:
	var route: Dictionary=group.presentation.call("dispatch",16,{})
	check(not route.has("error") and route.frame_active==false,"Shared FrameInput invalidates on both success and failure")
	check((route.selected>0)==group.reuse,"One-shot route census proves ordinary or typed mode")
	if group.reuse:check(route.advanced==route.entry_provider_borrows,"Every typed step borrows only its stable Entry provider record")`);
const helpers=String.raw`
func command_snapshot_case(scene: Node3D,typed: bool) -> Dictionary:
	var node:=Node3D.new();scene.add_child(node)
	var seed:=make_owner(false,"single",0,false,false);seed.state.birthRate=0.0
	var owner: RefCounted=ClassDB.instantiate("NwnParticleOwner")
	check(not owner.call("dispatch",0,{"state":seed.state,"update":"single","compactRecords":true,"typedEmitter":true,"poseId":node.get_instance_id(),"sourceId":node.get_instance_id()},{}).has("error"),"Command-lifetime owner configures")
	seed.providers.clear()
	var presentation: RefCounted=ClassDB.instantiate("NwnParticlePresentation")
	check(not presentation.call("dispatch",0,{"id":node.get_instance_id(),"owner":owner,"providers":{"random":func():return 1,"cosineDouble":func(angle):return cos(angle)},"culling":false,"typed_boundary":typed}).has("error"),"Typed route is explicit at registration")
	check(presentation.call("dispatch",4,{"id":node.get_instance_id(),"typed_boundary":not typed}).has("error"),"Route change rejects before pending/control mutation")
	check(not presentation.call("dispatch",4,{"id":node.get_instance_id(),"typed_boundary":typed}).has("error"),"Repeating the selected route is accepted")
	var sentinel:=RefCounted.new();var probe: WeakRef=weakref(sentinel)
	# Ordered first field fails before the sentinel can enter the resident state.
	# This isolates Step's retained snapshot from pending and simulated storage.
	var patch:={"birthRate":"invalid numeric field","private_lifetime_probe":sentinel}
	check(not presentation.call("dispatch",4,{"id":node.get_instance_id(),"patch":patch,"detonate":true}).has("error"),"Pending command duplicates at the existing boundary")
	patch.clear();sentinel=null
	check(probe.get_ref()!=null,"Pending command retains embedded resources after caller releases them")
	var failed: Dictionary=presentation.call("dispatch",1,{"delta":0.01,"view":view_packet(19000001,false)})
	check(failed.has("error"),"Malformed patch fails only at original application phase")
	var pending: Dictionary=presentation.call("dispatch",10,{"id":node.get_instance_id()})
	check(pending.pending_patch and pending.pending_detonate,"Failed Step does not consume either pending command")
	check(not presentation.call("dispatch",4,{"id":node.get_instance_id(),"patch":{"birthRate":0.0}}).has("error"),"Boundary patch replacement prepares retry")
	check(probe.get_ref()!=null,"Previous Step snapshot outlives pending replacement")
	var recovered: Dictionary=presentation.call("dispatch",1,{"delta":0.01,"view":view_packet(19000002,false)})
	check(not recovered.has("error"),"Retry applies replacement patch and preserves pending detonation")
	check(probe.get_ref()==null,"Old patch snapshot releases at the next Step setup, never earlier")
	var consumed: Dictionary=presentation.call("dispatch",10,{"id":node.get_instance_id()})
	check(not consumed.pending_patch and not consumed.pending_detonate,"Success consumes both pending commands")
	var census: Dictionary=presentation.call("dispatch",13,{})
	check(census.emitters.size()==1 and census.emitters[0].last_step_clip=="","Cold last clip survives shared-input retirement")
	var final: Dictionary=without_ids(owner.call("dispatch",2,{},{}))
	presentation.call("dispatch",3,{"id":node.get_instance_id()})
	check(not presentation.call("dispatch",0,{"id":node.get_instance_id(),"owner":owner,"providers":{},"typed_boundary":not typed}).has("error"),"Same-ID re-add owns an independent selected lifetime")
	presentation.call("dispatch",5,{});presentation=null;node.free()
	return {"failed":failed,"recovered":recovered,"state":final}

func readiness_case(scene: Node3D,typed: bool) -> Dictionary:
	var source:=Node3D.new();scene.add_child(source);var node:=Node3D.new();source.add_child(node)
	var seed:=make_owner(false,"fountain",0,false,false);seed.state.birthRate=0.0
	var owner: RefCounted=ClassDB.instantiate("NwnParticleOwner")
	check(not owner.call("dispatch",0,{"state":seed.state,"update":"fountain","compactRecords":true,"typedEmitter":true,"poseId":node.get_instance_id(),"sourceId":source.get_instance_id()},{}).has("error"),"Readiness owner configures")
	seed.providers.clear()
	var presentation: RefCounted=ClassDB.instantiate("NwnParticlePresentation");var observations: Array=[]
	var gate:={"probes":0,"common":{}}
	var ready:=func():
		gate.probes+=1;gate.common.animating=false;source.position=Vector3(gate.probes,2.0,3.0)
		observations.append(["ready",gate.probes,presentation.call("dispatch",10,{"id":node.get_instance_id()}).elapsed])
		return gate.probes>1
	check(not presentation.call("dispatch",0,{"id":node.get_instance_id(),"owner":owner,"providers":{"random":func():return 1,"cosineDouble":func(angle):return cos(angle)},"culling":false,"ready":ready,"typed_boundary":typed}).has("error"),"Readiness binding compiles only absence, not a guessed callback value")
	for index in 4:
		gate.common={"delta":0.125,"view":view_packet(19000100+index,false),"animating":true}
		var output: Dictionary=presentation.call("dispatch",1,gate.common)
		check(not output.has("error"),"Readiness frame succeeds "+str(index))
		var info: Dictionary=presentation.call("dispatch",10,{"id":node.get_instance_id()})
		observations.append(["end",index,info.elapsed,info.frames,gate.common.animating])
	check(gate.probes==2,"True readiness retires its callback exactly once")
	check(observations[1][2]==0.0,"Readiness false does not advance elapsed time")
	var state: Dictionary=without_ids(owner.call("dispatch",2,{},{}));var bytes: PackedByteArray=presentation.call("dispatch",2,{}).buffer
	presentation.call("dispatch",5,{});ready=Callable();presentation=null;gate.clear();source.free()
	return {"observations":observations,"state":state,"buffer":bytes}

`;
once('func run() -> void:',helpers+'func run() -> void:');
once('var lifetime_a:=provider_lifetime_case(scene,false);',`var command_a:=command_snapshot_case(scene,false);var command_b:=command_snapshot_case(scene,true)
	check(same(command_a,command_b).is_empty(),"Typed command lifetime/failure/retry/re-add matches ordinary output")
	var ready_a:=readiness_case(scene,false);var ready_b:=readiness_case(scene,true)
	check(same(ready_a,ready_b).is_empty(),"Typed readiness mutation/clock/geometry is exact")
	var lifetime_a:=provider_lifetime_case(scene,false);`);
source=source.replace('Explicit Entry-owned provider reference versus ordinary Step-owned copy.','One persistent typed presentation boundary versus the same-DLL original owned fallback.');
fs.writeFileSync(path.join(project,'tests/native_perf140_particle_typed_boundary_test.gd'),source);

// Installed source fields/TRS/controller data stays real, with deterministic
// external chunk services. This compares only input ownership, not RNG modes.
source=fs.readFileSync(path.join(project,'tests/native_perf140_particle_native_random_models_test.gd'),'utf8').replaceAll('\r\n','\n');
const change=(a,b)=>{if(source.split(a).length!==2)throw Error('Typed installed fixture differs: '+a.slice(0,100));source=source.replace(a,b);};
change('for native_rng in [false,true]:','for typed in [false,true]:');
change('var rng: RefCounted=ClassDB.instantiate("NwnVisualRandom") if native_rng else Random.new();rng.seed_value(8221)','var rng: RefCounted=ClassDB.instantiate("NwnVisualRandom");rng.seed_value(8221)');
change('"host":host,"rng":rng','"host":host,"typed":typed,"rng":rng');
change('"wind_token":row.wind.token,"culling":true','"wind_token":row.wind.token,"culling":true,"typed_boundary":row.typed');
change('check(rows[1].rng.snapshot().direct_hits>0,"Actual installed models use guarded native draws")',`var route_a: Dictionary=rows[0].presentation.call("dispatch",16,{})
	var route_b: Dictionary=rows[1].presentation.call("dispatch",16,{})
	check(route_a.selected==0 and route_b.selected==total_emitters and route_b.shared_frame_borrows==total_emitters,"Every installed model actually uses the selected input route")
	check(rows[1].rng.snapshot().direct_hits>0,"Both installed model routes retain guarded native draws")`);
change('Installed MDL fields/TRS/controller pools with exact native-vs-GD shared visual RNG state and CPU geometry;','Installed MDL fields/TRS/controller pools with exact ordinary-vs-typed presentation boundary, shared visual RNG state and CPU geometry;');
fs.writeFileSync(path.join(project,'tests/native_perf140_particle_typed_boundary_models_test.gd'),source);

source=fs.readFileSync(path.join(project,'tests/native_perf140_particle_clock_test.gd'),'utf8').replaceAll('\r\n','\n');
change('"id":node.get_instance_id(),"owner":owner,"providers":providers,"clock":slot.sample if typed else producer.sample','"id":node.get_instance_id(),"owner":owner,"providers":providers,"typed_boundary":true,"clock":slot.sample if typed else producer.sample');
change('for row: Dictionary in rows:row.presentation.call("dispatch",5,{})',`for row: Dictionary in rows:
		check(row.presentation.call("dispatch",16,{}).selected==1,"Native/fallback/custom clock suite actually uses typed input storage")
	for row: Dictionary in rows:row.presentation.call("dispatch",5,{})`);
change('Exact native published clock vs original callback:','Typed boundary exact native published clock vs original callback:');
fs.writeFileSync(path.join(project,'tests/native_perf140_particle_typed_boundary_clock_test.gd'),source);

const checker=path.join(project,'tools/perf140/particles/check.mjs');let content=fs.readFileSync(checker,'utf8');const name="'native_perf140_particle_typed_boundary_models_test'";
if(!content.includes(name)){const before="'native_perf140_particle_managed_eligibility_models_test'].includes(script)";if(content.split(before).length!==2)throw Error('Installed selector differs');content=content.replace(before,"'native_perf140_particle_managed_eligibility_models_test',"+name+"].includes(script)");fs.writeFileSync(checker,content);}
