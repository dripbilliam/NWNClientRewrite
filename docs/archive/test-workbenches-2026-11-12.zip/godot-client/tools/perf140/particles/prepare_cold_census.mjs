// Explicit, cold diagnostic only. No per-frame sampling/export hook is added.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {fileURLToPath} from 'node:url';
const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..'),[label,parentLabel='combined-particle-census-v1']=process.argv.slice(2),base=path.join(project,'.cache/native-140fps/particles-agent'),hash=b=>crypto.createHash('sha256').update(b).digest('hex');if(![label,parentLabel].every(v=>/^[a-z0-9-]+$/.test(v??'')))throw Error('Fresh cold-census label and frozen parent required');
const stage=path.join(base,label),parentFile=path.join(base,parentLabel,'candidate-built-sources.json'),parent=JSON.parse(fs.readFileSync(parentFile)),baselineFile=path.join(base,parentLabel,'baseline-sources.json'),baseline=JSON.parse(fs.readFileSync(baselineFile));if(fs.existsSync(stage))throw Error('Existing cold census preserved');for(const receipt of [parent,baseline])for(const pin of receipt.sourcePins)if(hash(fs.readFileSync(path.join(receipt.sourceProject,pin.relative)))!==pin.sha256)throw Error('Frozen source differs');fs.mkdirSync(stage);
const once=(s,a,b)=>{if(s.split(a).length!==2)throw Error('Cold census boundary differs: '+a.slice(0,100));return s.replace(a,b);};
for(const variant of ['baseline','candidate']){
 const original=variant==='baseline'?baseline:parent,copy=path.join(stage,variant),pins=[],overrides=variant==='baseline'?[]:parent.overrides.map(p=>({...p}));fs.mkdirSync(copy);
 for(const pin of original.sourcePins){const raw=fs.readFileSync(path.join(original.sourceProject,pin.relative)),dst=path.join(copy,pin.relative);fs.mkdirSync(path.dirname(dst),{recursive:true});fs.writeFileSync(dst,raw);if(hash(fs.readFileSync(dst))!==pin.sha256)throw Error('Copy differs');pins.push({...pin});}
 const install=(relative,s,reason)=>{fs.writeFileSync(path.join(copy,relative),s);const sha256=hash(fs.readFileSync(path.join(copy,relative)));Object.assign(pins.find(p=>p.relative===relative),{sha256,bytes:Buffer.byteLength(s)});const prior=overrides.find(p=>p.relative===relative);if(prior)Object.assign(prior,{sha256,reason});else overrides.push({relative,sha256,reason});};
 if(variant==='candidate'){
  let s=fs.readFileSync(path.join(copy,'native/particle_presentation.hpp'),'utf8').replaceAll('\r\n','\n');
  s=once(s,' EngineVar entry_info(int64_t id)const{',` EngineVar cold_census(){
  if(running)throw std::runtime_error("Cold particle census requires a complete frame boundary");struct Scope{bool& flag;explicit Scope(bool& next_flag):flag(next_flag){flag=true;}~Scope(){flag=false;}}guard(running);auto out=summary(),rows=::array_empty();
  for(const auto id:order){const auto& e=*entries.at(id);auto row=EngineVar::dictionary();
   const auto integer=[&](const char* field_name,int64_t value){::set(row,field_name,EngineVar::integer(value));};const auto number=[&](const char* field_name,double value){::set(row,field_name,EngineVar::number(value));};const auto flag=[&](const char* field_name,bool value){::set(row,field_name,EngineVar::boolean(value));};
   integer("id",id);flag("native",e.owner!=nullptr);flag("enabled",e.enabled);flag("source_animating",e.source_animating);flag("clock_valid",particle_frame_group::valid_callable(e.clock));::set(row,"static_clip",EngineVar::text(e.static_clip.c_str()));number("clip_length",e.clip_length);number("elapsed",e.elapsed);
   if(e.owner){const auto& owner=*e.owner;const auto& state=owner.compact_state;resident::FieldKeyScope fields(owner.field_keys);integer("kind",owner.kind);integer("flags",state.flags);integer("source_id",static_cast<int64_t>(owner.source_id));integer("pose_id",static_cast<int64_t>(owner.pose_id));integer("source_flags",e.controls.source_flags);integer("active",static_cast<int64_t>(owner.compact_pool.active.size()));integer("free",static_cast<int64_t>(owner.compact_pool.free.size()));integer("allocated",owner.allocations);integer("frames",e.frames);flag("chunk",state.chunk);::set(row,"chunk_name",EngineVar::text(resident::get(owner.state,"chunkName").string.c_str()));number("birth_rate",state.birthRate);number("life_exp",state.lifeExp);number("blast_latch",state.blastLatch1c8);integer("detonate",state.detonate108);integer("initialized",state.initialized208);integer("spawn_type",state.spawnType);integer("render_mode",state.renderMode1a8);flag("last_step_prepared",e.step.prepared);flag("last_step_culled",e.step.culled);flag("last_step_checked",e.step.checked);number("last_step_radius",e.step.radius);integer("clip_count",static_cast<int64_t>(owner.clips.size()));
    int64_t all=0;for(const auto& clip:owner.clips)all+=static_cast<int64_t>(clip.second.size());integer("all_channel_count",all);
    if(e.step.prepared){::set(row,"last_step_clip",EngineVar::text(e.step.controls.clip.c_str()));int64_t total=0,constant=0,cached=0;const auto selected=owner.clips.find(e.step.controls.clip);if(selected!=owner.clips.end())for(const auto& channel:selected->second){++total;if(channel.constant)++constant;if(channel.cached)++cached;}integer("selected_channel_count",total);integer("selected_constant_count",constant);integer("selected_cached_count",cached);}else{::set(row,"last_step_clip",EngineVar());::set(row,"selected_channel_count",EngineVar());::set(row,"selected_constant_count",EngineVar());::set(row,"selected_cached_count",EngineVar());}
   }::method(rows,"append",{row});
  }::set(out,"emitters",rows);::set(out,"scope",EngineVar::text("Explicit cold particle inputs; no particle pools, clock advance, RNG or simulation"));return out;
 }
 EngineVar entry_info(int64_t id)const{`);
  s=once(s,'case 12:out=emitter_lighting::inspect(input);break;','case 12:out=emitter_lighting::inspect(input);break;case 13:out=owner.cold_census();break;');install('native/particle_presentation.hpp',s,'Full combined candidate/profile census plus explicit detached compact-scalar rows; no particle pool export or hot work');
  s=fs.readFileSync(path.join(copy,'systems/native_render/particle_stream_group.gd'),'utf8').replaceAll('\r\n','\n');
  const wrapper=`\n# Explicit cold diagnostic: root's benchmark driver chooses invocation/export.
func cold_particle_census() -> Dictionary:
 if running:return {"error":"Cold particle census requires a complete frame boundary"}
 if native==null:return {"error":"No native particle presentation owner"}
 var result: Dictionary=native.call("dispatch",13,{})
 if result.has("error"):return result
 for row: Dictionary in result.get("emitters",[]):
  var member: Dictionary=members.get(int(row.id),{})
  var handle: Variant=member.get("emitter")
  var emitter: Node=handle.get_ref() if handle is WeakRef else null
  var known: bool=is_instance_valid(emitter)
  row.metadata_available=known
  row.origin_resource=emitter.get("origin_resource") if known else null
  row.physical_part=emitter.get("physical_part") if known else null
  row.source_path=str(emitter.get("source_path")) if known and emitter.get("source_path")!=null else null
  row.node_path=str(emitter.get_path()) if known and emitter.is_inside_tree() else null
 return result
`;s+=wrapper.split('\n').map(line=>line.replace(/^ +/,spaces=>'\t'.repeat(spaces.length))).join('\n');install('systems/native_render/particle_stream_group.gd',s,'Explicit cold weak-member metadata join; no timer, file polling, automatic export or frame path change');
 }
 const receipt={...original,label,variant,sourceProject:copy,sourcePins:pins,overrides,parent:{file:parentFile,sha256:hash(fs.readFileSync(parentFile)),renderer:parent.sourceProject},sharedNativeBuilds:0,scope:'Explicit cold idle-emitter census only on profile combined parent. No hot-loop changes, particle pools, network or graphical acceptance.'};delete receipt.isolatedBuildFinalized;delete receipt.build;delete receipt.prebuildReceipt;fs.writeFileSync(path.join(stage,variant+'-sources.json'),JSON.stringify(receipt,null,2)+'\n');
}
console.log(JSON.stringify({success:true,label,stage,coldOnly:true,sharedNativeBuilds:0}));
