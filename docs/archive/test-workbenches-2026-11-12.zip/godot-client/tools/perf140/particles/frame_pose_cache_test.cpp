#include "frame_pose_cache.hpp"
#include <cstring>
#include <iostream>
#include <limits>
#include <stdexcept>
using Raw=std::array<float,12>;
struct Pose {Raw raw;};
static int checks=0;
void check(bool value){++checks;if(!value)throw std::runtime_error("Frame cache check failed");}
int main(){
 nwn_frame_pose::Cache<Pose> cache;Raw raw{};raw[0]=raw[4]=raw[8]=1;int reads=0,converts=0;
 const auto read=[&]{++reads;return raw;};const auto convert=[&](const Raw& r){++converts;return Pose{r};};
 cache.begin(4);check(cache.read(7,read,convert).raw==raw);check(cache.read(7,read,convert).raw==raw);check(reads==1&&converts==1&&cache.hits==1);
 nwn_frame_pose::active_epoch=&cache.epoch;
 {nwn_frame_pose::CallbackBarrier barrier;check(nwn_frame_pose::active_epoch==nullptr);raw[9]=5;}
 check(nwn_frame_pose::active_epoch==&cache.epoch);check(cache.read(7,read,convert).raw[9]==5);check(reads==2);
 try{nwn_frame_pose::CallbackBarrier barrier;raw[9]=6;throw std::runtime_error("authored callback throw");}catch(const std::runtime_error&){}
 check(cache.read(7,read,convert).raw[9]==6);check(reads==3);
 cache.begin(4);check(cache.read(7,read,convert).raw[9]==6);check(reads==4);
 cache.read(8,read,convert);check(reads==5);cache.erase(7);cache.read(7,read,convert);check(reads==6);
 cache.epoch.invalidate();raw[4]=std::numeric_limits<float>::infinity();cache.read(7,read,convert);cache.read(7,read,convert);check(reads==8&&cache.rejected==2);
 raw[4]=1;cache.epoch.invalidate();int throws=0;
 try{cache.read(9,read,[&](const Raw&)->Pose{++throws;throw std::runtime_error("conversion failure");});}catch(const std::runtime_error&){}
 cache.read(9,read,convert);check(throws==1&&cache.rows.at(9).pose.raw==raw);
 cache.epoch.value=UINT64_MAX;cache.epoch.invalidate();raw[0]=2;check(cache.read(7,read,convert).raw[0]==2);check(!cache.epoch.wrapped);
 uint32_t random=93;
 for(int frame=0;frame<1000;++frame){cache.begin(16);for(int phase=0;phase<8;++phase){
  for(int id=1;id<=8;++id){random=random*1664525u+1013904223u;raw[9]=float(random%1024);cache.epoch.invalidate();const auto expected=raw;check(cache.read(id,read,convert).raw==expected);check(cache.read(id,read,convert).raw==expected);}
  {nwn_frame_pose::CallbackBarrier outer;check(nwn_frame_pose::active_epoch==nullptr);{nwn_frame_pose::CallbackBarrier inner;check(nwn_frame_pose::active_epoch==nullptr);}check(nwn_frame_pose::active_epoch==nullptr);}check(nwn_frame_pose::active_epoch==&cache.epoch);
 }}
 cache.clear();check(cache.rows.empty());nwn_frame_pose::active_epoch=nullptr;
 std::cout<<"{\"success\":true,\"checks\":"<<checks<<",\"scope\":\"Pure callback-epoch cache correctness; no engine, graphics, network or frame-performance claim\"}\n";
}
