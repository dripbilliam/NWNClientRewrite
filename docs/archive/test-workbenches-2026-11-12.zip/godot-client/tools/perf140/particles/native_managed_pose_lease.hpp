// Private canonical static-Placement proof. There are no scene pointers or
// retained Nodes in a token; existing native particle owners keep its lifetime.
namespace native_managed_pose {
GDExtensionInterfaceObjectGetInstanceId object_id=nullptr;
GDExtensionMethodBindPtr node_parent=nullptr;
bool registered=false;
struct Owner {
 GDExtensionObjectPtr object=nullptr;
 std::shared_ptr<nwn_managed_pose::Scope> scope;
 std::shared_ptr<nwn_managed_pose::Lease> lease;
};
std::mutex registry_mutex;
std::unordered_map<GDExtensionObjectPtr,Owner*> registry;

Owner* find(const EngineVar& value){
 if(value.type()!=GDEXTENSION_VARIANT_TYPE_OBJECT)return nullptr;
 GDExtensionObjectPtr object=nullptr;to[GDEXTENSION_VARIANT_TYPE_OBJECT](&object,const_cast<uint8_t*>(value.data));
 std::lock_guard<std::mutex> lock(registry_mutex);const auto row=registry.find(object);return row==registry.end()?nullptr:row->second;
}
uint64_t live_node_id(const EngineVar& value){
 if(value.type()!=GDEXTENSION_VARIANT_TYPE_OBJECT)return 0;
 GDExtensionObjectPtr object=nullptr;to[GDEXTENSION_VARIANT_TYPE_OBJECT](&object,const_cast<uint8_t*>(value.data));
 return object&&cast_object(object,node_tag)?object_id(object):0;
}
uint64_t parent_id(uint64_t id){
 auto object=instance_from_id(id);if(!object||!cast_object(object,node_tag))return 0;
 GDExtensionObjectPtr parent=nullptr;ptrcall(node_parent,object,nullptr,&parent);return parent?object_id(parent):0;
}
bool ancestor(uint64_t child,uint64_t wanted){
 for(size_t n=0;n<1024&&child;++n){if(child==wanted)return true;child=parent_id(child);}return false;
}
bool capture_endpoint(nwn_managed_pose::Lease& lease,uint64_t endpoint){
 nwn_managed_pose::Lease::Endpoint proof;auto current=endpoint;
 for(size_t n=0;n<1024&&current;++n){
  proof.parents.push_back(current);
  if(current==lease.source_id){proof.checked_mutation=nwn_managed_pose::callbacks.revision.value;lease.endpoints.insert_or_assign(endpoint,std::move(proof));return true;}
  current=parent_id(current);
 }
 return false;
}
bool allows(const std::shared_ptr<nwn_managed_pose::Lease>& lease,uint64_t endpoint){
 if(!lease||!active_frame_pose_cache||nwn_frame_pose::active_epoch!=&active_frame_pose_cache->epoch)return false;
 auto& mutation=nwn_managed_pose::callbacks;const auto call=active_frame_pose_cache->call;
 const auto found=lease->endpoints.find(endpoint);if(found==lease->endpoints.end())return false;
 if(!lease->validate(call,mutation,[&](){
  return lease->scope->validate(call,mutation,[&](){return instance_from_id(lease->scope->owner_id)!=nullptr;})&&instance_from_id(lease->placement_id)!=nullptr;
 }))return false;
 auto& proof=found->second;
 if(proof.checked_mutation!=mutation.revision.value){
  if(parent_id(lease->source_id)!=lease->placement_id||!ancestor(lease->placement_id,lease->scope->owner_id)){lease->revoke();return false;}
  auto current=endpoint;for(const auto expected:proof.parents){if(current!=expected){lease->revoke();return false;}if(current!=lease->source_id)current=parent_id(current);}
  if(current!=lease->source_id){lease->revoke();return false;}
  proof.checked_mutation=mutation.revision.value;
 }
 return true;
}
void revoke(Owner& owner){if(owner.lease)owner.lease->revoke();if(owner.scope)owner.scope->revoke();}

GDExtensionObjectPtr create(void*,GDExtensionBool notify){
 Name base("RefCounted"),name("NwnParticlePoseLease");auto object=construct_object(base.data);auto* owner=new Owner();owner->object=object;set_instance(object,name.data,owner);
 {std::lock_guard<std::mutex> lock(registry_mutex);registry.emplace(object,owner);}
 if(notify){EngineVar value;destroy(value.data);from[GDEXTENSION_VARIANT_TYPE_OBJECT](value.data,&object);::method(value,"notification",{EngineVar::integer(0)});}return object;
}
void free(void*,GDExtensionClassInstancePtr instance){auto* owner=static_cast<Owner*>(instance);revoke(*owner);{std::lock_guard<std::mutex> lock(registry_mutex);registry.erase(owner->object);}delete owner;}
bool count_ok(GDExtensionInt actual,GDExtensionInt expected,GDExtensionVariantPtr result,GDExtensionCallError* error){
 error->error=GDEXTENSION_CALL_OK;if(actual==expected)return true;error->error=actual<expected?GDEXTENSION_CALL_ERROR_TOO_FEW_ARGUMENTS:GDEXTENSION_CALL_ERROR_TOO_MANY_ARGUMENTS;error->expected=static_cast<int32_t>(expected);new_nil(result);return false;
}
void bind_scope(void*,GDExtensionClassInstancePtr,const GDExtensionConstVariantPtr* args,GDExtensionInt count,GDExtensionVariantPtr result,GDExtensionCallError* error){
 if(!count_ok(count,2,result,error))return;bool ok=false;EngineVar token(args[0]),node(args[1]);auto* owner=find(token);const auto id=live_node_id(node);
 if(owner&&!owner->scope&&!owner->lease&&id){owner->scope=std::make_shared<nwn_managed_pose::Scope>();owner->scope->identity=object_id(owner->object);owner->scope->owner_id=id;ok=true;}
 auto out=EngineVar::boolean(ok);new_copy(result,out.data);
}
void bind_placement(void*,GDExtensionClassInstancePtr,const GDExtensionConstVariantPtr* args,GDExtensionInt count,GDExtensionVariantPtr result,GDExtensionCallError* error){
 if(!count_ok(count,4,result,error))return;bool ok=false;EngineVar token(args[0]),scope(args[1]),placement(args[2]),source(args[3]);auto* owner=find(token);auto* parent=find(scope);const auto placement_id=live_node_id(placement),source_id=live_node_id(source);
 if(owner&&parent&&parent->scope&&parent->scope->usable()&&!owner->scope&&!owner->lease&&placement_id&&source_id&&parent_id(source_id)==placement_id&&ancestor(placement_id,parent->scope->owner_id)){
  owner->lease=std::make_shared<nwn_managed_pose::Lease>();owner->lease->scope=parent->scope;owner->lease->identity=object_id(owner->object);owner->lease->placement_id=placement_id;owner->lease->source_id=source_id;ok=true;
 }
 auto out=EngineVar::boolean(ok);new_copy(result,out.data);
}
void attach(void*,GDExtensionClassInstancePtr,const GDExtensionConstVariantPtr* args,GDExtensionInt count,GDExtensionVariantPtr result,GDExtensionCallError* error){
 if(!count_ok(count,2,result,error))return;bool ok=false;EngineVar token(args[0]),emitter(args[1]);auto* proof=find(token);resident::Owner* owner=nullptr;
 if(emitter.type()==GDEXTENSION_VARIANT_TYPE_OBJECT){GDExtensionObjectPtr object=nullptr;to[GDEXTENSION_VARIANT_TYPE_OBJECT](&object,emitter.data);std::lock_guard<std::mutex> lock(resident::owner_registry_mutex);const auto row=resident::owner_registry.find(object);if(row!=resident::owner_registry.end())owner=row->second;}
 if(proof&&proof->lease&&proof->lease->usable(nwn_managed_pose::callbacks)&&owner&&owner->configured&&owner->typed_frame&&owner->source_id==proof->lease->source_id&&capture_endpoint(*proof->lease,owner->pose_id)&&capture_endpoint(*proof->lease,owner->source_id)){
  owner->managed_lease=proof->lease;ok=true;
 }
 auto out=EngineVar::boolean(ok);new_copy(result,out.data);
}
void revoke_call(void*,GDExtensionClassInstancePtr,const GDExtensionConstVariantPtr* args,GDExtensionInt count,GDExtensionVariantPtr result,GDExtensionCallError* error){
 if(!count_ok(count,1,result,error))return;EngineVar token(args[0]);auto* owner=find(token);if(owner)revoke(*owner);new_nil(result);
}
void snapshot(void*,GDExtensionClassInstancePtr instance,const GDExtensionConstVariantPtr*,GDExtensionInt count,GDExtensionVariantPtr result,GDExtensionCallError* error){
 if(!count_ok(count,0,result,error))return;const auto& owner=*static_cast<Owner*>(instance);auto out=EngineVar::dictionary();::set(out,"scope",EngineVar::boolean(owner.scope!=nullptr));::set(out,"placement",EngineVar::boolean(owner.lease!=nullptr));::set(out,"active",EngineVar::boolean(owner.scope?owner.scope->usable():owner.lease&&owner.lease->usable(nwn_managed_pose::callbacks)));::set(out,"endpoints",EngineVar::integer(owner.lease?static_cast<int64_t>(owner.lease->endpoints.size()):0));new_copy(result,out.data);
}
template<class Property>void register_owner(const Property& property){
 if(!object_id)return;Name node("Node"),parent("get_parent");node_parent=class_method(node.data,parent.data,3160264692);if(!node_parent)return;
 Name name("NwnParticlePoseLease"),base("RefCounted"),empty(""),arg("value"),scope("bind_scope"),placement("bind_placement"),attach_name("attach"),revoke_name("revoke"),snap("snapshot");
 GDExtensionClassCreationInfo6 info{};info.is_exposed=true;info.is_runtime=true;info.create_instance_func=create;info.free_instance_func=free;register_class(library,name.data,base.data,&info);registered=true;
 Name arg1("owner_or_scope"),arg2("placement"),arg3("source");auto boolean=property(GDEXTENSION_VARIANT_TYPE_BOOL,empty),dictionary=property(GDEXTENSION_VARIANT_TYPE_DICTIONARY,empty);std::array<GDExtensionPropertyInfo,4> arguments{property(GDEXTENSION_VARIANT_TYPE_OBJECT,arg),property(GDEXTENSION_VARIANT_TYPE_OBJECT,arg1),property(GDEXTENSION_VARIANT_TYPE_OBJECT,arg2),property(GDEXTENSION_VARIANT_TYPE_OBJECT,arg3)};std::array<GDExtensionClassMethodArgumentMetadata,4> metadata{};
 GDExtensionClassMethodInfo m{};m.method_flags=GDEXTENSION_METHOD_FLAG_NORMAL|GDEXTENSION_METHOD_FLAG_STATIC;m.has_return_value=true;m.return_value_info=&boolean;m.arguments_info=arguments.data();m.arguments_metadata=metadata.data();m.argument_count=2;m.name=scope.data;m.call_func=bind_scope;register_method(library,name.data,&m);m.argument_count=4;m.name=placement.data;m.call_func=bind_placement;register_method(library,name.data,&m);m.argument_count=2;m.name=attach_name.data;m.call_func=attach;register_method(library,name.data,&m);m.argument_count=1;m.name=revoke_name.data;m.call_func=revoke_call;m.has_return_value=false;m.return_value_info=nullptr;register_method(library,name.data,&m);
 m.method_flags=GDEXTENSION_METHOD_FLAG_NORMAL;m.argument_count=0;m.name=snap.data;m.call_func=snapshot;m.has_return_value=true;m.return_value_info=&dictionary;register_method(library,name.data,&m);
}
void unregister_owner(){if(registered){Name name("NwnParticlePoseLease");unregister_class(library,name.data);registered=false;}}
} // namespace native_managed_pose
