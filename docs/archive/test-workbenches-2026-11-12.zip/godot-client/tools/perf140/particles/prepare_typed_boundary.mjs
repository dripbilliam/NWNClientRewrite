// One private persistent typed boundary experiment. Run only in a Root-approved
// source/CPU window: preparation verifies and copies the entire frozen parent.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url)),project=path.resolve(here,'../../..'),base=path.join(project,'.cache/native-140fps/particles-agent'),label=process.argv[2],hash=b=>crypto.createHash('sha256').update(b).digest('hex');
if(!/^[a-z0-9-]+$/.test(label??''))throw Error('Fresh typed-boundary label required');
const parentFile=path.join(base,'managed-pose-leases-v1/candidate-built-sources.json'),parent=JSON.parse(fs.readFileSync(parentFile)),stage=path.join(base,label);
if(fs.existsSync(stage))throw Error('Previous evidence preserved');
if(hash(fs.readFileSync(parentFile))!=='20fab7baae2500eb4e45a95e77da68a2f4f913b52fe252666e1f2fa81a1afd14')throw Error('Reviewed managed parent receipt differs');
for(const pin of parent.sourcePins)if(hash(fs.readFileSync(path.join(parent.sourceProject,pin.relative)))!==pin.sha256)throw Error('Frozen parent differs: '+pin.relative);
fs.mkdirSync(stage);
const once=(s,a,b)=>{if(s.split(a).length!==2)throw Error('Typed boundary differs: '+a.slice(0,140));return s.replace(a,b);};
for(const variant of ['baseline','candidate']){
 const copy=path.join(stage,variant),pins=[],overrides=variant==='candidate'?parent.overrides.map(row=>({...row})):[];fs.mkdirSync(copy);
 for(const pin of parent.sourcePins){const bytes=fs.readFileSync(path.join(parent.sourceProject,pin.relative)),destination=path.join(copy,pin.relative);fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,bytes);pins.push({...pin});}
 const install=(relative,source,reason)=>{const destination=path.join(copy,relative);fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,source);const sha256=hash(fs.readFileSync(destination)),record={relative,sha256,bytes:Buffer.byteLength(source)};const pin=pins.find(row=>row.relative===relative);if(pin)Object.assign(pin,record);else pins.push(record);let override=overrides.find(row=>row.relative===relative);if(!override){override={relative};overrides.push(override);}Object.assign(override,{sha256,reason});};
 if(variant==='candidate'){
  const relative='native/particle_presentation.hpp';let s=fs.readFileSync(path.join(copy,relative),'utf8').replaceAll('\r\n','\n');
  const start=s.indexOf('struct Controls {'),end=s.indexOf('struct Entry {');if(start<0||end<=start)throw Error('Step declaration boundaries differ');
  s=s.slice(0,start)+fs.readFileSync(path.join(here,'typed_boundary_step.hpp'),'utf8').replaceAll('\r\n','\n')+'\n'+s.slice(end);
  s=once(s,'NativeOwner* owner=nullptr;Controls controls;Step step;','NativeOwner* owner=nullptr;Controls controls;EntryConfig typed_config;PendingCommands pending;Step step;');
  s=once(s,'bool enabled=true,source_animating=false,reuse_controls=true,direct_animating=true;','bool enabled=true,source_animating=false,reuse_controls=true,direct_animating=true,typed_boundary=false,readiness_pending=false,clock_candidate=false;');
  s=once(s,'int64_t frames=0,culling_checks=0,culled_frames=0,culling_fallbacks=0,peak_active=0,published_vertices=0,direct_queries=0,direct_hits=0;','int64_t frames=0,culling_checks=0,culled_frames=0,culling_fallbacks=0,peak_active=0,published_vertices=0,direct_queries=0,direct_hits=0;\n const EntryConfig& config()const{return typed_boundary?typed_config:static_cast<const EntryConfig&>(controls);}\n EntryConfig& config(){return typed_boundary?typed_config:static_cast<EntryConfig&>(controls);}');
  // FrameInput precedes entries: reverse destruction retires all borrowing
  // Steps before this stable Owner-owned input slot is destroyed.
  s=once(s,'FramePoseCache frame_pose_cache;','FramePoseCache frame_pose_cache;FrameInput frame_input;');
  s=once(s,'auto entry=std::make_unique<Entry>();entry->id=id;','auto entry=std::make_unique<Entry>();entry->id=id;entry->typed_boundary=::has(config,"typed_boundary")&&::get(config,"typed_boundary").boolean();');
  s=once(s,'if(::has(config,"clip_length"))entry->clip_length=::get(config,"clip_length").number();if(::has(config,"clock"))entry->clock=::get(config,"clock");','if(::has(config,"clip_length"))entry->clip_length=::get(config,"clip_length").number();if(::has(config,"clock")){entry->clock=::get(config,"clock");entry->clock_candidate=entry->clock.type()==GDEXTENSION_VARIANT_TYPE_CALLABLE;}');
  s=once(s,'if(::has(config,"ready")){entry->readiness=::get(config,"ready");','if(::has(config,"ready")){entry->readiness_pending=true;entry->readiness=::get(config,"ready");');
  s=once(s,'auto& entry=*found->second;auto& c=entry.controls;','auto& entry=*found->second;auto& c=entry.config();\n  if(::has(config,"typed_boundary")&&::get(config,"typed_boundary").boolean()!=entry.typed_boundary)throw std::runtime_error("Native typed boundary mode requires fresh registration");');
  s=once(s,'if(::has(config,"patch")){auto patch=::get(config,"patch");c.patch=::method(patch,"duplicate",{EngineVar::boolean(true)});}if(::has(config,"detonate")&&::get(config,"detonate").boolean())c.detonate=true;',`if(::has(config,"patch")){auto patch=::get(config,"patch");auto copy=::method(patch,"duplicate",{EngineVar::boolean(true)});if(entry.typed_boundary){if(copy.nil())entry.pending.patch.reset();else entry.pending.patch=copy;}else entry.controls.patch=copy;}if(::has(config,"detonate")&&::get(config,"detonate").boolean()){if(entry.typed_boundary)entry.pending.detonate=true;else entry.controls.detonate=true;}`);
  s=once(s,'if(::has(config,"clock"))entry.clock=::get(config,"clock");','if(::has(config,"clock")){entry.clock=::get(config,"clock");entry.clock_candidate=entry.clock.type()==GDEXTENSION_VARIANT_TYPE_CALLABLE;}');
  const scene='direct_scene=true;}\n  std::array<int64_t,22> census{};';
  s=once(s,scene,`direct_scene=true;}
  frame_input.camera=camera;frame_input.delta=static_cast<float>(delta);frame_input.profile=profile;frame_input.direct_scene=direct_scene;frame_input.terrain_index=terrain;frame_input.static_index=statics;++frame_input.generation;frame_input.active=true;
  // One shared validity bit invalidates every synchronous borrow on all exits;
  // there is deliberately no additional per-frame walk of all member Steps.
  struct InputScope{FrameInput& input;~InputScope(){input.active=false;}}input_scope{frame_input};
  std::array<int64_t,22> census{};`);
  s=once(s,'if(!entry.readiness.nil()){','if(entry.typed_boundary?entry.readiness_pending:!entry.readiness.nil()){');
  s=once(s,'entry.readiness=EngineVar();}','entry.readiness=EngineVar();entry.readiness_pending=false;}');
  const oldBegin='entry.elapsed+=delta;std::optional<Controls> copied_controls;auto& next=entry.reuse_controls?entry.controls:copied_controls.emplace(entry.controls);next.delta=static_cast<float>(delta);next.profile=profile;next.clip=entry.static_clip;next.animate=(entry.direct_animating?common_animating(common):(!::has(common,"animating")||::get(common,"animating").boolean()))||(entry.source_key&&entry.source_animating);double time=entry.elapsed;';
  s=once(s,oldBegin,`entry.elapsed+=delta;std::optional<Controls> copied_controls;Controls* next=nullptr;
   if(!entry.typed_boundary)next=&(entry.reuse_controls?entry.controls:copied_controls.emplace(entry.controls));
   const bool animate=(entry.direct_animating?common_animating(common):(!::has(common,"animating")||::get(common,"animating").boolean()))||(entry.source_key&&entry.source_animating);
   if(next){next->delta=static_cast<float>(delta);next->profile=profile;next->clip=entry.static_clip;next->animate=animate;}
   std::string dynamic_clip;const std::string* selected_clip=&entry.static_clip;double time=entry.elapsed;`);
  s=once(s,'bool actor_clock=particle_frame_group::valid_callable(*clock);','bool actor_clock=(!entry.typed_boundary||entry.clock_candidate)&&particle_frame_group::valid_callable(*clock);');
  s=once(s,'if(typed_clock){next.clip=sampled_clock->valid?sampled_clock->clip:"";time=sampled_clock->valid?sampled_clock->time:0.0;}',`if(typed_clock){if(next)next->clip=sampled_clock->valid?sampled_clock->clip:"";else if(sampled_clock->valid)selected_clip=&sampled_clock->clip;else selected_clip=&dynamic_clip;time=sampled_clock->valid?sampled_clock->time:0.0;}`);
  s=once(s,'next.clip=::has(sampled,"clip")?engine_string(::get(sampled,"clip")):"";time=::has(sampled,"time")?::get(sampled,"time").number():0;','if(next)next->clip=::has(sampled,"clip")?engine_string(::get(sampled,"clip")):"";else{dynamic_clip=::has(sampled,"clip")?engine_string(::get(sampled,"clip")):"";selected_clip=&dynamic_clip;}time=::has(sampled,"time")?::get(sampled,"time").number():0;');
  s=once(s,'next.time=static_cast<float>(time);next.direct_scene=direct_scene;next.terrain_index=terrain;next.static_index=statics;','if(next){next->time=static_cast<float>(time);next->direct_scene=direct_scene;next->terrain_index=terrain;next->static_index=statics;}');
  s=once(s,'entry.step.advance(*entry.owner,next,entry.providers,camera,reject_plane);entry.controls.patch=EngineVar();entry.controls.detonate=false;++prepared;',`if(entry.typed_boundary){entry.step.advance_entry(*entry.owner,entry.config(),entry.pending,entry.providers,frame_input,*selected_clip,selected_clip==&entry.static_clip,static_cast<float>(time),animate,reject_plane);entry.pending.patch.reset();entry.pending.detonate=false;}else{entry.step.advance(*entry.owner,*next,entry.providers,camera,reject_plane);entry.controls.patch=EngineVar();entry.controls.detonate=false;}++prepared;`);
  s=once(s,'if(!next.animate)++census[15];','if(!animate)++census[15];');
  s=once(s,'else if(next.culling)++entry.culling_fallbacks;','else if(entry.config().culling)++entry.culling_fallbacks;');
  s=once(s,'!entry->controls.draw_enabled','!entry->config().draw_enabled');
  s=once(s,'integer("source_flags",e.controls.source_flags);','integer("source_flags",e.config().source_flags);');
  s=s.replaceAll('e.step.controls.clip','e.step.clip_name()');
  s=once(s,'::set(out,"reuse_controls",EngineVar::boolean(e.reuse_controls));','::set(out,"typed_boundary",EngineVar::boolean(e.typed_boundary));::set(out,"reuse_controls",EngineVar::boolean(e.reuse_controls));');
  s=once(s,'EngineVar::boolean(e.controls.detonate)','EngineVar::boolean(e.typed_boundary?e.pending.detonate:e.controls.detonate)');
  s=once(s,'EngineVar::boolean(!e.controls.patch.nil())','EngineVar::boolean(e.typed_boundary?e.pending.patch.has_value():!e.controls.patch.nil())');
  s=once(s,' void close(){if(running)',` EngineVar typed_boundary_info()const{
  if(running)throw std::runtime_error("Typed boundary census requires a complete frame boundary");
  auto out=EngineVar::dictionary();int64_t selected=0,advanced=0,shared=0,providers=0,patches=0;
  for(const auto& item:entries){const auto& entry=*item.second;if(!entry.typed_boundary)continue;++selected;
   if(entry.step.typed&&entry.step.input.frame==&frame_input&&entry.step.input.generation==frame_input.generation){++advanced;if(entry.step.prepared)++shared;if(entry.step.input.providers==&entry.providers)++providers;if(entry.step.retained_patch)++patches;}
  }
  ::set(out,"mode",EngineVar::text("persistent_entry_frame_commands"));::set(out,"selected",EngineVar::integer(selected));::set(out,"advanced",EngineVar::integer(advanced));::set(out,"shared_frame_borrows",EngineVar::integer(shared));::set(out,"entry_provider_borrows",EngineVar::integer(providers));::set(out,"retained_patch_snapshots",EngineVar::integer(patches));::set(out,"frame_generation",EngineVar::integer(static_cast<int64_t>(frame_input.generation)));::set(out,"frame_active",EngineVar::boolean(frame_input.active));return out;
 }
 void close(){if(running)`);
  s=once(s,'case 13:out=owner.cold_census();break;','case 13:out=owner.cold_census();break;case 16:out=owner.typed_boundary_info();break;');
  install(relative,s,'One synchronous execution body with original owned fallback; explicit persistent EntryConfig/shared FrameInput/optional commands/result lifetime; no wrapper/admission/clock skip');
  const group='systems/native_render/particle_stream_group.gd';s=fs.readFileSync(path.join(copy,group),'utf8').replaceAll('\r\n','\n');s=once(s,'var config:={"id":id,"enabled":emitter.particles_enabled}','var config:={"id":id,"enabled":emitter.particles_enabled,"typed_boundary":OS.get_cmdline_user_args().has("--particle-inputs=typed") or OS.get_environment("NWN_PARTICLE_INPUTS")=="typed"}');install(group,s,'Explicit independent typed-input registration mode, ordinary default retained');
 }
 const receipt={...parent,label,variant,sourceProject:copy,sourcePins:pins,overrides,parent:{file:parentFile,sha256:hash(fs.readFileSync(parentFile)),renderer:parent.sourceProject},scope:'Private single typed presentation boundary on proven managed-pose baseline; original owned fallback. No eligibility, provider-reference, snapshots or manual suppression bundle.',sharedNativeBuilds:0};delete receipt.isolatedBuildFinalized;delete receipt.build;delete receipt.prebuildReceipt;fs.writeFileSync(path.join(stage,variant+'-sources.json'),JSON.stringify(receipt,null,2)+'\n');
}
console.log(JSON.stringify({success:true,label,stage,sharedNativeBuilds:0}));
