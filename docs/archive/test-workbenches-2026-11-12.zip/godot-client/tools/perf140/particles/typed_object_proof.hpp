#pragma once
#include <cstdint>
#include <utility>
// A successful immutable native-type proof, not an owned/cached scene pointer.
// Caller MUST resolve the full live ObjectID on every use. The saved numeric
// address is compared only; it must never be cast back or dereferenced.
namespace nwn_typed_object {
struct Proof {
 std::uint64_t identity=0,hits=0,casts=0;
 std::uintptr_t address=0;
 void invalidate(){identity=0;address=0;}
 template<class Pointer,class Cast>bool validate(std::uint64_t id,Pointer live,Cast&& cast){
  if(!live){invalidate();return false;}
  const auto current=reinterpret_cast<std::uintptr_t>(live);
  if(identity==id&&address==current){++hits;return true;}
  ++casts;if(!std::forward<Cast>(cast)(live)){invalidate();return false;}
  identity=id;address=current;return true;
 }
};
}
