[CmdletBinding()]
param([Parameter(Mandatory)][ValidatePattern('^[a-z0-9-]+$')][string]$Label)
$ErrorActionPreference='Stop'
$project=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$stage=Join-Path $project ('.cache/native-140fps/particles-agent/'+$Label)
$receipt=Get-Content -LiteralPath (Join-Path $stage 'candidate-sources.json') -Raw|ConvertFrom-Json
$pure=$receipt.pureSourceProject
$proof=Join-Path $stage 'endpoint-pure-build.json'
if(Test-Path -LiteralPath $proof){throw 'Existing compiler evidence preserved'}
foreach($pin in $receipt.purePins){if((Get-FileHash -LiteralPath (Join-Path $pure $pin.relative)).Hash.ToLowerInvariant()-ne$pin.sha256){throw ('Private pure source changed: '+$pin.relative)}}
$vswhere=Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio/Installer/vswhere.exe'
$vs=@(& $vswhere -all -prerelease -products '*' -property installationPath)|Where-Object{Test-Path -LiteralPath (Join-Path $_ 'VC/Auxiliary/Build/Microsoft.VCToolsVersion.default.txt')}|Select-Object -First 1
if(-not$vs){throw 'Existing MSVC unavailable'}
$version=(Get-Content -LiteralPath (Join-Path $vs 'VC/Auxiliary/Build/Microsoft.VCToolsVersion.default.txt') -Raw).Trim()
$tools=Join-Path $vs ('VC/Tools/MSVC/'+$version)
$compiler=Join-Path $tools 'bin/Hostx64/x64/cl.exe'
$sdk=Join-Path ${env:ProgramFiles(x86)} 'Windows Kits/10'
$include=Get-ChildItem -LiteralPath (Join-Path $sdk 'Include') -Directory|Sort-Object Name -Descending|Where-Object{Test-Path -LiteralPath (Join-Path $_.FullName 'um/Windows.h')}|Select-Object -First 1
$priorInclude=$env:INCLUDE;$priorLib=$env:LIB
try{
 $env:INCLUDE=((Join-Path $tools 'include'),(Join-Path $include.FullName 'ucrt'),(Join-Path $include.FullName 'shared'),(Join-Path $include.FullName 'um'))-join';'
 $env:LIB=((Join-Path $tools 'lib/x64'),(Join-Path $sdk ('Lib/'+$include.Name+'/ucrt/x64')),(Join-Path $sdk ('Lib/'+$include.Name+'/um/x64')))-join';'
 $binary=Join-Path $stage 'endpoint-pure.exe'
 $args=@('/nologo','/O2','/fp:strict','/EHsc','/W4','/WX','/std:c++17','/MD',('/Fo'+(Join-Path $stage 'endpoint-pure.obj')),('/Fe'+$binary),(Join-Path $pure 'native_perf140_particle_endpoint_slot_test.cpp'),'/link','/INCREMENTAL:NO')
 $compile=@(& $compiler @args 2>&1);$compileExit=$LASTEXITCODE
 [IO.File]::WriteAllText((Join-Path $stage 'endpoint-pure-compile.log'),($compile-join[Environment]::NewLine))
 $runExit=$null;$result=$null
 if($compileExit-eq0){$result=@(& $binary);$runExit=$LASTEXITCODE;[IO.File]::WriteAllText((Join-Path $stage 'endpoint-pure-result.json'),($result-join[Environment]::NewLine))}
}finally{$env:INCLUDE=$priorInclude;$env:LIB=$priorLib}
$changed=@($receipt.purePins|Where-Object{(Get-FileHash -LiteralPath (Join-Path $pure $_.relative)).Hash.ToLowerInvariant()-ne$_.sha256}|ForEach-Object relative)
$report=@{success=$compileExit-eq0-and$runExit-eq0-and-not$changed.Count;compileExit=$compileExit;runExit=$runExit;compiler=$version;flags='/O2 /fp:strict /EHsc /W4 /WX /std:c++17 /MD';sourcePins=$receipt.purePins;changedSources=$changed;engineStarts=0;serverConnections=0;timing=$false}
[IO.File]::WriteAllText($proof,($report|ConvertTo-Json -Depth 6))
$report|ConvertTo-Json -Compress
if(-not$report.success){exit 1}
