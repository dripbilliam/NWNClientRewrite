// Explicit canonical static eligibility ownership. This is a separate grant
// from a pose lease. No Node pointers or cross-frame eligibility are retained.
namespace native_managed_eligibility {
struct Lease {
 std::shared_ptr<nwn_managed_pose::Scope> scope;
 uint64_t identity=0,anchor=0,source=0,checked_mutation=0,attached_total=0;
 bool active=true,cached_eligible=false;uint64_t cached_call=0,cached_mutation=0;
 void revoke(){active=false;cached_call=0;}
};
struct Endpoint {std::shared_ptr<Lease> lease;uint64_t id=0;std::vector<uint64_t> parents;uint64_t checked_mutation=0;};
struct Stats {uint64_t attempts=0,hits=0,anchor_reads=0,endpoint_validations=0,structural_checks=0,fallbacks=0;bool invalidated=false;};
struct Frame {
 Stats& published;Stats stats;uint64_t call=0,mutation=0,epoch_value=0;nwn_frame_pose::Epoch* epoch=nullptr;
 explicit Frame(Stats& target):published(target){if(active_frame_pose_cache){call=active_frame_pose_cache->call;epoch=nwn_frame_pose::active_epoch;if(epoch)epoch_value=epoch->value;}mutation=nwn_managed_pose::callbacks.revision.value;}
 bool current(){const bool ok=call&&epoch&&epoch==nwn_frame_pose::active_epoch&&epoch->value==epoch_value&&!epoch->wrapped&&nwn_managed_pose::callbacks.reusable()&&mutation==nwn_managed_pose::callbacks.revision.value;if(!ok)stats.invalidated=true;return ok;}
 ~Frame(){current();published=stats;}
};
thread_local Frame* frame=nullptr;
struct Scope {Frame* prior;explicit Scope(Frame& next):prior(frame){frame=&next;}~Scope(){frame=prior;}};
GDExtensionMethodBindPtr local_visible=nullptr,process_mode=nullptr,thread_group=nullptr,caller_thread=nullptr,main_thread=nullptr;
GDExtensionObjectPtr os=nullptr;void* node_class_tag=nullptr;bool registered=false;
static_assert(sizeof(GDExtensionInt)==8,"Godot ptrcall enum returns require int64 storage");
std::atomic<uint64_t> enum_abi_calls{0},enum_abi_failures{0};
bool read_enum(GDExtensionMethodBindPtr binding,GDExtensionObjectPtr object,GDExtensionInt& output){
 // method_ptrcall.h encodes BOTH native int32 and enum returns as int64.
 // Guard the real return destination at the cold grant/revalidation boundary.
 struct alignas(8) Slot {uint64_t before=0xf140cafe8badf00d;GDExtensionInt value=-1;uint64_t after=0x1947d00d05afe140;} slot;
 ptrcall(binding,object,nullptr,&slot.value);enum_abi_calls.fetch_add(1,std::memory_order_relaxed);
 if(slot.before!=0xf140cafe8badf00d||slot.after!=0x1947d00d05afe140){enum_abi_failures.fetch_add(1,std::memory_order_relaxed);return false;}output=slot.value;return true;
}
bool main_caller(){uint64_t caller=0,main=0;ptrcall(caller_thread,os,nullptr,&caller);ptrcall(main_thread,os,nullptr,&main);return caller==main;}
bool local_inherits(uint64_t id){auto node=instance_from_id(id);if(!node||!cast_object(node,node_tag))return false;GDExtensionBool shown=false;GDExtensionInt process=-1,group=-1;ptrcall(local_visible,node,nullptr,&shown);return read_enum(process_mode,node,process)&&read_enum(thread_group,node,group)&&shown&&process==0&&group==0;}
uint64_t generic_parent_id(uint64_t id){auto node=instance_from_id(id);if(!node||!cast_object(node,node_class_tag))return 0;GDExtensionObjectPtr parent=nullptr;ptrcall(native_managed_pose::node_parent,node,nullptr,&parent);return parent?native_managed_pose::object_id(parent):0;}
bool main_group(uint64_t id){for(size_t n=0;n<1024&&id;++n){auto node=instance_from_id(id);if(!node||!cast_object(node,node_class_tag))return false;GDExtensionInt group=-1;if(!read_enum(thread_group,node,group))return false;if(group!=0)return group==1;id=generic_parent_id(id);}return !id;}
bool check_chain(const Endpoint& endpoint){auto current=endpoint.id;for(const auto expected:endpoint.parents){if(current!=expected||!local_inherits(current))return false;current=native_managed_pose::parent_id(current);}return current==endpoint.lease->anchor;}
bool capture(Endpoint& endpoint){auto current=endpoint.id;for(size_t n=0;n<1024&&current&&current!=endpoint.lease->anchor;++n){if(!local_inherits(current))return false;endpoint.parents.push_back(current);current=native_managed_pose::parent_id(current);}return current==endpoint.lease->anchor&&!endpoint.parents.empty();}
std::optional<bool> eligible(resident::Owner& owner,uint64_t id){
 if(!frame)return std::nullopt;auto& stats=frame->stats;++stats.attempts;
 const auto fail=[&]()->std::optional<bool>{++stats.fallbacks;return std::nullopt;};
 auto endpoint=owner.managed_eligibility;if(!endpoint||endpoint->id!=id||!endpoint->lease||!endpoint->lease->active||!frame->current())return fail();
 auto& lease=*endpoint->lease;auto& mutation=nwn_managed_pose::callbacks;
 // Every participating leaf still performs live full-ObjectID and native type
 // validation before it can use the shared ancestor result.
 ++stats.endpoint_validations;auto node=instance_from_id(id);if(!node||!cast_object(node,node_tag)){lease.revoke();return false;}
 if(!lease.scope||!lease.scope->validate(frame->call,mutation,[&](){return instance_from_id(lease.scope->owner_id)!=nullptr;}))return fail();
 if(lease.checked_mutation!=mutation.revision.value){++stats.structural_checks;if(native_managed_pose::parent_id(lease.source)!=lease.anchor||!native_managed_pose::ancestor(lease.anchor,lease.scope->owner_id)||!main_group(lease.anchor)){lease.revoke();return fail();}lease.checked_mutation=mutation.revision.value;}
 if(endpoint->checked_mutation!=mutation.revision.value){++stats.structural_checks;if(!check_chain(*endpoint)){lease.revoke();return fail();}endpoint->checked_mutation=mutation.revision.value;}
 if(lease.cached_call!=frame->call||lease.cached_mutation!=mutation.revision.value){
  auto anchor=instance_from_id(lease.anchor);if(!anchor||!cast_object(anchor,node_tag)){lease.revoke();return fail();}
  ++stats.anchor_reads;GDExtensionBool inside=false,shown=false,process=false;ptrcall(particle_frame_group::inside_tree,anchor,nullptr,&inside);if(inside){ptrcall(particle_frame_group::visible_in_tree,anchor,nullptr,&shown);if(shown)ptrcall(particle_frame_group::can_process,anchor,nullptr,&process);}lease.cached_eligible=inside&&shown&&process;lease.cached_call=frame->call;lease.cached_mutation=mutation.revision.value;
 }
 ++stats.hits;return lease.cached_eligible;
}
EngineVar inspect(const Stats& stats){auto out=EngineVar::dictionary();const auto number=[&](const char* name,uint64_t value){::set(out,name,EngineVar::integer(static_cast<int64_t>(value)));};number("attempts",stats.attempts);number("hits",stats.hits);number("anchor_reads",stats.anchor_reads);number("endpoint_validations",stats.endpoint_validations);number("structural_checks",stats.structural_checks);number("fallbacks",stats.fallbacks);::set(out,"invalidated",EngineVar::boolean(stats.invalidated));return out;}
struct Owner {GDExtensionObjectPtr object=nullptr;std::shared_ptr<Lease> lease;};
std::mutex registry_mutex;std::unordered_map<GDExtensionObjectPtr,Owner*> registry;
Owner* find(const EngineVar& value){if(value.type()!=GDEXTENSION_VARIANT_TYPE_OBJECT)return nullptr;GDExtensionObjectPtr object=nullptr;to[GDEXTENSION_VARIANT_TYPE_OBJECT](&object,const_cast<uint8_t*>(value.data));std::lock_guard<std::mutex> lock(registry_mutex);const auto found=registry.find(object);return found==registry.end()?nullptr:found->second;}
GDExtensionObjectPtr create(void*,GDExtensionBool notify){Name base("RefCounted"),name("NwnParticleEligibilityLease");auto object=construct_object(base.data);auto* owner=new Owner();owner->object=object;set_instance(object,name.data,owner);{std::lock_guard<std::mutex> lock(registry_mutex);registry.emplace(object,owner);}if(notify){EngineVar value;destroy(value.data);from[GDEXTENSION_VARIANT_TYPE_OBJECT](value.data,&object);::method(value,"notification",{EngineVar::integer(0)});}return object;}
void free(void*,GDExtensionClassInstancePtr instance){auto* owner=static_cast<Owner*>(instance);if(owner->lease)owner->lease->revoke();{std::lock_guard<std::mutex> lock(registry_mutex);registry.erase(owner->object);}delete owner;}
void bind(void*,GDExtensionClassInstancePtr,const GDExtensionConstVariantPtr* args,GDExtensionInt count,GDExtensionVariantPtr result,GDExtensionCallError* error){
 if(!native_managed_pose::count_ok(count,4,result,error))return;bool ok=false;EngineVar token(args[0]),scope(args[1]),anchor(args[2]),source(args[3]);auto* owner=find(token);auto* context=native_managed_pose::find(scope);const auto anchor_id=native_managed_pose::live_node_id(anchor),source_id=native_managed_pose::live_node_id(source);
 if(main_caller()&&owner&&!owner->lease&&context&&context->scope&&context->scope->usable()&&anchor_id&&source_id&&native_managed_pose::parent_id(source_id)==anchor_id&&native_managed_pose::ancestor(anchor_id,context->scope->owner_id)&&main_group(anchor_id)){owner->lease=std::make_shared<Lease>();owner->lease->scope=context->scope;owner->lease->anchor=anchor_id;owner->lease->source=source_id;owner->lease->identity=native_managed_pose::object_id(owner->object);owner->lease->checked_mutation=nwn_managed_pose::callbacks.revision.value;ok=true;}auto out=EngineVar::boolean(ok);new_copy(result,out.data);
}
void attach(void*,GDExtensionClassInstancePtr,const GDExtensionConstVariantPtr* args,GDExtensionInt count,GDExtensionVariantPtr result,GDExtensionCallError* error){
 if(!native_managed_pose::count_ok(count,3,result,error))return;bool ok=false;EngineVar token(args[0]),value(args[1]),emitter(args[2]);auto* grant=find(token);resident::Owner* owner=nullptr;
 if(value.type()==GDEXTENSION_VARIANT_TYPE_OBJECT){GDExtensionObjectPtr object=nullptr;to[GDEXTENSION_VARIANT_TYPE_OBJECT](&object,value.data);std::lock_guard<std::mutex> lock(resident::owner_registry_mutex);const auto found=resident::owner_registry.find(object);if(found!=resident::owner_registry.end())owner=found->second;}
 const auto id=native_managed_pose::live_node_id(emitter);if(main_caller()&&grant&&grant->lease&&grant->lease->active&&owner&&owner->configured&&owner->typed_frame&&owner->source_id==grant->lease->source&&id&&native_managed_pose::parent_id(id)==owner->pose_id){auto endpoint=std::make_shared<Endpoint>();endpoint->id=id;endpoint->lease=grant->lease;endpoint->checked_mutation=nwn_managed_pose::callbacks.revision.value;if(capture(*endpoint)){owner->managed_eligibility=std::move(endpoint);++grant->lease->attached_total;ok=true;}}auto out=EngineVar::boolean(ok);new_copy(result,out.data);
}
void revoke(void*,GDExtensionClassInstancePtr,const GDExtensionConstVariantPtr* args,GDExtensionInt count,GDExtensionVariantPtr result,GDExtensionCallError* error){if(!native_managed_pose::count_ok(count,1,result,error))return;EngineVar value(args[0]);auto* owner=find(value);if(owner&&owner->lease)owner->lease->revoke();new_nil(result);}
void snapshot(void*,GDExtensionClassInstancePtr instance,const GDExtensionConstVariantPtr*,GDExtensionInt count,GDExtensionVariantPtr result,GDExtensionCallError* error){if(!native_managed_pose::count_ok(count,0,result,error))return;const auto& owner=*static_cast<Owner*>(instance);auto out=EngineVar::dictionary();::set(out,"active",EngineVar::boolean(owner.lease&&owner.lease->active&&owner.lease->scope&&owner.lease->scope->usable()));::set(out,"attached_total",EngineVar::integer(owner.lease?static_cast<int64_t>(owner.lease->attached_total):0));::set(out,"enum_return_bytes",EngineVar::integer(sizeof(GDExtensionInt)));::set(out,"enum_abi_calls",EngineVar::integer(static_cast<int64_t>(enum_abi_calls.load(std::memory_order_relaxed))));::set(out,"enum_abi_failures",EngineVar::integer(static_cast<int64_t>(enum_abi_failures.load(std::memory_order_relaxed))));new_copy(result,out.data);}
template<class Property>void register_owner(const Property& property){
 Name node("Node"),node3d("Node3D"),visible("is_visible"),process("get_process_mode"),group("get_process_thread_group"),os_name("OS"),caller("get_thread_caller_id"),main("get_main_thread_id");node_class_tag=class_tag(node.data);local_visible=class_method(node3d.data,visible.data,36873697);process_mode=class_method(node.data,process.data,739966102);thread_group=class_method(node.data,group.data,1866404740);caller_thread=class_method(os_name.data,caller.data,3905245786);main_thread=class_method(os_name.data,main.data,3905245786);os=global_singleton(os_name.data);if(!node_class_tag||!local_visible||!process_mode||!thread_group||!caller_thread||!main_thread||!os)return;
 Name name("NwnParticleEligibilityLease"),base("RefCounted"),empty(""),arg0("token"),arg1("scope_or_owner"),arg2("anchor_or_emitter"),arg3("source"),bind_name("bind"),attach_name("attach"),revoke_name("revoke"),snap("snapshot");GDExtensionClassCreationInfo6 info{};info.is_exposed=true;info.is_runtime=true;info.create_instance_func=create;info.free_instance_func=free;register_class(library,name.data,base.data,&info);registered=true;
 auto boolean=property(GDEXTENSION_VARIANT_TYPE_BOOL,empty),dictionary=property(GDEXTENSION_VARIANT_TYPE_DICTIONARY,empty);std::array<GDExtensionPropertyInfo,4> arguments{property(GDEXTENSION_VARIANT_TYPE_OBJECT,arg0),property(GDEXTENSION_VARIANT_TYPE_OBJECT,arg1),property(GDEXTENSION_VARIANT_TYPE_OBJECT,arg2),property(GDEXTENSION_VARIANT_TYPE_OBJECT,arg3)};std::array<GDExtensionClassMethodArgumentMetadata,4> metadata{};GDExtensionClassMethodInfo m{};m.method_flags=GDEXTENSION_METHOD_FLAG_NORMAL|GDEXTENSION_METHOD_FLAG_STATIC;m.has_return_value=true;m.return_value_info=&boolean;m.arguments_info=arguments.data();m.arguments_metadata=metadata.data();m.argument_count=4;m.name=bind_name.data;m.call_func=bind;register_method(library,name.data,&m);m.argument_count=3;m.name=attach_name.data;m.call_func=attach;register_method(library,name.data,&m);m.argument_count=1;m.name=revoke_name.data;m.call_func=revoke;m.has_return_value=false;m.return_value_info=nullptr;register_method(library,name.data,&m);m.method_flags=GDEXTENSION_METHOD_FLAG_NORMAL;m.argument_count=0;m.name=snap.data;m.call_func=snapshot;m.has_return_value=true;m.return_value_info=&dictionary;register_method(library,name.data,&m);
}
void unregister_owner(){if(registered){Name name("NwnParticleEligibilityLease");unregister_class(library,name.data);registered=false;}}
} // namespace native_managed_eligibility
