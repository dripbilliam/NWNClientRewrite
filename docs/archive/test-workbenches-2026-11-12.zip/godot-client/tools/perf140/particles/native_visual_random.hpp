// Private experiment: one original CRT visual stream shared by native frames,
// GD fallback emitters, wind and projectile callers. No scene ownership.
namespace native_visual_random {
GDExtensionInterfaceObjectMethodBindCall fixed_call=nullptr;
GDExtensionInterfaceClassdbRegisterExtensionClassProperty register_property=nullptr;
GDExtensionInterfaceVariantGetPtrOperatorEvaluator operators=nullptr;
GDExtensionMethodBindPtr object_script=nullptr;
GDExtensionPtrBuiltInMethod callable_custom=nullptr,callable_object_id=nullptr,callable_method=nullptr;
GDExtensionPtrOperatorEvaluator name_equal=nullptr;
std::unique_ptr<Name> next_name;
bool registered=false;
struct Owner {
 GDExtensionObjectPtr object=nullptr;
 int64_t state=1,draws=0;uint64_t direct_hits=0,script_checks=0;
 int64_t next(){const uint32_t n=static_cast<uint32_t>(state)*uint32_t{0x343fd}+uint32_t{0x269ec3};state=static_cast<int64_t>(n);const uint64_t count=static_cast<uint64_t>(draws)+1;std::memcpy(&draws,&count,8);return static_cast<int64_t>((n>>16)&0x7fff);}
 void seed(int64_t value){state=static_cast<int64_t>(static_cast<uint32_t>(value));draws=0;}
};
std::mutex registry_mutex;
std::unordered_map<GDExtensionObjectPtr,Owner*> registry;

bool try_draw(const EngineVar& callable,int64_t& result){
 if(!registered||callable.type()!=GDEXTENSION_VARIANT_TYPE_CALLABLE)return false;
 alignas(8) uint8_t raw[16];to[GDEXTENSION_VARIANT_TYPE_CALLABLE](raw,const_cast<uint8_t*>(callable.data));
 struct CallableGuard{void* raw;~CallableGuard(){ptr_destructor(GDEXTENSION_VARIANT_TYPE_CALLABLE)(raw);}}guard{raw};
 GDExtensionBool custom=false;callable_custom(raw,nullptr,&custom,0);if(custom)return false;
 int64_t id=0;callable_object_id(raw,nullptr,&id,0);if(!id)return false;
 auto object=instance_from_id(static_cast<uint64_t>(id));if(!object)return false;
 Owner* owner=nullptr;{std::lock_guard<std::mutex> lock(registry_mutex);auto found=registry.find(object);if(found==registry.end())return false;owner=found->second;}
 alignas(8) uint8_t method[8];ptr_constructor(GDEXTENSION_VARIANT_TYPE_STRING_NAME,0)(method,nullptr);callable_method(raw,nullptr,method,0);
 struct MethodGuard{void* raw;~MethodGuard(){ptr_destructor(GDEXTENSION_VARIANT_TYPE_STRING_NAME)(raw);}}method_guard{method};
 GDExtensionBool same=false;name_equal(method,next_name->data,&same);if(!same)return false;
 // Fixed nonvirtual Object binding, not a scripted `get_script` call. Reject
 // ANY attached script. Standard/native identity alone is insufficient when
 // a script overrides next(), including same-call replacement callbacks.
 EngineVar script;destroy(script.data);GDExtensionCallError error{};
 fixed_call(object_script,object,nullptr,0,script.data,&error);++owner->script_checks;
 if(error.error!=GDEXTENSION_CALL_OK||!script.nil())return false;
 result=owner->next();++owner->direct_hits;return true;
}

GDExtensionObjectPtr create(void*,GDExtensionBool notify){Name base("RefCounted"),name("NwnVisualRandom");auto object=construct_object(base.data);auto* owner=new Owner();owner->object=object;set_instance(object,name.data,owner);{std::lock_guard<std::mutex> lock(registry_mutex);registry.emplace(object,owner);}if(notify){EngineVar value;destroy(value.data);from[GDEXTENSION_VARIANT_TYPE_OBJECT](value.data,&object);method(value,"notification",{EngineVar::integer(0)});}return object;}
void free(void*,GDExtensionClassInstancePtr instance){auto* owner=static_cast<Owner*>(instance);{std::lock_guard<std::mutex> lock(registry_mutex);registry.erase(owner->object);}delete owner;}
bool count_ok(GDExtensionInt actual,GDExtensionInt expected,GDExtensionVariantPtr out,GDExtensionCallError* error){error->error=GDEXTENSION_CALL_OK;if(actual==expected)return true;error->error=actual<expected?GDEXTENSION_CALL_ERROR_TOO_FEW_ARGUMENTS:GDEXTENSION_CALL_ERROR_TOO_MANY_ARGUMENTS;error->expected=static_cast<int32_t>(expected);new_nil(out);return false;}
void next_call(void*,GDExtensionClassInstancePtr instance,const GDExtensionConstVariantPtr*,GDExtensionInt count,GDExtensionVariantPtr result,GDExtensionCallError* error){if(!count_ok(count,0,result,error))return;auto out=EngineVar::integer(static_cast<Owner*>(instance)->next());new_copy(result,out.data);}
void get_state(void*,GDExtensionClassInstancePtr instance,const GDExtensionConstVariantPtr*,GDExtensionInt count,GDExtensionVariantPtr result,GDExtensionCallError* error){if(!count_ok(count,0,result,error))return;auto out=EngineVar::integer(static_cast<Owner*>(instance)->state);new_copy(result,out.data);}
void get_draws(void*,GDExtensionClassInstancePtr instance,const GDExtensionConstVariantPtr*,GDExtensionInt count,GDExtensionVariantPtr result,GDExtensionCallError* error){if(!count_ok(count,0,result,error))return;auto out=EngineVar::integer(static_cast<Owner*>(instance)->draws);new_copy(result,out.data);}
void write(void* kind,GDExtensionClassInstancePtr instance,const GDExtensionConstVariantPtr* args,GDExtensionInt count,GDExtensionVariantPtr result,GDExtensionCallError* error){if(!count_ok(count,1,result,error))return;if(get_type(args[0])!=GDEXTENSION_VARIANT_TYPE_INT){error->error=GDEXTENSION_CALL_ERROR_INVALID_ARGUMENT;error->argument=0;error->expected=GDEXTENSION_VARIANT_TYPE_INT;new_nil(result);return;}EngineVar value(args[0]);auto& owner=*static_cast<Owner*>(instance);const auto operation=reinterpret_cast<uintptr_t>(kind);if(operation==0)owner.state=value.integer();else if(operation==1)owner.draws=value.integer();else owner.seed(value.integer());new_nil(result);}
void snapshot(void*,GDExtensionClassInstancePtr instance,const GDExtensionConstVariantPtr*,GDExtensionInt count,GDExtensionVariantPtr result,GDExtensionCallError* error){if(!count_ok(count,0,result,error))return;const auto& owner=*static_cast<Owner*>(instance);auto out=EngineVar::dictionary();::set(out,"state",EngineVar::integer(owner.state));::set(out,"draws",EngineVar::integer(owner.draws));::set(out,"direct_hits",EngineVar::integer(static_cast<int64_t>(owner.direct_hits)));::set(out,"script_checks",EngineVar::integer(static_cast<int64_t>(owner.script_checks)));new_copy(result,out.data);}

template<typename Property>void register_owner(const Property& property){
 if(!fixed_call||!register_property||!operators)return;
 Name object("Object"),script("get_script"),custom("is_custom"),id("get_object_id"),method_name("get_method");
 object_script=class_method(object.data,script.data,1214101251);callable_custom=builtin_method(GDEXTENSION_VARIANT_TYPE_CALLABLE,custom.data,3918633141);callable_object_id=builtin_method(GDEXTENSION_VARIANT_TYPE_CALLABLE,id.data,3173160232);callable_method=builtin_method(GDEXTENSION_VARIANT_TYPE_CALLABLE,method_name.data,1825232092);name_equal=operators(GDEXTENSION_VARIANT_OP_EQUAL,GDEXTENSION_VARIANT_TYPE_STRING_NAME,GDEXTENSION_VARIANT_TYPE_STRING_NAME);
 if(!object_script||!callable_custom||!callable_object_id||!callable_method||!name_equal)return;
 next_name=std::make_unique<Name>("next");Name name("NwnVisualRandom"),base("RefCounted"),empty(""),next("next"),state("state"),draws("draws"),state_get("get_state"),draws_get("get_draws"),state_set("set_state"),draws_set("set_draws"),seed("seed_value"),snap("snapshot"),value("value");
 GDExtensionClassCreationInfo6 info{};info.is_exposed=true;info.is_runtime=true;info.create_instance_func=create;info.free_instance_func=free;register_class(library,name.data,base.data,&info);registered=true;
 auto integer=property(GDEXTENSION_VARIANT_TYPE_INT,empty);GDExtensionClassMethodInfo m{};m.method_flags=GDEXTENSION_METHOD_FLAG_NORMAL;m.has_return_value=true;m.return_value_info=&integer;m.name=next.data;m.call_func=next_call;register_method(library,name.data,&m);m.name=state_get.data;m.call_func=get_state;register_method(library,name.data,&m);m.name=draws_get.data;m.call_func=get_draws;register_method(library,name.data,&m);
 auto dictionary=property(GDEXTENSION_VARIANT_TYPE_DICTIONARY,empty);m.name=snap.data;m.call_func=snapshot;m.return_value_info=&dictionary;register_method(library,name.data,&m);
 GDExtensionPropertyInfo arg=property(GDEXTENSION_VARIANT_TYPE_INT,value);GDExtensionClassMethodArgumentMetadata metadata{};m.has_return_value=false;m.return_value_info=nullptr;m.argument_count=1;m.arguments_info=&arg;m.arguments_metadata=&metadata;m.call_func=write;m.name=state_set.data;m.method_userdata=nullptr;register_method(library,name.data,&m);m.name=draws_set.data;m.method_userdata=reinterpret_cast<void*>(uintptr_t{1});register_method(library,name.data,&m);m.name=seed.data;m.method_userdata=reinterpret_cast<void*>(uintptr_t{2});register_method(library,name.data,&m);
 auto state_property=property(GDEXTENSION_VARIANT_TYPE_INT,state),draws_property=property(GDEXTENSION_VARIANT_TYPE_INT,draws);register_property(library,name.data,&state_property,state_set.data,state_get.data);register_property(library,name.data,&draws_property,draws_set.data,draws_get.data);
}
void unregister_owner(){if(registered){Name name("NwnVisualRandom");unregister_class(library,name.data);registered=false;}next_name.reset();}
}
