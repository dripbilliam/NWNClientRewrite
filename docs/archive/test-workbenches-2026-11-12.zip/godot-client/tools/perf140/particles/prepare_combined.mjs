// Combine only independently pinned/tested source reductions. Frozen parents
// remain separate. The paired baseline remains the original light-input-v3.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {fileURLToPath} from 'node:url';
const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..'),label=process.argv[2],base=path.join(project,'.cache/native-140fps/particles-agent'),hash=b=>crypto.createHash('sha256').update(b).digest('hex');if(!/^[a-z0-9-]+$/.test(label??''))throw Error('Fresh combined candidate label required');
const parents=['frame-pose-epochs-v2','controls-copy-v1','live-common-input-v1'].map(name=>{const file=path.join(base,name,'candidate-built-sources.json'),receipt=JSON.parse(fs.readFileSync(file));if(!receipt.isolatedBuildFinalized)throw Error('Parent not finalized');for(const pin of receipt.sourcePins)if(hash(fs.readFileSync(path.join(receipt.sourceProject,pin.relative)))!==pin.sha256)throw Error('Parent pin differs: '+name+'/'+pin.relative);return {name,file,sha256:hash(fs.readFileSync(file)),receipt};});
const stage=path.join(base,label);if(fs.existsSync(stage))throw Error('Existing combined candidate preserved');
const baselineFile=path.join(base,parents[0].name,'baseline-sources.json'),baseline=JSON.parse(fs.readFileSync(baselineFile));for(const pin of baseline.sourcePins)if(hash(fs.readFileSync(path.join(baseline.sourceProject,pin.relative)))!==pin.sha256)throw Error('Baseline differs');fs.mkdirSync(stage);
const once=(s,a,b)=>{if(s.split(a).length!==2)throw Error('Combined boundary differs: '+a.slice(0,90));return s.replace(a,b);};
for(const variant of ['baseline','candidate']){
 const original=variant==='baseline'?baseline:parents[0].receipt,copy=path.join(stage,variant),pins=[];fs.mkdirSync(copy);const overrides=variant==='baseline'?[]:original.overrides.map(p=>({...p}));
 for(const pin of original.sourcePins){const raw=fs.readFileSync(path.join(original.sourceProject,pin.relative)),destination=path.join(copy,pin.relative);fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,raw);if(hash(fs.readFileSync(destination))!==pin.sha256)throw Error('Combined copy differs');pins.push({...pin});}
 if(variant==='candidate'){
  const relative='native/particle_presentation.hpp',file=path.join(copy,relative);let s=fs.readFileSync(file,'utf8').replaceAll('\r\n','\n');
  s=once(s,' bool enabled=true,source_animating=false;',' bool enabled=true,source_animating=false,reuse_controls=true,direct_animating=true;');
  s=once(s,'  if(::has(config,"enabled"))entry.enabled=::get(config,"enabled").boolean();','  if(::has(config,"reuse_controls"))entry.reuse_controls=::get(config,"reuse_controls").boolean();\n  if(::has(config,"direct_animating"))entry.direct_animating=::get(config,"direct_animating").boolean();\n  if(::has(config,"enabled"))entry.enabled=::get(config,"enabled").boolean();');
  s=once(s,'entry.elapsed+=delta;auto next=entry.controls;','entry.elapsed+=delta;std::optional<Controls> copied_controls;auto& next=entry.reuse_controls?entry.controls:copied_controls.emplace(entry.controls);');
  s=once(s,'struct Controls {',`// Read live for each entry: an opaque callback may mutate common controls.
bool common_animating(const EngineVar& common){EngineVar value;destroy(value.data);GDExtensionBool present=false;get_keyed(common.data,::key("animating").data,value.data,&present);return !present||value.boolean();}
struct Controls {`);
  s=once(s,'next.animate=!::has(common,"animating")||::get(common,"animating").boolean()||(entry.source_key&&entry.source_animating);','next.animate=(entry.direct_animating?common_animating(common):(!::has(common,"animating")||::get(common,"animating").boolean()))||(entry.source_key&&entry.source_animating);');
  s=once(s,'const auto& e=*found->second;::set(out,"fast",','const auto& e=*found->second;::set(out,"reuse_controls",EngineVar::boolean(e.reuse_controls));::set(out,"direct_animating",EngineVar::boolean(e.direct_animating));::set(out,"fast",');
  fs.writeFileSync(file,s);const sha256=hash(fs.readFileSync(file));Object.assign(pins.find(p=>p.relative===relative),{sha256,bytes:Buffer.byteLength(s)});Object.assign(overrides.find(p=>p.relative===relative),{sha256,reason:'Combined independently gated synchronous pose epochs, intermediate Controls elision, and live common.animating lookup; same-DLL all-off oracle retained'});
 }
 const receipt={...original,label,variant,sourceProject:copy,sourcePins:pins,overrides,parent:{file:baselineFile,sha256:hash(fs.readFileSync(baselineFile)),renderer:baseline.sourceProject},combinedParents:parents.map(({name,file,sha256})=>({name,file,sha256})),sharedNativeBuilds:0,scope:'Private combination of three independently native-validated particle candidates; no shared outputs or graphical acceptance.'};delete receipt.isolatedBuildFinalized;delete receipt.build;delete receipt.prebuildReceipt;fs.writeFileSync(path.join(stage,variant+'-sources.json'),JSON.stringify(receipt,null,2)+'\n');
}
console.log(JSON.stringify({success:true,label,stage,combined:true,parents:parents.map(p=>p.name),sharedNativeBuilds:0}));
