// Private cache-index experiment. Run only after Root grants a CPU/copy slot.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url)),project=path.resolve(here,'../../..'),base=path.join(project,'.cache/native-140fps/particles-agent'),label=process.argv[2],hash=b=>crypto.createHash('sha256').update(b).digest('hex');
if(!/^[a-z0-9-]+$/.test(label??''))throw Error('Fresh endpoint-slot label required');
const parentFile=path.join(base,'managed-pose-leases-v1/candidate-built-sources.json'),parent=JSON.parse(fs.readFileSync(parentFile)),stage=path.join(base,label);
if(fs.existsSync(stage))throw Error('Previous evidence preserved');
if(hash(fs.readFileSync(parentFile))!=='20fab7baae2500eb4e45a95e77da68a2f4f913b52fe252666e1f2fa81a1afd14')throw Error('Reviewed managed parent receipt differs');
for(const pin of parent.sourcePins)if(hash(fs.readFileSync(path.join(parent.sourceProject,pin.relative)))!==pin.sha256)throw Error('Frozen parent differs: '+pin.relative);
fs.mkdirSync(stage);
const once=(s,a,b)=>{if(s.split(a).length!==2)throw Error('Endpoint slot boundary differs: '+a.slice(0,140));return s.replace(a,b);};
const pure=path.join(stage,'pure');fs.mkdirSync(pure);
const pureSources=[['native_perf140_particle_endpoint_slot_test.cpp',path.join(here,'native_perf140_particle_endpoint_slot_test.cpp')],['endpoint_frame_pose_cache.hpp',path.join(here,'endpoint_frame_pose_cache.hpp')],['endpoint_slot_cache.hpp',path.join(here,'endpoint_slot_cache.hpp')],['oracle_frame_pose_cache.hpp',path.join(parent.sourceProject,'native/experimental/frame_pose_cache.hpp')],['managed_pose_lease_policy.hpp',path.join(parent.sourceProject,'native/experimental/managed_pose_lease_policy.hpp')]];
const purePins=pureSources.map(([relative,source])=>{const bytes=fs.readFileSync(source);fs.writeFileSync(path.join(pure,relative),bytes);return{relative,sha256:hash(bytes),bytes:bytes.length};});
for(const variant of ['baseline','candidate']){
 const copy=path.join(stage,variant),pins=[],overrides=variant==='candidate'?parent.overrides.map(row=>({...row})):[];fs.mkdirSync(copy);
 for(const pin of parent.sourcePins){const bytes=fs.readFileSync(path.join(parent.sourceProject,pin.relative)),destination=path.join(copy,pin.relative);fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,bytes);pins.push({...pin});}
 const load=relative=>fs.readFileSync(path.join(copy,relative),'utf8').replaceAll('\r\n','\n');
 const install=(relative,source,reason)=>{const destination=path.join(copy,relative);fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,source);const record={relative,sha256:hash(fs.readFileSync(destination)),bytes:Buffer.byteLength(source)},pin=pins.find(row=>row.relative===relative);if(pin)Object.assign(pin,record);else pins.push(record);let override=overrides.find(row=>row.relative===relative);if(!override){override={relative};overrides.push(override);}Object.assign(override,{sha256:record.sha256,reason});};
 if(variant==='candidate'){
  install('native/experimental/endpoint_slot_cache.hpp',fs.readFileSync(path.join(here,'endpoint_slot_cache.hpp'),'utf8'),'Same-owned-row integer index/generation handles; no retained Node or row pointer; bounded free-list reuse');
  install('native/experimental/frame_pose_cache.hpp',fs.readFileSync(path.join(here,'endpoint_frame_pose_cache.hpp'),'utf8'),'Optional indexed storage with original ordinary cache/default; lease/witness/source-read ordering unchanged');
  let s=load('native/particle_resident.hpp');
  s=once(s,'explicit FramePoseScope(FramePoseCache& cache,size_t expected):','explicit FramePoseScope(FramePoseCache& cache,size_t expected,bool indexed=false):');
  s=once(s,'cache.begin(expected);active_frame_pose_cache=','cache.begin(expected,indexed);active_frame_pose_cache=');
  s=once(s,'const std::shared_ptr<nwn_managed_pose::Lease>& managed={}){','const std::shared_ptr<nwn_managed_pose::Lease>& managed={},FramePoseCache::Handle* slot=nullptr){');
  s=once(s,'active_frame_pose_cache->managed_read(id,*managed,read,convert_cached);return active_frame_pose_cache->read(id,read,convert_cached);','active_frame_pose_cache->managed_read(id,*managed,read,convert_cached,slot);return active_frame_pose_cache->read(id,read,convert_cached,slot);');
  s=once(s,'std::shared_ptr<nwn_managed_pose::Lease> managed_lease;','std::shared_ptr<nwn_managed_pose::Lease> managed_lease;FramePoseCache::Handle pose_slot,source_slot;');
  s=once(s,'share_frame_pose,managed_lease);','share_frame_pose,managed_lease,source?&source_slot:&pose_slot);');
  install('native/particle_resident.hpp',s,'Keep live ID/type and managed allowance predicates verbatim; pass nonowning integer handles into the same active cache');
  s=load('native/particle_presentation.hpp');
  s=once(s,'FramePoseScope frame_pose_scope(frame_pose_cache,entries.size()*2);','FramePoseScope frame_pose_scope(frame_pose_cache,entries.size()*2,::has(common,"pose_slots")&&::get(common,"pose_slots").boolean());');
  if(!s.includes('frame_pose_cache.rows.size()'))throw Error('Expected retained row counter missing');
  s=s.replaceAll('frame_pose_cache.rows.size()','frame_pose_cache.row_count()');
  s=once(s,' void close(){if(running)',` EngineVar endpoint_slot_info()const{
  if(running)throw std::runtime_error("Endpoint slot census requires a complete frame boundary");
  const auto& slots=frame_pose_cache.indexed_rows;auto out=EngineVar::dictionary();
  const auto number=[&](const char* name,uint64_t value){::set(out,name,EngineVar::integer(static_cast<int64_t>(value)));};
  ::set(out,"mode",EngineVar::text(frame_pose_cache.indexed?"indexed":"ordinary"));::set(out,"handles_enabled",EngineVar::boolean(slots.handles_enabled));
  number("retained",frame_pose_cache.row_count());number("ordinary_rows",frame_pose_cache.rows.size());number("indexed_rows",slots.size());number("arena_slots",slots.arena.size());number("arena_capacity",slots.arena.capacity());number("free_slots",slots.free.size());
  number("direct_hits",slots.direct_hits);number("map_lookups",slots.lookups);number("lookup_misses",slots.misses);
  number("handle_bytes",sizeof(FramePoseCache::Handle));number("owner_handle_bytes",sizeof(FramePoseCache::Handle)*2);number("ordinary_row_bytes",sizeof(FramePoseCache::Row));number("indexed_slot_bytes",sizeof(decltype(slots.arena)::value_type));number("arena_payload_bytes",slots.payload_bytes());number("free_capacity_bytes",slots.free_bytes());
  number("native_owner_bytes",sizeof(resident::Owner));number("frame_cache_bytes",sizeof(FramePoseCache));return out;
 }
 void close(){if(running)`);
  s=once(s,'case 13:out=owner.cold_census();break;','case 13:out=owner.cold_census();break;case 17:out=owner.endpoint_slot_info();break;');
  install('native/particle_presentation.hpp',s,'Explicit common-frame mode at existing presentation boundary and cold mode/coverage/footprint readback; no new eligibility or simulation branch');
  s=load('systems/native_render/particle_stream_group.gd');
  s=once(s,'var pooled_lighting:=','var pose_slot_indexes:=OS.get_cmdline_user_args().has("--particle-pose-slots=indexed") or OS.get_environment("NWN_PARTICLE_POSE_SLOTS")=="indexed"\nvar pooled_lighting:=');
  s=once(s,'var input:={"delta":delta,','var input:={"pose_slots":pose_slot_indexes,"delta":delta,');
  install('systems/native_render/particle_stream_group.gd',s,'Optional isolated indexed-pose registration profile; ordinary default retained');
 }
 const receipt={...parent,label,variant,sourceProject:copy,sourcePins:pins,overrides,parent:{file:parentFile,sha256:hash(fs.readFileSync(parentFile)),renderer:parent.sourceProject},pureSourceProject:pure,purePins,scope:'Private optional cache-index storage on managed-pose-v1 only. Original ID/type, lease/scope/topology/callback and fallback checks remain. No typed/manual/eligibility bundle.',sharedNativeBuilds:0};delete receipt.isolatedBuildFinalized;delete receipt.build;delete receipt.prebuildReceipt;fs.writeFileSync(path.join(stage,variant+'-sources.json'),JSON.stringify(receipt,null,2)+'\n');
}
console.log(JSON.stringify({success:true,label,stage,sharedNativeBuilds:0}));
