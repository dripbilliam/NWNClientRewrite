// Explicit typed publication of the existing ModelRigs clock. This owner does
// not advance time, select animations, blend runs or own a model/Node.
namespace native_particle_clock {
GDExtensionInterfaceObjectGetInstanceId object_id=nullptr;
GDExtensionPtrOperatorEvaluator callable_equal=nullptr;
std::unique_ptr<Name> sample_name;
bool registered=false;
enum class Route {ordinary,direct,fallback};
struct Sample {bool valid=false;std::string clip;double time=0;int64_t serial=0;EngineVar fallback;};
struct Owner {
 GDExtensionObjectPtr object=nullptr;uint64_t producer=0;uintptr_t producer_address=0;
 EngineVar original,producer_script;bool bound=false,disabled=false,valid=false;
 std::string clip;double time=0;int64_t serial=0;uint64_t revision=0,direct_reads=0;
};
std::mutex registry_mutex;std::unordered_map<GDExtensionObjectPtr,Owner*> registry;
GDExtensionObjectPtr object_of(const EngineVar& value){if(value.type()!=GDEXTENSION_VARIANT_TYPE_OBJECT)return nullptr;GDExtensionObjectPtr result=nullptr;to[GDEXTENSION_VARIANT_TYPE_OBJECT](&result,const_cast<uint8_t*>(value.data));return result;}
EngineVar script_of(GDExtensionObjectPtr value){EngineVar script;destroy(script.data);GDExtensionCallError error{};native_visual_random::fixed_call(native_visual_random::object_script,value,nullptr,0,script.data,&error);if(error.error!=GDEXTENSION_CALL_OK)throw std::runtime_error("Native clock producer script lookup failed");return script;}
Owner* find(const EngineVar& value){auto object=object_of(value);if(!object)return nullptr;std::lock_guard<std::mutex> lock(registry_mutex);auto found=registry.find(object);return found==registry.end()?nullptr:found->second;}
bool producer_live(const Owner& owner){auto object=instance_from_id(owner.producer);if(!object||reinterpret_cast<uintptr_t>(object)!=owner.producer_address)return false;auto current=script_of(object);return object_of(current)==object_of(owner.producer_script);}
Route read(Owner& owner,Sample& result){if(!owner.bound)return Route::ordinary;if(!owner.disabled&&!producer_live(owner))owner.disabled=true;if(owner.disabled){result.fallback=owner.original;return Route::fallback;}result.valid=owner.valid;if(owner.valid){result.clip=owner.clip;result.time=owner.time;result.serial=owner.serial;}return Route::direct;}
Route try_sample(const EngineVar& callable,Sample& result){
 if(!registered||callable.type()!=GDEXTENSION_VARIANT_TYPE_CALLABLE)return Route::ordinary;
 alignas(8) uint8_t raw[16];to[GDEXTENSION_VARIANT_TYPE_CALLABLE](raw,const_cast<uint8_t*>(callable.data));
 struct Guard{void* raw;~Guard(){ptr_destructor(GDEXTENSION_VARIANT_TYPE_CALLABLE)(raw);}}guard{raw};
 GDExtensionBool custom=false;native_visual_random::callable_custom(raw,nullptr,&custom,0);if(custom)return Route::ordinary;
 int64_t id=0;native_visual_random::callable_object_id(raw,nullptr,&id,0);auto object=instance_from_id(static_cast<uint64_t>(id));if(!object)return Route::ordinary;
 Owner* owner=nullptr;{std::lock_guard<std::mutex> lock(registry_mutex);auto found=registry.find(object);if(found==registry.end())return Route::ordinary;owner=found->second;}
 alignas(8) uint8_t method_name[8];ptr_constructor(GDEXTENSION_VARIANT_TYPE_STRING_NAME,0)(method_name,nullptr);
 struct NameGuard{void* raw;~NameGuard(){ptr_destructor(GDEXTENSION_VARIANT_TYPE_STRING_NAME)(raw);}}name_guard{method_name};
 native_visual_random::callable_method(raw,nullptr,method_name,0);GDExtensionBool same=false;native_visual_random::name_equal(method_name,sample_name->data,&same);if(!same)return Route::ordinary;
 // A consumer script is a real handler, never a purity claim. Let the original
 // opaque callback execute it even when it delegates to this native method.
 if(!script_of(object).nil())return Route::ordinary;
 const auto route=read(*owner,result);if(route==Route::direct)++owner->direct_reads;return route;
}
EngineVar sample(Owner& owner){Sample state;const auto route=read(owner,state);if(route==Route::fallback){if(particle_frame_group::valid_callable(state.fallback))return ::method(state.fallback,"call");return EngineVar::dictionary();}auto out=EngineVar::dictionary();if(route==Route::direct&&state.valid){::set(out,"clip",EngineVar::text(state.clip.c_str()));::set(out,"time",EngineVar::number(state.time));::set(out,"serial",EngineVar::integer(state.serial));}return out;}
GDExtensionObjectPtr create(void*,GDExtensionBool notify){Name base("RefCounted"),name("NwnParticleClock");auto object=construct_object(base.data);auto* owner=new Owner();owner->object=object;set_instance(object,name.data,owner);{std::lock_guard<std::mutex> lock(registry_mutex);registry.emplace(object,owner);}if(notify){EngineVar value;destroy(value.data);from[GDEXTENSION_VARIANT_TYPE_OBJECT](value.data,&object);method(value,"notification",{EngineVar::integer(0)});}return object;}
void free(void*,GDExtensionClassInstancePtr instance){auto* owner=static_cast<Owner*>(instance);{std::lock_guard<std::mutex> lock(registry_mutex);registry.erase(owner->object);}delete owner;}
void sample_call(void*,GDExtensionClassInstancePtr instance,const GDExtensionConstVariantPtr*,GDExtensionInt count,GDExtensionVariantPtr result,GDExtensionCallError* error){if(!particle_upload::count_ok(count,0,result,error))return;try{const auto out=sample(*static_cast<Owner*>(instance));new_copy(result,out.data);}catch(const std::exception& failure){auto out=EngineVar::dictionary();::set(out,"error",EngineVar::text(failure.what()));new_copy(result,out.data);}}
void snapshot(void*,GDExtensionClassInstancePtr instance,const GDExtensionConstVariantPtr*,GDExtensionInt count,GDExtensionVariantPtr result,GDExtensionCallError* error){if(!particle_upload::count_ok(count,0,result,error))return;const auto& owner=*static_cast<Owner*>(instance);auto out=EngineVar::dictionary();::set(out,"bound",EngineVar::boolean(owner.bound));::set(out,"disabled",EngineVar::boolean(owner.disabled));::set(out,"valid",EngineVar::boolean(owner.valid));::set(out,"revision",EngineVar::integer(static_cast<int64_t>(owner.revision)));::set(out,"direct_reads",EngineVar::integer(static_cast<int64_t>(owner.direct_reads)));new_copy(result,out.data);}
void producer_call(void* operation,GDExtensionClassInstancePtr,const GDExtensionConstVariantPtr* args,GDExtensionInt count,GDExtensionVariantPtr result,GDExtensionCallError* error){
 const auto code=reinterpret_cast<uintptr_t>(operation);const auto expected=code==0?3:code==1?5:1;if(!particle_upload::count_ok(count,expected,result,error))return;
 try{EngineVar object(args[0]);auto* owner=find(object);if(!owner)throw std::runtime_error("Native clock publication owner is absent");
  if(code==0){if(owner->bound)throw std::runtime_error("Native clock source binds once");EngineVar producer(args[1]),fallback(args[2]);auto raw=object_of(producer);if(!raw||!particle_frame_group::valid_callable(fallback))throw std::runtime_error("Native clock requires a live producer and fallback");const auto id=object_id(raw);if(!id||instance_from_id(id)!=raw)throw std::runtime_error("Native clock producer identity is absent");auto script=script_of(raw);owner->producer=id;owner->producer_address=reinterpret_cast<uintptr_t>(raw);owner->producer_script=script;owner->original=fallback;owner->bound=true;++owner->revision;
  }else if(code==1){if(!owner->bound)throw std::runtime_error("Native clock publication before source binding");EngineVar clip(args[1]),time(args[2]),serial(args[3]),valid(args[4]);const auto name=engine_string(clip);const auto at=time.number();const auto sequence=serial.integer();const auto present=valid.boolean();owner->clip=name;owner->time=at;owner->serial=sequence;owner->valid=present;++owner->revision;
  }else{owner->disabled=true;++owner->revision;}
  auto out=EngineVar::boolean(true);new_copy(result,out.data);
 }catch(const std::exception&){auto out=EngineVar::boolean(false);new_copy(result,out.data);}
}
template<typename Property>void register_owner(const Property& property){
 if(!object_id||!native_visual_random::registered)return;Name name("NwnParticleClock"),base("RefCounted"),empty(""),sample_method("sample"),snap("snapshot"),bind("bind_source"),publish("publish_fields"),disable("disable"),slot("slot"),producer("producer"),fallback("fallback"),clip("clip"),time("time"),serial("serial"),valid("valid");sample_name=std::make_unique<Name>("sample");
 GDExtensionClassCreationInfo6 info{};info.is_exposed=true;info.is_runtime=true;info.create_instance_func=create;info.free_instance_func=free;register_class(library,name.data,base.data,&info);registered=true;
 auto dictionary=property(GDEXTENSION_VARIANT_TYPE_DICTIONARY,empty),boolean=property(GDEXTENSION_VARIANT_TYPE_BOOL,empty);GDExtensionClassMethodInfo m{};m.method_flags=GDEXTENSION_METHOD_FLAG_NORMAL;m.has_return_value=true;m.return_value_info=&dictionary;m.name=sample_method.data;m.call_func=sample_call;register_method(library,name.data,&m);m.name=snap.data;m.call_func=snapshot;register_method(library,name.data,&m);
 GDExtensionPropertyInfo bind_args[]={property(GDEXTENSION_VARIANT_TYPE_OBJECT,slot),property(GDEXTENSION_VARIANT_TYPE_OBJECT,producer),property(GDEXTENSION_VARIANT_TYPE_CALLABLE,fallback)};GDExtensionPropertyInfo publish_args[]={bind_args[0],property(GDEXTENSION_VARIANT_TYPE_STRING,clip),property(GDEXTENSION_VARIANT_TYPE_FLOAT,time),property(GDEXTENSION_VARIANT_TYPE_INT,serial),property(GDEXTENSION_VARIANT_TYPE_BOOL,valid)};GDExtensionClassMethodArgumentMetadata metadata[5]{};m.method_flags=GDEXTENSION_METHOD_FLAG_NORMAL|GDEXTENSION_METHOD_FLAG_STATIC;m.return_value_info=&boolean;m.call_func=producer_call;m.arguments_metadata=metadata;m.name=bind.data;m.argument_count=3;m.arguments_info=bind_args;m.method_userdata=nullptr;register_method(library,name.data,&m);m.name=publish.data;m.argument_count=5;m.arguments_info=publish_args;m.method_userdata=reinterpret_cast<void*>(uintptr_t{1});register_method(library,name.data,&m);m.name=disable.data;m.argument_count=1;m.arguments_info=bind_args;m.method_userdata=reinterpret_cast<void*>(uintptr_t{2});register_method(library,name.data,&m);
}
void unregister_owner(){if(registered){Name name("NwnParticleClock");unregister_class(library,name.data);registered=false;}sample_name.reset();}
}
