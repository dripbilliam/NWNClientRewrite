#pragma once
#include "managed_pose_lease_policy.hpp"
#include "endpoint_slot_cache.hpp"
#include <array>
#include <cmath>
#include <cstdint>
#include <cstddef>
#include <unordered_map>
#include <utility>

// Private index-only cache experiment. Existing ObjectID/type and lease checks
// stay outside this storage exactly as before; no scene pointer is retained.
namespace nwn_frame_pose {
struct Epoch {
 uint64_t value=1,invalidations=0;bool wrapped=false;
 void invalidate(){++value;++invalidations;if(!value){value=1;wrapped=true;}}
};
inline thread_local Epoch* active_epoch=nullptr;
struct CallbackBarrier {
 Epoch* prior;
 CallbackBarrier():prior(active_epoch){nwn_managed_pose::callbacks.enter();if(prior)prior->invalidate();active_epoch=nullptr;}
 ~CallbackBarrier(){nwn_managed_pose::callbacks.leave();active_epoch=prior;if(prior)prior->invalidate();}
 CallbackBarrier(const CallbackBarrier&)=delete;
};
template<typename Pose>struct Cache {
 struct Row {uint64_t epoch=0;Pose pose;nwn_managed_pose::Witness managed;};
 using Handle=nwn_endpoint_slots::Handle;
 Epoch epoch;
 std::unordered_map<uint64_t,Row> rows;
 nwn_endpoint_slots::Slots<Row> indexed_rows;
 bool indexed=false;
 uint64_t hits=0,reads=0,rejected=0,managed_hits=0,managed_refreshes=0,call=0;
 size_t reserved=0;
 void drop_rows(){rows.clear();indexed_rows.clear();}
 void begin(size_t expected,bool use_indexes=false){
  if(indexed!=use_indexes){drop_rows();indexed=use_indexes;reserved=0;}
  call=nwn_managed_pose::next_presentation_call();managed_hits=managed_refreshes=0;
  if(epoch.value==UINT64_MAX||epoch.wrapped){drop_rows();epoch.value=1;epoch.wrapped=false;}else epoch.invalidate();
  epoch.invalidations=0;hits=reads=rejected=0;indexed_rows.reset_counts();
  if(expected>reserved){if(indexed)indexed_rows.reserve(expected);else rows.reserve(expected);reserved=expected;}
 }
 size_t row_count()const noexcept{return indexed?indexed_rows.size():rows.size();}
 void erase(uint64_t id){rows.erase(id);indexed_rows.erase(id);}
 void clear(){drop_rows();reserved=0;hits=reads=rejected=0;}
 Row* lookup(uint64_t id,Handle* handle){
  if(indexed)return indexed_rows.find(id,handle);
  const auto found=rows.find(id);return found==rows.end()?nullptr:&found->second;
 }
 void assign(uint64_t id,Row value,Handle* handle){
  if(indexed)indexed_rows.insert_or_assign(id,std::move(value),handle);
  else rows.insert_or_assign(id,std::move(value));
 }
 template<typename Read,typename Convert>Pose managed_read(uint64_t id,const nwn_managed_pose::Lease& lease,Read&& source,Convert&& convert,Handle* handle=nullptr){
  auto* found=lookup(id,handle);
  if(found&&lease.accepts(found->managed,nwn_managed_pose::callbacks)){++hits;++managed_hits;found->epoch=epoch.value;return found->pose;}
  ++managed_refreshes;const auto value=read(id,std::forward<Read>(source),std::forward<Convert>(convert),handle);
  found=lookup(id,handle);if(found)found->managed=lease.witness(nwn_managed_pose::callbacks);return value;
 }
 template<typename Read,typename Convert>Pose read(uint64_t id,Read&& source,Convert&& convert,Handle* handle=nullptr){
  if(epoch.wrapped){drop_rows();epoch.wrapped=false;}
  const auto* found=lookup(id,handle);
  if(found&&found->epoch==epoch.value){++hits;return found->pose;}
  ++reads;const auto raw=source();const auto value=convert(raw);
  bool finite=true;for(const auto word:raw)finite=finite&&std::isfinite(word);
  if(finite)assign(id,Row{epoch.value,value,{}},handle);
  else{++rejected;erase(id);if(handle)handle->clear();}
  return value;
 }
};
} // namespace nwn_frame_pose
