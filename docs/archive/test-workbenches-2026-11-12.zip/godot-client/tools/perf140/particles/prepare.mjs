import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {fileURLToPath} from 'node:url';
const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..');
const label=process.argv[2];if(!/^[a-z0-9-]+$/.test(label??''))throw Error('Fresh particle experiment label required');
const stage=path.join(project,'.cache/native-140fps/particles-agent',label);
if(fs.existsSync(stage))throw Error('Existing experiment preserved');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const parentFile=path.join(project,'reports/native-movement-recording-latest.json'),launch=JSON.parse(fs.readFileSync(parentFile));
const overlayFile=process.argv[3]?path.resolve(process.argv[3]):launch.overlay,overlay=JSON.parse(fs.readFileSync(overlayFile));
const normalize=b=>b.toString().replaceAll('\r\n','\n');
const once=(s,a,b)=>{if(s.split(a).length!==2)throw Error('Particle boundary differs: '+a.slice(0,70));return s.replace(a,b);};
for(const pin of overlay.trialPins)if(hash(fs.readFileSync(path.join(overlay.rendererProject,pin.relative)))!==pin.sha256)throw Error('Parent changed: '+pin.relative);
fs.mkdirSync(stage,{recursive:true});
for(const variant of ['baseline','candidate']){
 const copy=path.join(stage,variant),pins=[];fs.mkdirSync(copy);
 for(const pin of overlay.trialPins){const bytes=fs.readFileSync(path.join(overlay.rendererProject,pin.relative)),destination=path.join(copy,pin.relative);fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,bytes);pins.push({relative:pin.relative,sha256:hash(bytes),bytes:bytes.length});}
 const overrides=[];
 const install=(relative,bytes,reason)=>{if(typeof bytes==='string')bytes=Buffer.from(bytes);const destination=path.join(copy,relative);fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,bytes);let pin=pins.find(p=>p.relative===relative);if(!pin){pin={relative};pins.push(pin);}pin.sha256=hash(bytes);pin.bytes=bytes.length;overrides.push({relative,sha256:pin.sha256,reason});};
 if(variant==='candidate'){
  install('native/experimental/frame_pose_cache.hpp',fs.readFileSync(path.join(project,'tools/perf140/particles/frame_pose_cache.hpp')),'Private synchronous pose sharing, invalidated around arbitrary script callbacks');
  let cpp=normalize(fs.readFileSync(path.join(copy,'native/particle_kernel.cpp')));
  cpp=once(cpp,'#include "experimental/particle_pose_cache.hpp"','#include "experimental/particle_pose_cache.hpp"\n#include "experimental/frame_pose_cache.hpp"');install('native/particle_kernel.cpp',cpp,'Private frame cache helper include');
  let resident=normalize(fs.readFileSync(path.join(copy,'native/particle_resident.hpp')));
  const marker='EnginePose read_engine_pose(uint64_t id,particle_pose_cache::Conversion<EnginePose>* cache=nullptr){';
  resident=once(resident,marker,`using FramePoseCache=nwn_frame_pose::Cache<EnginePose>;
thread_local FramePoseCache* active_frame_pose_cache=nullptr;
struct FramePoseScope {
 FramePoseCache* prior; nwn_frame_pose::Epoch* prior_epoch;
 explicit FramePoseScope(FramePoseCache& cache,size_t expected):prior(active_frame_pose_cache),prior_epoch(nwn_frame_pose::active_epoch){cache.begin(expected);active_frame_pose_cache=&cache;nwn_frame_pose::active_epoch=&cache.epoch;}
 ~FramePoseScope(){active_frame_pose_cache=prior;nwn_frame_pose::active_epoch=prior_epoch;}
};
EnginePose read_engine_pose(uint64_t id,particle_pose_cache::Conversion<EnginePose>* cache=nullptr,bool share_frame=true){`);
  resident=once(resident,' alignas(8) std::array<float,12> transform{};ptrcall(node_transform,object,nullptr,transform.data());',' const auto read=[object](){alignas(8) std::array<float,12> transform{};ptrcall(node_transform,object,nullptr,transform.data());return transform;};');
  resident=once(resident,' return cache?cache->read(id,transform,convert):convert(transform);',' const auto convert_cached=[&](const std::array<float,12>& transform){return cache?cache->read(id,transform,convert):convert(transform);};\n if(share_frame&&cache&&active_frame_pose_cache&&nwn_frame_pose::active_epoch==&active_frame_pose_cache->epoch)return active_frame_pose_cache->read(id,read,convert_cached);\n return convert_cached(read());');
  resident=once(resident,'uint64_t pose_id=0,source_id=0;bool cache_engine_pose=true;','uint64_t pose_id=0,source_id=0;bool cache_engine_pose=true,share_frame_pose=true;');
  resident=once(resident,'EnginePose read_pose(bool source=false){return read_engine_pose(source?source_id:pose_id,cache_engine_pose?(source?&source_cache:&pose_cache):nullptr);}','EnginePose read_pose(bool source=false){return read_engine_pose(source?source_id:pose_id,cache_engine_pose?(source?&source_cache:&pose_cache):nullptr,share_frame_pose);}');
  resident=once(resident,'  cache_engine_pose=!::has(config,"cacheEnginePose")||::get(config,"cacheEnginePose").boolean();','  cache_engine_pose=!::has(config,"cacheEnginePose")||::get(config,"cacheEnginePose").boolean();\n  share_frame_pose=!::has(config,"reuseFramePose")||::get(config,"reuseFramePose").boolean();');
  resident=once(resident,' Name call("call");EngineVar out;destroy(out.data);GDExtensionCallError error{};variant_call(callable.data,call.data,args.data(),static_cast<GDExtensionInt>(args.size()),out.data,&error);',' nwn_frame_pose::CallbackBarrier mutation_barrier;Name call("call");EngineVar out;destroy(out.data);GDExtensionCallError error{};variant_call(callable.data,call.data,args.data(),static_cast<GDExtensionInt>(args.size()),out.data,&error);');
  install('native/particle_resident.hpp',resident,'Keep every live ObjectID/type validation; share only within callback-free synchronous read epochs');
  let presentation=normalize(fs.readFileSync(path.join(copy,'native/particle_presentation.hpp')));
  presentation=once(presentation,' GDExtensionObjectPtr identity=nullptr;',' FramePoseCache frame_pose_cache;\n GDExtensionObjectPtr identity=nullptr;');
  presentation=once(presentation,'  const bool native_surface_output=','  FramePoseScope frame_pose_scope(frame_pose_cache,entries.size()*2);\n  const bool native_surface_output=');
  presentation=once(presentation,'if(!entry.owner){::method(entry.fallback,"call",{EngineVar::number(delta)});++fallbacks;continue;}','if(!entry.owner){nwn_frame_pose::CallbackBarrier mutation_barrier;::method(entry.fallback,"call",{EngineVar::number(delta)});++fallbacks;continue;}');
  presentation=once(presentation,'if(!entry.readiness.nil()){if(!::method(entry.readiness,"call").boolean())continue;entry.readiness=EngineVar();}','if(!entry.readiness.nil()){nwn_frame_pose::CallbackBarrier mutation_barrier;if(!::method(entry.readiness,"call").boolean())continue;entry.readiness=EngineVar();}');
  presentation=once(presentation,'if(particle_frame_group::valid_callable(entry.clock)){auto sampled=','if(particle_frame_group::valid_callable(entry.clock)){nwn_frame_pose::CallbackBarrier mutation_barrier;auto sampled=');
  presentation=once(presentation,' void erase(int64_t id){if(running)throw std::runtime_error("Native presentation removal requires a frame boundary");entries.erase(id);',' void erase(int64_t id){if(running)throw std::runtime_error("Native presentation removal requires a frame boundary");auto found=entries.find(id);if(found!=entries.end()&&found->second->owner){frame_pose_cache.erase(found->second->owner->pose_id);frame_pose_cache.erase(found->second->owner->source_id);}entries.erase(id);');
  presentation=once(presentation,'closed=true;packet.reset();canonical_packet.reset();entries.clear();','closed=true;frame_pose_cache.clear();packet.reset();canonical_packet.reset();entries.clear();');
  presentation=once(presentation,'  auto out=summary();auto layout=','  auto out=summary();auto pose_reads=EngineVar::dictionary();::set(pose_reads,"hits",EngineVar::integer(frame_pose_cache.hits));::set(pose_reads,"reads",EngineVar::integer(frame_pose_cache.reads));::set(pose_reads,"invalidations",EngineVar::integer(frame_pose_cache.epoch.invalidations));::set(pose_reads,"retained",EngineVar::integer(frame_pose_cache.rows.size()));::set(out,"frame_pose_reuse",pose_reads);auto layout=');
  install('native/particle_presentation.hpp',presentation,'Private per-call pose epoch with clock/readiness/fallback mutation barriers and cold diagnostics');
 }
 const receipt={version:1,label,variant,sourceProject:copy,parent:{file:overlayFile,sha256:hash(fs.readFileSync(overlayFile)),renderer:overlay.rendererProject},sourcePins:pins,overrides,sharedNativeBuilds:0,scope:'Isolated particle experiment; no ordinary renderer/native outputs edited'};
 fs.writeFileSync(path.join(stage,variant+'-sources.json'),JSON.stringify(receipt,null,2)+'\n');
}
console.log(JSON.stringify({success:true,label,stage,sharedNativeBuilds:0}));
