import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {fileURLToPath} from 'node:url';
const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..'),destination=path.join(project,'tests/native_perf140_particle_endpoint_slot_models_test.gd');
if(fs.existsSync(destination))throw Error('Existing dedicated fixture preserved');
const base=fs.readFileSync(path.join(project,'tests/native_perf140_particle_managed_lease_models_test.gd'));
if(crypto.createHash('sha256').update(base).digest('hex')!=='09d7af39f3e6f2b1703f08df163744e1d2645787c7e6409821bde792641e9751')throw Error('Reviewed installed fixture source differs');
let output=base.toString('utf8').replaceAll('\r\n','\n');
output=output.replace('dispatch",1,{"delta":','dispatch",1,{"pose_slots":row.managed,"delta":');
output=output.replace('\t\tmanaged_hits+=int(b.frame_pose_reuse.managed_hits)',`\t\tvar ordinary_slots: Dictionary=rows[0].presentation.call("dispatch",17,{})
\t\tvar indexed_slots: Dictionary=rows[1].presentation.call("dispatch",17,{})
\t\tcheck(ordinary_slots.mode=="ordinary" and indexed_slots.mode=="indexed","Actual installed model cache modes are exercised")
\t\tcheck(ordinary_slots.indexed_rows==0 and indexed_slots.ordinary_rows==0,"Installed model modes retain one row authority")
\t\tmanaged_hits+=int(b.frame_pose_reuse.managed_hits)`);
output=output.replace('"scope":"Installed MDL fields','"scope":"Optional indexed pose rows with installed MDL fields');
fs.writeFileSync(destination,output);console.log(JSON.stringify({success:true,file:destination,sharedEdits:0,nativeChanges:0}));
