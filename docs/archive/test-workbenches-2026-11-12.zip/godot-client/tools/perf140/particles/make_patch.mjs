// Export only the pinned candidate source changes; never apply/promote them.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {fileURLToPath} from 'node:url';
const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..'),label=process.argv[2];if(!/^[a-z0-9-]+$/.test(label??''))throw Error('Private candidate label required');
const stage=path.join(project,'.cache/native-140fps/particles-agent',label),candidate=JSON.parse(fs.readFileSync(path.join(stage,'candidate-built-sources.json'))),baseline=JSON.parse(fs.readFileSync(path.join(stage,'baseline-sources.json'))),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
for(const receipt of [candidate,baseline])for(const pin of receipt.sourcePins)if(hash(fs.readFileSync(path.join(receipt.sourceProject,pin.relative)))!==pin.sha256)throw Error('Private pin differs: '+pin.relative);
const lines=f=>{if(!fs.existsSync(f))return [];const text=fs.readFileSync(f,'utf8').replaceAll('\r\n','\n');return text.endsWith('\n')?text.slice(0,-1).split('\n'):text.split('\n');};
let patch='';
for(const override of candidate.overrides){
 const relative=override.relative,oldFile=path.join(baseline.sourceProject,relative),a=lines(oldFile),b=lines(path.join(candidate.sourceProject,relative)),width=b.length+1,table=new Uint16Array((a.length+1)*width);
 for(let i=a.length-1;i>=0;--i)for(let j=b.length-1;j>=0;--j)table[i*width+j]=a[i]===b[j]?table[(i+1)*width+j+1]+1:Math.max(table[(i+1)*width+j],table[i*width+j+1]);
 const ops=[];let i=0,j=0;const push=(kind,text)=>ops.push({kind,text,old:i,new:j});
 while(i<a.length||j<b.length){if(i<a.length&&j<b.length&&a[i]===b[j]){push(' ',a[i]);++i;++j;}else if(j<b.length&&(i===a.length||table[i*width+j+1]>=table[(i+1)*width+j])){push('+',b[j]);++j;}else{push('-',a[i]);++i;}}
 const changes=ops.flatMap((v,n)=>v.kind===' '?[]:[n]);if(!changes.length)continue;
 patch+='--- '+(fs.existsSync(oldFile)?'a/'+relative:'/dev/null')+'\n+++ b/'+relative+'\n';
 const spans=[];for(const index of changes){const start=Math.max(0,index-3),end=Math.min(ops.length,index+4),last=spans.at(-1);if(last&&start<=last[1])last[1]=end;else spans.push([start,end]);}
 for(const [start,end]of spans){const part=ops.slice(start,end),oldCount=part.filter(v=>v.kind!=='+').length,newCount=part.filter(v=>v.kind!=='-').length;patch+=`@@ -${oldCount?part[0].old+1:part[0].old},${oldCount} +${newCount?part[0].new+1:part[0].new},${newCount} @@\n`+part.map(v=>v.kind+v.text+'\n').join('');}
}
const output=process.argv[3]??'candidate.patch';if(!/^[a-z0-9-]+\.patch$/.test(output))throw Error('Fresh simple patch filename required');const file=path.join(stage,output);fs.writeFileSync(file,patch,{flag:'wx'});console.log(JSON.stringify({success:true,file,sha256:hash(patch),bytes:Buffer.byteLength(patch),promoted:false}));
