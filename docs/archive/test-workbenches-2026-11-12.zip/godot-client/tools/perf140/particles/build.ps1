[CmdletBinding()]
param([Parameter(Mandatory)][ValidatePattern('^[a-z0-9-]+$')][string]$Label,[switch]$SkipPure,[ValidateSet('frame_pose_cache_test.cpp','typed_object_proof_test.cpp')][string]$PureSource='frame_pose_cache_test.cpp')
$ErrorActionPreference='Stop'
$project=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$stage=Join-Path $project ('.cache/native-140fps/particles-agent/'+$Label)
$receiptPath=Join-Path $stage 'candidate-sources.json'
$receipt=Get-Content -LiteralPath $receiptPath -Raw|ConvertFrom-Json
$copy=Join-Path $stage 'candidate'
if($receipt.sourceProject-ne$copy-or$receipt.variant-ne'candidate'){throw 'Private build identity differs'}
$output=Join-Path $copy '.cache/native-kernel'
$proof=Join-Path $stage 'build.json'
if(Test-Path -LiteralPath $proof){throw 'Existing compiler evidence preserved'}
foreach($pin in $receipt.sourcePins){if((Get-FileHash -LiteralPath (Join-Path $copy $pin.relative)).Hash.ToLowerInvariant()-ne$pin.sha256){throw ('Private source changed: '+$pin.relative)}}
$guards=@()
foreach($relative in @('.cache/native-kernel/nwn-particle-kernel.dll','.cache/native-resource-index/nwn-resource-index.dll','.cache/native-window/nwn-window-modes.exe')){$guards+=@{relative=$relative;sha256=(Get-FileHash -LiteralPath (Join-Path $project $relative)).Hash.ToLowerInvariant()}}
$vswhere=Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio/Installer/vswhere.exe'
$vs=@(& $vswhere -all -prerelease -products '*' -property installationPath)|Where-Object{Test-Path -LiteralPath (Join-Path $_ 'VC/Auxiliary/Build/Microsoft.VCToolsVersion.default.txt')}|Select-Object -First 1
if(-not$vs){throw 'Existing MSVC unavailable'}
$version=(Get-Content -LiteralPath (Join-Path $vs 'VC/Auxiliary/Build/Microsoft.VCToolsVersion.default.txt') -Raw).Trim()
$tools=Join-Path $vs ('VC/Tools/MSVC/'+$version)
$compiler=Join-Path $tools 'bin/Hostx64/x64/cl.exe'
$sdk=Join-Path ${env:ProgramFiles(x86)} 'Windows Kits/10'
$include=Get-ChildItem -LiteralPath (Join-Path $sdk 'Include') -Directory|Sort-Object Name -Descending|Where-Object{Test-Path -LiteralPath (Join-Path $_.FullName 'um/Windows.h')}|Select-Object -First 1
$api=Join-Path $project '.tools/extension-api'
$priorInclude=$env:INCLUDE;$priorLib=$env:LIB
try{
 $env:INCLUDE=((Join-Path $tools 'include'),(Join-Path $include.FullName 'ucrt'),(Join-Path $include.FullName 'shared'),(Join-Path $include.FullName 'um'))-join';'
 $env:LIB=((Join-Path $tools 'lib/x64'),(Join-Path $sdk ('Lib/'+$include.Name+'/ucrt/x64')),(Join-Path $sdk ('Lib/'+$include.Name+'/um/x64')))-join';'
 if(-not$SkipPure){
 $pureName=if($PureSource-eq'typed_object_proof_test.cpp'){'typed-object-proof-test'}else{'frame-pose-cache-test'}
 $pureExe=Join-Path $stage ($pureName+'.exe')
 $pureArgs=@('/nologo','/O2','/fp:strict','/EHsc','/W4','/WX','/std:c++17','/MD',('/Fo'+(Join-Path $stage ($pureName+'.obj'))),('/Fe'+$pureExe),(Join-Path $PSScriptRoot $PureSource),'/link','/INCREMENTAL:NO')
 $pureLog=@(& $compiler @pureArgs 2>&1);$pureCompile=$LASTEXITCODE
 [IO.File]::WriteAllText((Join-Path $stage 'pure-compile.log'),($pureLog-join[Environment]::NewLine))
 if($pureCompile-ne0){throw 'Pure frame cache compilation failed'}
 $pureResult=@(& $pureExe);$pureExit=$LASTEXITCODE
 [IO.File]::WriteAllText((Join-Path $stage 'pure-result.json'),($pureResult-join[Environment]::NewLine))
 if($pureExit-ne0){throw 'Pure frame cache checks failed'}
 }
 $binary=Join-Path $output 'nwn-particle-kernel.dll'
 $args=@('/nologo','/O2','/fp:strict','/EHsc','/W4','/WX','/std:c++17','/MD','/LD',('/I'+$api),('/Fo'+(Join-Path $output 'frame-pose-kernel.obj')),('/Fe'+$binary),(Join-Path $copy 'native/particle_kernel.cpp'),'/link','/INCREMENTAL:NO',('/IMPLIB:'+(Join-Path $output 'frame-pose-kernel.lib')))
 $log=@(& $compiler @args 2>&1);$exitCode=$LASTEXITCODE
 [IO.File]::WriteAllText((Join-Path $stage 'compile.log'),($log-join[Environment]::NewLine))
}finally{$env:INCLUDE=$priorInclude;$env:LIB=$priorLib}
$changed=@($guards|Where-Object{(Get-FileHash -LiteralPath (Join-Path $project $_.relative)).Hash.ToLowerInvariant()-ne$_.sha256}|ForEach-Object relative)
$result=@{success=$exitCode-eq0-and-not$changed.Count;label=$Label;exit=$exitCode;pureExit=$pureExit;pureSuite=if($SkipPure){'Skipped; dedicated native experiment oracles selected'}else{$PureSource};compiler=$version;flags='/O2 /fp:strict /EHsc /W4 /WX /std:c++17 /MD /LD';binary=$binary;binarySha256=if($exitCode-eq0){(Get-FileHash -LiteralPath $binary).Hash.ToLowerInvariant()}else{$null};sourceReceiptSha256=(Get-FileHash -LiteralPath $receiptPath).Hash.ToLowerInvariant();guards=$guards;changedSharedOutputs=$changed;sharedNativeBuilds=0;isolatedNativeBuilds=1;engineStarts=0;serverConnections=0}
[IO.File]::WriteAllText($proof,($result|ConvertTo-Json -Depth 5))
if($result.success){[IO.File]::WriteAllText((Join-Path $output 'build-manifest.json'),($result|ConvertTo-Json -Depth 5))}
$result|ConvertTo-Json -Compress
if(-not$result.success){exit 1}
