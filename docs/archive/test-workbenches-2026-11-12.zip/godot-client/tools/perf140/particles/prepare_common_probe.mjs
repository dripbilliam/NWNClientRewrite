// Independent live common-input probe. Avoids dynamic Dictionary.has without
// retaining a value across entries or callback mutation boundaries.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {fileURLToPath} from 'node:url';
const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..'),[label,parentLabel='frame-pose-epochs-v2']=process.argv.slice(2);
if(![label,parentLabel].every(v=>/^[a-z0-9-]+$/.test(v??'')))throw Error('Fresh common-input label and frozen particle parent required');
const stage=path.join(project,'.cache/native-140fps/particles-agent',label),parentFile=path.join(project,'.cache/native-140fps/particles-agent',parentLabel,'baseline-sources.json'),parent=JSON.parse(fs.readFileSync(parentFile)),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
if(fs.existsSync(stage))throw Error('Existing private experiment preserved');
const once=(s,a,b)=>{if(s.split(a).length!==2)throw Error('Common input boundary differs: '+a.slice(0,90));return s.replace(a,b);};
for(const pin of parent.sourcePins)if(hash(fs.readFileSync(path.join(parent.sourceProject,pin.relative)))!==pin.sha256)throw Error('Frozen baseline differs: '+pin.relative);
fs.mkdirSync(stage,{recursive:true});
for(const variant of ['baseline','candidate']){
 const copy=path.join(stage,variant),pins=[];fs.mkdirSync(copy);const overrides=[];
 for(const pin of parent.sourcePins){const bytes=fs.readFileSync(path.join(parent.sourceProject,pin.relative)),destination=path.join(copy,pin.relative);fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,bytes);if(hash(fs.readFileSync(destination))!==pin.sha256)throw Error('Copy differs: '+pin.relative);pins.push({...pin});}
 if(variant==='candidate'){
  const relative='native/particle_presentation.hpp',file=path.join(copy,relative);let source=fs.readFileSync(file,'utf8').replaceAll('\r\n','\n');
  source=once(source,'struct Controls {',`// Read live for each entry: an opaque callback may mutate common controls.
bool common_animating(const EngineVar& common){EngineVar value;destroy(value.data);GDExtensionBool present=false;get_keyed(common.data,::key("animating").data,value.data,&present);return !present||value.boolean();}
struct Controls {`);
  source=once(source,' bool enabled=true,source_animating=false;',' bool enabled=true,source_animating=false,direct_animating=true;');
  source=once(source,'  if(::has(config,"enabled"))entry.enabled=::get(config,"enabled").boolean();','  if(::has(config,"direct_animating"))entry.direct_animating=::get(config,"direct_animating").boolean();\n  if(::has(config,"enabled"))entry.enabled=::get(config,"enabled").boolean();');
  source=once(source,'next.animate=!::has(common,"animating")||::get(common,"animating").boolean()||(entry.source_key&&entry.source_animating);','next.animate=(entry.direct_animating?common_animating(common):(!::has(common,"animating")||::get(common,"animating").boolean()))||(entry.source_key&&entry.source_animating);');
  source=once(source,'const auto& e=*found->second;::set(out,"fast",','const auto& e=*found->second;::set(out,"direct_animating",EngineVar::boolean(e.direct_animating));::set(out,"fast",');
  fs.writeFileSync(file,source);const sha256=hash(fs.readFileSync(file));Object.assign(pins.find(p=>p.relative===relative),{sha256,bytes:Buffer.byteLength(source)});overrides.push({relative,sha256,reason:'One live keyed common.animating read per entry, with ordinary has/get same-DLL oracle; no value hoisting'});
 }
 const receipt={...parent,label,variant,sourceProject:copy,sourcePins:pins,overrides,parent:{file:parentFile,sha256:hash(fs.readFileSync(parentFile)),renderer:parent.sourceProject},sharedNativeBuilds:0,scope:'Independent live common-input lookup only. No Controls elision, frame-pose sharing or ordinary native output changes.'};fs.writeFileSync(path.join(stage,variant+'-sources.json'),JSON.stringify(receipt,null,2)+'\n');
}
console.log(JSON.stringify({success:true,label,stage,sharedNativeBuilds:0,combined:false}));
