extends RefCounted
# Evidence-only observer. It always returns the unmodified production digest.
const Actual=preload("res://systems/native_data/prepared_cache.gd")
static var gate:=Mutex.new()
static var active: Dictionary={}
static var jobs: Dictionary={}
static func begin_scope(key: String,metadata: Dictionary) -> void:
	gate.lock();active[OS.get_thread_caller_id()]=key;jobs[key]={"metadata":metadata.duplicate(true),"digests":{},"calls":0,"bytes_hashed":0};gate.unlock()
static func end_scope() -> void:
	gate.lock();active.erase(OS.get_thread_caller_id());gate.unlock()
static func digest(bytes: PackedByteArray,site: String) -> String:
	var result:=Actual.digest(bytes)
	gate.lock()
	var scope: String=active.get(OS.get_thread_caller_id(),"")
	if not scope.is_empty():
		var record: Dictionary=jobs[scope];var identity:=result+":"+str(bytes.size())
		if not record.digests.has(identity):record.digests[identity]={"sha256":result,"bytes":bytes.size(),"calls":0,"bytes_hashed":0,"sites":{}}
		var row: Dictionary=record.digests[identity];row.calls+=1;row.bytes_hashed+=bytes.size();row.sites[site]=int(row.sites.get(site,0))+1;record.calls+=1;record.bytes_hashed+=bytes.size()
	gate.unlock();return result
static func snapshot() -> Dictionary:
	gate.lock();var answer:=jobs.duplicate(true);gate.unlock();return answer
