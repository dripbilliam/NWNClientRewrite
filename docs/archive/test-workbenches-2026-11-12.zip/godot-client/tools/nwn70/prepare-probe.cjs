'use strict';
// Freeze source and redirect exact digest calls to a transparent observer.
// No production edits, parser/builds, original-asset reads or cache bypasses.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const project=path.resolve(__dirname,'../..'),label=process.argv[2]??'counts-a';assert(/^[a-z0-9-]+$/.test(label));
const out=path.join(project,'.cache/nwn70',label);assert(!fs.existsSync(out));fs.mkdirSync(out,{recursive:true});
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
function redirect(source,prefix,file){
 const changes=[],sites=[];let index=0;
 while((index=source.indexOf(prefix+'(',index))>=0){
  const start=index;let cursor=index+prefix.length+1,depth=1,quote=null;
  for(;cursor<source.length&&depth;cursor++){
   const c=source[cursor];if(quote){if(c==='\\'){cursor++;continue;}if(c===quote)quote=null;continue;}
   if(c==='"'||c==="'"){quote=c;continue;}if(c==='(')depth++;else if(c===')')depth--;
  }
  assert.equal(depth,0);const line=source.slice(0,start).split('\n').length,site=file+':'+line+':'+sites.length;
  changes.push({at:start,length:prefix.length,text:'Probe.digest'},{at:cursor-1,length:0,text:','+JSON.stringify(site)});sites.push(site);index=start+prefix.length;
 }
 for(const change of changes.sort((a,b)=>b.at-a.at))source=source.slice(0,change.at)+change.text+source.slice(change.at+change.length);
 return {source,sites};
}
const names=['systems/native_data/asset_service.gd','systems/native_data/prework_store.gd'];const originals=new Map(names.map(name=>[name,fs.readFileSync(path.join(project,name))]));
const sources=[];
for(const name of names){
 const input=originals.get(name),baseline=path.join(out,path.basename(name)+'.original');fs.writeFileSync(baseline,input,{flag:'wx'});
 let source=input.toString('utf8');assert(!source.includes('const Probe='));
 let transformed=redirect(source,'Cache.digest',name),sites=transformed.sites;source=transformed.source;
 if(name.endsWith('/prework_store.gd')){transformed=redirect(source,'Digest.digest',name);source=transformed.source;sites.push(...transformed.sites);}
 else {const before='const Prework=preload("res://systems/native_data/prework_store.gd")';assert.equal(source.split(before).length-1,1);source=source.replace(before,'const Prework=preload('+JSON.stringify('res://.cache/nwn70/'+label+'/prework_store.gd')+')');}
 source=source.replace(/^(extends[^\r\n]+)\r?\n/,'$1\nconst Probe=preload("res://tools/nwn70/hash_probe.gd")\n');
 const target=path.join(out,path.basename(name));fs.writeFileSync(target,source,{flag:'wx'});assert(fs.readFileSync(path.join(project,name)).equals(input),'Shared source changed during freeze');
 sources.push({name,baseline,baselineSha256:sha(input),instrumented:target,instrumentedSha256:sha(Buffer.from(source)),sites});
}
const manifest={version:1,label,created:new Date().toISOString(),sources,observer:{file:'tools/nwn70/hash_probe.gd',sha256:sha(fs.readFileSync(path.join(project,'tools/nwn70/hash_probe.gd')))},scope:'Private exact source snapshots; only digest calls redirected with source-site labels, and private Prework preload. Observer returns actual production SHA256; no production files altered or validation bypassed.'};
fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({out,sources:sources.map(row=>({name:row.name,sha256:row.baselineSha256,sites:row.sites.length}))}));
