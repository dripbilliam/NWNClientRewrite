extends SceneTree
const Base=preload("res://systems/model_rigs.gd")
const Candidate=preload("res://tests/nwn65_native_batch_candidate.gd")
const Fixture=preload("res://tests/nwn65_active_event_test.gd")
var output:=""
var preflight:=false
var checks:=0
var failures: Array=[]
func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.trim_prefix("--report=")
		if arg=="--preflight":preflight=true
	call_deferred("run")
func check(value: bool,label: String) -> void:
	checks+=1
	if not value:failures.append(label);push_error(label)
func digest(value: Variant) -> String:
	var hash:=HashingContext.new();hash.start(HashingContext.HASH_SHA256);hash.update(var_to_bytes(value));return hash.finish().hex_encode()
func statistics(values: Array) -> Dictionary:
	values.sort();return {"count":values.size(),"median_us":values[values.size()/2],"p95_us":values[mini(values.size()-1,int(ceil(values.size()*0.95))-1)],"max_us":values[-1]}
func leg(script,eventful: bool) -> Dictionary:
	var rows: Array=[]
	for index in 80:
		var row:=Fixture.fixture(self,script,eventful);row.entry.animated_models=[0,1];rows.append(row)
	var samples: Array=[];var warm:=0 if preflight else 20;var frames:=32 if preflight else 120
	for frame in warm+frames:
		var began:=Time.get_ticks_usec()
		for row in rows:row.rigs._update(1.0/60.0)
		if frame>=warm and not preflight:samples.append(Time.get_ticks_usec()-began)
	var snapshots: Array=[];var events:=0;var calls:=0;var running:=0
	var counts:={"calls":0,"models":0,"advances":0,"empty_models":0,"interval_models":0,"event_rows":0,"fallbacks":0,"post_fallbacks":0,"reentrant":0,"failures":0}
	for row in rows:
		snapshots.append(Fixture.capture(row));events+=row.log.size();calls+=int(row.rigs.stats.pose_frames)
		for model_index in [0,1]:
			if row.entry.models[model_index].player.is_playing():running+=1
		if row.rigs.has_method("native_batch_snapshot"):
			var info: Dictionary=row.rigs.native_batch_snapshot()
			for key in counts:counts[key]+=int(info.totals[key])
	var result:={"owners":rows.size(),"animation_players":rows.size()*2,"running_players":running,"event_records":events,"update_calls":calls,"state_sha256":digest(snapshots),"native_counts":counts}
	if not preflight:result.timing=statistics(samples)
	for row in rows:Fixture.dispose(row)
	return result
func run() -> void:
	if output.is_empty() or FileAccess.file_exists(output):quit(2);return
	var source_sha:=FileAccess.get_sha256("res://systems/model_rigs.gd");var candidate_sha:=FileAccess.get_sha256("res://tests/nwn65_native_batch_candidate.gd");var cases: Array=[]
	check(ClassDB.class_exists("NwnRigAnimationBatch") and bool(ProjectSettings.get_setting("nwn/rig_animation_batch",false)),"explicit private native component admitted")
	if not failures.is_empty():quit(1);return
	for eventful in [false,true]:
		var legs: Array=[]
		for mode in ["original","candidate","candidate","original"]:
			var result:=leg(Base if mode=="original" else Candidate,eventful);result.mode=mode;legs.append(result)
			check(result.owners==80 and result.animation_players==160 and result.running_players==160,"all80owners/160active players admitted")
			check(result.event_records>0 if eventful else result.event_records==0,"event population exercised")
			check(result.state_sha256==legs[0].state_sha256,"ABBA clocks/pose/event/attachment output bit equality")
			if mode=="candidate":
				check(result.native_counts.advances==result.update_calls*2 and result.native_counts.calls==result.update_calls,"every measured model actually native advanced once")
				check(result.native_counts.fallbacks==0 and result.native_counts.post_fallbacks==0 and result.native_counts.failures==0,"no accidental fallback or failed native admission")
		cases.append({"eventful":eventful,"legs":legs})
	check(source_sha==FileAccess.get_sha256("res://systems/model_rigs.gd") and candidate_sha==FileAccess.get_sha256("res://tests/nwn65_native_batch_candidate.gd"),"source frozen throughout component execution")
	var file:=FileAccess.open(output,FileAccess.WRITE);file.store_string(JSON.stringify({"passed":failures.is_empty(),"checks":checks,"failures":failures,"preflight":preflight,"rig_sha256":source_sha,"candidate_sha256":candidate_sha,"cases":cases,"scope":"Actual80owner/160AnimationPlayer ModelRigs update, main-thread ordinary path, authored active property clips/events/attachments; no skins/original live clip weighting/SceneTree callbacks or whole-client FPS claim."},"\t"));file.close();quit(0 if failures.is_empty() else 1)
