extends SceneTree
# Frozen/source TileTerms comparison, including exact Vector2 output bytes.
# 38 different endpoints model repeated blocked-path work; no FPS/client.
var checks:=0
var failures: Array=[]
func check(value: bool,label: String)->void:
	checks+=1
	if not value and failures.size()<8:failures.append(label)
static func cross(a: Vector2,b: Vector2)->float:return a.x*b.y-a.y*b.x
static func triangle(a: Vector2,b: Vector2,c: Vector2)->Dictionary:
	var points: Array=[a,b,c]
	return {"xy_points":points,"xy_area":cross(b-a,c-a),"xy_edges":[b-a,c-b,a-c]}
func stats(values: Array)->Dictionary:
	var ordered:=values.duplicate();ordered.sort()
	return {"samples_usec":values,"median_usec":ordered[int(ordered.size()/2)],"minimum_usec":ordered[0],"maximum_usec":ordered[-1]}
func _initialize()->void:
	var options: Dictionary={}
	for argument in OS.get_cmdline_user_args():
		var parts:=argument.trim_prefix("--").split("=",true,1)
		if parts.size()==2:options[parts[0]]=parts[1]
	var control_script=load("res://.cache/nwn63/arithmetic-publish-a/before.gd")
	var candidate_script=load("res://systems/native_render/drive_preview_arithmetic.gd")
	if control_script==null or candidate_script==null:print("Arithmetic scripts unavailable");quit(1);return
	var triangles: Array=[]
	for index in 1152:
		var x:=float(index%48)*0.2;var y:=float(index/48)*0.2
		triangles.append(triangle(Vector2(x,y),Vector2(x+0.18,y+0.01),Vector2(x+0.02,y+0.19)))
	var endpoints: Array=[]
	for index in 38:endpoints.append(Vector2(float(index%17)*0.127+0.03,float(index%11)*0.137-0.09))
	var control=control_script.new();var candidate=candidate_script.new()
	var old_terms=control.tile_terms(0,triangles);var new_terms=candidate.tile_terms(0,triangles)
	var from:=Vector2(1.003,1.997)
	for endpoint_index in endpoints.size():
		for triangle_index in triangles.size():
			var old_value: Vector2=old_terms.interval(from,endpoints[endpoint_index],triangle_index,triangles[triangle_index])
			var new_value: Vector2=new_terms.interval(from,endpoints[endpoint_index],triangle_index,triangles[triangle_index])
			check(var_to_bytes(old_value)==var_to_bytes(new_value),"Exact interval "+str(endpoint_index)+"/"+str(triangle_index))
	check(old_terms.counts.term_prepares==new_terms.counts.term_prepares and old_terms.counts.term_reuses==new_terms.counts.term_reuses,"Exact cache counters")
	var legs: Array=[]
	for mode in ["control","candidate","candidate","control"]:
		var terms=old_terms if mode=="control" else new_terms
		var began:=Time.get_ticks_usec()
		var visited:=0
		for endpoint in endpoints:
			for triangle_index in triangles.size():
				var value: Vector2=terms.interval(from,endpoint,triangle_index,triangles[triangle_index])
				if value.x<=value.y:visited+=1
		legs.append({"mode":mode,"usec":Time.get_ticks_usec()-began,"visited":visited})
	check(legs[0].visited==legs[1].visited and legs[1].visited==legs[2].visited and legs[2].visited==legs[3].visited,"All component legs visit same intervals")
	var report:={"success":failures.is_empty(),"checks":checks,"failures":failures,"faces":triangles.size(),"endpoints":endpoints.size(),"old_cache":{"prepared":old_terms.counts.term_prepares,"reused":old_terms.counts.term_reuses},"new_cache":{"prepared":new_terms.counts.term_prepares,"reused":new_terms.counts.term_reuses},"legs":legs,"scope":"Same-process frozen/current exact Vector2 byte parity and warmed repeated-interval ABBA on authored triangles/endpoints. Component only; no original asset/client/FPS claim."}
	if options.has("report"):
		var file:=FileAccess.open(str(options.report),FileAccess.WRITE);file.store_string(JSON.stringify(report,"  "));file.close()
	print(JSON.stringify({"success":report.success,"checks":checks,"legs":legs,"failures":failures}));quit(0 if failures.is_empty() else 1)
