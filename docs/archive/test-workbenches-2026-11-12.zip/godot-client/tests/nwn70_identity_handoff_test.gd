extends SceneTree
const Store=preload("res://systems/native_data/prework_store.gd")
const Cache=preload("res://systems/native_data/prepared_cache.gd")
const Catalog=preload("res://systems/native_data/resource_catalog.gd")
var checks:=0
var failures: Array=[]
var report_path:=""
class MutableSource extends RefCounted:
	var bytes:=PackedByteArray([1,2,3,4])
	var failure:=""
	var failed:=false
	func get_resource(_name: String,_type: int) -> PackedByteArray:
		failure="authored failure" if failed else "";return bytes
func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):report_path=arg.substr(9)
	call_deferred("run")
func check(value: bool,label: String) -> void:
	checks+=1
	if not value:failures.append(label);print("FAIL ",label)
func write(path: String,bytes: PackedByteArray) -> void:
	var file:=FileAccess.open(path,FileAccess.WRITE);file.store_buffer(bytes);file.close()
func run() -> void:
	if report_path.is_empty() or FileAccess.file_exists(report_path):quit(2);return
	var before=load("res://.cache/nwn70/baseline/prework_store.gd")
	var root_path:=OS.get_temp_dir().path_join("nwn70-handoff-"+str(OS.get_process_id())+"-"+str(Time.get_ticks_usec()))
	for child in ["base","override","cache"]:DirAccess.make_dir_recursive_absolute(root_path.path_join(child))
	var raw:="2DA V2.0\n\nName\n0 before\n".to_ascii_buffer();var changed:="2DA V2.0\n\nName\n0 after!\n".to_ascii_buffer()
	var source_path:=root_path.path_join("base/testres.2da");var override_path:=root_path.path_join("override/testres.2da");write(source_path,raw);write(override_path,changed)
	var catalog:=Catalog.new();check(catalog.mount_directory(root_path.path_join("base"),10),"Actual lower-priority data catalog mounts")
	var original=before.Inputs.new(catalog);var current:=Store.Inputs.new(catalog)
	var known:=Cache.digest(raw);original.remember("TeStReS",2017,raw);current.remember("TeStReS",2017,raw,known)
	check(original.snapshot()==current.snapshot(),"Known same-job source SHA produces exactly the original dependency rows")
	check(current.rows.values()[0].keys()==["operation","name","type","sha256"],"Handoff retains only existing small identity fields, no raw buffers or global cache")
	var mutable:=MutableSource.new();var pairs:=Store.Inputs.new(mutable)
	var first:=pairs.get_resource_with_digest("same",2002);var first_hash: String=first.sha256
	check(first_hash==Cache.digest(first.bytes) and first.bytes==mutable.bytes,"Paired read returns actual matching bytes/digest from one read")
	mutable.bytes[0]=9
	var second:=pairs.get_resource_with_digest("same",2002)
	check(first.bytes==PackedByteArray([1,2,3,4]) and first_hash==Cache.digest(first.bytes) and second.sha256!=first_hash,"Later same-name mutable-source read cannot alter an earlier owned byte/digest pair")
	var interleaved:=pairs.get_resource_with_digest("other",2002)
	mutable.bytes[1]=8;var third:=pairs.get_resource_with_digest("same",2002)
	check(first.sha256==Cache.digest(first.bytes) and second.sha256==Cache.digest(second.bytes) and interleaved.sha256==Cache.digest(interleaved.bytes) and third.sha256==Cache.digest(third.bytes),"Interleaved/reread pairs retain identities for their own immutable byte snapshot")
	mutable.failed=true;var failed:=pairs.get_resource_with_digest("same",2002)
	check(str(failed.sha256).is_empty() and not pairs.failure.is_empty(),"A failed later read supplies no stale identity hint")
	mutable.failed=false;var ordinary:=pairs.get_resource("same",2002)
	check(ordinary==mutable.bytes and pairs.rows["bytes:same:2002"].sha256==Cache.digest(ordinary),"Original get_resource still returns and hashes normally without packet API")
	for supplied in ["","bad","A".repeat(64),"0".repeat(63)]:
		current.remember("testres",2017,raw,supplied)
		check(current.snapshot()==original.snapshot(),"Existing/default or malformed hints still compute actual SHA: "+str(supplied.length()))
	var empty:=PackedByteArray();original.remember("empty",2017,empty);current.remember("empty",2017,empty,Cache.digest(empty));check(original.snapshot()==current.snapshot(),"Empty immutable buffers keep exact original identities")
	original.rows.erase("bytes:empty:2017");current.rows.erase("bytes:empty:2017")
	var store:=Store.new();var control=before.new();var directory:=root_path.path_join("cache")
	check(store.configure(directory) and control.configure(directory),"Original/candidate prework owners use the same bounded external cache")
	var identity:=Cache.key(known,"nwn70-handoff-fixture");var data:={"typed":PackedFloat32Array([1,2,3]),"label":"original-content","array":[1,2,3]}
	check(store.save_entry(identity,current.snapshot(),data,store.generation()),"Known source handoff persists through the unchanged native cache format")
	check(store.load_entry(identity,catalog)==data and control.load_entry(identity,catalog)==data,"Original and candidate validate identical saved data")
	var pinned=catalog.fork();check(catalog.mount_directory(root_path.path_join("override"),20),"Higher-priority active content mounts through the actual catalog")
	check(catalog.get_resource("testres",2017)==changed and pinned.get_resource("testres",2017)==raw,"Catalog generation forks preserve original ownership and current precedence")
	check(store.load_entry(identity,catalog).is_empty() and control.load_entry(identity,catalog).is_empty(),"Changed same-name/same-size current bytes invalidate both saved dependency paths")
	check(store.load_entry(identity,pinned)==data,"A retained original scope can still validate its original immutable source")
	var path:=store.cache.filename(identity);var file:=FileAccess.open(path,FileAccess.READ_WRITE);file.seek(60);var byte:=file.get_8();file.seek(60);file.store_8(byte^255);file.close()
	check(store.load_entry(identity,pinned).is_empty() and control.load_entry(identity,pinned).is_empty(),"Same-length payload corruption is still rejected by original and candidate checksum validation")
	check(store.save_entry(identity,current.snapshot(),data,store.generation()) and store.load_entry(identity,pinned)==data,"Original prepared data repairs corruption using unchanged disk publication checks")
	var forged:=Store.Inputs.new(pinned);forged.remember("testres",2017,raw,"0".repeat(64));var wrong:=Cache.key(known,"nwn70-wrong-internal-hint")
	check(store.save_entry(wrong,forged.snapshot(),data,store.generation()) and store.load_entry(wrong,pinned).is_empty(),"Even a wrongly supplied well-formed internal hint cannot bypass later actual-byte dependency validation")
	var old_ticket:=store.generation();var cleared:=store.clear();check(cleared.get("errors",[]).is_empty(),"Scoped cache clear retains original generated-file ownership rules")
	check(not store.save_entry(identity,current.snapshot(),data,old_ticket),"Generation changes reject cancelled/stale cache publication")
	current.remember("testres",2017,changed,Cache.digest(changed));check(current.snapshot()!=original.snapshot(),"A later same-name revision receives its own actual digest")
	var new_key:=Cache.key(Cache.digest(changed),"nwn70-handoff-fixture");check(store.save_entry(new_key,current.snapshot(),data,store.generation()) and store.load_entry(new_key,catalog)==data,"Current higher-priority source can be prepared after cancellation without reviving old bytes")
	store.clear();catalog=null;pinned=null
	for owned in [source_path,override_path]:DirAccess.remove_absolute(owned)
	for owned in [root_path.path_join("cache/saved-prework-v1"),root_path.path_join("cache"),root_path.path_join("base"),root_path.path_join("override"),root_path]:check(DirAccess.remove_absolute(owned)==OK,"Remove only exact empty fixture directory "+owned.get_file())
	var report:={"success":failures.is_empty(),"checks":checks,"failures":failures,"prepared_cache_sha256":FileAccess.get_sha256("res://systems/native_data/prepared_cache.gd"),"scope":"Pure data original/candidate dependency-row parity, malformed/default hints, original format, actual catalog precedence/generation forks, same-size source changes, payload corruption/repair, cancelled publication and bounded ownership. No full world/GUI, server, throughput or FPS test."}
	file=FileAccess.open(report_path,FileAccess.WRITE);file.store_string(JSON.stringify(report,"\t"));file.close();print("NWN70_IDENTITY_HANDOFF ",checks," checks; ",failures.size()," failures");quit(0 if report.success else 1)
