extends SceneTree
const Preparation=preload("res://systems/native_data/world_snapshot_preparation.gd")
const Metadata=preload("res://systems/native_data/world_snapshot_metadata.gd")
const Verified=preload("res://systems/native_data/world_snapshot_verified_packet.gd")
const World=preload("res://systems/native_render/live_world.gd")
var checks:=0
var failures: Array=[]

func check(ok: bool,label: String) -> void:
	checks+=1
	if not ok:failures.append(label);push_error(label)

func _initialize() -> void:call_deferred("run")

func run() -> void:
	var args:={}
	for arg in OS.get_cmdline_user_args():
		var pair:=arg.trim_prefix("--").split("=",true,1)
		if pair.size()==2:args[pair[0]]=pair[1]
	if not args.has("input") or not args.has("report") or FileAccess.file_exists(args.report):quit(2);return
	var expect_verified:=str(args.get("expect-verified","on"))=="on"
	check(World.configured_verified_packet()==expect_verified,"Cached verified-packet runtime selection matches explicit argument")
	var fixture: Variant=JSON.parse_string(FileAccess.get_file_as_string(args.input))
	if not fixture is Dictionary or not fixture.get("rows") is Array:quit(3);return
	var rows: Array=fixture.rows
	var area:=int(fixture.area)
	var scope:=[1,5,int(fixture.serial),area]
	var owner:=Preparation.new()
	check(owner.begin(scope,area,rows.size()),"Original full snapshot scope begins")
	for offset in range(0,rows.size(),64):check(owner.submit(rows.slice(offset,mini(rows.size(),offset+64))),"Original 64-row chunk "+str(offset))
	check(owner.seal(),"Original full snapshot scope seals")
	var packet: Dictionary={}
	var deadline:=Time.get_ticks_msec()+10000
	while packet.is_empty() and Time.get_ticks_msec()<deadline:
		packet=owner.take(scope)
		if packet.is_empty():await process_frame
	check(not packet.is_empty() and str(packet.get("error","missing")).is_empty(),"Worker packet completes without fallback")
	if packet.is_empty() or not str(packet.get("error","missing")).is_empty():quit(4);return
	check(packet.get("proof") is Verified and packet.rows.size()==rows.size(),"Only worker owner issued proof for every source row")
	check(packet.rows.is_read_only() and packet.rows[0].is_read_only() and packet.rows[0].pose.is_read_only() and packet.proof.sources.is_read_only(),"Verified packet metadata and source-reference arrays cannot mutate after completion")
	check(Metadata.digest(var_to_bytes(packet.rows))==Metadata.digest(var_to_bytes(Metadata.prepare(rows,area))),"Worker packet matches original ordered metadata bytes")
	var world:=World.new();world.area_id=area;world.generation=5
	var slow: Dictionary=packet.duplicate();slow.erase("proof")
	var timings: Array=[]
	for mode in ["unverified","verified","verified","unverified"]:
		var began:=Time.get_ticks_usec()
		var ok: bool=world.stage_received_metadata(rows,packet if mode=="verified" else slow)
		var elapsed:=Time.get_ticks_usec()-began
		check(ok,"Original rows accepted through "+mode+" gate")
		timings.append({"mode":mode,"us":elapsed})
	var clone:=rows.duplicate(true)
	check(world.stage_received_metadata(clone,packet)!=expect_verified,"Equal-value cloned source dictionaries use proof only when selected")
	world.generation=6
	check(not world.stage_received_metadata(rows,packet),"Stale generation cannot reuse worker proof")
	world.generation=5
	var wrong_scope: Dictionary=packet.duplicate();wrong_scope.scope=scope.duplicate();wrong_scope.scope[2]+=1
	check(world.stage_received_metadata(rows,wrong_scope)!=expect_verified,"Mutated serial uses proof only when selected")
	var wrong_rows: Dictionary=packet.duplicate();wrong_rows.rows=packet.rows.duplicate()
	check(world.stage_received_metadata(rows,wrong_rows)!=expect_verified,"Replaced metadata rows use proof only when selected")
	var forged: Dictionary=slow.duplicate(true);forged["_worker_verified"]=true;forged.rows[0].index=-1
	check(not world.stage_received_metadata(rows,forged),"Forged flag without proof retains complete fallback validation")
	var counterfeit: Dictionary=slow.duplicate(true);counterfeit.rows[0].index=-1;counterfeit.proof=RefCounted.new()
	check(not world.stage_received_metadata(rows,counterfeit),"Counterfeit RefCounted proof retains complete fallback validation")
	check(world._staged_received_metadata.is_empty(),"Rejected packets leave no staged metadata")
	check(world.received_metadata_stats.verified_staged==(2 if expect_verified else 0) and world.received_metadata_stats.full_staged==(2 if expect_verified else 7),"Selected fast/full staging counters match actual packet admissions")
	world.free();owner.close()
	var report:={"issue":"NWN-73","success":failures.is_empty(),"checks":checks,"failures":failures,"rows":rows.size(),"verified_selected":expect_verified,"timings":timings,"scope":"Exact original 2832-row full snapshot worker proof, explicit cached rollback, source identity/generation/tamper checks and component stage cost. No scene publication, entry latency, graphics or FPS measurement."}
	var file:=FileAccess.open(args.report,FileAccess.WRITE)
	if file==null:quit(5);return
	file.store_string(JSON.stringify(report,"  ")+"\n");file.close();quit(0 if failures.is_empty() else 1)
