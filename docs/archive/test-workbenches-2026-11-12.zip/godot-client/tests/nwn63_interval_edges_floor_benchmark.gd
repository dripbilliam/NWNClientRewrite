extends "res://tests/nwn63_floor_coverage_benchmark.gd"
# Same 1,152-face and sparse ABBA fixture, exact before/after owner only.
const ExactBefore=preload("res://.cache/nwn63/interval-edges-a/before/systems/native_render/drive_collision_indexed.gd")

func pair()->Array:
	var result: Array=[]
	for old in [true,false]:
		var setup:=make_world(false);var world=setup.world
		var collision=ExactBefore.new() if old else Collision.new()
		world.add_child(collision);collision.world=world;collision.tables=tables();world.drive_collision=collision;collision.ensure_spatial_scope();collision.set_process(false)
		world.receive([creature(1,Vector2(1,1))],1)
		result.append(setup.merged({"collision":collision},true))
	return result
