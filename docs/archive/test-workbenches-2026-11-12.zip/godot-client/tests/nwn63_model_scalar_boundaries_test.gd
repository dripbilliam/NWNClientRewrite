extends "res://tests/nwn63_model_scalars_test.gd"
# A few double-bound/float32-endpoint edges, plus exact expansion arguments
# observed at the existing spatial boundary. No synthetic numeric algorithm.
class QuerySpy extends RefCounted:
	var delegate
	var calls: Array=[]
	func query(ticket: Dictionary,from: Vector3,to: Vector3,radius: float,exclude: int=-1,creatures: bool=true,vertical: Variant=null)->Dictionary:
		calls.append([from,to,PackedFloat64Array([radius]).to_byte_array(),exclude,creatures,vertical])
		return delegate.query(ticket,from,to,radius,exclude,creatures,vertical)
	func snapshot()->Dictionary:return delegate.snapshot()
	func root_bounds()->Dictionary:return delegate.root_bounds()
	func begin_batch(ticket: Dictionary)->bool:return delegate.begin_batch(ticket)
	func end_batch(ticket: Dictionary)->bool:return delegate.end_batch(ticket)
func run()->void:
	var pair:=group_pair(0);var spies: Array=[];var originals: Array=[];var observed:=0
	for setup in pair:
		var owner_spies: Array=[];var owner_bounds: Dictionary={}
		for key in setup.collision.static_groups:
			var group: Dictionary=setup.collision.static_groups[key];var spy:=QuerySpy.new();spy.delegate=group.index;group.index=spy
			owner_spies.append(spy);owner_bounds[key]=group.bounds.duplicate(true)
		spies.append(owner_spies);originals.append(owner_bounds)
	var cases: Array=[
		{"name":"signed-zero","bounds":[-0.0,-0.0,0.0,0.0],"radius":-0.0,"from":Vector3.ZERO,"to":Vector3(0.00000011920928955078125,0,0)},
		{"name":"double-precision-bound","bounds":[4.000000000000001,1.0000000000000002,4.000000000000002,1.0000000000000004],"radius":0.3,"from":Vector3(2.285771608352661,1,0),"to":Vector3(2.28577184677124,1,0)},
		{"name":"float32-coordinate-ulp","bounds":[16777216.000000004,-1.0,16777216.000000007,1.0],"radius":0.0,"from":Vector3(16777152,0,0),"to":Vector3(16777154,0,0)},
		{"name":"tiny-double-radius","bounds":[-0.000000000000001,-0.0,0.000000000000001,0.0],"radius":5e-324,"from":Vector3.ZERO,"to":Vector3(0.000003814697265625,0,0)},
		{"name":"positive-infinity-bound","bounds":[-INF,-1.0,INF,1.0],"radius":0.3,"from":Vector3.ZERO,"to":Vector3.ONE},
		{"name":"nan-bound-first","bounds":[NAN,-1.0,4.0,1.0],"radius":0.3,"from":Vector3.ZERO,"to":Vector3.ONE},
		{"name":"nan-bound-last","bounds":[-1.0,-1.0,4.0,NAN],"radius":0.3,"from":Vector3.ZERO,"to":Vector3.ONE},
		{"name":"infinite-model-radius","bounds":[4.0,1.0,4.0,1.0],"radius":0.3,"from":Vector3.ZERO,"to":Vector3.ONE,"model_radius":INF},
		{"name":"nan-model-radius","bounds":[4.0,1.0,4.0,1.0],"radius":0.3,"from":Vector3.ZERO,"to":Vector3.ONE,"model_radius":NAN}
	]
	for spec in cases:
		var results: Array=[];var calls: Array=[]
		for index in pair.size():
			var collision=pair[index].collision
			for key in collision.static_groups:collision.static_groups[key].bounds=originals[index][key].duplicate(true)
			collision.publish_model("chest:placeable",{"states":[footprint()]})
			if spec.has("model_radius"):collision.model_bounds["chest:placeable"][0].radius=spec.model_radius
			collision.static_groups["chest:placeable"].bounds={"min_x":spec.bounds[0],"min_y":spec.bounds[1],"max_x":spec.bounds[2],"max_y":spec.bounds[3]}
			for spy in spies[index]:spy.calls.clear()
			results.append(collision.static_candidates(spec.from,spec.to,float(spec.radius),1))
			var transcript: Array=[]
			for spy in spies[index]:transcript.append(spy.calls.duplicate(true));observed+=spy.calls.size()
			calls.append(transcript)
		check(var_to_bytes(results[0])==var_to_bytes(results[1]),str(spec.name)+": exact readiness/candidates")
		check(var_to_bytes(calls[0])==var_to_bytes(calls[1]),str(spec.name)+": exact float64 expansion bits and float32 endpoints/order")
	check(observed>0,"Boundary cases actually reach the unchanged spatial query")
	for setup in pair:setup.world.free()
	await process_frame;await process_frame
	var result:={"success":failures.is_empty(),"checks":checks,"failures":failures,"numeric_cases":cases.size(),"observed_spatial_calls":observed,"scope":"Actual before/current static_candidates float32 endpoint and float64 expansion argument parity at signed zero, small/large ULPs, subnormal radius, infinities and NaNs. No timing/FPS claim."}
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--report="):
			var file:=FileAccess.open(argument.trim_prefix("--report="),FileAccess.WRITE);file.store_string(JSON.stringify(result,"  "));file.close()
	print(JSON.stringify(result));quit(0 if failures.is_empty() else 1)
