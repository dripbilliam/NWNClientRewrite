extends "res://tests/nwn63_floor_coverage_test.gd"
# Current accepted indexed owner versus a private repeated height index.
# Inherits crossing, edge, degenerate, elevation, blocker and path transcripts.
const Candidate=preload("res://.cache/nwn63/search-height-a/drive_collision_indexed.gd")
const IndexedHeight=preload("res://.cache/nwn63/search-height-a/height_index.gd")

func pair()->Array:
	var result: Array=[]
	for candidate in [false,true]:
		var setup:=make_world(false);var world=setup.world
		var collision=Candidate.new() if candidate else Collision.new()
		world.add_child(collision);collision.world=world;collision.tables=tables();world.drive_collision=collision;collision.ensure_spatial_scope();collision.set_process(false)
		world.receive([creature(1,Vector2(1,1))],1)
		result.append(setup.merged({"collision":collision},true))
	return result

func face(a: Vector3,b: Vector3,c: Vector3,walk: bool=true)->Dictionary:
	var value: Dictionary=Candidate.triangle(a,b,c);value.walk=walk;return value

func actual_counts()->void:
	# The inherited route check names this step after its old profiler counter.
	# Keep this private parity gate count-only while another engine build runs.
	var worlds:=pair();var current=worlds[0].collision;var candidate=worlds[1].collision
	var geometry:=floor_faces(256);current.tiles[0]=geometry;candidate.tiles[0]=geometry
	var a:=Vector3(1,1,0);var b:=Vector3(3,1,0)
	check(current.query_preview(1,a,b,a).call(a,b)==candidate.query_preview(1,a,b,a).call(a,b),"512-face direct clear agrees")
	for setup in worlds:setup.world.free()
	# A retained preview Callable can be used multiple times in one frame. Edit
	# a nested WOK vertex in place between calls; the bounds snapshot must be
	# rejected and the original TerrainSurface sampling used for that probe.
	worlds=pair();current=worlds[0].collision;candidate=worlds[1].collision
	var control_clear: Callable=current.query_preview(1,a,b,a)
	var candidate_clear: Callable=candidate.query_preview(1,a,b,a)
	check(control_clear.call(a,b)==candidate_clear.call(a,b),"Mutation route initial clear")
	var built_before: int=IndexedHeight.total_builds
	check(control_clear.call(a,Vector3(2,1,0))==candidate_clear.call(a,Vector3(2,1,0)),"Mutation route prepared clear")
	check(control_clear.call(a,Vector3(2.5,1,0))==candidate_clear.call(a,Vector3(2.5,1,0)) and IndexedHeight.total_builds>built_before,"Mutation route reused indexed clear")
	for setup in worlds:
		var vertex: Array=setup.world.surface.meshes.floor.vertices[0]
		vertex[0]=float(vertex[0])+0.25
	var misses_before: int=IndexedHeight.mismatch_fallbacks
	check(control_clear.call(a,Vector3(2.6,1,0))==candidate_clear.call(a,Vector3(2.6,1,0)) and IndexedHeight.mismatch_fallbacks>misses_before,"Nested vertex edit falls back between same-frame preview calls")
	for setup in worlds:setup.world.free()
