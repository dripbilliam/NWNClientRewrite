extends "res://tests/nwn63_walkable_aabb_original_wok_test.gd"
const Worker=preload("res://systems/native_render/drive_preview_worker.gd")

func measure_one(collision,name: String,mesh: Dictionary,table: Dictionary,setup: Dictionary,samples: int)->Dictionary:
	install_asset(setup,name,mesh,table)
	var blocker:=Collision.triangle(Vector3(0,0,0),Vector3(5,0,0),Vector3(0,5,0));blocker.walk=false;collision.tile(0).append(blocker)
	var from:=Vector3(1,1,0);var target:=Vector3(3,1,0)
	var probe_count:=[0];var reference_query: Callable=collision.query_preview(1,from,target,from)
	var counted:=func(a: Vector3,b: Vector3):probe_count[0]+=1;return reference_query.call(a,b)
	var reference:=var_to_bytes(Plan.path(from,target,from,counted))
	check(probe_count[0]==38,"Original "+name+" exercises 38 blocked probes")
	var legs: Array=[]
	for mode in ["off","on","on","off"]:
		var main_us: Array=[];var admit_us: Array=[];var worker_us: Array=[];var latency_us: Array=[];var packet_bytes: Array=[]
		for warm in 3:
			if mode=="off":Plan.path(from,target,from,collision.query_preview(1,from,target,from))
			else:
				var prepared: Dictionary=collision.prepare_worker_preview(1,from,target,from)
				if prepared.has("packet"):
					var warm_worker:=Worker.new();warm_worker.packet=prepared.packet;warm_worker.run()
		for sample in samples:
			var began:=Time.get_ticks_usec()
			if mode=="off":
				var path: Dictionary=Plan.path(from,target,from,collision.query_preview(1,from,target,from))
				main_us.append(Time.get_ticks_usec()-began)
				check(var_to_bytes(path)==reference,"Original "+name+" OFF exact path")
			else:
				var snapshot: Dictionary=collision.prepare_worker_preview(1,from,target,from)
				check(snapshot.has("packet"),"Original "+name+" ON sealed packet")
				if not snapshot.has("packet"):continue
				var worker:=Worker.new();worker.packet=snapshot.packet;var job:=Thread.new()
				var err:=job.start(worker.run)
				check(err==OK,"Original "+name+" worker starts")
				if err!=OK:continue
				main_us.append(Time.get_ticks_usec()-began)
				var outcome: Dictionary=job.wait_to_finish()
				var finished:=Time.get_ticks_usec();worker_us.append(float(outcome.get("worker_ms",-1))*1000.0)
				var admit_began:=Time.get_ticks_usec()
				var current: bool=collision.worker_preview_current(snapshot)
				admit_us.append(Time.get_ticks_usec()-admit_began)
				latency_us.append(finished-began)
				packet_bytes.append(var_to_bytes(snapshot.packet).size())
				check(current and outcome.get("valid",false) and var_to_bytes(outcome.get("path",{}))==reference,"Original "+name+" ON exact path/current source")
		var leg:={"mode":mode,"main":stats_for(main_us)}
		if mode=="on":leg.merge({"admission":stats_for(admit_us),"worker":stats_for(worker_us),"latency":stats_for(latency_us),"packet_bytes":stats_for(packet_bytes)})
		legs.append(leg)
	return {"name":name,"faces":mesh.faces.size(),"legs":legs,"probes":probe_count[0],"scope":"Same process OFF/ON/ON/OFF full original blocked preview versus main snapshot+thread start, worker, and later main deep validation. Validation is separated; fixture joins immediately, so latency is not a normal-client overlap measurement."}

func run()->void:
	var options: Dictionary={}
	for argument in OS.get_cmdline_user_args():
		var split:=argument.trim_prefix("--").split("=",true,1)
		if split.size()==2:options[split[0]]=split[1]
	if not options.has("fixture") or not options.has("report"):quit(2);return
	var fixture: Variant=JSON.parse_string(FileAccess.get_file_as_string(str(options.fixture)))
	check(fixture is Dictionary and fixture.get("sources") is Array and fixture.sources.size()==74,"Pinned original WOK corpus")
	if not failures.is_empty():quit(2);return
	var samples:=int(options.get("samples",12));check(samples>=8 and samples<=24,"Bounded per-leg sample count")
	var catalog:=Catalog.new();var install:=str(options.get("install",ProjectSettings.globalize_path("res://../../FullDecomp/NwnRootInstall")))
	check(catalog.mount_install(install),"Original install mounts read-only")
	if not failures.is_empty():quit(2);return
	var table_bytes: PackedByteArray=catalog.get_resource("surfacemat",2017)
	var parser:=Table.new();var table: Dictionary=parser.parse(Binary.new(table_bytes).text(0,table_bytes.size()))
	check(not table_bytes.is_empty() and parser.failure.is_empty() and digest(table_bytes)==str(fixture.table_sha256),"Pinned original surfacemat")
	if not failures.is_empty():quit(2);return
	var selected: Array=[]
	for faces in [2,50,90,122]:
		for row in fixture.sources:
			if int(row.faces)==faces:selected.append(row);break
	check(selected.size()==4,"Selected original low/mid/high WOK face counts")
	if not failures.is_empty():quit(2);return
	var pair:=group_pair(340);var setup: Dictionary=pair[1];var collision=setup.collision
	var cases: Array=[]
	for row in selected:
		var bytes: PackedByteArray=catalog.get_resource(str(row.name),2016)
		var decoder:=TileSurface.new();var mesh: Dictionary=decoder.parse_bytes(bytes)
		check(not bytes.is_empty() and decoder.failure.is_empty() and digest(bytes)==str(row.sha256) and mesh.faces.size()==int(row.faces),"Pinned original "+str(row.name))
		if mesh.is_empty():continue
		cases.append(measure_one(collision,str(row.name),mesh,table,setup,samples))
	for owner in pair:owner.world.free()
	await process_frame;await process_frame
	var report:={"success":failures.is_empty(),"checks":checks,"failures":failures,"cases":cases,"samples":samples,"scope":"Quiet same-source original-WOK component ABBA only; frame/FPS and actual async input latency require normal-client exclusive gate. Main snapshot+thread start and later deep admission are both reported; packet serialization size is a proxy, not peak RSS."}
	var file:=FileAccess.open(str(options.report),FileAccess.WRITE);file.store_string(JSON.stringify(report,"  "));file.close()
	print(JSON.stringify({"success":report.success,"checks":checks,"failures":failures,"cases":cases.map(func(row):return {"name":row.name,"faces":row.faces,"off_us":row.legs[0].main.median_us,"on_main_us":row.legs[1].main.median_us,"on_admit_us":row.legs[1].admission.median_us})}));quit(0 if failures.is_empty() else 1)
