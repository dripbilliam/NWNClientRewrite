extends "res://tests/nwn65_script_skin_setter_test.gd"
# Exact sparse-slot skip parity. No timing or GPU readback.

func compare_sparse_skip(combined: bool, identity: bool) -> void:
	var original: Dictionary=setup(false,false,false)
	var candidate: Dictionary=setup(false,false,false)
	for row: Dictionary in [original,candidate]:
		row.rigs.use_combined_skin_setter=combined
		row.rigs.use_identity_skin_setter=identity
		for skin: Dictionary in row.entry.skins:
			var skeleton: Skeleton3D=skin.skeleton
			skeleton.set_bone_parent(1,0)
			skeleton.set_bone_parent(2,1)
			skeleton.set_bone_rest(0,Transform3D(Basis(Quaternion(Vector3.UP,0.23)),Vector3(0.2,-0.3,0.4)))
			skeleton.set_bone_rest(1,Transform3D(Basis(Quaternion(Vector3.RIGHT,-0.17)),Vector3(-0.1,0.5,0.3)))
	candidate.rigs.use_skip_identity_skin_setter=true
	check(not original.rigs.use_skip_identity_skin_setter and candidate.rigs.use_skip_identity_skin_setter,"Sparse skip is explicitly selected")
	var sparse_slots:=0
	for skin: Dictionary in original.entry.skins:
		for part in skin.bones:
			if int(part)<0:sparse_slots+=1
	check(sparse_slots>100,"Both authored skins exercise many sparse identity slots")
	for frame: int in 24:
		for row: Dictionary in [original,candidate]:
			for skin: Dictionary in row.entry.skins:
				var skeleton: Skeleton3D=skin.skeleton
				if frame in [0,4,11,19]:
					# Restore a full external edit, including nonunit scale.
					skeleton.set_bone_pose(12,Transform3D(Basis(Quaternion.from_euler(Vector3(0.3,-0.2,0.7))).scaled(Vector3(1.7,0.6,2.3)),Vector3(0.4,-0.5,0.8)))
				if frame==7:
					# Its composed basis is identity, but its stored quaternion is not.
					skeleton.set_bone_pose_rotation(12,Quaternion(0.0,0.0,0.0,-1.0))
					check(skeleton.get_bone_pose(12)==Transform3D.IDENTITY and skeleton.get_bone_pose_rotation(12)!=Quaternion.IDENTITY,"Equivalent-basis quaternion requires a reset")
				if frame==15:skeleton.set_bone_pose_scale(12,Vector3(1.0,1.25,1.0))
			if frame==5:row.rigs.set_manual_pose(1,row.entry.nodes[1],Vector3(0.2,-0.7,0.3),Quaternion(Vector3.RIGHT,0.17))
			if frame==8:row.entry.attachments[0].flags=0
			if frame==12:row.entry.attachments[0].flags=3
			if frame==13:row.rigs._play(row.entry.models[0],"turn",true,-0.5,0.4,true)
			if frame==17:row.entry.parents=[-1,0,0,2,3]
			row.rigs._update(0.0625)
		check(var_to_bytes(capture(original))==var_to_bytes(capture(candidate)),"Exact nodes, bone components/global poses, clocks, events and force notifications frame "+str(frame)+" combined="+str(combined)+" identity="+str(identity))
		check(var_to_bytes(skin_matrices(original))==var_to_bytes(skin_matrices(candidate)),"Exact CPU skin matrices frame "+str(frame)+" combined="+str(combined)+" identity="+str(identity))
		for row: Dictionary in [original,candidate]:
			for skin: Dictionary in row.entry.skins:
				var skeleton: Skeleton3D=skin.skeleton
				check(skeleton.get_bone_pose_position(12)==Vector3.ZERO and skeleton.get_bone_pose_rotation(12)==Quaternion.IDENTITY and skeleton.get_bone_pose_scale(12)==Vector3.ONE,"Sparse slot components restored frame "+str(frame))
	check(original.forces==candidate.forces and not original.forces.is_empty(),"Force notification order/count preserved")
	for row: Dictionary in [original,candidate]:
		row.rigs.forget_entity(1)
		check(row.rigs.entities.is_empty(),"Appearance entity retired")
		row.host.free()
		row.clear()
	coverage.append("24 animated frames; sparse external full/scale/quaternion edits and idle slots; rest/parent/manual/reverse/attachments; exact local/global pose, CPU skin matrices, clocks/events/force order and retirement; combined="+str(combined)+" identity="+str(identity))

func run() -> void:
	for combined: bool in [false,true]:
		for identity: bool in [false,true]:compare_sparse_skip(combined,identity)
	finish()
