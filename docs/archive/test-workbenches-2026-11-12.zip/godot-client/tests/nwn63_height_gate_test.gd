extends "res://tests/nwn63_single_preview_breakdown_test.gd"
# Production flag defaults off; original decoded face count gates the opt-in.
const HeightIndex=preload("res://systems/native_render/drive_height_index.gd")

func production_pair()->Array:
	var result: Array=[]
	for enabled in [false,true]:
		var setup:=make_world(false);var world=setup.world;var collision=Collision.new()
		world.add_child(collision);collision.world=world;collision.tables=tables();world.drive_collision=collision;collision.ensure_spatial_scope();collision.set_process(false)
		collision._preview_height_index_enabled=enabled
		world.receive([creature(1,Vector2(1,1))],1)
		setup.collision=collision;result.append(setup)
	return result

func run()->void:
	var pair:=production_pair();var from:=Vector3(1,1,0);var target:=Vector3(3,1,0)
	for divisions in [5,7]:
		var faces: int=divisions*divisions*2
		for setup in pair:
			grid_mesh(setup.world,divisions)
			var collision=setup.collision;collision.tiles.clear()
			var wall: Dictionary=Collision.triangle(Vector3(0,0,0),Vector3(5,0,0),Vector3(0,5,0))
			wall.walk=false;collision.tile(0).append(wall)
		var before: int=HeightIndex.total_builds
		var control: Dictionary=profile_path(pair[0].collision,"preview",from,target,false)
		check(HeightIndex.total_builds==before,"Flag-off "+str(faces)+"-face route builds no index")
		var candidate: Dictionary=profile_path(pair[1].collision,"preview",from,target,false)
		check(var_to_bytes(candidate.path)==var_to_bytes(control.path) and candidate.transcript==control.transcript and candidate.transcript.size()==38,"Exact "+str(faces)+"-face path/transcript")
		check(int(candidate.counts.collections)==1 and int(candidate.counts.reused_clears)==37 and int(candidate.counts.fallback_clears)==0,"Contained "+str(faces)+"-face schedule")
		check((HeightIndex.total_builds>before)==(faces>=HeightIndex.MIN_FACES),"Only "+str(HeightIndex.MIN_FACES)+"+ original faces engage index")
		var off_state: Dictionary=pair[0].collision.snapshot().preview_height_index
		var on_state: Dictionary=pair[1].collision.snapshot().preview_height_index
		check(not off_state.requested and not off_state.active and on_state.requested and on_state.active,"Collision snapshot exposes OFF/ON selection")
		if faces>=HeightIndex.MIN_FACES:check(int(on_state.builds_process)>0 and int(on_state.samples_process)>0 and int(on_state.fallbacks_process)>=0,"Collision snapshot exposes actual indexed samples and fallbacks")
		if faces>=HeightIndex.MIN_FACES:
			var original_clear: Callable=pair[0].collision.query_preview(1,from,target,from)
			var indexed_clear: Callable=pair[1].collision.query_preview(1,from,target,from)
			check(original_clear.call(from,target)==indexed_clear.call(from,target),"Retained route initial clear")
			check(original_clear.call(from,Vector3(2,1,0))==indexed_clear.call(from,Vector3(2,1,0)),"Retained route builds index")
			for setup in pair:
				var vertex: Array=setup.world.surface.meshes.floor.vertices[0]
				vertex[0]=float(vertex[0])+0.25
			var before_mismatch: int=HeightIndex.mismatch_fallbacks
			check(original_clear.call(from,Vector3(2.5,1,0))==indexed_clear.call(from,Vector3(2.5,1,0)) and HeightIndex.mismatch_fallbacks>before_mismatch,"In-place vertex edit falls back in production")
			var surface=pair[1].world.surface;var tiles: Array=surface.definition.tiles
			surface.definition.tiles=[]
			check(not HeightIndex.worthwhile(surface,Vector3.ZERO,Vector3(9,9,0)),"Malformed tile list cannot enable index")
			surface.definition.tiles=tiles
	for setup in pair:setup.world.free()
	await process_frame;await process_frame
	var report:={"success":failures.is_empty(),"checks":checks,"failures":failures,"threshold":HeightIndex.MIN_FACES,"face_cases":[50,98],"scope":"Same production collision source flag OFF/ON, authored blocked 38-probe paths. Low-face direct route and high-face indexed route are checked by actual helper builds; no FPS or original-area claim."}
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--report="):
			var file:=FileAccess.open(argument.trim_prefix("--report="),FileAccess.WRITE);file.store_string(JSON.stringify(report,"  "));file.close()
	print(JSON.stringify(report));quit(0 if failures.is_empty() else 1)
