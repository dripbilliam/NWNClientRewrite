extends SceneTree

const Original = preload("res://.cache/nwn65/dormant-baseline-a.gd")
const Candidate = preload("res://systems/model_rigs.gd")
const Fixture = preload("res://tests/nwn65_active_event_test.gd")

var output := ""
var checks := 0
var failures: Array[String] = []

func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):
			output = arg.trim_prefix("--report=")
	call_deferred("run")

func check(value: bool, label: String) -> void:
	checks += 1
	if not value:
		failures.append(label)
		push_error(label)

func state(row: Dictionary) -> Dictionary:
	var result: Dictionary = Fixture.capture(row)
	result.erase("pose_frames")
	return result

func make(script) -> Dictionary:
	var row: Dictionary = Fixture.fixture(self, script, true)
	row.entry.animated_models = [0, 1]
	row.entry.attachments.clear()
	for index in [0, 1]:
		row.rigs._play(row.entry.models[index], "motion", false, 1.0, 0.0, true)
	row.rigs._refresh_processing()
	return row

func run() -> void:
	if output.is_empty() or FileAccess.file_exists(output):
		quit(2)
		return
	var original: Dictionary = make(Original)
	var candidate: Dictionary = make(Candidate)
	check(original.rigs.is_processing() and candidate.rigs.is_processing(), "both active one-shots initially scheduled")
	for frame in 6:
		original.rigs._update(0.125)
		candidate.rigs._update(0.125)
		check(var_to_bytes(state(original)) == var_to_bytes(state(candidate)), "clock, pose, event and serial parity through completion frame %d" % frame)
	check(original.rigs.is_processing() and not candidate.rigs.is_processing(), "completed owner suspends only its empty callback")
	var before_original := int(original.rigs.stats.pose_frames)
	var before_candidate := int(candidate.rigs.stats.pose_frames)
	for frame in 6:
		await process_frame
	var idle_original := int(original.rigs.stats.pose_frames) - before_original
	var idle_candidate := int(candidate.rigs.stats.pose_frames) - before_candidate
	check(idle_original >= 5 and idle_candidate == 0, "actual SceneTree stops only completed owner callbacks")
	check(var_to_bytes(state(original)) == var_to_bytes(state(candidate)), "dormancy retains final pose, clock and event state")
	for row in [original, candidate]:
		var direct_model: Dictionary=row.entry.models[0]
		direct_model.player.play(direct_model.names.motion)
	check(candidate.rigs.is_processing(), "external AnimationPlayer.play wakes dormant owner")
	for frame in 6:
		original.rigs._update(0.125)
		candidate.rigs._update(0.125)
		check(var_to_bytes(state(original)) == var_to_bytes(state(candidate)), "external playback preserves original clock, pose and events %d" % frame)
	check(not candidate.rigs.is_processing(), "externally started one-shot suspends again after completion")
	for row in [original, candidate]:
		row.rigs._play(row.entry.models[0], "motion", true, -1.0, 0.4, true)
	check(candidate.rigs.is_processing(), "direct playback reactivates dormant owner")
	for frame in 8:
		for row in [original, candidate]:
			if frame == 2:
				row.host.hide()
			if frame == 4:
				row.host.show()
			row.rigs._update(0.125)
		check(var_to_bytes(state(original)) == var_to_bytes(state(candidate)), "resume, reverse, hidden and visible parity frame %d" % frame)
	check(candidate.rigs.is_processing(), "looping animation remains scheduled")
	for row in [original, candidate]:
		row.entry.models[0].player.stop()
		row.entry.models[1].player.stop()
		row.rigs._refresh_processing()
	check(candidate.rigs.is_processing(), "external stop without completion retains legacy scheduling")
	Fixture.dispose(original)
	Fixture.dispose(candidate)
	# A blend can outlast the one-shot clip. Advancing a stopped player after
	# animation_finished must not carry a hidden pose transition.
	var blend_original: Dictionary = make(Original)
	var blend_candidate: Dictionary = make(Candidate)
	for row in [blend_original, blend_candidate]:
		for index in [0, 1]:
			row.entry.models[index].transitions.motion = 1.0
			row.rigs._play(row.entry.models[index], "motion", false, 1.0, 0.0, true)
	for frame in 12:
		blend_original.rigs._update(0.125)
		blend_candidate.rigs._update(0.125)
		check(var_to_bytes(state(blend_original)) == var_to_bytes(state(blend_candidate)), "blend and stopped-player pose parity frame %d" % frame)
	Fixture.dispose(blend_original)
	Fixture.dispose(blend_candidate)
	# NativeLive can transfer a fully constructed entry between rig owners.
	# Completion must notify its current owner, including after replacement.
	var donor: Dictionary = make(Candidate)
	var adopted: Dictionary = donor.duplicate()
	var receiver = Candidate.new()
	donor.host.add_child(receiver)
	receiver.adopt_entities(donor.rigs, [1])
	for index in [0, 1]:
		var player: AnimationPlayer = donor.entry.models[index].player
		check(not player.animation_finished.is_connected(Callable(donor.rigs, "_animation_finished").bind(player)),
			"adoption removes prior completion owner %d" % index)
		check(player.animation_finished.is_connected(Callable(receiver, "_animation_finished").bind(player)),
			"adoption binds current completion owner %d" % index)
		check(not player.animation_started.is_connected(Callable(donor.rigs, "_animation_started").bind(player)),
			"adoption removes prior start owner %d" % index)
		check(player.animation_started.is_connected(Callable(receiver, "_animation_started").bind(player)),
			"adoption binds current start owner %d" % index)
	donor.rigs.forget_entity(1)
	adopted.rigs = receiver
	receiver.model_event.connect(func(id: int, index: int, name: String, serial: int) -> void:
		adopted.log.append(["model", id, index, name, serial, adopted.nodes[0].position]))
	receiver.animation_event.connect(func(id: int, name: String, serial: int) -> void:
		adopted.log.append(["animation", id, name, serial]))
	var control: Dictionary = make(Candidate)
	for frame in 6:
		receiver._update(0.125)
		control.rigs._update(0.125)
		check(var_to_bytes(state(adopted)) == var_to_bytes(state(control)), "adopted owner preserves clock and event parity %d" % frame)
	check(not receiver.is_processing(), "adopted completed owner suspends its callback")
	var adopted_model: Dictionary=adopted.entry.models[0]
	adopted_model.player.play(adopted_model.names.motion)
	check(receiver.is_processing(), "external play wakes adopted owner")
	for frame in 6:
		receiver._update(0.125)
	check(not receiver.is_processing(), "adopted external playback completes and suspends")
	var replacement: Dictionary = make(Candidate)
	receiver.adopt_entities(replacement.rigs, [1])
	replacement.rigs.forget_entity(1)
	check(receiver.is_processing(), "replacement reactivates receiver with new playback")
	var old_player: AnimationPlayer = adopted.entry.models[0].player
	old_player.play(old_player.current_animation)
	old_player.advance(0.6)
	check(receiver.is_processing(), "retired model completion cannot suspend replacement")
	for frame in 6:
		receiver._update(0.125)
	check(not receiver.is_processing(), "replacement completes and suspends through rebound signal")
	old_player.play(old_player.current_animation)
	check(not receiver.is_processing(), "retired model external start cannot wake replacement")
	var replacement_model: Dictionary=replacement.entry.models[0]
	replacement_model.player.play(replacement_model.names.motion)
	check(receiver.is_processing(), "external play wakes replacement owner")
	Fixture.dispose(control)
	receiver.forget_entity(1)
	replacement.host.free()
	donor.host.free()
	var report := {"ticket": "NWN-65", "passed": failures.is_empty(), "checks": checks,
		"failures": failures, "idle_original_callbacks": idle_original,
		"idle_candidate_callbacks": idle_candidate,
		"baseline_sha256": FileAccess.get_sha256("res://.cache/nwn65/dormant-baseline-a.gd"),
		"candidate_sha256": FileAccess.get_sha256("res://systems/model_rigs.gd"),
		"scope": "Actual SceneTree completed one-shot scheduling and deterministic original/candidate clocks, events, poses, direct resume, visibility, reverse and external stop. No asset, skin, live scene or FPS claim."}
	var file := FileAccess.open(output, FileAccess.WRITE)
	file.store_string(JSON.stringify(report, "\t"))
	file.close()
	quit(0 if failures.is_empty() else 1)
