extends SceneTree
const Style=preload("res://systems/native_client_menu_style.gd")
const WindowPanel=preload("res://systems/draggable_panel.gd")
class Art extends Node:
	signal loaded(key: String,texture: Texture2D,bounds: Dictionary)
	var textures: Dictionary={}
	func request_model(name: String,clip: String="up") -> String:return name+":"+clip
class Fonts extends Node:
	signal loaded(name: String)
	var fonts: Dictionary={}
	var metrics: Dictionary={}
	func request(_name: String) -> void:pass
class Painter extends Node:
	var art:=Art.new()
	var fonts:=Fonts.new()
	func _init() -> void:add_child(art);add_child(fonts)
var checks:=0
var failures: Array=[]
var report_path:="res://.cache/nwn61/style-cache-a.json"
func _initialize() -> void:call_deferred("run")
func check(value: bool,label: String) -> void:
	checks+=1
	if not value:failures.append(label)
func run() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):report_path=arg.substr(9)
	if FileAccess.file_exists(report_path):quit(2);return
	var original:=Style.base_theme();var first:=Style.refresh_base_theme();var second:=Style.refresh_base_theme()
	check(first!=second and first!=original and second!=original,"Cached blueprint returns distinct Themes")
	check(first.get_color("font_color","Button")==original.get_color("font_color","Button") and second.get_stylebox("normal","Button").bg_color==original.get_stylebox("normal","Button").bg_color,"Cached copy matches fresh public base theme")
	var first_box: StyleBoxFlat=first.get_stylebox("normal","Button")
	var second_box: StyleBoxFlat=second.get_stylebox("normal","Button")
	check(first_box!=second_box and first_box!=original.get_stylebox("normal","Button"),"Mutable base StyleBoxes are deeply copied")
	first.set_color("font_color","Button",Color.RED);first_box.bg_color=Color.RED
	check(second.get_color("font_color","Button")==original.get_color("font_color","Button") and second_box.bg_color==original.get_stylebox("normal","Button").bg_color,"Mutating first Theme and StyleBox leaves later copies intact")
	var painter:=Painter.new();root.add_child(painter)
	var image:=Image.create_empty(2,2,false,Image.FORMAT_RGBA8);var texture:=ImageTexture.create_from_image(image)
	for name in ["ctl_btn_pre_176","ctl_btn_x"]:
		for clip in ["up","hilite","down"]:painter.art.textures[name+":"+clip]=texture
	for clip in ["uncheckedup","checkedup","disabled"]:painter.art.textures["ctl_chk_pre:"+clip]=texture
	for name in ["pb_scrl_up","pb_scrl_down"]:painter.art.textures[name+":up"]=texture
	var font:=FontFile.new();painter.fonts.fonts[Style.FONT]=font;painter.fonts.metrics[Style.FONT]={"height":17.0}
	var window:=WindowPanel.new();root.add_child(window);window.configure("Style copy","style-copy",Vector2.ZERO,"")
	var publisher_a:=Style.new();root.add_child(publisher_a);publisher_a.configure(painter)
	var first_published: Theme=publisher_a.current
	check(window.theme==first_published and first_published.default_font==font and first_published.get_stylebox("normal","Button") is StyleBoxTexture,"First publication retains font, artwork and window theme")
	first_published.set_color("font_color","Label",Color.RED)
	var publisher_b:=Style.new();root.add_child(publisher_b);publisher_b.configure(painter)
	var second_published: Theme=publisher_b.current
	check(second_published!=first_published and second_published.get_color("font_color","Label")!=Color.RED and second_published.default_font==font and second_published.get_icon("client_close","Button")==texture,"Reopened publication has independent colors and same authored resources")
	check(window.theme==second_published and get_meta("native_client_menu_theme",null)==second_published,"New publisher replaces visible window and tree theme")
	publisher_a.close();publisher_a.free()
	check(window.theme==second_published and get_meta("native_client_menu_theme",null)==second_published,"Closing previous publisher cannot clear current theme")
	publisher_b.close();publisher_b.free()
	check(not has_meta("native_client_menu_theme"),"Closing current publisher clears tree-scoped theme")
	var publisher_c:=Style.new();root.add_child(publisher_c);publisher_c.begin_entry_publication();publisher_c.configure(painter)
	check(publisher_c.current==null and window.theme==second_published,"Staged reopen leaves the old window theme until publication")
	publisher_c.entry_publication_step()
	var late_image:=Image.create_empty(2,2,false,Image.FORMAT_RGBA8);late_image.fill(Color.BLUE)
	var late_texture:=ImageTexture.create_from_image(late_image)
	publisher_c.art_loaded("ctl_btn_pre_176:up",late_texture,{})
	var result: Dictionary={}
	for index in 32:
		result=publisher_c.entry_publication_step()
		if result.get("done",false):break
	check(result.get("accepted",false) and window.theme==publisher_c.current and publisher_c.current.get_stylebox("normal","Button").texture==late_texture,"Staged reopen publishes the latest art and theme")
	check(publisher_c.current.get_color("font_color","Label")!=Color.RED and publisher_c.current.default_font==font,"Staged reopen keeps independent base values and authored font")
	publisher_c.close();publisher_c.free()
	check(not has_meta("native_client_menu_theme"),"Staged publisher retirement clears tree theme")
	window.free();painter.free()
	var report:={"issue":"NWN-61","passed":failures.is_empty(),"checks":checks,"failures":failures,"scope":"Headless base-theme deep-copy and repeated publisher lifecycle; no original assets, FPS or world-entry timing"}
	var file:=FileAccess.open(report_path,FileAccess.WRITE);file.store_string(JSON.stringify(report,"\t"));file.close()
	print(JSON.stringify(report));quit(0 if failures.is_empty() else 1)
