extends SceneTree
const Original=preload("res://tests/nwn61_tail_menu_original.gd")
const Candidate=preload("res://tests/nwn61_tail_menu_candidate.gd")
const Owners=preload("res://tests/nwn61_tail_owners.gd")
var checks:=0
var failures: Array=[]
var output:=""
func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.trim_prefix("--report=")
	call_deferred("run")
func check(value: bool,label: String) -> void:
	checks+=1
	if not value:failures.append(label);push_error(label)
func setup(script):
	var menu=script.new();root.add_child(menu);menu.layout_path=""
	menu.pregame=Owners.Pregame.new();menu.pregame.painter=Owners.Painter.new("pregame");menu.get_child(0).add_child(menu.pregame)
	menu.client_style=Owners.Style.new();menu.get_child(0).add_child(menu.client_style)
	menu.native_frame=Owners.Frame.new();menu.panel.add_child(menu.native_frame)
	menu.video_owner=Owners.Video.new();menu.get_child(0).add_child(menu.video_owner)
	menu.key_owner=Owners.Keys.new();menu.get_child(0).add_child(menu.key_owner)
	menu.window_settings=Node.new();root.add_child(menu.window_settings)
	menu.key_bindings=Owners.Bindings.new();menu.observed_bindings=menu.key_bindings;menu.key_bindings.changed.connect(menu.update_native)
	return menu
func finish(menu) -> void:
	menu.window_settings.free();menu.free()
func run() -> void:
	if output.is_empty() or FileAccess.file_exists(output):quit(2);return
	var painter:=Owners.Painter.new("gameplay");var scope: Array=[1,4,7,99]
	var original=setup(Original);Owners.EventLog.items=[];original.configure_native(painter,null,null,"",scope)
	var original_events: Array=Owners.EventLog.items.duplicate();var original_state:={"scope":original.native_scope.duplicate(),"frame_scope":original.native_frame.scope.duplicate(),"theme":original.panel.theme.get_meta("painter"),"playing":original.native_playing,"has_video":is_instance_valid(original.video_owner),"has_keys":is_instance_valid(original.key_owner)}
	finish(original)
	var candidate=setup(Candidate);Owners.EventLog.items=[]
	var state: Dictionary=candidate.begin_native_configuration(painter,null,null,"",scope);var steps:=0;var result: Dictionary={}
	while steps<30:
		result=candidate.native_configuration_step(state);steps+=1
		if result.get("done",false):break
	check(result.get("accepted",false) and steps==20,"style publication continuation reaches full configuration in20ordered steps")
	check(Owners.EventLog.items==original_events,"actual original menu and candidate preserve exact owner/style/theme/callback operation ordering")
	var final_state:={"scope":candidate.native_scope.duplicate(),"frame_scope":candidate.native_frame.scope.duplicate(),"theme":candidate.panel.theme.get_meta("painter"),"playing":candidate.native_playing,"has_video":is_instance_valid(candidate.video_owner),"has_keys":is_instance_valid(candidate.key_owner)}
	check(final_state==original_state,"original/candidate final menu ownership/scope/theme match")
	check(not candidate.native_configuration_step(state).get("accepted",false),"completed configuration token cannot run again")
	finish(candidate)
	# A REAL pending task must not be joined or busy-polled by a menu step.
	candidate=setup(Candidate);var gate:=Semaphore.new();var task:=WorkerThreadPool.add_task(func():gate.wait())
	var old_keys=candidate.key_owner;old_keys.assets.running={"held":task}
	state=candidate.begin_native_configuration(painter,null,null,"",scope)
	candidate.native_configuration_step(state);candidate.native_configuration_step(state)
	result=candidate.native_configuration_step(state)
	check(result.get("blocked",false) and candidate.key_owner==old_keys and not old_keys.closed,"unfinished real worker blocks cooperatively before close")
	check(old_keys.assets.retirements==1,"retirement invalidates pending requests exactly once")
	result=candidate.native_configuration_step(state)
	check(result.get("blocked",false) and old_keys.assets.retirements==1,"repeated external poll does not re-retire or join worker")
	gate.post()
	while not WorkerThreadPool.is_task_completed(task):await process_frame
	result=candidate.native_configuration_step(state)
	check(not result.get("blocked",false) and old_keys.closed and candidate.key_owner==null,"only completed real worker is joined by owner close")
	candidate.cancel_native_configuration(state);check(state.cancelled and candidate.native_configuration.is_empty(),"cancel invalidates exact active token")
	var replacement: Dictionary=candidate.begin_native_configuration(painter,null,null,"",scope)
	candidate.cancel_native_configuration(state);check(candidate.native_configuration_current(replacement),"old cancellation cannot revoke replacement configuration")
	finish(candidate)
	# Synchronous theme observers can revoke work during either original theme
	# notification. No later menu owner may be created by the invalid token.
	for tag in ["pregame","gameplay"]:
		candidate=setup(Candidate)
		var target=candidate
		candidate.client_theme_changed.connect(func(value: Theme):
			if value.get_meta("painter","")==tag:target.cancel_native_configuration())
		state=candidate.begin_native_configuration(painter,null,null,"",scope);Owners.EventLog.items=[];steps=0
		while steps<30:
			result=candidate.native_configuration_step(state);steps+=1
			if result.get("done",false):break
		check(result.get("done",false) and not result.get("accepted",false) and state.cancelled,"theme callback cancels active configure during "+tag)
		check(not Owners.EventLog.items.has("video.configure") and not Owners.EventLog.items.has("keys.configure"),"cancelled theme callback cannot create subsequent child owners "+tag)
		finish(candidate)
	await process_frame
	var file:=FileAccess.open(output,FileAccess.WRITE);file.store_string(JSON.stringify({"passed":failures.is_empty(),"checks":checks,"failures":failures,"original_events":original_events,"final_state":original_state,"scope":"Actual original/candidate MainMenu logic with authored frame/video/key/style providers; real WorkerThreadPool retirement and callback tokens. No originalasset, GPU, FPS or4ms performance claim."},"\t"));file.close();quit(0 if failures.is_empty() else 1)
