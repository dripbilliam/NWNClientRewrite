extends "res://tests/nwn63_single_preview_breakdown_test.gd"
# Same-source control/candidate ABBA of private walkable-face culling.
# The timed call includes query_preview creation and the complete 38-probe path.
const Candidate=preload("res://.cache/nwn63/single-preview-broadphase-a/drive_collision_indexed.gd")

func stats_for(samples: Array)->Dictionary:
	var sorted:=samples.duplicate();sorted.sort();var total:=0.0
	for value in sorted:total+=float(value)
	return {"count":sorted.size(),"mean_us":total/sorted.size(),"median_us":sorted[sorted.size()/2],"p95_us":sorted[mini(sorted.size()-1,ceili(sorted.size()*0.95)-1)],"p99_us":sorted[mini(sorted.size()-1,ceili(sorted.size()*0.99)-1)],"max_us":sorted[-1]}

func make_pair()->Array:
	var pair: Array=[]
	for candidate in [false,true]:
		var setup:=make_world(false);var collision=Candidate.new() if candidate else Collision.new()
		setup.world.add_child(collision);collision.world=setup.world;collision.tables=tables();setup.world.drive_collision=collision;collision.ensure_spatial_scope();collision.set_process(false)
		var rows: Array=[creature(1,Vector2(1,1)),creature(4,Vector2(6,3)),object(2,Vector2(4,1)),object(3,Vector2(9,1),10)]
		collision.publish_model("chest:placeable",{"states":[footprint()]})
		collision.publish_model("gate:door",{"states":[footprint(),{"vertices":[],"faces":[]},footprint(2)]})
		for i in 340:
			var key:="cohort_"+str(i);var appearance: int=collision.tables.placeables.orderedRows.size()
			collision.tables.placeables.orderedRows.append({"ModelName":key})
			if i%17!=0:collision.publish_model(key+":placeable",{"states":[footprint(1+i%4)]})
			rows.append(object(100+i,Vector2(24+(i%12)*8,24+(i/12)*8),9,1,appearance))
		for extra in 549:
			var cohort:=extra%340
			var anchor:=Vector2(24+(cohort%12)*8,24+(cohort/12)*8)
			rows.append(object(1000+extra,anchor+Vector2(float(extra%3)*0.4,float(extra%5)*0.4),9,1,2+cohort))
		setup.world.receive(rows,1);setup.collision=collision;pair.append(setup)
		check(collision.static_groups.size()==342 and int(collision.snapshot().static_entries)==891,"Same 342-group/891-entry publication")
	return pair

func install_floor(setup: Dictionary,density: int)->void:
	var collision=setup.collision
	if density==1152:grid_mesh(setup.world,24)
	collision.tiles.clear()
	var faces: Array=collision.tile(0)
	var blocker: Dictionary=Candidate.triangle(Vector3(0,0,0),Vector3(5,0,0),Vector3(0,5,0)) if collision.get_script()==Candidate else Collision.triangle(Vector3(0,0,0),Vector3(5,0,0),Vector3(0,5,0))
	blocker.walk=false;faces.append(blocker)

func measure_case(pair: Array,density: int,samples: int)->Dictionary:
	var from:=Vector3(1,1,0);var target:=Vector3(3,1,0)
	var tile_cold: Array=[];var geometry_bytes: Array=[]
	for setup in pair:
		if density==1152:grid_mesh(setup.world,24)
		var collision=setup.collision;var times: Array=[]
		for warm in 3:collision.tiles.clear();collision.tile(0)
		for sample in 8:
			collision.tiles.clear();var began:=Time.get_ticks_usec();var triangles: Array=collision.tile(0);times.append(Time.get_ticks_usec()-began)
			if sample==0:geometry_bytes.append(var_to_bytes(triangles).size())
		tile_cold.append(stats_for(times))
		install_floor(setup,density)
	var blocks: Array=[];var reference_result:=PackedByteArray();var reference_transcript: Array=[]
	for index in [0,1,1,0]:
		var collision=pair[index].collision
		for warm in 8:Plan.path(from,target,from,collision.query_preview(1,from,target,from))
		var one: Dictionary=profile_path(collision,"preview",from,target,false)
		var one_bytes:=var_to_bytes(one.path)
		if reference_result.is_empty():reference_result=one_bytes;reference_transcript=one.transcript
		check(one_bytes==reference_result and one.transcript==reference_transcript and one.transcript.size()==38,"Exact 38-probe result/transcript density "+str(density))
		var before: Dictionary=collision.preview_stats.duplicate(true)
		var times: Array=[];var result_digest:=0
		for sample in samples:
			var began:=Time.get_ticks_usec()
			var result: Dictionary=Plan.path(from,target,from,collision.query_preview(1,from,target,from))
			times.append(Time.get_ticks_usec()-began)
			var bytes:=var_to_bytes(result)
			check(bytes==reference_result,"Exact sampled path density "+str(density))
			result_digest=result_digest^hash(bytes)
		var counts: Dictionary={}
		for key in collision.preview_stats:counts[key]=int(collision.preview_stats[key])-int(before[key])
		check(int(counts.probes)==38*samples and int(counts.collections)==samples and int(counts.reused_clears)==37*samples and int(counts.fallback_clears)==0,"Complete contained 38-probe route density "+str(density))
		blocks.append({"owner":"candidate" if index==1 else "control","timing":stats_for(times),"counts":counts,"probes":int(counts.probes),"digest":result_digest})
	var baseline_terms:=int(blocks[0].counts.get("from_terms_prepared",0))+int(blocks[0].counts.get("from_terms_reused",0))
	var candidate_terms:=int(blocks[1].counts.get("from_terms_prepared",0))+int(blocks[1].counts.get("from_terms_reused",0))
	check(int(blocks[0].counts.collections)==int(blocks[1].counts.collections) and int(blocks[0].counts.probes)==int(blocks[1].counts.probes),"Exact collection/probe scheduling density "+str(density))
	return {"floor_faces":density,"groups":342,"static_entries":891,"tile_build_us":[tile_cold[0],tile_cold[1]],"serialized_tile_bytes":[geometry_bytes[0],geometry_bytes[1]],"walkable_interval_evaluations_control":baseline_terms,"walkable_interval_evaluations_candidate":candidate_terms,"walkable_interval_evaluations_avoided":baseline_terms-candidate_terms,"blocks":blocks}

func run()->void:
	var options: Dictionary={}
	for argument in OS.get_cmdline_user_args():
		var split:=argument.trim_prefix("--").split("=",true,1)
		if split.size()==2:options[split[0]]=split[1]
	var samples:=int(options.get("samples",32));check(samples>=16 and samples<=64,"Bounded sample count")
	var pair:=make_pair();var cases: Array=[]
	for density in [2,1152]:cases.append(measure_case(pair,density,samples))
	for setup in pair:setup.world.free()
	await process_frame;await process_frame
	var report:={"success":failures.is_empty(),"checks":checks,"failures":failures,"cases":cases,"order":"A-B-B-A per density","scope":"Same accepted Core E binary and authored 342-group/891-entry source pair; private AABB script versus current accepted script, complete 38-probe path including query creation. Warm path samples and separate cold tile-construction samples; serialized tile bytes are a data-size proxy, not heap/RSS. No live original area or FPS acceptance."}
	if options.has("report"):
		var file:=FileAccess.open(str(options.report),FileAccess.WRITE);file.store_string(JSON.stringify(report,"  "));file.close()
	print(JSON.stringify({"success":report.success,"checks":checks,"failures":failures,"cases":cases}));quit(0 if failures.is_empty() else 1)
