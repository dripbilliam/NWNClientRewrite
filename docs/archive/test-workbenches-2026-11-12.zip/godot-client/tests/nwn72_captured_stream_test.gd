extends SceneTree
const Motion=preload("res://systems/network_motion.gd")
const Lifetime=preload("res://systems/native_data/entity_presentation_lifetime.gd")
var checks:=0
var failures: Array=[]
var output:=""
var captured:=""
var fixture_output:=""
var sources: Dictionary={}
var revisions: Dictionary={}
var generation:=-1
var area:=-1
func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.trim_prefix("--report=")
		if arg.begins_with("--captured="):captured=arg.trim_prefix("--captured=")
		if arg.begins_with("--fixture="):fixture_output=arg.trim_prefix("--fixture=")
	call_deferred("run")
func check(value: bool,label: String) -> void:
	checks+=1
	if not value and failures.size()<20:failures.append(label);push_error(label)
func bind(motion) -> void:
	motion.facing_target_query=func(id):
		var source: Dictionary=sources.get(id,{})
		if int(source.get("areaId",-1))!=area or source.get("replicationRemoved",false):return null
		if motion.objects.has(id):return motion.objects[id].position
		var position: Variant=source.get("replicated",{}).get("position")
		return Motion.vector(position) if position is Array and position.size()>=3 else null
func apply_snapshot(motions: Array,snapshot: Dictionary) -> void:
	var prior: Dictionary=sources.duplicate()
	if snapshot.mode=="full":
		var current: Dictionary={}
		for source in snapshot.objects:current[int(source.id)]=source
		for id in sources:
			if not current.has(id):
				for motion in motions:motion.objects.erase(id)
		sources=current
	else:
		for id in snapshot.removed:
			sources.erase(int(id));revisions.erase(int(id))
			for motion in motions:motion.objects.erase(int(id))
		for source in snapshot.objects:sources[int(source.id)]=source
	for source in snapshot.objects:
		var id:=int(source.id)
		if int(source.objectType)!=5 or int(source.areaId)!=area or source.replicationRemoved:
			for motion in motions:motion.objects.erase(id)
			continue
		var state: Dictionary=source.replicated
		if not state.get("position") is Array or state.position.size()<3:continue
		for motion in motions:
			if prior.has(id) and Lifetime.changed(prior[id],source):motion.objects.erase(id);revisions.erase(id)
			if not motion.objects.has(id):motion.observe(id,state,true,state)
			motion.objects[id].facingTarget=int(state.get("facingTarget",0x7f000000))
func run() -> void:
	if output.is_empty() or captured.is_empty() or FileAccess.file_exists(output):quit(2);return
	var baseline=load("res://.cache/nwn72/baseline/systems/network_motion.gd")
	var input: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(captured));var original=baseline.new();var candidate:=Motion.new();var quiet:=Motion.new()
	quiet.collect_diagnostics=false
	bind(original);bind(candidate);bind(quiet)
	var reports: Dictionary={};var total_rows:=0;var total_settled:=0;var peak_rows:=0;var peak: Dictionary={}
	for event in input.events:
		if event.kind=="reset":
			sources={};revisions={};generation=-1;area=-1
			original.configure([]);candidate.configure([]);quiet.configure([]);continue
		if event.kind=="snapshot":
			var snapshot: Dictionary=event.value
			if int(snapshot.generation)!=generation:
				original.facing_target_query=Callable();candidate.facing_target_query=Callable();quiet.facing_target_query=Callable()
				original=baseline.new();candidate=Motion.new();quiet=Motion.new();quiet.collect_diagnostics=false;bind(original);bind(candidate);bind(quiet)
				sources={};revisions={};generation=int(snapshot.generation);area=int(snapshot.area)
			apply_snapshot([original,candidate,quiet],snapshot)
		elif event.kind=="movement" and int(event.generation)==generation and int(event.area)==area:
			for row in event.records:
				var id:=int(row.id);var revision:=int(row.revision)
				if revision<=int(revisions.get(id,-1)):continue
				revisions[id]=revision
				for motion in [original,candidate,quiet]:motion.observe(id,row.changes,bool(row.get("created",false)),row.initial)
		if generation<0:continue
		original.update(0.016);candidate.update(0.016);quiet.update(0.016)
		check(var_to_bytes(original.objects)==var_to_bytes(candidate.objects),"captured ordered input bit-exact event"+str(checks))
		check(var_to_bytes(candidate.objects)==var_to_bytes(quiet.objects),"quiet diagnostics preserve captured motion state event"+str(checks))
		check(int(quiet.evaluation_stats.updates)==0,"quiet diagnostics do not accumulate stats event"+str(checks))
		var counts:=candidate.evaluation_snapshot();var key:=str(generation)
		if not reports.has(key):reports[key]={"generation":generation,"area":area,"samples":0,"rows":0,"settled":0,"active":0,"correcting":0,"targeted":0,"maximum_registered":0}
		var report: Dictionary=reports[key]
		report.samples+=1;report.rows+=int(counts.last_rows);report.settled+=int(counts.last_stationary_settled);report.active+=int(counts.last_active);report.correcting+=int(counts.last_correcting);report.targeted+=int(counts.last_targeted);report.maximum_registered=maxi(int(report.maximum_registered),int(counts.last_rows))
		total_rows+=int(counts.last_rows);total_settled+=int(counts.last_stationary_settled)
		if int(counts.last_rows)>peak_rows:
			peak_rows=int(counts.last_rows)
			peak={"generation":generation,"area":area,"motion":original.objects.duplicate(true),"sources":sources.duplicate(true),"counts":counts.duplicate()}
		for id in original.objects:original.finish_frame(int(id));candidate.finish_frame(int(id));quiet.finish_frame(int(id))
	check(peak_rows>0 and total_rows>0,"captured subsequent deltas supply actual populated motion workload")
	original.facing_target_query=Callable();candidate.facing_target_query=Callable();quiet.facing_target_query=Callable()
	if not fixture_output.is_empty():
		var fixture:=FileAccess.open(fixture_output,FileAccess.WRITE);fixture.store_var(peak,false);fixture.close()
	var file:=FileAccess.open(output,FileAccess.WRITE);file.store_string(JSON.stringify({"checks":checks,"failures":failures,"passed":failures.is_empty(),"timeline_sha256":input.timelineSha256,"total_rows":total_rows,"settled_rows":total_settled,"maximum_registered":peak_rows,"areas":reports.values(),"scope":"Actual ordered captured full/delta/movement inputs sampled once16ms per admitted message, with received facing targets. No later combat visualAnimation, local drive prediction, time-weighted live eligibility, renderer or FPS claim"},"\t"));file.close();quit(0 if failures.is_empty() else 1)
