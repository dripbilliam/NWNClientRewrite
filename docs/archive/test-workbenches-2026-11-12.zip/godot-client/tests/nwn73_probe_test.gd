extends SceneTree
var checks:=0
var failures: Array=[]
func check(value: bool,label: String) -> void:
	checks+=1
	if not value:failures.append(label);push_error(label)
func _initialize() -> void:call_deferred("run")
func run() -> void:
	var args: Dictionary={}
	for arg in OS.get_cmdline_user_args():
		var pair:=arg.trim_prefix("--").split("=",true,1)
		if pair.size()==2:args[pair[0]]=pair[1]
	if not args.has("report") or FileAccess.file_exists(args.report):quit(2);return
	check(ClassDB.class_exists("NwnCpuProbe"),"Private read-only probe loads")
	if not failures.is_empty():quit(1);return
	var probe: RefCounted=ClassDB.instantiate("NwnCpuProbe")
	var stamp: int=probe.call("stamp");probe.call("capture",0,stamp)
	var task: int=WorkerThreadPool.add_task(Callable(probe,"capture").bind(2,probe.call("stamp")),false,"NWN73 read-only CPU sample")
	RenderingServer.call_on_render_thread(Callable(probe,"capture").bind(1,probe.call("stamp")))
	var rows: Array=[];var dropped:=0;var frequency:=0
	for attempt in 300:
		var packet: Dictionary=probe.call("take");frequency=int(packet.qpc_frequency);rows.append_array(packet.samples);dropped+=int(packet.dropped)
		if rows.size()>=3 and WorkerThreadPool.is_task_completed(task):break
		await process_frame
	check(WorkerThreadPool.is_task_completed(task),"Sparse worker callback completed")
	if WorkerThreadPool.is_task_completed(task):WorkerThreadPool.wait_for_task_completion(task)
	var main_tid:=-1;var worker_tid:=-1;var render_tid:=-1
	for row in rows:
		check(int(row.pid)==OS.get_process_id() and int(row.tid)>0,"Actual Windows callback process/thread identity")
		check(int(row.cpu)>=0 and int(row.cpu)<OS.get_processor_count() and int(row.group)==0,"Actual executing CPU sample fits this host topology")
		check(int(row.qpc)>=int(row.submitted) and int(row.cycles)>=0,"Monotonic enqueue/sample counters")
		check(int(row.power_error)==0,"Current-thread QoS read is supported")
		if int(row.channel)==0:main_tid=int(row.tid)
		if int(row.channel)==1:render_tid=int(row.tid)
		if int(row.channel)==2:worker_tid=int(row.tid)
	check(frequency>0 and dropped==0 and rows.size()==3,"Allthree sparse samples observed without overflow")
	check(main_tid>0 and worker_tid>0 and main_tid!=worker_tid,"Worker callback runs on an actual different OS thread")
	check(render_tid>0,"Render callback executes; actual thread relation reported without assuming headless renderer")
	var separate: bool=ProjectSettings.get_setting("rendering/driver/threads/thread_model")==2
	if args.get("expect-render","")=="separate":check(separate and render_tid!=main_tid,"Configured separate-render callback has a distinct actual Windows TID")
	for index in 4097:probe.call("capture",7,0)
	var full: Dictionary=probe.call("take");check(full.samples.size()==4096 and int(full.dropped)==1,"Private bounded ring reports overflow without allocation growth")
	var empty: Dictionary=probe.call("take");check(empty.samples.is_empty() and int(empty.dropped)==0,"Taking a packet drains records and overflow counts")
	var weak: WeakRef=weakref(probe);probe=null;check(weak.get_ref()==null,"Completed callbacks and packet do not retain probe ownership")
	var report:={"issue":"NWN-73","success":failures.is_empty(),"checks":checks,"failures":failures,"samples":rows,"qpcFrequency":frequency,"mainWindowsTid":main_tid,"renderWindowsTid":render_tid,"workerWindowsTid":worker_tid,"separateRenderConfigured":separate,"actualRenderSeparate":render_tid!=main_tid,"scope":"Untimed private read-only CPU probe correctness; main/render/worker actual OS identity and executing CPU, queued callback completion, bounded overflow/drain and owner retirement. No scheduling changes, workload benchmark or FPS measurement."}
	var file:=FileAccess.open(args.report,FileAccess.WRITE);file.store_string(JSON.stringify(report,"\t"));file.close();print("NWN73_PROBE ",checks," checks; ",failures.size()," failures");quit(0 if failures.is_empty() else 1)
