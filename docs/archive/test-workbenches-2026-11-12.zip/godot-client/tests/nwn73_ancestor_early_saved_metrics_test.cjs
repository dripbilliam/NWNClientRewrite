'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const root=path.resolve(__dirname,'..');
const source=path.join(root,'reports/nwn73-entry-b-on.json');
const output=path.join(root,'.cache/nwn73/ancestor-early-a/saved-pme0-projection.json');
const bytes=fs.readFileSync(source),report=JSON.parse(bytes.toString('utf8'));
const job=report.native.world.batches.flatMap(b=>b.jobs).find(j=>j.model==='pme0'&&j.phases?.ancestor_preparation?.reads?.length>1);
assert.ok(job,'saved pme0 job with ancestor reads');
const old=job.phases.ancestor_preparation;
const readNames=old.reads.map(r=>r.name);
assert.deepEqual(readNames,['a_ba','a_ba_non_combat','a_ba_med_weap','a_ba_custom','a_ba_casts']);
assert.equal(old.sources[0].name,'a_ba');
const prefix=old.reads.slice(0,2);
const sum=list=>Number(list.reduce((value,r)=>value+r.ms,0).toFixed(3));
const sumBytes=list=>list.reduce((value,r)=>value+r.bytes,0);
assert.equal(sum(old.reads),54.797);
assert.equal(sum(prefix),43.085);
assert.equal(sumBytes(old.reads),old.held_source_bytes);
const projection={schema:'nwn73-ancestor-early-projection-v1',source,
  sourceSha256:crypto.createHash('sha256').update(bytes).digest('hex'),model:'pme0',
  saved:{helper:old.sources[0].name,startup_ms:old.startup_ms,reads:old.reads,read_sum_ms:sum(old.reads),held_source_bytes:old.held_source_bytes},
  earlyOneHelper:{projected_helper:prefix[1].name,required_read_names:prefix.map(r=>r.name),saved_read_sum_ms:sum(prefix),saved_read_bytes:sumBytes(prefix),omitted_tail_read_ms:sum(old.reads.slice(2)),omitted_tail_bytes:sumBytes(old.reads.slice(2)),projected_startup_ms_if_nonread_cost_constant:Number((old.startup_ms-sum(old.reads.slice(2))).toFixed(3))},
  limitation:'This subtracts saved tail read times only. It is not an early-policy runtime, loading, FPS, contention or cache measurement.'};
fs.writeFileSync(output,JSON.stringify(projection,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({output,old_helper:projection.saved.helper,projected_helper:projection.earlyOneHelper.projected_helper,old_startup_ms:old.startup_ms,projected_startup_ms:projection.earlyOneHelper.projected_startup_ms_if_nonread_cost_constant,tail_read_ms:projection.earlyOneHelper.omitted_tail_read_ms}));
