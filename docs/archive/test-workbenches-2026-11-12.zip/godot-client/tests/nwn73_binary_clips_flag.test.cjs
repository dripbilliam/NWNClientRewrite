'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
const project=path.resolve(__dirname,'..');
const flags=require('../tools/native-client-flags.cjs');
const binary=flags.catalogue(project).features.filter(row=>row.name==='binary-clips');
assert.equal(binary.length,1);
assert.deepEqual(binary[0].choices,['off','parallel']);
assert.equal(binary[0].default,'off');
assert.equal(binary[0].target,'native');
assert.equal(binary[0].forwarder,'performance');
for(const argv of [[],['--performance-runtime=verified-native']]){
 const resolved=flags.resolvePerformanceOptions(argv);
 assert.deepEqual(resolved.requested['binary-clips'],{value:'off',explicit:false});
 assert(!resolved.nativeArguments.some(value=>value.startsWith('--binary-clips=')));
}
for(const choice of ['off','parallel']){
 const token='--binary-clips='+choice;
 const parsed=flags.validateHostOptions([token]);
 assert.equal(parsed.values['binary-clips'],choice);
 const resolved=flags.resolvePerformanceOptions([token]);
 assert.deepEqual(resolved.requested['binary-clips'],{value:choice,explicit:true});
 assert.equal(resolved.nativeArguments.filter(value=>value.startsWith('--binary-clips=')).length,1);
 assert(resolved.nativeArguments.includes(token));
}
for(const argv of [['--binary-clips'],['--binary-clips=worker'],['--binary-clips=on'],['--binary-clips=parallel','--binary-clips=off']])assert.throws(()=>flags.validateHostOptions(argv));
const actor=fs.readFileSync(path.join(project,'systems/native_data/actor_model.gd'),'utf8');
assert(actor.includes('OS.get_cmdline_user_args().has("--binary-clips=parallel")'));
assert(actor.includes('binary_clip_helpers_active<1'));
console.log(JSON.stringify({passed:true,checks:22,scope:'Default-off explicit binary clip selection, host validation and one bounded existing parser helper; no Godot launch, original entry or FPS.'}));
