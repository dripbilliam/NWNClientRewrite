extends SceneTree
func _initialize() -> void:call_deferred("run")
func run() -> void:
	var args: Dictionary={}
	for arg in OS.get_cmdline_user_args():
		var pair:=arg.trim_prefix("--").split("=",true,1)
		if pair.size()==2:args[pair[0]]=pair[1]
	if not args.has("report") or FileAccess.file_exists(args.report):quit(2);return
	var report:={"pid":OS.get_process_id(),"mainThread":OS.get_main_thread_id(),"processorCount":OS.get_processor_count(),"poolSetting":ProjectSettings.get_setting("threading/worker_pool/max_threads"),"lowPriorityRatio":ProjectSettings.get_setting("threading/worker_pool/low_priority_thread_ratio"),"overrides":ProjectSettings.get_setting("threading/worker_pool/max_threads")!=-1,"scope":"Idle private engine pool inventory only; no workload, timing, frame/FPS or rendering test."}
	var file:=FileAccess.open(args.report,FileAccess.WRITE);file.store_string(JSON.stringify(report,"\t"));file.close();print("NWN73_POOL_READY ",report.pid)
	await create_timer(10.0).timeout;quit()
