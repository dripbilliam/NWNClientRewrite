extends SceneTree
const Baseline=preload("res://.cache/nwn65/active-baseline-b/systems/model_rigs.gd")
const Candidate=preload("res://systems/model_rigs.gd")
const Fixture=preload("res://tests/nwn65_active_event_test.gd")
class EventlessOwner extends RefCounted:
	var events: Array=[]
	var calls:=0
	var gob:={"runsE0":[{"clip0":{"name":"native"},"speed8":1.0,"time14":0.0,"flagsC":0}]}
	func advance(delta: float) -> void:
		calls+=1;gob.runsE0[0].time14+=delta
	func close() -> void:events.clear()
var output:=""
var checks:=0
var failures: Array=[]
func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.trim_prefix("--report=")
	call_deferred("run")
func check(ok: bool,label: String) -> void:
	checks+=1
	if not ok:failures.append(label);push_error(label)
func digest(value: Variant) -> String:
	var context:=HashingContext.new();context.start(HashingContext.HASH_SHA256);context.update(var_to_bytes(value));return context.finish().hex_encode()
func statistics(values: Array[int]) -> Dictionary:
	values.sort()
	return {"median_us":values[values.size()/2],"p95_us":values[int(ceil(values.size()*0.95))-1],"worst_us":values[-1]}
func leg(script,eventless: bool) -> Dictionary:
	var rows: Array=[]
	for index in 80:
		var row: Dictionary=Fixture.fixture(self,script,false)
		row.entry.animated_models=[2]
		row.entry.attachments.clear()
		if eventless:row.entry.models[2].native_owner=EventlessOwner.new()
		rows.append(row)
	var samples: Array[int]=[]
	for frame in 140:
		var began:=Time.get_ticks_usec()
		for row in rows:row.rigs._update(1.0/60.0)
		if frame>=20:samples.append(Time.get_ticks_usec()-began)
	var snapshots: Array=[];var event_rows:=0;var calls:=0;var retained:=0
	for row in rows:
		snapshots.append(Fixture.capture(row));event_rows+=row.log.size();calls+=row.entry.models[2].native_owner.calls
		retained+=int(row.rigs.event_batch_snapshot().retained_batches)
		Fixture.dispose(row)
	return {"owners":80,"calls":calls,"event_rows":event_rows,"retained_batches":retained,"state_sha256":digest(snapshots),"timing":statistics(samples)}
func run() -> void:
	if output.is_empty() or FileAccess.file_exists(output):quit(2);return
	var source_sha:=FileAccess.get_sha256("res://systems/model_rigs.gd")
	var baseline_sha:=FileAccess.get_sha256("res://.cache/nwn65/active-baseline-b/systems/model_rigs.gd")
	var cases: Array=[]
	for eventless in [true,false]:
		var legs: Array=[]
		for mode in ["baseline","candidate","candidate","baseline"]:
			var result:=leg(Baseline if mode=="baseline" else Candidate,eventless);result.mode=mode;legs.append(result)
			check(result.owners==80 and result.calls==80*140,"80 actual native owners advance in every measured frame")
			check(result.event_rows==0 if eventless else result.event_rows>0,"event population matches scenario")
			check(result.state_sha256==legs[0].state_sha256,"clock/pose/event output matches baseline")
		cases.append({"eventless":eventless,"legs":legs})
	check(source_sha==FileAccess.get_sha256("res://systems/model_rigs.gd"),"candidate source unchanged")
	check(baseline_sha=="3007891a0a8d6f7505dc6f08ba8eb9d76bc6ab78a4a142a5da94378627fd611b","frozen pre-edit source unchanged")
	var file:=FileAccess.open(output,FileAccess.WRITE)
	file.store_string(JSON.stringify({"ticket":"NWN-65","passed":failures.is_empty(),"checks":checks,"failures":failures,"candidate_sha256":source_sha,"baseline_sha256":baseline_sha,"cases":cases,"scope":"Manual headless ModelRigs._update component ABBA for 80 native-owner rigs, 140 frames, no skins/attachments, eventless and periodic native events. No live original asset, GPU or FPS inference."},"\t"))
	file.close();quit(0 if failures.is_empty() else 1)
