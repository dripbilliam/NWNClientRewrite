extends SceneTree

func _initialize() -> void:
	var script: Variant=load("res://.cache/nwn63/support-diagnostic-a/native_client_support_scene.gd")
	if script is GDScript and script.can_instantiate():
		print("NWN63_SUPPORT_DIAGNOSTIC_PARSE_OK")
		quit(0)
	else:
		push_error("NWN-63 support diagnostic overlay did not parse")
		quit(1)
