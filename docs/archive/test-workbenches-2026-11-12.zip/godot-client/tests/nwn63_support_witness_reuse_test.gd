extends SceneTree
# The real scene fixture covers authored geometry. This checks the no-ray
# tile branch, where only query()'s final witness can reject a changed source.
const Adapter=preload("res://systems/native_render/native_client_support_scene.gd")
var checks:=0
var failures: Array=[]

class SurfaceStub extends Node:
	var definition:={"width":1,"height":1,"tiles":[]}

class WorldStub extends Node3D:
	var generation:=1
	var area_id:=25
	var closed:=false
	var retiring:=false
	var surface: Node
	var terrain: Node

func _initialize() -> void:
	call_deferred("run")

func check(value: bool,label: String) -> void:
	checks+=1
	if not value: failures.append(label)

func run() -> void:
	var output:=""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="): output=arg.substr(9)
	if output.is_empty() or FileAccess.file_exists(output): quit(2); return
	var world:=WorldStub.new(); root.add_child(world)
	world.surface=SurfaceStub.new(); world.add_child(world.surface)
	world.terrain=Node.new(); world.add_child(world.terrain)
	var binding:=Adapter.new()
	var state:={"revision":1,"guards":0,"witnesses":0,"change_on_guard":0,"retire_on_guard":0,"reenter_on_guard":0,"nested":{}}
	var guard: Callable=func():
		state.guards+=1
		if state.guards==state.change_on_guard: state.revision+=1
		if state.guards==state.retire_on_guard: world.retiring=true
		if state.guards==state.reenter_on_guard: state.nested=binding.query(Vector3(20,20,0),0.0)
		return true
	var witness: Callable=func():
		state.witnesses+=1
		return {"available":true,"scope":"published-static-scene","revision":state.revision}
	check(binding.configure(world,guard,witness),"binding")
	var point:=Vector3(20,20,0)
	var before: Dictionary=binding.snapshot()
	var result: Dictionary=binding.query(point,0.0)
	var after: Dictionary=binding.snapshot()
	check(result.available and result.branch=="missing_tile" and result.rays==0,"no-ray tile branch")
	check(int(after.scope_checks)-int(before.scope_checks)==(2 if OS.get_cmdline_user_args().has("--client-support-reuse-tile-witness") else 3),"tile witness count")
	state.guards=0; state.change_on_guard=2
	result=binding.query(point,0.0)
	check(not result.available and result.reason=="Client support source changed during projection","tile callback revision invalidation")
	state.guards=0; state.change_on_guard=0; state.retire_on_guard=2
	result=binding.query(point,0.0)
	check(not result.available,"tile callback scene retirement")
	world.retiring=false; state.guards=0; state.retire_on_guard=0; state.reenter_on_guard=2; state.nested={}
	result=binding.query(point,0.0)
	check(result.available and result.branch=="missing_tile","outer query survives nested rejection")
	check(state.nested is Dictionary and state.nested.get("available",true)==false,"nested query rejected")
	state.reenter_on_guard=0
	check(binding.retire(),"retire")
	check(not binding.query(point,0.0).available,"retired binding unavailable")
	world.free()
	var file:=FileAccess.open(output,FileAccess.WRITE)
	if file==null: quit(3); return
	file.store_string(JSON.stringify({"success":failures.is_empty(),"checks":checks,"failures":failures,"candidate":OS.get_cmdline_user_args().has("--client-support-reuse-tile-witness"),"scope_checks":after.scope_checks-before.scope_checks,"witness_calls":state.witnesses},"  ")); file.close()
	quit(0 if failures.is_empty() else 1)
