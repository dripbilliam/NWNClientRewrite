extends "res://tests/nwn63_interval_edges_groups_test.gd"
# Exact before/current selected rows and path transcripts at captured density.
func add_density(pair: Array)->void:
	var additions: Array=[]
	for extra in 549:
		var cohort:=extra%340
		var anchor:=Vector2(24+(cohort%12)*8,24+(cohort/12)*8)
		additions.append(object(1000+extra,anchor+Vector2(float(extra%3)*0.4,float(extra%5)*0.4),9,1,2+cohort))
	for setup in pair:
		setup.world.receive_delta(additions,[],1)
		check(int(setup.collision.snapshot().static_entries)==891,"342 groups/891 static entries match captured density")
		check(int(setup.collision.static_groups["cohort_0:placeable"].index.entry_count())==3,"Small model group is eligible for flat query")

func run()->void:
	var pair:=group_pair(340)
	add_density(pair)
	ordinary_and_seeded(pair)
	# Force one retained group across the eight-entry threshold. The previous
	# owner and bounded candidate must still yield identical ordering/results.
	var large: Array=[]
	for extra in 12:large.append(object(2000+extra,Vector2(4.0+extra*0.1,1.0),9,1,0))
	for setup in pair:
		setup.world.receive_delta(large,[],1)
		check(int(setup.collision.static_groups["chest:placeable"].index.entry_count())==13,"Large model group keeps BVH route")
	compare_groups(pair,Vector3(1,1,0),Vector3(8,1,0),"Large-group BVH fallback")
	compare_paths(pair,Vector3(1,1,0),Vector3(8,1,0),"Large-group path")
	mutations(pair)
	lifecycle(pair)
	for setup in pair:setup.world.free()
	await process_frame;await process_frame
	var result:={"success":failures.is_empty(),"checks":checks,"failures":failures,"compared_queries":compared_queries,"compared_paths":compared_paths,"scope":"Exact current baseline versus bounded ≤8-member flat static-group query; 342 groups/891 entries plus 13-member BVH fallback, seeded queries, blockers/door/elevation/path order, in-place state mutations, entry and retirement. No FPS or original Arelith claim."}
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--report="):
			var file:=FileAccess.open(argument.trim_prefix("--report="),FileAccess.WRITE);file.store_string(JSON.stringify(result,"  "));file.close()
	print(JSON.stringify(result));quit(0 if failures.is_empty() else 1)
