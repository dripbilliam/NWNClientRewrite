extends SceneTree
# Two exact original binary actor decodes in the existing worker pool.
# The optional parser adds at most one private nested clip helper. This tests
# whether it shortens actual concurrent job completion rather than an isolated
# single source. No scene/GPU, normal-entry or FPS measurement occurs.
const Actor=preload("res://systems/native_data/actor_model.gd")
var output:=""
func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.trim_prefix("--report=")
	call_deferred("run")
func digest(value: Variant) -> String:
	var context:=HashingContext.new();context.start(HashingContext.HASH_SHA256)
	context.update(var_to_bytes(value));return context.finish().hex_encode()
func sha_bytes(value: PackedByteArray) -> String:
	var context:=HashingContext.new();context.start(HashingContext.HASH_SHA256)
	context.update(value);return context.finish().hex_encode()
func parse_one(bytes: PackedByteArray) -> Dictionary:
	var actor:=Actor.new();var start:=Time.get_ticks_usec()
	var model: Dictionary=actor.parse(bytes)
	var elapsed:=Time.get_ticks_usec()-start
	return {"elapsed_us":elapsed,"thread":OS.get_thread_caller_id(),"failure":actor.failure,"nodes":model.get("nodes",[]).size(),"clips":model.get("animations",[]).size(),"model":model}
func run() -> void:
	if output.is_empty() or FileAccess.file_exists(output):quit(2);return
	var archive_path:=ProjectSettings.globalize_path("res://.cache/loading-benchmark-worlds/arelith-archive-shaders-v1/catalog-1/resources.erf")
	var archive:=FileAccess.open(archive_path,FileAccess.READ)
	if archive==null or archive.get_length()!=289956979:quit(3);return
	var sources: Array=[]
	for row in [{"name":"a_ba","offset":20148484,"bytes":5990990,"sha256":"a38c9f0de00a7e401419d1e668ad1b9d825cfc9635712cdb9ae63e840104ee2b"},{"name":"a_dfa","offset":36825551,"bytes":1694488,"sha256":"c95e0587de016d97379e5ed5ebc5b3a093d2f7e66af1ab86d9ff28cf993447b3"}]:
		archive.seek(int(row.offset))
		var bytes: PackedByteArray=archive.get_buffer(int(row.bytes))
		if bytes.size()!=int(row.bytes) or bytes.decode_u32(0)!=0:quit(3);return
		var actual:=sha_bytes(bytes)
		if actual!=str(row.sha256):push_error("Original actor SHA mismatch "+str(row.name)+" "+actual);quit(3);return
		sources.append({"name":row.name,"sha256":actual,"bytes":bytes})
	archive.close()
	var rows: Array=[];var valid:=true
	for repetition in 3:
		var first: Array=[];var second: Array=[]
		var begin:=Time.get_ticks_usec()
		var task_a:=WorkerThreadPool.add_task(func():first.append(parse_one(sources[0].bytes)),false,"NWN73 original actor A")
		var task_b:=WorkerThreadPool.add_task(func():second.append(parse_one(sources[1].bytes)),false,"NWN73 original actor B")
		WorkerThreadPool.wait_for_task_completion(task_a)
		WorkerThreadPool.wait_for_task_completion(task_b)
		var elapsed:=Time.get_ticks_usec()-begin
		if first.size()!=1 or second.size()!=1:valid=false;break
		var a: Dictionary=first[0];var b: Dictionary=second[0]
		a.digest=digest(a.model);b.digest=digest(b.model)
		a.erase("model");b.erase("model")
		valid=valid and a.failure.is_empty() and b.failure.is_empty() and a.nodes>0 and b.nodes>0 and a.clips>0 and b.clips>0
		rows.append({"wall_us":elapsed,"a":a,"b":b})
	var helpers: Dictionary=Actor.binary_clip_helper_snapshot()
	var selected:=OS.get_cmdline_user_args().has("--binary-clips=parallel")
	valid=valid and rows.size()==3 and int(helpers.active)==0 and (not selected or int(helpers.started)>0)
	var report:={"issue":"NWN-73","success":valid,"selected":selected,"rows":rows,"helpers":helpers,"sources":sources.map(func(row):return {"name":row.name,"sha256":row.sha256,"bytes":row.bytes.size()}),"actor_source_sha256":FileAccess.get_sha256("res://systems/native_data/actor_model.gd"),"scope":"Two exact sealed original binary MDLs decoded concurrently by actual Godot WorkerThreadPool tasks, with optional one-helper nested clip parse. Component wall/worker CPU only; no world, GPU, FPS or original-entry claim."}
	var file:=FileAccess.open(output,FileAccess.WRITE)
	if file==null:quit(3);return
	file.store_string(JSON.stringify(report,"\t"));file.close()
	print(JSON.stringify({"success":valid,"selected":selected,"wall_us":rows.map(func(row):return row.wall_us),"helpers":helpers}));quit(0 if valid else 1)
