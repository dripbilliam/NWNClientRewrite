extends SceneTree
const Recorded=preload("res://systems/native_data/recorded_catalog.gd")
var checks:=0
var failures: Array=[]
func _initialize() -> void:call_deferred("run")
func check(ok: bool,label: String) -> void:
	checks+=1
	if not ok:failures.append(label);print("FAIL ",label)
func digest(value: PackedByteArray) -> String:
	var context:=HashingContext.new();context.start(HashingContext.HASH_SHA256);context.update(value)
	return context.finish().hex_encode()
func write_case(folder: String,availability: Dictionary,expected_delta: int=0) -> void:
	DirAccess.make_dir_recursive_absolute(folder)
	var names:=["shared","other"];var contents:=["original first".to_ascii_buffer(),"original second".to_ascii_buffer()]
	var at:=160+names.size()*32;var bytes:="HAK V1.0".to_ascii_buffer();bytes.resize(at)
	bytes.encode_u32(16,names.size());bytes.encode_u32(24,160);bytes.encode_u32(28,160+names.size()*24)
	var resources:={}
	for index in names.size():
		var label: PackedByteArray=names[index].to_ascii_buffer()
		for offset in label.size():bytes[160+index*24+offset]=label[offset]
		bytes.encode_u16(180+index*24,2017)
		bytes.encode_u32(160+names.size()*24+index*8,at)
		bytes.encode_u32(164+names.size()*24+index*8,contents[index].size())
		bytes.append_array(contents[index]);at+=contents[index].size()
		resources[names[index]+":2017"]={"sha256":digest(contents[index]),"bytes":contents[index].size()}
	var file:=FileAccess.open(folder.path_join("resources.erf"),FileAccess.WRITE);file.store_buffer(bytes);file.close()
	var manifest:={"version":2,"complete":true,"availability":availability,"resources":resources,"portraitFiles":[],"packedSource":{"version":1,"file":"resources.erf","bytes":bytes.size()+expected_delta,"namespaceEntries":availability.size()}}
	file=FileAccess.open(folder.path_join("manifest.json"),FileAccess.WRITE);file.store_string(JSON.stringify(manifest));file.close()
func run() -> void:
	var output:=""
	for arg in OS.get_cmdline_user_args():if arg.begins_with("--report="):output=arg.substr(9)
	if output.is_empty() or FileAccess.file_exists(output):quit(2);return
	var base:=output+".fixture"
	var valid:=base.path_join("valid");write_case(valid,{"shared:2017":3,"other:2017":3})
	var broken_identity:=base.path_join("identity");write_case(broken_identity,{"shared:2017":3,"../other:2017":3})
	var broken_length:=base.path_join("length");write_case(broken_length,{"shared:2017":3,"other:2017":3},1)
	var broken_metadata:=base.path_join("metadata");write_case(broken_metadata,{"shared:2017":3,"other:2017":3})
	var manifest_file:=broken_metadata.path_join("manifest.json")
	var malformed: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(manifest_file));malformed.packedSource.version=2
	var changed:=FileAccess.open(manifest_file,FileAccess.WRITE);changed.store_string(JSON.stringify(malformed));changed.close()
	var broken_archive:=base.path_join("archive");write_case(broken_archive,{"shared:2017":3,"other:2017":3})
	changed=FileAccess.open(broken_archive.path_join("resources.erf"),FileAccess.READ_WRITE);changed.seek(0);changed.store_buffer("BAD!".to_ascii_buffer());changed.close()
	var recorded:=Recorded.new()
	check(recorded.mount(valid) and recorded.layers.size()==1 and recorded.packed_catalog.resolved.size()==2,"Valid packed recording publishes one complete namespace")
	check(recorded.cache_source_scope_v1()!=null and recorded.get_resource("shared",2017).get_string_from_ascii()=="original first" and recorded.get_resource("other",2017).get_string_from_ascii()=="original second","Worker-prepared packed source retains exact checked payloads and scope")
	check(recorded.manifest.is_read_only() and recorded.manifest.availability.is_read_only() and recorded.manifest.resources.is_read_only() and recorded.manifest.resources["shared:2017"].is_read_only() and recorded.layers.is_read_only(),"Published manifest and layer graph are deeply sealed")
	if OS.get_cmdline_user_args().has("--recorded-catalog-overlap=inline"):
		check(not recorded.stats.overlap_thread_started and int(recorded.stats.overlap_start_error)==ERR_CANT_CREATE,"Forced thread-start failure uses the synchronous packed-index fallback")
	var old:=recorded.fork()
	check(not recorded.mount(broken_identity) and recorded.failure=="Invalid recorded resource identity" and recorded.layers.is_empty() and recorded.packed_catalog==null,"Identity failure joins preparation and publishes no partial catalog")
	if OS.get_cmdline_user_args().has("--recorded-catalog-overlap=packed"):
		check(recorded.stats.overlap_thread_started,"Invalid identity started and joined the packed worker before rejection")
	check(old.cache_source_scope_v1()==null and old.get_resource("shared",2017).get_string_from_ascii()=="original first","Retirement revokes cache scope while an earlier fork retains immutable source bytes")
	check(not recorded.mount(broken_length) and recorded.failure=="Benchmark clone archive length differs" and recorded.layers.is_empty() and recorded.packed_catalog==null,"Packed length failure leaves no published bindings")
	check(not recorded.mount(broken_metadata) and recorded.failure=="Invalid benchmark clone source" and recorded.layers.is_empty() and recorded.packed_catalog==null,"Malformed packed metadata is rejected before publication")
	check(not recorded.mount(broken_archive) and not recorded.failure.is_empty() and recorded.layers.is_empty() and recorded.packed_catalog==null,"Malformed packed archive bytes are rejected before publication")
	check(recorded.mount(valid) and recorded.cache_source_scope_v1()!=null and recorded.get_resource("shared",2017).get_string_from_ascii()=="original first","Fresh mount recovers after invalid identity and packed source")
	if OS.get_cmdline_user_args().has("--recorded-catalog-overlap=packed"):
		# Exercise joined worker data and RefCounted retirement across repeated
		# valid/failed mounts. The original-entry candidate once reported a Windows
		# heap-corruption exit after its final report, so process teardown matters.
		var retained_forks: Array=[]
		var churn_ok:=true
		for churn_index in 12:
			var churn:=Recorded.new()
			if not churn.mount(valid):churn_ok=false;break
			retained_forks.append(churn.fork())
			if churn.mount(broken_identity) or churn.failure!="Invalid recorded resource identity":churn_ok=false;break
		for forked in retained_forks:
			if forked.get_resource("shared",2017).get_string_from_ascii()!="original first":churn_ok=false;break
		retained_forks.clear()
		check(churn_ok,"Repeated worker joins and retained forks survive valid/failed mount turnover")
	var file:=FileAccess.open(output,FileAccess.WRITE);file.store_string(JSON.stringify({"success":failures.is_empty(),"checks":checks,"failures":failures,"selected":OS.get_cmdline_user_args().has("--recorded-catalog-overlap=packed"),"inline_fallback":OS.get_cmdline_user_args().has("--recorded-catalog-overlap=inline"),"scope":"Tiny deterministic packed recording: valid source, failure joins, sealed graph, fork lifetime, inline fallback and recovery. No FPS or live loading claim."},"  ")+"\n");file.close();quit(0 if failures.is_empty() else 1)
