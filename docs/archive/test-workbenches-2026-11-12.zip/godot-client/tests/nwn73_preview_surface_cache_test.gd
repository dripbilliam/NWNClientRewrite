extends "res://tests/nwn73_preview_worker_parity_test.gd"

func median(values: Array) -> float:
	values.sort();return float(values[values.size()/2])

func run() -> void:
	var pair:=group_pair(340);var setup: Dictionary=pair[1];var collision=setup.collision
	check(not collision._worker_surface_cache_enabled,"Reusable worker surface cache defaults off")
	grid_mesh(setup.world,24);collision.tiles.clear()
	var floor: Array=collision.tile(0)
	var blocker: Dictionary=Collision.triangle(Vector3(0,0,0),Vector3(5,0,0),Vector3(0,5,0))
	blocker.walk=false;floor.append(blocker)
	var from:=Vector3(1,1,0);var target:=Vector3(3,1,0)
	var baseline:=ordinary_path(collision,from,target)
	var reference: PackedByteArray
	var blocks: Array=[];var prior: Dictionary={}
	for enabled in [false,true,true,false]:
		collision._worker_surface_cache_enabled=enabled
		var samples: Array=[];var snapshot: Dictionary={}
		for i in 48:
			snapshot=collision.prepare_worker_preview(1,from,target,from)
			check(snapshot.has("packet"),"Blocked worker packet exists")
			if not snapshot.has("packet"):break
			samples.append(float(snapshot.snapshot_ms)*1000.0)
			var bytes:=var_to_bytes(snapshot.packet.surface)
			if reference.is_empty():reference=bytes
			check(bytes==reference,"Cached immutable surface packet matches original packet exactly")
		if snapshot.has("packet"):
			var worker:=Worker.new();worker.packet=snapshot.packet
			var result: Dictionary=worker.run()
			check(result.get("valid",false) and var_to_bytes(result.get("path",{}))==var_to_bytes(baseline.path) and result.probes==baseline.probes,"Exact path and ordered probe transcript")
			check(collision.worker_preview_current(snapshot),"Current worker packet admits")
			if enabled:prior=snapshot
		blocks.append({"cache":enabled,"median_snapshot_us":median(samples) if not samples.is_empty() else -1.0,"samples":samples.size(),"faces":int(snapshot.get("faces",0))})
	# The cache never mutates a packet already borrowed by an in-flight worker.
	var old_packet:=var_to_bytes(prior.packet.surface) if prior.has("packet") else PackedByteArray()
	var concurrent:=Worker.new();concurrent.packet=prior.packet
	var thread:=Thread.new();var thread_error:=thread.start(concurrent.run)
	check(thread_error==OK,"Cached packet starts a real worker thread")
	collision._worker_surface_cache_enabled=true
	var old: float=setup.world.surface.meshes.floor.vertices[0][0]
	setup.world.surface.meshes.floor.vertices[0][0]=old+0.25
	check(not collision.worker_preview_current(prior),"In-place WOK edit rejects old packet")
	var revised: Dictionary=collision.prepare_worker_preview(1,from,target,from)
	check(revised.has("packet") and revised.packet.surface.meshes.floor.vertices[0][0]==old+0.25,"In-place WOK edit refreshes cached copy")
	check(var_to_bytes(prior.packet.surface)==old_packet,"Earlier worker packet remains immutable")
	if thread_error==OK:
		var concurrent_result: Dictionary=thread.wait_to_finish()
		check(concurrent_result.get("valid",false) and var_to_bytes(concurrent_result.get("path",{}))==var_to_bytes(baseline.path) and concurrent_result.probes==baseline.probes,"Old cached packet remains exact during concurrent main-thread source replacement")
	setup.world.surface.meshes.floor.vertices[0][0]=old
	var source: Dictionary=setup.world.surface.definition.tiles[0]
	var saved:=int(source.orientation);source.orientation=(saved+1)%4
	var moved: Dictionary=collision.prepare_worker_preview(1,from,target,from)
	check(moved.has("packet") and int(moved.packet.surface.tiles[0].orientation)==int(source.orientation),"In-place tile edit refreshes copied row")
	source.orientation=saved
	var triangle_packet: Dictionary=collision.prepare_worker_preview(1,from,target,from)
	var old_walk: bool=bool(collision.tiles[0][0].walk)
	collision.tiles[0][0].walk=not old_walk
	check(not collision.worker_preview_current(triangle_packet),"In-place prepared triangle edit rejects old packet")
	var recooked: Dictionary=collision.prepare_worker_preview(1,from,target,from)
	check(recooked.has("packet") and bool(recooked.packet.surface.triangles[0][0].walk)!=old_walk,"In-place prepared triangle edit refreshes copied triangle")
	collision.tiles[0][0].walk=old_walk
	var table_packet: Dictionary=collision.prepare_worker_preview(1,from,target,from)
	var old_rule: String=str(setup.world.surface.table.orderedRows[0].Walk)
	setup.world.surface.table.orderedRows[0].Walk="0" if old_rule!="0" else "1"
	check(not collision.worker_preview_current(table_packet),"In-place material table edit rejects old packet")
	var reclassified: Dictionary=collision.prepare_worker_preview(1,from,target,from)
	check(reclassified.has("packet") and str(reclassified.packet.surface.table.orderedRows[0].Walk)==str(setup.world.surface.table.orderedRows[0].Walk),"In-place material table edit refreshes copied table")
	setup.world.surface.table.orderedRows[0].Walk=old_rule
	var previous: Dictionary=collision.prepare_worker_preview(1,from,target,from)
	var changed:=object(2,Vector2(30,30));setup.world.receive_delta([changed],[],1)
	check(not collision.worker_preview_current(previous),"Same-ID replacement invalidates packet")
	var area_packet: Dictionary=collision.prepare_worker_preview(1,from,target,from)
	var retained: Dictionary=collision._worker_surface_cache
	var retained_bytes:=var_to_bytes([retained.rows,retained.meshes,retained.triangles,retained.table]).size()
	for index in 513:retained.rows[10000+index]={"model":"old"}
	var bounded: Dictionary=collision._preview_worker_surface_cache(setup.world.surface,setup.world.surface.definition,64,64)
	check(not is_same(retained,bounded) and bounded.rows.is_empty(),"Bounded cache replaces oversized storage without mutating borrowed packets")
	check(area_packet.has("packet") and int(area_packet.packet.surface.tiles[0].orientation)==saved,"Old packet survives bounded cache replacement")
	setup.world.generation+=1;collision.sync_full()
	check(collision._worker_surface_cache.is_empty(),"Area supersession releases retained cache")
	check(not collision.worker_preview_current(area_packet),"Area supersession rejects old packet")
	var report:={"passed":failures.is_empty(),"checks":checks,"failures":failures,"blocks":blocks,"cache":collision._worker_surface_cache_stats.duplicate(true),"retained_bytes_before_area_reset":retained_bytes,"source_sha256":FileAccess.get_sha256("res://systems/native_render/drive_collision_indexed.gd"),"scope":"Headless 342-group, 1153-face packet ABBA, exact original packet/path/probe/state oracle; no FPS or live movement claim."}
	for owner in pair:owner.world.free()
	await process_frame;await process_frame
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--report="):
			var file:=FileAccess.open(argument.substr(9),FileAccess.WRITE);file.store_string(JSON.stringify(report,"\t"));file.close()
	print(JSON.stringify(report));quit(0 if failures.is_empty() else 1)
