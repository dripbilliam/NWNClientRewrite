extends SceneTree
func _initialize() -> void:
	var scripts: Array=["res://systems/native_render/received_snapshot_commit.gd","res://systems/native_render/drive_collision_indexed.gd","res://systems/native_render/perception_visuals.gd","res://systems/native_render/live_world_pending_appearances.gd","res://native_session_world.gd"]
	for path in scripts:
		var script=load(path)
		if script==null or not script.can_instantiate():quit(1);return
	var output:="res://.cache/nwn61/helper-parse-a.json"
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.trim_prefix("--report=")
	var file:=FileAccess.open(output,FileAccess.WRITE)
	if file==null:quit(2);return
	file.store_string(JSON.stringify({"checks":scripts.size(),"scripts":scripts,"passed":true},"\t"));file.close()
	print("NWN61 helper parser: 3 scripts")
	quit(0)
