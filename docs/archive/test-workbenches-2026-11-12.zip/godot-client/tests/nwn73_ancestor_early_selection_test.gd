extends SceneTree
const Ancestors=preload("res://systems/native_data/ancestor_preparation.gd")

class Reader:
	extends RefCounted
	var entries: Dictionary={}
	var failure: String=""
	var requests: Array=[]
	func fork() -> RefCounted:return self
	func get_resource(name: String,_type: int) -> PackedByteArray:
		requests.append(name)
		if entries.has(name):failure="";return entries[name]
		failure="Missing test ancestor";return PackedByteArray()
	func decoded_cache():return null

class Decoder:
	extends RefCounted
	var fail:=false
	func decode(_bytes: PackedByteArray,_type: int,_format: String,_cache: String,_store) -> Dictionary:
		return {"error":"Speculative decoder failure" if fail else "","timings":{}}

var checks:=0
var failures: Array[String]=[]
func _initialize() -> void:call_deferred("run")
func check(ok: bool,label: String) -> void:
	checks+=1
	if not ok:failures.append(label)
func model(name: String,parent: String,size: int) -> PackedByteArray:
	var header:="newmodel "+name+"\n"+("setsupermodel "+name+" "+parent+"\n" if not parent.is_empty() else "")+"beginmodelgeom "+name+"\n"
	var result:=header.to_ascii_buffer();result.resize(maxi(size,result.size()));return result
func selected(reader: Reader,root_parent: String,decoder: Decoder) -> Dictionary:
	var state:=Ancestors.start(reader,"root",model("root",root_parent,100),"",decoder.decode)
	var names: Array=[]
	for job in state.jobs:names.append(str(job.name))
	var metrics:=Ancestors.finish(state)
	return {"names":names,"metrics":metrics,"requests":reader.requests.duplicate()}
func run() -> void:
	var report:=""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):report=arg.trim_prefix("--report=")
	if report.is_empty() or FileAccess.file_exists(report) or not Ancestors.configured_early_prefetch():quit(2);return
	var share:=Ancestors.configured_share()
	var reader:=Reader.new();var decoder:=Decoder.new()
	reader.entries={"near":model("near","mid",1000),"mid":model("mid","far",900),"far":model("far","tail",950),"tail":model("tail","",2000)}
	var chain:=selected(reader,"near",decoder)
	check(chain.requests==(["near","mid"] if share==1 else ["near","mid","far"]),"early reads only immediate plus bounded deeper candidates")
	check(chain.names==(["mid"] if share==1 else ["far","mid"]),"early prefers deeper candidates and current bounded sizes")
	check(chain.metrics.scan_capped and chain.metrics.reads.size()==share+1 and chain.metrics.held_source_bytes==(1900 if share==1 else 2850),"partial read count and source bytes reported exactly")
	check(chain.metrics.jobs_started==share and chain.metrics.sources.size()==share and Ancestors.snapshot().active==0,"all started helpers joined and credits released")
	reader=Reader.new();reader.entries={"near":model("near","mid",1000)}
	var missing:=selected(reader,"near",decoder)
	check(missing.requests==["near","mid"] and missing.names==["near"] and missing.metrics.reads[1].error=="Missing test ancestor","missing deeper source records failed read and keeps immediate helper")
	check(missing.metrics.held_source_bytes==1000 and Ancestors.snapshot().active==0,"missing deeper source retains only successfully read bytes and releases unused credit")
	reader=Reader.new();reader.entries={"near":model("near","../unsafe",1000)}
	var broken:=selected(reader,"near",decoder)
	check(broken.requests==["near"] and broken.names==["near"] and Ancestors.snapshot().active==0,"unsafe next hint is not read and reserved credit drains")
	reader=Reader.new();var first_missing:=selected(reader,"near",decoder)
	check(first_missing.requests==["near"] and first_missing.names.is_empty() and first_missing.metrics.held_source_bytes==0 and Ancestors.snapshot().active==0,"missing immediate parent starts no helper and releases all credits")
	reader=Reader.new();var no_parent:=selected(reader,"",decoder)
	check(no_parent.requests.is_empty() and no_parent.names.is_empty() and Ancestors.snapshot().active==0,"no hint never reserves helper credit")
	reader=Reader.new();reader.entries={"near":model("near","",1000)};decoder.fail=true
	var failed:=selected(reader,"near",decoder)
	check(failed.metrics.sources.size()==1 and failed.metrics.sources[0].error=="Speculative decoder failure" and Ancestors.snapshot().active==0,"failed speculative decode joins without replacing authoritative error")
	var file:=FileAccess.open(report,FileAccess.WRITE)
	if file==null:quit(3);return
	file.store_string(JSON.stringify({"success":failures.is_empty(),"checks":checks,"failures":failures,"share":share,"chain":chain,"missing":missing,"broken":broken,"first_missing":first_missing,"scope":"Early speculative hint scan only; authoritative actor composition and whole-world timing require separate checks"},"\t"));file.close()
	quit(0 if failures.is_empty() else 1)
