extends "res://native_session_world.gd"
var checks:=0
var failures: Array=[]
var output:=""
var events: Array=[]
var packets: Array=[]
class Slots extends RefCounted:
	var creature_slots:=false
class Inventory extends RefCounted:
	var frame_skin: RefCounted
	var ui:=Slots.new()
class Ui extends Node:
	signal options_requested
	var generation:=4
	var area_id:=7
	var controlled_id:=99
	var inventory:=Inventory.new()
	var text:=RefCounted.new()
	var key_bindings:=RefCounted.new()
	var modal_order: RefCounted
	var modal_surfaces: RefCounted
	var radial: Dictionary={}
	var callback: Callable
	func set_radial_preferences(value: Dictionary) -> void:
		radial=value.duplicate()
		if callback.is_valid():var fn:=callback;callback=Callable();fn.call()
class World extends Node3D:
	var generation:=4
	var area_id:=7
	var closed:=false
	var retiring:=false
class Settings extends Node:
	var radial_preferences:={"test":true}
	var creature_slots:=true
class Pointer extends Node:
	var extra_pointer_block: Callable
class Menu extends Node:
	var events: Array=[]
	var key_bindings: RefCounted
	var native_scope: Array=[]
	var active: Dictionary={}
	var blocked:=false
	var calls:=0
	var cancellations:=0
	var callback: Callable
	func set_modal_order(_order,_surfaces) -> void:events.append("modal")
	func begin_native_configuration(_frame,_text,_catalog,_cache,value: Array) -> Dictionary:
		events.append("menu_begin");active={"phase":0,"scope":value.duplicate()};return active
	func native_configuration_phase(value: Dictionary) -> String:return "test_"+str(value.get("phase",0))
	func native_configuration_step(value: Dictionary) -> Dictionary:
		calls+=1
		if blocked:return {"done":false,"blocked":true}
		if callback.is_valid():var fn:=callback;callback=Callable();fn.call()
		if not is_same(value,active):return {"done":true,"accepted":false}
		value.phase=int(value.phase)+1;events.append("menu_unit"+str(value.phase))
		if int(value.phase)<3:return {"done":false}
		native_scope=value.scope.duplicate();active={};return {"done":true,"accepted":true}
	func cancel_native_configuration(value: Dictionary={}) -> void:
		if not active.is_empty() and (value.is_empty() or is_same(value,active)):cancellations+=1;active={};events.append("menu_cancel")
	func set_native_scope(value: Array) -> void:native_scope=value.duplicate();events.append("menu_scope")
func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.trim_prefix("--report=")
	call_deferred("run")
func check(value: bool,label: String) -> void:
	checks+=1
	if not value:failures.append(label);push_error(label)
func send(packet: Dictionary) -> void:packets.append(packet);events.append("ack")
func creation_trace(_phase: String) -> void:pass
func start_case():
	closing=false;initialized=true;session_connection=1;cancelled_connection=-1;raw_serial=7;accepted_raw_serial=-1;epoch=4;received=1;events=[];packets=[]
	world=World.new();root.add_child(world);world.process_mode=Node.PROCESS_MODE_DISABLED;world.set_meta("native_entry_commit_pending",true)
	gameplay_ui=Ui.new();root.add_child(gameplay_ui)
	render_settings=Settings.new();root.add_child(render_settings);world_input=Pointer.new();root.add_child(world_input)
	render_menu=Menu.new();render_menu.events=events;root.add_child(render_menu)
	var snapshot:={"serial":7,"generation":4,"connection":1,"data":{}}
	entry_snapshot_commit={"snapshot":snapshot,"phase":"ack","context":raw_snapshot_context(),"initial_ui":gameplay_ui,"started_us":Time.get_ticks_usec(),"steps":0,"maximum_step_us":0,"overruns":{},"phase_us":{},"base_state":{"new_world":world,"previous_mode":Node.PROCESS_MODE_INHERIT,"phase_us":{},"maximum_unit_us":0,"overruns":{}}}
	snapshot_commit_running=true;entry_snapshot_frame=-1;entry_snapshot_budget_us=1000000
	return entry_snapshot_commit
func end_case() -> void:
	if not entry_snapshot_commit.is_empty():cancel_snapshot_preparation()
	for node in [render_menu,world_input,render_settings,gameplay_ui,world]:if is_instance_valid(node):node.free()
	render_menu=null;world_input=null;render_settings=null;gameplay_ui=null;world=null
func run() -> void:
	if output.is_empty() or FileAccess.file_exists(output):quit(2);return
	var state: Dictionary=start_case();render_menu.blocked=true
	advance_entry_snapshot_commit()
	check(not entry_snapshot_commit.is_empty() and packets.is_empty() and render_menu.calls==1,"blocked menu is polled once and cannot ACK")
	var deadline:=entry_snapshot_deadline;var calls: int=int(render_menu.calls)
	advance_entry_snapshot_commit();advance_entry_snapshot_commit()
	check(render_menu.calls==calls and entry_snapshot_deadline==deadline,"same-frame repeated poll neither spins blocked worker nor renews deadline")
	check(snapshot_transition_waiting() and world.process_mode==Node.PROCESS_MODE_DISABLED and world.get_meta("native_entry_commit_pending"),"control and scene processing remain fenced while tail blocked")
	render_menu.blocked=false;advance_entry_snapshot_commit();check(packets.is_empty(),"unblocked provider still waits for future frame after blocked poll")
	var blocked_frame: int=int(state.get("blocked_frame",-1))
	for _frame in 3:
		await process_frame
		if Engine.get_process_frames()!=blocked_frame:break
	check(Engine.get_process_frames()!=blocked_frame,"blocked menu resumes on a later engine frame")
	advance_entry_snapshot_commit()
	check(entry_snapshot_commit.is_empty() and packets.size()==1 and packets[0].serial==7,"tail completes and ACKs exact snapshot once")
	check(events.find("menu_unit3")<events.find("ack") and gameplay_ui.options_requested.is_connected(open_game_options),"all menu preparation and option binding precede ACK")
	check(gameplay_ui.inventory.ui.creature_slots and gameplay_ui.radial==render_settings.radial_preferences and world_input.extra_pointer_block.is_valid(),"complete slots/radial/pointer tail preserved")
	check(world.process_mode==Node.PROCESS_MODE_INHERIT and not world.get_meta("native_entry_commit_pending"),"world clock/control fence released only after full tail")
	check(state.receipt.tail_units_us.has("menu:test_0") and state.receipt.phase_us.has("ack"),"tail units remain explicitly included in aggregate ACK-phase receipt")
	check(state.receipt.tail_max_units_us.has("menu_step") and state.receipt.tail_max_units_us.has("menu:test_0"),"receipt separates full menu wrapper and named menu call maxima")
	check(render_menu.calls==4 and int(state.receipt.tail_units_us.get("menu:test_0",0))>=int(state.receipt.tail_max_units_us.get("menu:test_0",0)),"blocked and resumed menu phase is called twice while total and maximum remain distinct")
	check(int(state.receipt.tail_max_units_us.get("menu_step",0))>=int(state.receipt.tail_max_units_us.get("menu:test_0",0)),"full ACK menu wrapper maximum includes named menu call")
	check(int(state.receipt.ack_maximum_step_us)>=int(state.receipt.tail_max_units_us.get("menu_step",0)) and int(state.receipt.ack_maximum_step_us)<=int(state.receipt.phase_us.ack),"full ACK iteration maximum includes tail wrapper and final receipt work")
	end_case()
	state=start_case();entry_snapshot_frame=Engine.get_process_frames();entry_snapshot_deadline=Time.get_ticks_usec()-1
	advance_entry_snapshot_commit();check(render_menu.calls==0 and packets.is_empty() and not state.has("tail"),"exhausted same-frame deadline admits no new tail work")
	await process_frame;advance_entry_snapshot_commit();check(packets.size()==1,"next frame resumes work with original deadline policy")
	end_case()
	state=start_case();render_menu.callback=func():cancel_snapshot_preparation()
	advance_entry_snapshot_commit()
	check(entry_snapshot_commit.is_empty() and packets.is_empty() and render_menu.cancellations==1,"reentrant menu callback cancels its exact token and suppresses ACK")
	check(world.process_mode==Node.PROCESS_MODE_DISABLED,"cancelled entry never starts world processing")
	end_case()
	state=start_case();gameplay_ui.callback=func():raw_serial+=1
	advance_entry_snapshot_commit()
	check(entry_snapshot_commit.is_empty() and packets.is_empty() and accepted_raw_serial==7,"serial change during radial callback suppresses later scope/pointer/ACK")
	end_case()
	snapshot_preparation.close()
	var file:=FileAccess.open(output,FileAccess.WRITE);file.store_string(JSON.stringify({"passed":failures.is_empty(),"checks":checks,"failures":failures,"scope":"Actual session continuation/deadline/blocked-frame/cancel logic with authored UI/menu/world. No originalasset/GPU/FPS or4ms performance claim; existing full-session reset fixture remains required."},"\t"));file.close();quit(0 if failures.is_empty() else 1)
