extends SceneTree
const Metadata=preload("res://systems/native_data/world_snapshot_metadata.gd")
const World=preload("res://systems/native_render/live_world.gd")

func _initialize() -> void:call_deferred("run")

func run() -> void:
	var args:={}
	for arg in OS.get_cmdline_user_args():
		var pair:=arg.trim_prefix("--").split("=",true,1)
		if pair.size()==2:args[pair[0]]=pair[1]
	if not args.has("input") or not args.has("report") or FileAccess.file_exists(args.report):quit(2);return
	var input:=FileAccess.get_file_as_string(args.input)
	var fixture: Variant=JSON.parse_string(input)
	if not fixture is Dictionary or not fixture.get("rows") is Array:quit(3);return
	var rows: Array=fixture.rows
	var area:=int(fixture.area)
	var scope:=[1,5,int(fixture.serial),area]
	var world:=World.new()
	world.area_id=area;world.generation=5
	var samples: Array=[]
	for iteration in 5:
		var started:=Time.get_ticks_usec()
		var prepared:=Metadata.prepare(rows,area)
		var prepared_us:=Time.get_ticks_usec()-started
		var packet:={"version":Metadata.VERSION,"error":"","scope":scope,"area_id":area,"count":rows.size(),"rows":prepared}
		started=Time.get_ticks_usec()
		var identities_valid:=true
		for index in rows.size():
			if int(prepared[index].id)!=int(rows[index].id) or int(prepared[index].index)!=index:
				identities_valid=false;break
		var identity_us:=Time.get_ticks_usec()-started
		if not identities_valid:quit(6);return
		started=Time.get_ticks_usec()
		var valid: bool=world.stage_received_metadata(rows,packet)
		var adoption_us:=Time.get_ticks_usec()-started
		if not valid:quit(4);return
		samples.append({"prepare_us":prepared_us,"identity_only_us":identity_us,"adoption_us":adoption_us,"accepted_rows":prepared.filter(func(row):return row.accepted).size()})
	world.free()
	var report:={"issue":"NWN-73","scope":"Original 2832-row saved generation-5 input; pure metadata preparation and main-thread validation/adoption component only. No scene commit, worker queue, entry, graphics or FPS.","area":area,"rows":rows.size(),"samples":samples}
	var output:=FileAccess.open(args.report,FileAccess.WRITE)
	if output==null:quit(5);return
	output.store_string(JSON.stringify(report,"  ")+"\n");output.close();quit()
