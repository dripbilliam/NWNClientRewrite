extends SceneTree
# Exact saved actor sources, one parse each, in a fresh process. This measures
# only actor decoding and cannot stand in for whole entry or FPS.
const Actor=preload("res://systems/native_data/actor_model.gd")
func _initialize() -> void:call_deferred("run")
func run() -> void:
	var output:=""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.substr(9)
	if output.is_empty() or FileAccess.file_exists(output):quit(2);return
	var archive_path:=ProjectSettings.globalize_path("res://.cache/loading-benchmark-worlds/arelith-archive-shaders-v1/catalog-1/resources.erf")
	var archive:=FileAccess.open(archive_path,FileAccess.READ)
	if archive==null or archive.get_length()!=289956979:quit(3);return
	var rows: Array=[];var accepted:=true
	for source in [{"name":"a_ba","offset":20148484,"bytes":5990990},{"name":"a_dfa","offset":36825551,"bytes":1694488}]:
		archive.seek(int(source.offset))
		var bytes: PackedByteArray=archive.get_buffer(int(source.bytes))
		if bytes.size()!=int(source.bytes) or bytes.decode_u32(0)!=0:accepted=false;break
		var actor:=Actor.new();var began:=Time.get_ticks_usec();var model: Dictionary=actor.parse(bytes)
		var elapsed:=Time.get_ticks_usec()-began
		var valid:=actor.failure.is_empty() and not model.is_empty()
		rows.append({"name":source.name,"parse_ms":elapsed/1000.0,"nodes":model.get("nodes",[]).size(),"clips":model.get("animations",[]).size(),"failure":actor.failure,"valid":valid})
		if not valid:accepted=false
	archive.close()
	var helpers: Dictionary=Actor.binary_clip_helper_snapshot()
	var selected:=OS.get_cmdline_user_args().has("--binary-clips=parallel")
	var success: bool=accepted and rows.size()==2 and int(helpers.active)==0 and (not selected or int(helpers.started)>=2)
	var report:={"success":success,"selected":selected,"rows":rows,"helpers":helpers,"scope":"Two exact saved binary actor sources, fresh-process component parse time under possible user-game load; no whole loading, FPS or visual claim."}
	var file:=FileAccess.open(output,FileAccess.WRITE)
	if file==null:quit(3);return
	file.store_string(JSON.stringify(report,"  ")+"\n");file.close();quit(0 if success else 1)
