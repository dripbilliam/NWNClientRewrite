extends "res://tests/nwn63_model_scalars_test.gd"
const SpatialOwnerBefore=preload("res://.cache/nwn63/spatial-scalars-a/before/systems/native_render/drive_collision_indexed.gd")
# Match the captured342 model groups/897 static entries/9 creatures.58 model
# roots span the probe region while their individual anchors remain distant.
# This is authored topology, not an original-asset/live Arelith acceptance.
func group_pair(_count: int=340)->Array:
	var pair: Array=[]
	for before in [true,false]:
		var setup:=make_world(false);var collision=SpatialOwnerBefore.new() if before else Collision.new()
		setup.world.add_child(collision);collision.world=setup.world;collision.tables=tables();setup.world.drive_collision=collision;collision.ensure_spatial_scope();collision.set_process(false)
		var rows: Array=[creature(1,Vector2(1,1)),creature(4,Vector2(6,3)),object(2,Vector2(4,1)),object(3,Vector2(9,1),10)]
		for i in 7:rows.append(creature(10+i,Vector2(300+i*4,300)))
		collision.publish_model("chest:placeable",{"states":[footprint()]})
		collision.publish_model("gate:door",{"states":[footprint(),{"vertices":[],"faces":[]},footprint(2)]})
		var next_id:=100
		for i in 340:
			var key:="cohort_"+str(i);var appearance: int=collision.tables.placeables.orderedRows.size()
			collision.tables.placeables.orderedRows.append({"ModelName":key});collision.publish_model(key+":placeable",{"states":[footprint(1+i%4)]})
			var positions: Array=[]
			if i<23:positions=[Vector2(-64,-64),Vector2(-64,64),Vector2(0,-64),Vector2(0,64),Vector2(64,-64),Vector2(64,64)]
			elif i<58:positions=[Vector2(-64,-64),Vector2(64,64)]
			else:
				var position:=Vector2(200+(i%24)*8,200+(i/24)*8);positions.append(position)
				positions.append(position+Vector2.ONE)
				if i<181:positions.append(position+Vector2(2,2))
			for position in positions:rows.append(object(next_id,position,9,1,appearance));next_id+=1
		setup.world.receive(rows,1);setup.collision=collision;pair.append(setup)
	return pair
func run()->void:
	var pair:=group_pair();var census: Array=[]
	for setup in pair:
		var counts: Dictionary=setup.collision.snapshot()
		check(counts.static_groups==342 and counts.static_entries==897 and counts.sources==906,"Captured group/source population is represented")
		setup.collision.static_candidates(Vector3(1,7,0),Vector3(4,7,0),0.3,1)
		var queried:=0;var visited:=0
		for group in setup.collision.static_groups.values():
			var query: Dictionary=group.index.snapshot().last_query
			if not query.is_empty():queried+=1;visited+=int(query.visited_nodes)
		census.append({"groups":counts.static_groups,"static_entries":counts.static_entries,"sources":counts.sources,"queried_groups":queried,"visited_nodes":visited})
		check(queried==58,"Actual static_candidates engages58 model-group spatial queries")
	ordinary_and_seeded(pair);mutations(pair);lifecycle(pair)
	for setup in pair:setup.world.free()
	await process_frame;await process_frame
	var result:={"success":failures.is_empty(),"checks":checks,"failures":failures,"compared_queries":compared_queries,"compared_paths":compared_paths,"census":census,"scope":"Same frozen B collision before/current spatial scalars only; authored342groups/897staticentries/9creatures with58 actually queried model roots. Exact candidate/path/probe transcripts, mutations, doors, membership, entry, lifetimes, area and retirement. No timing/FPS or original-asset acceptance."}
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--report="):
			var file:=FileAccess.open(argument.trim_prefix("--report="),FileAccess.WRITE);file.store_string(JSON.stringify(result,"  "));file.close()
	print(JSON.stringify(result));quit(0 if failures.is_empty() else 1)
