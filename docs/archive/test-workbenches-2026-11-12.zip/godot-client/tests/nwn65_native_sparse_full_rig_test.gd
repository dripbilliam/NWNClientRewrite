extends "res://tests/nwn65_rig_skin_publisher_test.gd"
# End-to-end AnimationPlayer, event, attachment, reentry and retirement parity
# for the private sparse native publisher, with its default-off switch tested
# by separate engine invocations.

func run() -> void:
	var expect_skip:=OS.get_cmdline_user_args().has("--rig-native-sparse-skip=on")
	var ordinary: Dictionary=setup(false,false)
	var candidate: Dictionary=setup(true,false)
	for frame in 24:
		for row: Dictionary in [ordinary,candidate]:
			if frame in [3,8,17]:row.rigs.set_manual_pose(1,row.entry.nodes[1],Vector3(frame*0.03,-0.7,0.2),Quaternion(Vector3.RIGHT,frame*0.017))
			if frame==10:row.entry.attachments[0].flags=0
			if frame==16:row.entry.attachments[0].flags=3
			if frame==7:row.entry.parents=[-1,0,0,2,3]
			if frame==12:row.rigs._play(row.entry.models[0],"turn",true,-0.5,0.4,true)
			if frame==18:
				for skin: Dictionary in row.entry.skins:
					skin.skeleton.set_bone_pose(12,Transform3D(Basis(Quaternion(Vector3.UP,0.3)).scaled(Vector3(1.7,0.6,2.3)),Vector3(0.4,-0.5,0.8)))
			row.rigs._update(0.125)
		check(var_to_bytes(capture(ordinary))==var_to_bytes(capture(candidate)),"Actual clock/event/node/local/global bone/attachment parity frame "+str(frame))
	var route: Dictionary=candidate.rigs.native_skin_snapshot(1)
	check(int(route.completed)==24 and int(route.force_calls)==48,"Native publisher and force boundaries complete each frame")
	check(bool(route.get("sparse_skip_enabled",false))==expect_skip,"Native sparse candidate flag state")
	check(int(route.bone_writes)<1536 if expect_skip else int(route.bone_writes)==3072,"Native write count matches selected route")
	check(ordinary.sequence.recursed and candidate.sequence.recursed,"Nested callback preserved")
	check(ordinary.forces==candidate.forces and ordinary.events==candidate.events,"Exact force and animation event order")
	for row: Dictionary in [ordinary,candidate]:
		var weak: WeakRef=weakref(row.rigs.native_skin_publishers[1][1]) if row.rigs.native_skin_publishers.has(1) else null
		row.rigs.forget_entity(1)
		check(row.rigs.native_skin_publishers.is_empty() and (weak==null or weak.get_ref()==null),"Appearance publisher retired")
		row.host.free();row.clear()
	coverage.append("24 actual AnimationPlayer frames, original 64-slot sparse skins, manual/reverse/attachments, external nonunit bone edit, exact skin/node/event/force output, nested update and retirement; skip="+str(expect_skip))
	finish()
