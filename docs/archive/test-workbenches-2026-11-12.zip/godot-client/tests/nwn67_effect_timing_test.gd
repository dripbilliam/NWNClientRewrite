extends SceneTree
const Effects=preload("res://systems/native_render/effect_world.gd")
const Fixtures=preload("res://tests/native_effect_membership_test.gd")
const Presentation=preload("res://systems/native_data/entity_presentation_lifetime.gd")
class IdleController extends RefCounted:
	func advance(_delta: float=0.0) -> void:pass
	func close() -> void:pass
var report_path:=""
var samples:=180
var failure:=""
func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):report_path=arg.substr(9)
		elif arg.begins_with("--samples="):samples=int(arg.substr(10))
	call_deferred("run")
func fixture(reuse: bool) -> Dictionary:
	var log:=Fixtures.Log.new();log.enabled=false
	var client:=Fixtures.Client.new();client.log=log
	var w:=Effects.new();w.client=client;w.reuse_selection_inputs=reuse;w.reused_selection_setup=reuse;root.add_child(w);w.set_process(false)
	w.world={"desired":{},"instances":{},"controlled_id":123}
	for property in ["casts","blood","parries","special_attacks","equipped_attacks","creature_voices"]:w.set(property,IdleController.new())
	var actors: Array=[]
	for index in 48:
		var actor:=1000+index;var node:=Node3D.new();root.add_child(node);actors.append(node)
		var source:={"nativeLifetime":index+10,"clientKnownLifetime":index+20}
		w.world.desired[actor]={"object":source,"key":"fixture"};w.world.instances[actor]=node
		for effect in 6:
			var id:=index*6+effect+1
			w.receive({"kind":"visual-reserve","effectId":id,"actorId":actor,"visualId":456,"transient":false})
			var s:={"finishedF4":0,"field110":0,"attached114":1,"closedEc":0,"scope10c":effect%3,"programType10d":effect%2,"visualF8":456,"phase184":0,"destroyed":false}
			# Construct the same canonical physical row as reserve/definition admission.
			var runtime:=Fixtures.Runtime.new();runtime.configure(s,id,log)
			w.entries[id].runtime=runtime;w.entries[id].binding=node;w.entries[id].definition={"ready":true}
			w.records[id]={"actor":actor,"privateToken":0,"lifetime":index+10,"area":false,"record":{},"definition":{"ready":true},"presentation_lifetime":Presentation.token(source)}
	return {"world":w,"actors":actors}
func dispose(f: Dictionary) -> void:
	f.world.close();f.world.free()
	for actor in f.actors:actor.free()
	f.clear()
func summarize(values: Array) -> Dictionary:
	var sorted:=values.duplicate();sorted.sort();var total:=0
	for value in values:total+=int(value)
	return {"samples":values.size(),"median_us":sorted[values.size()/2],"p95_us":sorted[mini(values.size()-1,int(ceil(values.size()*0.95))-1)],"p99_us":sorted[mini(values.size()-1,int(ceil(values.size()*0.99))-1)],"mean_us":float(total)/values.size()}
func measure(reuse: bool) -> Dictionary:
	var f:=fixture(reuse);var w=f.world
	for warm in 30:w.advance(0.016)
	var projections_before:=int(w.selection_owner_projections);var presentations_before:=int(w.selection_presentation_projections)
	var elapsed: Array=[]
	for sample in samples:
		var began:=Time.get_ticks_usec();w.advance(0.016);elapsed.append(Time.get_ticks_usec()-began)
	var states: Array=w.entries.values().map(func(entry):return entry.runtime.state.duplicate(true))
	var stats:=summarize(elapsed);stats.owner_projections=w.selection_owner_projections-projections_before;stats.presentation_projections=w.selection_presentation_projections-presentations_before;stats.selection_invocations_per_frame=48*6
	var result:={"timing":stats,"states":states,"entry_count":w.entries.size(),"models":w.models.size(),"reused_callbacks":w.reused_selection_calls,"contexts_remaining":w.selection_contexts.size()}
	dispose(f);return result
func run() -> void:
	if report_path.is_empty() or FileAccess.file_exists(report_path) or samples<30 or samples>1000:quit(2);return
	var a:=measure(false);var b:=measure(true);var c:=measure(true);var d:=measure(false)
	var matched: bool=a.states==b.states and a.states==c.states and a.states==d.states and a.entry_count==288 and b.entry_count==288 and b.contexts_remaining==0 and c.contexts_remaining==0
	var out:={"success":matched,"order":"A-B-B-A","actors":48,"effects_per_actor":6,"samples_per_leg":samples,"reference":[a.timing,d.timing],"optimized":[b.timing,c.timing],"states_equal":matched,"scope":"Actual native effect-world advance, current physical effect list/phase/selection order and per-effect histories in normal uninstrumented Core E. Fixed scene inputs with in-memory fixture runtimes; excludes asset construction/GPU/whole-client FPS and live Arelith acceptance."}
	var file:=FileAccess.open(report_path,FileAccess.WRITE);file.store_string(JSON.stringify(out,"\t"));file.close();print("NWN67_EFFECT_TIMING ",JSON.stringify(out));quit(0 if matched else 1)
