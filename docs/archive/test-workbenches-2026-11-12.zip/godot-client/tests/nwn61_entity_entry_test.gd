extends SceneTree
const Entities=preload("res://systems/client_api/entities.gd")
var checks:=0
var failures: Array=[]
var output:=""
var events: Array=[]
var source: Dictionary={}
func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.trim_prefix("--report=")
	call_deferred("run")
func check(value: bool,label: String) -> void:
	checks+=1
	if not value:failures.append(label)
func bind(api) -> void:
	api._bind_sources(func(id):return source.get(id),func(_id):return null)
func observe(api,log: Array) -> void:
	api.scope_changed.connect(func(event):log.append(["scope",event]))
	api.entity_removed.connect(func(event):log.append(["removed",event]))
	api.entity_added.connect(func(event):
		log.append(["added",event,api.list_references()])
		check(not api._reset("reentrant"),"publication callback reset remains rejected"))
	api.entity_updated.connect(func(event):log.append(["updated",event]))
	api.controlled_entity_changed.connect(func(event):log.append(["controlled",event]))
func row(id: int,area: int,lifetime: int=1) -> Dictionary:
	return {"id":id,"areaId":area,"objectType":5,"nativeLifetime":lifetime,"clientKnownLifetime":lifetime,"replicated":{"name":"actor-"+str(id)}}
func normalize(value: Variant) -> Variant:
	if value is Dictionary:
		var result: Dictionary={}
		for key in value:
			if key!="api_instance":result[key]=normalize(value[key])
		return result
	if value is Array:
		var result: Array=[]
		for item in value:result.append(normalize(item))
		return result
	return value
func run() -> void:
	if output.is_empty() or FileAccess.file_exists(output):quit(2);return
	var baseline=load("res://.cache/nwn61/baseline/systems/client_api/entities.gd")
	var before=baseline.new();var candidate:=Entities.new();bind(before);bind(candidate)
	source={7:row(7,100),9:row(9,100)}
	check(before._apply_boundary(1,1,100,7,source.values(),[],true),"original first scope accepted")
	check(candidate._apply_boundary(1,1,100,7,source.values(),[],true),"candidate synchronous first scope accepted")
	var old:=candidate.list_references();var logs_before: Array=[];var logs_after: Array=[]
	observe(before,logs_before);observe(candidate,logs_after)
	var rows: Array=[row(12,200),row(4,200),row(12,200,3),{"id":14,"replicationRemoved":true},row(0x7f000000,200),{"id":"bad"}]
	source={4:rows[1],12:rows[2]}
	check(candidate._begin_entry_boundary(1,2,200,12,rows),"new-area cooperative entry admitted")
	check(candidate.list_references()==old,"entry admission leaves complete prior registry untouched")
	check(not candidate._apply_boundary(1,2,200,12,[],[],true),"overlapping synchronous publication rejected")
	check(not candidate._presentation_records(1,1,100,[{"id":7,"revision":1}]),"presentation writer fenced while private registry builds")
	check(before._apply_boundary(1,2,200,12,rows,[],true),"original new-area scope accepted")
	var count:=0;var result: Dictionary={}
	while count<1000:
		result=candidate._entry_boundary_step();count+=1
		if result.get("done",false):break
	check(result.get("accepted",false) and count<1000,"cooperative boundary completes")
	check(count>rows.size(),"entry actually advances through bounded units")
	check(before.get_scope()==candidate.get_scope(),"scope publication matches original")
	check(normalize(before.list_references())==normalize(candidate.list_references()),"sorted IDs and allocated lifetimes match original")
	check(before._known==candidate._known,"complete compact registry matches original")
	check(before._player_identity==candidate._player_identity,"unreceived player identity matches original")
	check(before.diagnostics()==candidate.diagnostics(),"publication metrics match original")
	check(normalize(logs_before)==normalize(logs_after),"ordered detached observer events and complete callback registry match original")
	check(not candidate._begin_entry_boundary(1,2,200,12,rows),"live same-area full boundary stays outside entry path")
	var invalid: Array=[row(1,300),{"id":2,"areaId":300,"clientKnownLifetime":0}]
	var prior:=candidate._known.duplicate(true);var prior_scope:=candidate.get_scope()
	check(candidate._begin_entry_boundary(1,3,300,1,invalid),"invalid disclosure is admitted for bounded validation")
	for i in 20:
		result=candidate._entry_boundary_step()
		if result.get("done",false):break
	check(not result.get("accepted",false),"invalid disclosure rejected before registry publication")
	check(candidate._known==prior and candidate.get_scope()==prior_scope,"invalid disclosure retains complete previous registry")
	check(candidate._begin_entry_boundary(1,3,300,1,[row(1,300)]),"cancel fixture admitted")
	candidate._entry_boundary_step();candidate._cancel_entry_boundary()
	check(candidate._known==prior and candidate.get_scope()==prior_scope,"cancel during preparation retains previous registry")
	check(candidate._reset("finished"),"cancel unwinds writer guard for lifecycle reset")
	var file:=FileAccess.open(output,FileAccess.WRITE)
	file.store_string(JSON.stringify({"checks":checks,"failures":failures,"passed":failures.is_empty(),"steps":count},"\t"));file.close()
	quit(0 if failures.is_empty() else 1)
