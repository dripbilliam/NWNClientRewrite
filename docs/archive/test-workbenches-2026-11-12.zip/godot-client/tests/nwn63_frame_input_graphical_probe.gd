extends "res://native_session_world.gd"
# Private recorded-area probe. The normal replay disables keyboard input and
# replays captured predictions directly. This restores the actual viewport
# event route only during its post-input steady window. Synthetic requests do
# not enter the replay transport; the loaded world still runs normal preview.
var nwn63_probe_active:=false
var nwn63_probe_frame:=0
var nwn63_probe_previous_us:=0
var nwn63_probe_gaps:=PackedFloat64Array()
var nwn63_probe_packets: Array=[]
var nwn63_probe_start: Dictionary={}
var nwn63_probe_motion_before: Dictionary={}

func receive(message: Dictionary)->void:
	super.receive(message)
	if message.get("kind")=="begin-performance-window" and report.get("performance_window",{}).get("steady",false):
		nwn63_probe_active=true
		nwn63_probe_frame=0
		nwn63_probe_previous_us=0
		nwn63_probe_start=keyboard.stats.duplicate(true) if is_instance_valid(keyboard) else {}
		var current: Dictionary=keyboard_context()
		nwn63_probe_motion_before=current.state.duplicate(true) if current.has("state") else {}

func player_command(value: Dictionary)->void:
	if nwn63_probe_active and value.get("kind")=="drive":
		nwn63_probe_packets.append(value.duplicate(true))
		return
	super.player_command(value)

func nwn63_probe_key(pressed: bool,echo: bool=false)->void:
	var event:=InputEventKey.new()
	event.physical_keycode=KEY_W
	event.keycode=KEY_W
	event.pressed=pressed
	event.echo=echo
	root.push_input(event,true)

func _profile_tick()->void:
	super._profile_tick()
	if not nwn63_probe_active or closing or not is_instance_valid(keyboard) or not is_instance_valid(world):return
	# NativeSessionWorld disables input in offline replay. The probe restores
	# only the keyboard; pointer and other replay owners retain their policy.
	keyboard.process_mode=Node.PROCESS_MODE_INHERIT
	keyboard.require_focus=false
	var now:=Time.get_ticks_usec()
	if nwn63_probe_previous_us>0 and nwn63_probe_frame>0 and nwn63_probe_frame<=60:
		nwn63_probe_gaps.append((now-nwn63_probe_previous_us)/1000.0)
	nwn63_probe_previous_us=now
	if nwn63_probe_frame==0:nwn63_probe_key(true)
	elif nwn63_probe_frame<60:
		# Two real viewport key echoes in one frame exercise the native-style
		# admission boundary while keeping the same held movement input.
		nwn63_probe_key(true,true)
		nwn63_probe_key(true,true)
	elif nwn63_probe_frame==60:nwn63_probe_key(false)
	elif nwn63_probe_frame==62:
		var sorted:=nwn63_probe_gaps.duplicate();sorted.sort()
		var middle:=sorted[sorted.size()/2] if not sorted.is_empty() else -1.0
		var tail:=sorted[mini(sorted.size()-1,int(ceil(sorted.size()*0.95))-1)] if not sorted.is_empty() else -1.0
		var current: Dictionary=keyboard_context()
		var restored:=current.has("state") and not nwn63_probe_motion_before.is_empty()
		if restored:
			# This fixture owns the synthetic preview. Restore the exact local
			# pre-probe motion state so the sealed replay's terminal-camera and
			# authority checks still apply to the captured traffic.
			current.state.clear();current.state.merge(nwn63_probe_motion_before,true)
		report.nwn63_os_input_probe={"frame_intervals":nwn63_probe_gaps.size(),"median_ms":middle,"p95_ms":tail,"max_ms":sorted[-1] if not sorted.is_empty() else -1.0,"packets":nwn63_probe_packets.size(),"stats_before":nwn63_probe_start,"stats_after":keyboard.stats.duplicate(true),"frame_admission":keyboard.frame_input_admission,"world_ready":world.ready_for_control(),"state_restored":restored,"scope":"Original recorded graphical area, actual Window.push_input keyboard route, repeated W echoes, local synthetic packet sink, exact pre-probe motion state restored. Not live server input or whole-client FPS acceptance."}
		nwn63_probe_active=false
	nwn63_probe_frame+=1
