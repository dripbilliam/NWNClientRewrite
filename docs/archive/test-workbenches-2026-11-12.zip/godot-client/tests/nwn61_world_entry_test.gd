extends SceneTree
const World=preload("res://systems/native_render/live_world_pending_appearances.gd")
const Metadata=preload("res://systems/native_data/world_snapshot_metadata.gd")
const Perception=preload("res://systems/native_render/perception_visuals.gd")
const Drive=preload("res://systems/native_render/drive_collision_indexed.gd")
const Lights=preload("res://systems/native_render/placeable_lights.gd")
var checks:=0
var failures: Array=[]
var output:=""
class Combat extends RefCounted:
	var forgotten: Array=[]
	func forget(id: int,removed: bool=false) -> void:forgotten.append([id,removed])
	func close() -> void:pass
class Effects extends Node:
	var perception_visuals:=Perception.new()
	var observations:=0
	var world
	var order: Array=[]
	var applied: Array=[]
	var creature_voices
	var world_audio
	func configure(owner) -> void:world=owner;perception_visuals.configure(world,apply,remove)
	func apply(id: int,lifetime: int,visual: int) -> int:applied.append(["apply",id,lifetime,visual]);return applied.size()
	func remove(id: int,effect: int) -> void:applied.append(["remove",id,effect])
	func capture_order() -> void:order.append([world._planning_revision,world._pending_writer_depth,world._support_writer_depth,world.base_scenery_boundary_depth,world.desired.size()])
	func observe_perception(rows: Array,controlled: int) -> void:observations+=1;capture_order();perception_visuals.receive(rows,controlled)
	func begin_received_perception(rows: Array,controlled: int) -> void:observations+=1;capture_order();perception_visuals.begin_received(rows,controlled)
	func received_perception_step() -> bool:return perception_visuals.received_step()
	func cancel_received_perception() -> void:perception_visuals.cancel_received()
	func close() -> void:perception_visuals.close()
func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.trim_prefix("--report=")
	call_deferred("run")
func check(value: bool,label: String) -> void:
	checks+=1
	if not value:failures.append(label);push_error(label)
static func row(id: int,kind: int=9) -> Dictionary:
	var result:={"id":id,"objectType":kind,"areaId":7,"nativeLifetime":id+100,"clientKnownLifetime":id+200,"replicated":{"position":[1,2,3],"orientation":[0.25,0.75,0],"animation":0,"appearance":17,"walkRate":2,"runRate":4,"lightOn":true}}
	if kind==9:result.staticState={"id":id,"appearance":17,"position":[1,2,3],"orientation":[0.25,0.75,0]}
	return result
func make_world():
	var world:=World.new();world.area_id=7;world.generation=3;world.combat=Combat.new();world.continuous_base_stream=true
	world.placeable_lights=Lights.new();world.placeable_lights.world=world;world.add_child(world.placeable_lights)
	world.drive_collision=Drive.new();world.drive_collision.world=world;world.add_child(world.drive_collision)
	world.effects=Effects.new();world.add_child(world.effects);world.effects.configure(world)
	return world
func state(world) -> Dictionary:
	var motions: Dictionary={}
	for id in world.motion.objects:
		var value: Dictionary=world.motion.objects[id];motions[id]={"position":value.position,"orientation":value.orientation,"animation":value.animation,"facingTarget":value.get("facingTarget")}
	return {"desired":world.desired,"omitted":world.base_scenery_omitted,"unaddressable":world.base_scenery_unaddressable_omitted,"progress":world.base_scenery_progress_counts,"population_revision":world.base_scenery_population_revision,"live_revision":world.base_live_revision,"schedule":world.base_stream_schedule.entries,"motion":motions,"forgotten":world.combat.forgotten,"lights":world.placeable_lights.objects,"drive":world.drive_collision.source_rows,"drive_errors":world.drive_collision.source_errors,"drive_next_order":world.drive_collision.next_order,"drive_ready":world.drive_collision.sources_synchronized,"pending":world._pending_model_ids,"perception":world.effects.perception_visuals.snapshot(),"perception_calls":world.effects.observations,"perception_applied":world.effects.applied,"perception_order":world.effects.order,"support_revision":world.client_support_revision}
func run() -> void:
	if output.is_empty() or FileAccess.file_exists(output):quit(2);return
	var rows: Array=[]
	for id in range(1,101):rows.append(row(id,5 if id%3==1 else 10 if id%3==2 else 9))
	rows[0].playerState={"visibility":{"1":0,"4":0,"8":0}}
	rows.append(row(3));rows.append(row(104,1));rows.append(row(105));rows[-1].replicated.position=[];rows[-1].staticState.position=[]
	rows.append(row(-1,7));rows.append(row(106));rows[-1].areaId=8
	# Duplicate IDs can remove or replace an earlier light; the staged
	# receiver must preserve the synchronous last-row result.
	rows.append(row(107,9));rows.append(row(107,10))
	rows.append(row(108,10));rows.append(row(108,9))
	var hashes: Array=[]
	for prepared in [false,true]:
		var original=make_world();var candidate=make_world()
		var metadata: Dictionary={"version":1,"error":"","scope":[1,3,50,7],"area_id":7,"count":rows.size(),"rows":Metadata.prepare(rows,7)} if prepared else {}
		if prepared:check(original.stage_received_metadata(rows,metadata),"original prepared rows admitted")
		original.receive(rows,1)
		check(candidate.begin_received_snapshot(rows,1,metadata),"fresh unpublished entry admitted")
		check(candidate.process_mode==Node.PROCESS_MODE_DISABLED and candidate._pending_writer_depth==1 and candidate._support_writer_depth==1,"entry fences scene and inherited writer scopes once")
		check(candidate.advance_received_snapshot(Time.get_ticks_usec()).units==0,"expired deadline performs no hidden publication work")
		var count:=0;var result: Dictionary={}
		while candidate.received_snapshot_active() and count<10000:
			# A tiny deadline forces multiple resumptions without measuring FPS.
			result=candidate.advance_received_snapshot(Time.get_ticks_usec()+25);count+=1
			check(candidate.desired.is_empty() or candidate.desired.size()==original.desired.size(),"desired dictionary is never partially published")
		check(count>1 and count<10000 and not result.get("cancelled",false),"bounded entry completes across resumptions")
		check(state(candidate)==state(original),"full receiver final state matches synchronous control including drive/lights/pending/perception")
		check(not candidate.placeable_lights.objects.has(107) and candidate.placeable_lights.objects.has(108),"duplicate light IDs retain last-row semantics")
		check(candidate.process_mode==Node.PROCESS_MODE_INHERIT,"entry restores original process mode only after full state")
		check(candidate._pending_writer_depth==0 and candidate._support_writer_depth==0 and candidate.base_scenery_boundary_depth==0,"all inherited scopes unwind after completion")
		check(candidate._boundary_received_metadata.is_empty(),"private source-row metadata expires at completion")
		check(not candidate.begin_received_snapshot(rows,1,metadata),"ready/live full snapshots are rejected by entry-only helper")
		original.close();candidate.close();original.free();candidate.free();hashes.append({"prepared":prepared,"resumptions":count})
	for cancel_after in [0,1,20,160]:
		var candidate=make_world();check(candidate.begin_received_snapshot(rows,1),"cancel fixture admitted")
		for index in cancel_after:
			if not candidate.received_snapshot_active():break
			candidate._received_snapshot_commit._unit()
		candidate.cancel_received_snapshot()
		check(not candidate.received_snapshot_active() and candidate.process_mode==Node.PROCESS_MODE_DISABLED,"cancelled unpublished owner stays disabled")
		check(candidate._pending_writer_depth==0 and candidate._support_writer_depth==0 and candidate.base_scenery_boundary_depth==0,"cancel unwinds pending/support/base writer scopes")
		candidate.close();candidate.free()
	var file:=FileAccess.open(output,FileAccess.WRITE);file.store_string(JSON.stringify({"checks":checks,"failures":failures,"passed":failures.is_empty(),"cases":hashes,"scope":"Actual inherited fresh World full receive with real drive/perception/lights; authored rows, no asset admission, GPU, FPS or loading-latency claim"},"\t"));file.close();quit(0 if failures.is_empty() else 1)
