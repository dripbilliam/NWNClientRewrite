extends "res://tests/nwn63_model_groups_test.gd"
# Instrument one blocked input preview at captured model-group scale. The
# tessellated floor and start-overlap blocker are authored stress geometry;
# this is phase attribution, not a live Arelith or FPS measurement.
const Profile=preload("res://systems/native_render/frame_profile.gd")

func grid_mesh(world,divisions: int)->void:
	var mesh:={"vertices":[],"faces":[],"materials":[],"normals":[],"constants":[]}
	for y in divisions+1:
		for x in divisions+1:mesh.vertices.append([10.0*x/divisions,10.0*y/divisions,0.0])
	for y in divisions:
		for x in divisions:
			var a:=y*(divisions+1)+x;var b:=a+1;var c:=a+divisions+1;var d:=c+1
			mesh.faces.append([a,b,d]);mesh.faces.append([a,d,c])
			mesh.materials.append(0);mesh.materials.append(0)
			mesh.normals.append([0,0,1]);mesh.normals.append([0,0,1])
			mesh.constants.append(0);mesh.constants.append(0)
	world.surface.meshes.floor=mesh

func profile_path(collision,kind: String,from: Vector3,target: Vector3,measure: bool)->Dictionary:
	var before: Dictionary=collision.preview_stats.duplicate(true)
	var transcript: Array=[]
	Profile.enabled=measure;Profile.phases={};Profile.phase_frame=-1;Profile.collected_frame=-1
	var clear: Callable=collision.query_preview(1,from,target,from) if kind=="preview" else collision.query(1)
	var recording:=func(a: Vector3,b: Vector3):
		var accepted: bool=clear.call(a,b)
		transcript.append([a,b,accepted,collision.stats.get("last_blocked",{}).get("reason","") if not accepted else ""])
		return accepted
	var path: Dictionary=Plan.path(from,target,from,recording)
	var phases: Dictionary=Profile.phases.duplicate(true)
	Profile.enabled=false;Profile.phases={};Profile.phase_frame=-1
	var counts: Dictionary={}
	for key in collision.preview_stats:counts[key]=int(collision.preview_stats[key])-int(before[key])
	return {"path":path,"transcript":transcript,"phases":phases,"counts":counts}

func run()->void:
	var options: Dictionary={}
	for argument in OS.get_cmdline_user_args():
		var split:=argument.trim_prefix("--").split("=",true,1)
		if split.size()==2:options[split[0]]=split[1]
	var measure:=str(options.get("counts-only","false"))!="true"
	var pair:=group_pair(340)
	var setup: Dictionary=pair[1];var collision=setup.collision
	check(collision.static_groups.size()==342,"Captured-scale model-group count")
	var from:=Vector3(1,1,0);var target:=Vector3(3,1,0)
	var cases: Array=[]
	for density in [2,1152]:
		if density==1152:grid_mesh(setup.world,24)
		collision.tiles.clear()
		var geometry: Array=collision.tile(0)
		var blocker: Dictionary=Collision.triangle(Vector3(0,0,0),Vector3(5,0,0),Vector3(0,5,0))
		blocker.walk=false;geometry.append(blocker)
		for warm in 3:Plan.path(from,target,from,collision.query_preview(1,from,target,from))
		var ordinary:=profile_path(collision,"ordinary",from,target,measure)
		var preview:=profile_path(collision,"preview",from,target,measure)
		check(var_to_bytes(ordinary.path)==var_to_bytes(preview.path),"Density "+str(density)+" exact result")
		check(ordinary.transcript==preview.transcript,"Density "+str(density)+" exact probe order, decisions and blocker reasons")
		check(preview.transcript.size()==38,"Density "+str(density)+" exercises 38-probe blocked input")
		check(int(preview.counts.collections)==1 and int(preview.counts.initial_clears)==1 and int(preview.counts.reused_clears)==37 and int(preview.counts.fallback_clears)==0,"Density "+str(density)+" one immutable collection, 37 reused clears")
		cases.append({"floor_faces":density,"ordinary":{"probes":ordinary.transcript.size(),"phases":ordinary.phases,"counts":ordinary.counts},"preview":{"probes":preview.transcript.size(),"phases":preview.phases,"counts":preview.counts}})
	for owner in pair:owner.world.free()
	await process_frame;await process_frame
	var report:={"success":failures.is_empty(),"checks":checks,"failures":failures,"cases":cases,"counts_only":not measure,"source":"Current indexed collision, 342 authored model groups, one 2-face and one 1,152-face tessellated floor; an authored start-overlap blocker forces the full 38-probe path. Optional instrumented single-call phases overlap parents and include profiling overhead. No live area, actual input route, frame/FPS or production gain claim."}
	if options.has("report"):
		var file:=FileAccess.open(str(options.report),FileAccess.WRITE);file.store_string(JSON.stringify(report,"  "));file.close()
	print(JSON.stringify({"success":report.success,"checks":checks,"failures":failures,"cases":cases}));quit(0 if failures.is_empty() else 1)
