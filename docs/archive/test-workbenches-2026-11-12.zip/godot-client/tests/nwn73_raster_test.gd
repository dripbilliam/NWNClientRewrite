extends SceneTree
const Preparation=preload("res://systems/native_data/raster_upload_preparation.gd")
const Raster=preload("res://systems/native_data/texture_data.gd")
var checks:=0
var failures: Array=[]
class CpuJob:
	extends RefCounted
	var record: Dictionary
	var profile:=false
	var cached:=false
	var result: Dictionary={}
	func run() -> void:
		var began:=Time.get_ticks_usec() if profile else 0
		result=Preparation.prepare_cached(record) if cached else Preparation.prepare(record,profile)
		if profile and not result.is_empty():result.whole_worker_us=Time.get_ticks_usec()-began
class AttachmentJob:
	extends RefCounted
	var value: Dictionary
	var result: Dictionary={}
	func run() -> void:result=Preparation.sidecar_on_worker(value)
func _initialize() -> void:call_deferred("run")
func check(ok: bool,label: String) -> void:
	checks+=1
	if not ok:failures.append(label);print("FAIL: ",label)
func digest(bytes: PackedByteArray) -> String:
	var hash:=HashingContext.new();hash.start(HashingContext.HASH_SHA256)
	if not bytes.is_empty():hash.update(bytes)
	return hash.finish().hex_encode()
func freeze(value: Variant) -> void:
	if value is Dictionary:
		for item in value.values():freeze(item)
		value.make_read_only()
	elif value is Array:
		for item in value:freeze(item)
		value.make_read_only()
func legacy_image(data: Dictionary,profile: bool) -> Dictionary:
	# Independent verbatim operation order from ResourcePool.prepare_texture.
	var mips: Array=data.mips
	if mips.is_empty():return {"error":"Native raster has no image levels"}
	var format: int={"rgba8":Image.FORMAT_RGBA8,"dxt1_rgb":Image.FORMAT_DXT1,"dxt1_rgba":Image.FORMAT_DXT1,"dxt3":Image.FORMAT_DXT3,"dxt5":Image.FORMAT_DXT5,"etc1":Image.FORMAT_ETC,"bc6h_signed":Image.FORMAT_BPTC_RGBF,"bc6h_unsigned":Image.FORMAT_BPTC_RGBFU}.get(data.format,-1)
	if format<0:return {"error":"Native upload format is unavailable"}
	if mips.size()>1 and (int(mips[-1].width)!=1 or int(mips[-1].height)!=1):return {"error":"Partial native mip chain needs completion before upload"}
	var began:=Time.get_ticks_usec() if profile else 0;var phases: Dictionary={};var bytes:=PackedByteArray()
	for mip in mips:bytes.append_array(mip.data)
	var image:=Image.create_from_data(int(data.width),int(data.height),mips.size()>1,format,bytes)
	if profile:phases.create_us=Time.get_ticks_usec()-began;began=Time.get_ticks_usec()
	if image==null or image.is_empty():return {"error":"Native image construction failed"}
	if format==Image.FORMAT_ETC and image.decompress()!=OK:return {"error":"Native ETC decompression failed"}
	if profile:phases.decompress_us=Time.get_ticks_usec()-began;began=Time.get_ticks_usec()
	if bool(data.get("generate_mips",false)) and image.generate_mipmaps()!=OK:return {"error":"Native mip generation failed"}
	if profile:phases.mipmap_us=Time.get_ticks_usec()-began
	return {"error":"","image":image,"phases":phases}
func same_image(a: Image,b: Image) -> bool:
	return a!=null and b!=null and a.get_width()==b.get_width() and a.get_height()==b.get_height() and a.get_format()==b.get_format() and a.has_mipmaps()==b.has_mipmaps() and a.get_mipmap_count()==b.get_mipmap_count() and a.get_data()==b.get_data()
func summary(values: Array) -> Dictionary:
	if values.is_empty():return {}
	var sorted:=values.duplicate();sorted.sort();var total:=0.0
	for value in sorted:total+=float(value)
	return {"count":sorted.size(),"median_us":sorted[int(ceil(sorted.size()*0.5))-1],"p95_us":sorted[int(ceil(sorted.size()*0.95))-1],"max_us":sorted[-1],"mean_us":total/sorted.size(),"total_us":total}
func synthetic_checks() -> void:
	for size in [Vector2i(1,1),Vector2i(7,3),Vector2i(32,16)]:
		var bytes:=PackedByteArray();bytes.resize(size.x*size.y*4)
		for index in bytes.size():bytes[index]=(index*37+index/7*13)&255
		var value:={"width":size.x,"height":size.y,"format":"rgba8","mips":[{"width":size.x,"height":size.y,"data":bytes}],"generate_mips":true}
		var record:={"sha256":digest(bytes),"value":value};var expected:=legacy_image(value,false);var prepared:=Preparation.prepare(record)
		check(not prepared.is_empty() and same_image(expected.image,Preparation.image(record,prepared.get("prepared",{}))),"Unaligned/one-pixel RGBA/mip/alpha bytes preserved "+str(size))
		if prepared.is_empty():continue
		var payload: Dictionary=prepared.prepared
		check(payload.is_read_only(),"Prepared mip metadata is immutable")
		for field in ["revision","source_sha256","width","height","format","mipmaps","bytes","source_format","source_mips","source_generate_mips","source_bytes"]:
			var broken:=payload.duplicate();broken.erase(field)
			check(not Preparation.valid(record,broken),"Missing prepared field declines to original consumer "+field)
		for replacement in [{"revision":"older"},{"source_sha256":"other"},{"format":Image.FORMAT_DXT1},{"width":size.x+1},{"bytes":PackedByteArray([1])}]:
			var broken:=payload.duplicate();broken.merge(replacement,true);check(not Preparation.valid(record,broken),"Changed prepared identity/schema declines "+str(replacement.keys()))
		var mutable_value: Dictionary=value.duplicate(true);var mutable_record:={"sha256":record.sha256,"value":mutable_value};var proof:=Preparation.prepare(mutable_record)
		check(not proof.is_empty() and Preparation.valid(mutable_record,proof.prepared),"Retained source byte proof initially matches")
		var old: int=mutable_value.mips[0].data[0];mutable_value.mips[0].data[0]=old^255
		check(not Preparation.valid(mutable_record,proof.prepared),"Listener mutation without SHA change declines stale prepared pixels")
		check(int(proof.prepared.source_bytes[0][0])==old,"Explicit packed-byte COW snapshot survives source wrapper mutation")
		mutable_value.mips[0].data[0]=old
		check(Preparation.valid(mutable_record,proof.prepared),"Exact restored bytes remain valid after COW storage replacement")
	var unsupported:={"sha256":"a".repeat(64),"value":{"width":8,"height":8,"format":"rgba8","mips":[{"width":8,"height":8,"data":PackedByteArray()}],"generate_mips":true}}
	check(Preparation.prepare(unsupported).is_empty(),"Unsupported source safely retains original error path")
func worker_records(records: Array,workers: int,profile: bool) -> Dictionary:
	var pending: Array=[];var next:=0;var results: Array=[];results.resize(records.size());var peak:=0;var began:=Time.get_ticks_usec() if profile else 0;var first:=0
	while next<records.size() or not pending.is_empty():
		while next<records.size() and pending.size()<workers:
			var job:=CpuJob.new();job.record=records[next].record;job.profile=profile
			var task:=WorkerThreadPool.add_task(job.run,false,"NWN73 private raster CPU preparation");pending.append({"task":task,"job":job,"index":next});next+=1;peak=maxi(peak,pending.size())
		for row in pending.duplicate():
			if not WorkerThreadPool.is_task_completed(row.task):continue
			WorkerThreadPool.wait_for_task_completion(row.task);results[int(row.index)]=row.job.result;pending.erase(row)
			if profile and first==0:first=Time.get_ticks_usec()-began
		if not pending.is_empty():await process_frame
	return {"results":results,"peak":peak,"full_us":Time.get_ticks_usec()-began if profile else 0,"first_us":first}
func memo_checks(records: Array) -> void:
	Preparation.clear();var before:=Preparation.snapshot();var record: Dictionary=records[2].record;var jobs: Array=[];var tasks: Array=[]
	for index in 4:
		var job:=CpuJob.new();job.record=record;job.cached=true;jobs.append(job);tasks.append(WorkerThreadPool.add_task(job.run,false,"NWN73 memo coalescing"))
	for task in tasks:
		while not WorkerThreadPool.is_task_completed(task):await process_frame
		WorkerThreadPool.wait_for_task_completion(task)
	var after:=Preparation.snapshot();check(int(after.builds)-int(before.builds)==1 and after.entries==1,"Concurrent identical original has one CPU producer")
	check(int(after.retained_bytes)<=Preparation.MAX_RETAINED_BYTES and after.inflight==0,"Memo retains bounded CPU bytes and no completed flights")
	for job in jobs:check(not job.result.is_empty() and Preparation.valid(record,job.result.prepared),"Every memo consumer receives complete exact original packet")
	var original:={"textures":{"a":record,"b":record},"emitter_textures":{"c":record},"error":""};var original_headers: Dictionary=original.textures;var original_bytes:=var_to_bytes(original)
	var attachment:=AttachmentJob.new();attachment.value=original;var task:=WorkerThreadPool.add_task(attachment.run,false,"NWN73 existing-job adapter")
	while not WorkerThreadPool.is_task_completed(task):await process_frame
	WorkerThreadPool.wait_for_task_completion(task)
	check(int(attachment.result.stats.prepared)==1 and attachment.result.rows.size()==1,"Separate sidecar prepares duplicate texture/emitter identities once")
	check(var_to_bytes(original)==original_bytes and is_same(original_headers,original.textures) and is_same(original.textures.a,record),"Every original header/container/serialized byte remains identical")
	var ready: Image=Preparation.image(record,attachment.result.rows[record.sha256]);check(ready!=null,"Main consumes separate worker packet by original SHA")
	check(attachment.result.is_read_only() and attachment.result.rows.is_read_only(),"Separate runtime packet and rows are immutable")
	var saved: Dictionary=original.duplicate();check(var_to_bytes(saved)==original_bytes and not saved.has("raster_upload_sidecar"),"Original persistent bundle contains no worker sidecar bytes")
	Preparation.clear();check(Preparation.snapshot().retained_bytes==0 and Preparation.snapshot().entries==0,"Explicit cache clear releases all bounded retained pixels")
func run() -> void:
	var args: Dictionary={}
	for arg in OS.get_cmdline_user_args():
		var pair:=arg.trim_prefix("--").split("=",true,1)
		if pair.size()==2:args[pair[0]]=pair[1]
	if not args.has("report") or FileAccess.file_exists(args.report):quit(2);return
	var benchmark: bool=args.get("benchmark","")=="on";var gpu: bool=args.get("gpu","")=="on";var records: Array=[]
	var corpus: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://originals/corpus.json"));var parser:=Raster.new();parser.use_native=false
	for row in corpus.records:
		var bytes:=FileAccess.get_file_as_bytes("res://originals/"+str(row.file));check(digest(bytes)==str(row.sha256),"Original recorded TGA bytes pinned "+str(row.name))
		var value:=parser.parse(bytes,int(row.type));check(parser.failure.is_empty(),"Original TGA decodes "+str(row.name)+" "+parser.failure)
		records.append({"name":row.name,"kind":row.category,"record":{"sha256":row.sha256,"value":value}})
	var file:=FileAccess.open("res://original-tile.var",FileAccess.READ);var tile: Dictionary=file.get_var(false);file.close();var seen: Dictionary={}
	for name in tile.textures:
		var record: Dictionary=tile.textures[name]
		if seen.has(record.sha256):continue
		seen[record.sha256]=true;records.append({"name":name,"kind":"world DDS","record":record})
	for row in records:freeze(row.record)
	synthetic_checks()
	var before: Array=[];var control: Array=[];var original_phases: Array=[]
	for row in records:
		before.append(digest(var_to_bytes(row.record.value)));var result:=legacy_image(row.record.value,benchmark)
		check(str(result.error).is_empty(),"Original Image baseline succeeds "+str(row.name));control.append(result.get("image"));original_phases.append(result.get("phases",{}))
	var workers:=clampi(int(args.get("workers",4)),1,4);var prepared:=await worker_records(records,workers,benchmark);var metadata: Array=[];var main_ready_us: Array=[];var uploads: Array=[];var textures: Array=[];var worker_threads: Dictionary={}
	for index in records.size():
		var row: Dictionary=records[index];var result: Dictionary=prepared.results[index]
		check(not result.is_empty(),"Private CPU worker prepared original "+str(row.name))
		if result.is_empty():continue
		worker_threads[int(result.thread)]=true;check(int(result.thread)!=OS.get_main_thread_id(),"Original CPU Image preparation executes on a worker")
		var began:=Time.get_ticks_usec() if benchmark else 0;var actual:=Preparation.image(row.record,result.prepared)
		if benchmark:main_ready_us.append(Time.get_ticks_usec()-began)
		check(same_image(control[index],actual),"Exact complete original mip bytes/format/alpha "+str(row.name))
		check(digest(var_to_bytes(row.record.value))==before[index],"Worker never modifies original decoded raster "+str(row.name))
		if gpu:
			began=Time.get_ticks_usec() if benchmark else 0;var texture:=ImageTexture.create_from_image(actual)
			if benchmark:uploads.append(Time.get_ticks_usec()-began)
			check(texture!=null and texture.get_width()==actual.get_width() and texture.get_height()==actual.get_height(),"Main-thread GPU texture publication preserves dimensions "+str(row.name));textures.append(texture)
		var value: Dictionary=row.record.value
		metadata.append({"name":row.name,"kind":row.kind,"width":actual.get_width(),"height":actual.get_height(),"format":actual.get_format(),"mips":actual.get_mipmap_count(),"bytes":actual.get_data().size(),"proof_plus_prepared_bytes":Preparation.retained_size(result.prepared),"input_mips":value.mips.size(),"input_types":value.mips.map(func(mip):return type_string(typeof(mip.data))),"input_format":value.format,"needs_mip_generation":bool(value.get("generate_mips",false)),"needs_etc_decode":value.format=="etc1","digest":digest(actual.get_data()),"baseline_cpu_phases":original_phases[index],"worker_cpu_phases":result.phases,"whole_worker_us":result.get("whole_worker_us",0),"ready_image_main_us":main_ready_us[-1] if benchmark else 0,"texture_submit_main_us":uploads[-1] if benchmark and gpu else 0})
	check(not worker_threads.is_empty(),"Real original worker path engaged")
	check(prepared.peak<=workers,"Existing four-worker concurrency cap preserved")
	if not benchmark:await memo_checks(records)
	var report:={"issue":"NWN-73","success":failures.is_empty(),"checks":checks,"failures":failures,"originals":metadata,"worker_threads":worker_threads.keys(),"workers":workers,"peak_jobs":prepared.peak,"worker_batch_us":prepared.full_us,"first_worker_us":prepared.first_us,"ready_image_main_us":summary(main_ready_us),"texture_submit_main_us":summary(uploads),"cpu_memo":Preparation.snapshot(),"gpu_requested":gpu,"display":DisplayServer.get_name(),"render_method":RenderingServer.get_current_rendering_method(),"scope":"Private CPU Image work on existing Godot workers, original recorded Arelith TGA and original tile DDS; byte-exact full mip/format/alpha and source identity. Separate create/decompress/mipmap CPU and optional MAIN ImageTexture submit. Headless has no meaningful GPU upload cost. No normal runtime selection, frame/FPS or entry latency claim."}
	textures.clear();await process_frame
	file=FileAccess.open(args.report,FileAccess.WRITE);file.store_string(JSON.stringify(report,"\t"));file.close();print("NWN73_RASTER ",checks," checks; ",failures.size()," failures");quit(0 if failures.is_empty() else 1)
