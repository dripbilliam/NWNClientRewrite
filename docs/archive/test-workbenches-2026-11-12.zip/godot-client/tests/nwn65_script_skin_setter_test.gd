extends "res://tests/nwn65_rig_skin_publisher_test.gd"
# Exact script scalar-versus-combined setter parity. No timing or GPU readback.

func skin_matrices(row: Dictionary) -> Array:
	var result: Array=[]
	for skin: Dictionary in row.entry.skins:
		var skeleton: Skeleton3D=skin.skeleton
		var binding: Skin=skin.mesh.skin
		var matrices: Array=[]
		for bind in binding.get_bind_count():
			var bone: int=binding.get_bind_bone(bind)
			matrices.append(skeleton.get_bone_global_pose(bone)*binding.get_bind_pose(bind))
		result.append(matrices)
	return result

func run() -> void:
	var original: Dictionary=setup(false,false,false)
	var combined: Dictionary=setup(false,false,false)
	combined.rigs.use_combined_skin_setter=true
	check(not original.rigs.use_combined_skin_setter and combined.rigs.use_combined_skin_setter,"Combined setter is explicitly selected")
	for row: Dictionary in [original,combined]:
		for skin: Dictionary in row.entry.skins:
			var skeleton: Skeleton3D=skin.skeleton
			skeleton.set_bone_parent(1,0)
			skeleton.set_bone_parent(2,1)
			skeleton.set_bone_rest(0,Transform3D(Basis(Quaternion(Vector3.UP,0.23)),Vector3(0.2,-0.3,0.4)))
			skeleton.set_bone_rest(1,Transform3D(Basis(Quaternion(Vector3.RIGHT,-0.17)),Vector3(-0.1,0.5,0.3)))
	for frame: int in 24:
		for row: Dictionary in [original,combined]:
			if frame in [0,4,11,19]:
				for skin: Dictionary in row.entry.skins:
					skin.skeleton.set_bone_pose_scale(0,Vector3(1.7,0.6,2.3))
					skin.skeleton.set_bone_pose_scale(2,Vector3(0.8,1.4,0.5))
			if frame==5:row.rigs.set_manual_pose(1,row.entry.nodes[1],Vector3(0.2,-0.7,0.3),Quaternion(Vector3.RIGHT,0.17))
			if frame==8:row.entry.attachments[0].flags=0
			if frame==12:row.entry.attachments[0].flags=3
			if frame==13:row.rigs._play(row.entry.models[0],"turn",true,-0.5,0.4,true)
			if frame==17:row.entry.parents=[-1,0,0,2,3]
			row.rigs._update(0.0625)
		check(var_to_bytes(capture(original))==var_to_bytes(capture(combined)),"Exact node/local/global bone, event, force and clock output frame "+str(frame))
		check(var_to_bytes(skin_matrices(original))==var_to_bytes(skin_matrices(combined)),"Exact skin matrices frame "+str(frame))
		for row: Dictionary in [original,combined]:
			for skin: Dictionary in row.entry.skins:
				check(skin.skeleton.get_bone_pose_scale(0)==Vector3.ONE and skin.skeleton.get_bone_pose_scale(2)==Vector3.ONE,"Preexisting nonunit scale reset frame "+str(frame))
	check(original.forces==combined.forces and not original.forces.is_empty(),"Force notification order/count preserved")
	for row: Dictionary in [original,combined]:
		row.rigs.forget_entity(1)
		row.host.free()
		row.clear()
	coverage.append("24 animated frames; preexisting nonunit scale; parented skin slots and rest pose; manual/reverse/attachment changes; exact local/global bone and skin matrices; event and force order")
	finish()
