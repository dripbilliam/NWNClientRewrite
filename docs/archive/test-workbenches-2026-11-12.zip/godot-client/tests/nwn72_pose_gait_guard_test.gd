extends SceneTree
const Rigs=preload("res://systems/model_rigs.gd")
var checks:=0
var failures: Array=[]
var output:=""
class CountRigs extends Rigs:
	var calls:=0
	func clip_length(id: int,animation: int,side: int=-1) -> float:calls+=1;return super.clip_length(id,animation,side)
class Instance extends Node3D:
	var rigs
class Combat extends RefCounted:
	var events: Array=[]
	func base_frame(id: int,code: int,speed: float,remaining: float) -> void:events.append(["base",id,code,speed,remaining])
	func movement_cue(id: int,cue: Dictionary) -> void:events.append(["cue",id,cue])
	func visual_animation(_id: int,code: int) -> int:return code
	func close() -> void:pass
class Observer extends RefCounted:
	var events: Array=[]
	func observe(object: Dictionary,code: int=-1) -> void:events.append([object,code])
class Effects extends Node:
	var casts:=Observer.new()
	var special_attacks:=Observer.new()
	var equipped_attacks:=Observer.new()
	func close() -> void:pass
func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.trim_prefix("--report=")
	call_deferred("run")
func check(value: bool,label: String) -> void:
	checks+=1
	if not value:failures.append(label);push_error(label)
func make_world(script,active: bool,has_gait: bool,code: int,clip_length: float):
	var world=script.new();world.area_id=7;world.generation=3;world.controlled_id=1
	var object:={"id":1,"objectType":5,"replicated":{"animationSpeed":1.3}}
	world.desired[1]={"object":object,"key":"same"}
	var instance:=Instance.new();instance.rigs=CountRigs.new();instance.add_child(instance.rigs)
	instance.rigs.entities[1]={"side":0,"side_maps":{},"clip_map":{str(code):"selected"},"models":[{"follow":true,"indexed_asset":{"clipIndex":{"selected":0},"clips":[{"length":clip_length}]}}]}
	world.instances[1]=instance;world.add_child(instance)
	world.combat=Combat.new();world.effects=Effects.new();world.add_child(world.effects)
	var state: Dictionary=world.motion.ensure(1,{"position":[1,2,3],"orientation":[0.6,0.8,0],"animation":code,"walkRate":2,"runRate":4,"walkDistance":1.6,"runDistance":2.8})
	state.active=active;state.script=1;state.path=[Vector3(1,2,3),Vector3(4,2,3)];state.correctionCue={"animation":26};state.facingTurn=81
	if has_gait:state.gait={"animation":code,"rate":2.5,"script":1,"factor":0.8,"acceleration":0.7}
	return world
func captured(world) -> Dictionary:
	return {"transform":world.instances[1].transform,"animation":world.animations,"motion":world.motion.objects,"combat":world.combat.events,"casts":world.effects.casts.events,"special":world.effects.special_attacks.events,"equipped":world.effects.equipped_attacks.events,"stats":world.stats}
func run() -> void:
	if output.is_empty() or FileAccess.file_exists(output):quit(2);return
	var original=load("res://.cache/nwn72/pose-guard-a/control.gd");var candidate=load("res://.cache/nwn72/pose-guard-a/candidate.gd")
	var original_calls:=0;var candidate_calls:=0;var eligible_frames:=0
	for active in [false,true]:
		for has_gait in [false,true]:
			for code in [0,2,4,53,78]:
				for clip_length in [0.0,1.7]:
					var before=make_world(original,active,has_gait,code,clip_length);var after=make_world(candidate,active,has_gait,code,clip_length)
					for frame in 8:before.apply_pose(1);after.apply_pose(1)
					check(var_to_bytes(captured(before))==var_to_bytes(captured(after)),"actual World pose output/combat/effects match active%s gait%s animation%s clip%s"%[active,has_gait,code,clip_length])
					check(before.instances[1].rigs.calls==8,"control performs original eight eager clip reads")
					check(after.instances[1].rigs.calls==(8 if active and has_gait else 0),"candidate removes only provably unused clip reads")
					check(after.combat.events.size()==16 and after.effects.casts.events.size()==8 and after.effects.special_attacks.events.size()==8 and after.effects.equipped_attacks.events.size()==8,"all per-frame combat/correction/effect observers remain live")
					original_calls+=before.instances[1].rigs.calls;candidate_calls+=after.instances[1].rigs.calls
					if not active or not has_gait:eligible_frames+=8
					before.instances.clear();after.instances.clear();before.close();after.close();before.free();after.free()
	var file:=FileAccess.open(output,FileAccess.WRITE);file.store_string(JSON.stringify({"checks":checks,"failures":failures,"passed":failures.is_empty(),"control_clip_reads":original_calls,"candidate_clip_reads":candidate_calls,"eligible_frames":eligible_frames,"scope":"Actual private World.apply_pose and canonical ModelRigs metadata getter with authored combat/effect observers; output and call counts only, no timing/FPS/visual claim; production World unchanged"},"\t"));file.close();quit(0 if failures.is_empty() else 1)
