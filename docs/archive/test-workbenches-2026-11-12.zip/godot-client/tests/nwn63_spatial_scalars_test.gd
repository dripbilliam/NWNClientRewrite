extends "res://tests/native_drive_spatial_index_test.gd"
const BeforeIndex=preload("res://.cache/nwn63/spatial-scalars-a/before/systems/native_render/drive_spatial_index.gd")
var exact_queries:=0
func same_query(pair: Array,tickets: Array,a: Vector3,b: Vector3,radius: float,exclude: int=-1,creatures: bool=true,vertical: Variant=null,compare_flat: bool=true)->void:
	var before: Dictionary=pair[0].query(tickets[0],a,b,radius,exclude,creatures,vertical)
	var after: Dictionary=pair[1].query(tickets[1],a,b,radius,exclude,creatures,vertical)
	check(var_to_bytes(before)==var_to_bytes(after),"Exact public query packet, diagnostics and visit counters "+str(exact_queries))
	check(pair[0].snapshot().last_query==pair[1].snapshot().last_query,"Exact retained last_query metadata "+str(exact_queries))
	if compare_flat and before.ready and vertical==null:
		check(before.ids==pair[0].query_flat_control(tickets[0],a,b,radius,exclude,creatures).ids,"Original index agrees with flat control "+str(exact_queries))
		check(after.ids==pair[1].query_flat_control(tickets[1],a,b,radius,exclude,creatures).ids,"Current index agrees with flat control "+str(exact_queries))
	exact_queries+=1
func paired_queries()->void:
	var pair: Array=[BeforeIndex.new(),Index.new()];var tickets: Array=[]
	for index in pair:
		var ticket: Dictionary=index.begin([736,4,91]);tickets.append(ticket);index.begin_batch(ticket)
		for i in 192:
			var point:=Vector2((i%16)*8-64,(i/16)*8-48)
			if i%11==0:index.upsert_pending(ticket,i,[i+1,3],1,point,false,i%17)
			elif i%7==0:index.upsert_creature(ticket,i,[i+1,3],1,point,0.2+i%4,false,i%17)
			else:index.upsert_shape(ticket,i,[i+1,3],1,"dwk" if i%3==0 else "pwk",Vector3(point.x,point.y,-2),Vector3(point.x+2,point.y+1,3),false,i%17)
		index.end_batch(ticket)
	var rng:=RandomNumberGenerator.new();rng.seed=0x63d94120
	for i in 128:
		var a:=Vector3(rng.randf_range(-80,80),rng.randf_range(-64,64),rng.randf_range(-10,10));var b:=a+Vector3(rng.randf_range(-24,24),rng.randf_range(-24,24),0)
		same_query(pair,tickets,a,b,float(i%5)*0.3,i%193,i%2==0,Vector2(-1,1) if i%3==0 else null)
	for spec in [[Vector3.ZERO,Vector3.ZERO,-0.0,null],[Vector3(16777216,0,0),Vector3(16777218,0,0),0.3,null],[Vector3.ZERO,Vector3.ONE,5e-324,null],[Vector3(NAN,0,0),Vector3.ONE,0.0,null],[Vector3.ZERO,Vector3(INF,0,0),0.0,null],[Vector3.ZERO,Vector3.ONE,NAN,null],[Vector3.ZERO,Vector3.ONE,INF,null],[Vector3.ZERO,Vector3.ONE,-1.0,null],[Vector3.ZERO,Vector3.ONE,0.0,Vector2(NAN,1)],[Vector3.ZERO,Vector3.ONE,0.0,Vector2(0,INF)],[Vector3.ZERO,Vector3.ONE,0.0,Vector2(2,1)],[Vector3.ZERO,Vector3.ONE,0.0,[]]]:
		same_query(pair,tickets,spec[0],spec[1],float(spec[2]),-1,true,spec[3])
	# Public APIs reject nonfinite rows. Corrupt the private root deliberately
	# to prove the original positive-AND NaN behavior was not DeMorgan-rewritten.
	for value in [NAN,INF,-INF]:
		var previous: Array=[]
		for index in pair:previous.append(index._nodes[index._root].min_x);index._nodes[index._root].min_x=value
		same_query(pair,tickets,Vector3.ZERO,Vector3.ONE,0.3,-1,true,null,false)
		for i in pair.size():pair[i]._nodes[pair[i]._root].min_x=previous[i]
	for i in pair.size():
		pair[i].begin_batch(tickets[i]);pair[i].remove(tickets[i],0,[1,3],2)
	same_query(pair,tickets,Vector3.ZERO,Vector3.ONE,0.3)
	for i in pair.size():pair[i].end_batch(tickets[i])
	same_query(pair,tickets,Vector3(-80,-64,0),Vector3(80,64,0),0.3)
	for i in pair.size():pair[i].clear(tickets[i])
	same_query(pair,tickets,Vector3.ZERO,Vector3.ONE,0.3)
func run()->void:
	basics();lifecycle();edges_and_structure();randomized();bulk_publication();paired_queries()
	var result:={"success":failures.is_empty(),"checks":checks,"failures":failures,"exact_queries":exact_queries,"random_queries":random_queries,"narrow_comparisons":narrow_comparisons,"scope":"Existing scoped-tree/flat/narrow/lifecycle oracle plus exact before/current full query packets, visitation/last-query metadata, ordering/ties, finite and nonfinite input/vertical edges, pending/creature/shape exclusion, publication/retirement and positive-AND NaN behavior. No timing or FPS claim."}
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--report="):
			var file:=FileAccess.open(argument.trim_prefix("--report="),FileAccess.WRITE);file.store_string(JSON.stringify(result,"  "));file.close()
	print(JSON.stringify(result));quit(0 if failures.is_empty() else 1)
