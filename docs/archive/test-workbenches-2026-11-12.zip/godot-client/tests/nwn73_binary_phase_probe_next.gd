extends SceneTree

const Actor = preload("res://systems/native_data/actor_model.gd")
const Binary = preload("res://systems/native_data/binary_data.gd")
const BinaryModel = preload("res://systems/native_data/binary_model.gd")

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var output := ""
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--report="): output = argument.trim_prefix("--report=")
	if output.is_empty() or FileAccess.file_exists(output):
		quit(2)
		return
	var archive_path := ProjectSettings.globalize_path("res://.cache/loading-benchmark-worlds/arelith-archive-shaders-v1/catalog-1/resources.erf")
	var archive := FileAccess.open(archive_path,FileAccess.READ)
	if archive == null or archive.get_length() != 289956979:
		quit(3)
		return
	var rows := []
	for source in [{"name":"a_ba","offset":20148484,"bytes":5990990},{"name":"a_dfa","offset":36825551,"bytes":1694488}]:
		archive.seek(int(source.offset))
		var bytes: PackedByteArray=archive.get_buffer(int(source.bytes))
		if bytes.size()!=int(source.bytes) or bytes.decode_u32(0)!=0:
			quit(4)
			return
		var whole := Actor.new()
		var began := Time.get_ticks_usec()
		var complete: Dictionary=whole.parse(bytes)
		var whole_ms := (Time.get_ticks_usec()-began)/1000.0
		var geometry := BinaryModel.new()
		began=Time.get_ticks_usec()
		var model: Dictionary=geometry.parse(bytes)
		var geometry_ms := (Time.get_ticks_usec()-began)/1000.0
		var actor := Actor.new()
		actor.reader=Binary.new(bytes)
		actor.model_end=12+actor.reader.u32(4)
		actor.raw_start=actor.model_end
		actor.physical=0
		actor.visited={}
		began=Time.get_ticks_usec()
		actor.binary_parts(actor.reader.u32(84),model.nodes,0)
		var parts_ms := (Time.get_ticks_usec()-began)/1000.0
		began=Time.get_ticks_usec()
		var animations: Array=actor.binary_animations()
		var animations_ms := (Time.get_ticks_usec()-began)/1000.0
		rows.append({"name":source.name,"whole_ms":whole_ms,"geometry_ms":geometry_ms,"parts_ms":parts_ms,"animations_ms":animations_ms,
			"whole_nodes":complete.get("nodes",[]).size(),"nodes":model.get("nodes",[]).size(),"whole_clips":complete.get("animations",[]).size(),"clips":animations.size(),
			"whole_error":whole.failure,"geometry_error":geometry.failure,"phase_error":actor.failure})
	archive.close()
	var file := FileAccess.open(output,FileAccess.WRITE)
	file.store_string(JSON.stringify({"rows":rows,"scope":"Single contended headless decomposition of two saved original binary sources. No parallel candidate or loading/FPS claim."},"\t"))
	file.close()
	quit(0 if rows.all(func(row): return row.whole_error.is_empty() and row.geometry_error.is_empty() and row.phase_error.is_empty() and row.whole_nodes==row.nodes and row.whole_clips==row.clips) else 1)
