extends SceneTree
# Component callback window only. This does not collect frame periods or FPS.
const Original = preload("res://.cache/nwn65/dormant-baseline-a.gd")
const Candidate = preload("res://systems/model_rigs.gd")

class Early extends Node:
	var began := 0
	func _process(_delta: float) -> void:
		began = Time.get_ticks_usec()

class Late extends Node:
	var early: Node
	var warm := 0
	var limit := 0
	var samples: Array[int] = []
	var collecting := false
	func _process(_delta: float) -> void:
		if not collecting:
			return
		if warm > 0:
			warm -= 1
			return
		samples.append(Time.get_ticks_usec() - early.began)
		if samples.size() >= limit:
			collecting = false

var output := ""
var checks := 0
var failures: Array[String] = []

func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):
			output = arg.trim_prefix("--report=")
	call_deferred("run")

func check(value: bool, label: String) -> void:
	checks += 1
	if not value:
		failures.append(label)
		push_error(label)

func create(script, id: int) -> Dictionary:
	var host := Node3D.new()
	root.add_child(host)
	var rigs = script.new()
	host.add_child(rigs)
	var rest := {"position": [0.0, 0.0, 0.0], "quaternion": [0.0, 0.0, 0.0, 1.0], "scale": [1.0, 1.0, 1.0]}
	var asset := {"defaults": [rest], "clips": [{"name": "once", "length": 0.1, "transition": 0.0, "events": [], "tracks": []}]}
	var model := {"asset": 0, "parts": [0], "defaults": [rest], "clip": "once", "loop": false, "follow": true}
	var data := {"rigs": {"version": 1, "assets": [asset], "entities": [{"id": id,
		"nodes": [{"name": "root", "parent": -1, "position": rest.position, "quaternion": rest.quaternion, "scale": rest.scale}],
		"models": [model]}]}, "meshes": []}
	rigs.configure({"meshes_by_name": {}}, {id: host}, data)
	rigs._update(0.125)
	return {"host": host, "rigs": rigs, "id": id}

func summary(values: Array[int]) -> Dictionary:
	values.sort()
	return {"samples": values.size(), "median_us": values[int(ceil(values.size() * 0.5)) - 1],
		"p95_us": values[int(ceil(values.size() * 0.95)) - 1],
		"max_us": values[-1]}

func run() -> void:
	if output.is_empty() or FileAccess.file_exists(output):
		quit(2)
		return
	var early := Early.new()
	early.process_priority = -1000000
	root.add_child(early)
	var late := Late.new()
	late.early = early
	late.process_priority = 1000000
	root.add_child(late)
	var old: Array = []
	var current: Array = []
	for id in 80:
		old.append(create(Original, id))
		current.append(create(Candidate, id))
	check(old.all(func(row): return row.rigs.is_processing()) and current.all(func(row): return not row.rigs.is_processing()),
		"all completed one-shot owners use the intended scheduling policy")
	var legs: Array = []
	for mode in ["reference", "optimized", "optimized", "reference"]:
		for row in old:
			row.rigs.set_process(mode == "reference")
		var before := 0
		for row in old:
			before += int(row.rigs.stats.pose_frames)
		var current_before := 0
		for row in current:
			current_before += int(row.rigs.stats.pose_frames)
		late.samples.clear()
		late.warm = 8
		late.limit = 120
		late.collecting = true
		while late.collecting:
			await process_frame
		var after := 0
		for row in old:
			after += int(row.rigs.stats.pose_frames)
		var current_after := 0
		for row in current:
			current_after += int(row.rigs.stats.pose_frames)
		check(after - before == 80 * 128 if mode == "reference" else after == before,
			"reference callback count matches selected leg " + mode)
		check(current_after == current_before, "candidate completed owners stay suspended " + mode)
		legs.append({"mode": mode, "timing": summary(late.samples.duplicate()),
			"reference_callbacks": after - before, "candidate_callbacks": current_after - current_before})
	for row in old + current:
		row.host.free()
	early.free()
	late.free()
	await process_frame
	var report := {"ticket": "NWN-65", "passed": failures.is_empty(), "checks": checks,
		"failures": failures, "order": "A-B-B-A", "completed_owners": 80,
		"baseline_sha256": FileAccess.get_sha256("res://.cache/nwn65/dormant-baseline-a.gd"),
		"candidate_sha256": FileAccess.get_sha256("res://systems/model_rigs.gd"), "legs": legs,
		"scope": "Normal Core E headless SceneTree callback window for 80 synthetic completed one-shot owners without skins, attachments or manual poses. Fixture population only; no live eligibility, full frame, GPU, asset or FPS claim."}
	var file := FileAccess.open(output, FileAccess.WRITE)
	file.store_string(JSON.stringify(report, "\t"))
	file.close()
	quit(0 if failures.is_empty() else 1)
