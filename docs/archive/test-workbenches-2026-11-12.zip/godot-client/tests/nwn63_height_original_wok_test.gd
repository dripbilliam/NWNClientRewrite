extends "res://.cache/nwn63/search-height-a/component_test.gd"
# Read-only pinned original WOK corpus. Authored local placement/blocker forces
# 38 probes; this is not a recorded Arelith tile layout or live keyboard input.
const TileSurface=preload("res://systems/native_data/tile_surface.gd")
const Table=preload("res://systems/native_data/two_da.gd")
const Binary=preload("res://systems/native_data/binary_data.gd")
const Catalog=preload("res://systems/native_data/resource_catalog.gd")
const HeightIndex=preload("res://.cache/nwn63/search-height-a/height_index.gd")
const ProductionHeightIndex=preload("res://systems/native_render/drive_height_index.gd")

func gate_scope()->String:
	var route:="production source flag OFF/ON" if OS.get_cmdline_user_args().has("--production-gate=on") else "private repeated end-height index versus accepted collision"
	return "Read-only SHA-pinned original install WOK corpus; "+route+". 74 face/walkable counts and eight original tile meshes under authored 342-group/891-entry, start-overlap blocker 38-probe path. Exact endpoint/result/blocker parity. The tile placements/blocker are authored, not recorded Arelith layout or live keyboard/click input. Serialized bytes proxy is not heap/RSS; no FPS claim."

func make_pair()->Array:
	if not OS.get_cmdline_user_args().has("--production-gate=on"):return super.make_pair()
	var pair: Array=[]
	for enabled in [false,true]:
		var setup:=make_world(false);var collision=Collision.new()
		setup.world.add_child(collision);collision.world=setup.world;collision.tables=tables();setup.world.drive_collision=collision;collision.ensure_spatial_scope();collision.set_process(false)
		collision._preview_height_index_enabled=enabled
		var rows: Array=[creature(1,Vector2(1,1)),creature(4,Vector2(6,3)),object(2,Vector2(4,1)),object(3,Vector2(9,1),10)]
		collision.publish_model("chest:placeable",{"states":[footprint()]})
		collision.publish_model("gate:door",{"states":[footprint(),{"vertices":[],"faces":[]},footprint(2)]})
		for i in 340:
			var key:="cohort_"+str(i);var appearance: int=collision.tables.placeables.orderedRows.size()
			collision.tables.placeables.orderedRows.append({"ModelName":key})
			if i%17!=0:collision.publish_model(key+":placeable",{"states":[footprint(1+i%4)]})
			rows.append(object(100+i,Vector2(24+(i%12)*8,24+(i/12)*8),9,1,appearance))
		for extra in 549:
			var cohort:=extra%340
			var anchor:=Vector2(24+(cohort%12)*8,24+(cohort/12)*8)
			rows.append(object(1000+extra,anchor+Vector2(float(extra%3)*0.4,float(extra%5)*0.4),9,1,2+cohort))
		setup.world.receive(rows,1);setup.collision=collision;pair.append(setup)
		check(collision.static_groups.size()==342 and int(collision.snapshot().static_entries)==891,"Same 342-group/891-entry production publication")
	return pair

func digest(bytes: PackedByteArray)->String:
	var hash:=HashingContext.new();hash.start(HashingContext.HASH_SHA256);hash.update(bytes);return hash.finish().hex_encode()

func install_asset(setup: Dictionary,name: String,mesh: Dictionary,table: Dictionary)->void:
	var surface=setup.world.surface;var collision=setup.collision
	surface.table=table;surface.meshes[name]=mesh
	var definition: Dictionary=surface.definition;var placed: Dictionary=definition.tiles[0]
	placed.model=name;definition.tiles[0]=placed
	collision.invalidate_preview_geometry();collision.tiles.clear()

func measure_asset(pair: Array,name: String,mesh: Dictionary,table: Dictionary,samples: int)->Dictionary:
	var from:=Vector3(1,1,0);var target:=Vector3(3,1,0)
	var production_gate:=OS.get_cmdline_user_args().has("--production-gate=on")
	var production_built_before: int=ProductionHeightIndex.total_builds
	var cold: Array=[];var bytes: Array=[]
	for setup in pair:
		install_asset(setup,name,mesh,table)
		var collision=setup.collision;var times: Array=[]
		for warm in 2:collision.tiles.clear();collision.tile(0)
		for sample in 6:
			collision.tiles.clear();var began:=Time.get_ticks_usec();var triangles: Array=collision.tile(0);times.append(Time.get_ticks_usec()-began)
			if sample==0:bytes.append(var_to_bytes(triangles).size())
		cold.append(stats_for(times))
		var wall: Dictionary=Candidate.triangle(Vector3(0,0,0),Vector3(5,0,0),Vector3(0,5,0)) if collision.get_script()==Candidate else Collision.triangle(Vector3(0,0,0),Vector3(5,0,0),Vector3(0,5,0))
		wall.walk=false;collision.tiles[0].append(wall)
	var reference: PackedByteArray=PackedByteArray();var transcript: Array=[];var blocks: Array=[]
	for index in [0,1,1,0]:
		var collision=pair[index].collision
		for warm in 4:Plan.path(from,target,from,collision.query_preview(1,from,target,from))
		var one: Dictionary=profile_path(collision,"preview",from,target,false)
		var result_bytes:=var_to_bytes(one.path)
		if reference.is_empty():reference=result_bytes;transcript=one.transcript
		check(result_bytes==reference and one.transcript==transcript and one.transcript.size()==38,"Original "+name+" exact 38-probe path and blocker order")
		var before: Dictionary=collision.preview_stats.duplicate(true);var times: Array=[]
		for sample in samples:
			var began:=Time.get_ticks_usec()
			var path: Dictionary=Plan.path(from,target,from,collision.query_preview(1,from,target,from))
			times.append(Time.get_ticks_usec()-began)
			check(var_to_bytes(path)==reference,"Original "+name+" exact sampled path")
		var counts: Dictionary={}
		for key in collision.preview_stats:counts[key]=int(collision.preview_stats[key])-int(before[key])
		check(int(counts.probes)==38*samples and int(counts.collections)==samples and int(counts.reused_clears)==37*samples and int(counts.fallback_clears)==0,"Original "+name+" unchanged 38-probe schedule")
		blocks.append({"owner":"candidate" if index==1 else "control","timing":stats_for(times),"counts":counts})
	var base_terms:=int(blocks[0].counts.get("from_terms_prepared",0))+int(blocks[0].counts.get("from_terms_reused",0))
	var candidate_terms:=int(blocks[1].counts.get("from_terms_prepared",0))+int(blocks[1].counts.get("from_terms_reused",0))
	var walkable:=0
	for material in mesh.materials:
		if TileSurface.walkable(table,int(material)):walkable+=1
	var live_production_builds: int=ProductionHeightIndex.total_builds-production_built_before
	var index_cold: Array=[];var index_bytes:=0;var indexed_faces:=0;var rejected_faces:=0
	for sample in 6:
		var index=ProductionHeightIndex.new() if production_gate else HeightIndex.new();check(index.configure(pair[1].world.surface),"Original "+name+" height index configures")
		var began:=Time.get_ticks_usec();var result: float=index.height(pair[1].world.surface,Vector3(1,1,0),0);index_cold.append(Time.get_ticks_usec()-began)
		check(result==pair[1].world.surface.height(Vector3(1,1,0),0),"Original "+name+" cold indexed height")
		if sample==0:
			var plan: Dictionary=index.plans.get(name,{})
			if not plan.is_empty():index_bytes=plan.bounds.size()*8+var_to_bytes(plan.faces_snapshot).size()+var_to_bytes(plan.vertices_snapshot).size()
			indexed_faces=index.candidate_faces;rejected_faces=index.rejected_faces
	if production_gate:check((live_production_builds>0)==(mesh.faces.size()>=ProductionHeightIndex.MIN_FACES),"Original "+name+" timed production threshold engages exactly")
	return {"name":name,"faces":mesh.faces.size(),"walkable_faces":walkable,"cold_tile_us":[cold[0],cold[1]],"serialized_tile_bytes":[bytes[0],bytes[1]],"height_index_cold_us":stats_for(index_cold),"height_index_metadata_bytes":index_bytes,"height_index_first_sample_candidates":indexed_faces,"height_index_first_sample_rejected":rejected_faces,"production_index_builds":live_production_builds,"walkable_interval_evaluations_control":base_terms,"walkable_interval_evaluations_candidate":candidate_terms,"walkable_interval_evaluations_avoided":base_terms-candidate_terms,"interval_count_available":mesh.faces.size()>=64,"blocks":blocks}

func run()->void:
	var options: Dictionary={}
	for argument in OS.get_cmdline_user_args():
		var split:=argument.trim_prefix("--").split("=",true,1)
		if split.size()==2:options[split[0]]=split[1]
	if not options.has("fixture") or not options.has("report"):quit(2);return
	var fixture: Variant=JSON.parse_string(FileAccess.get_file_as_string(str(options.fixture)))
	check(fixture is Dictionary and fixture.get("sources") is Array and fixture.get("table_sha256") is String,"Pinned original WOK census report")
	if not failures.is_empty():quit(2);return
	var catalog:=Catalog.new();var install:=str(options.get("install",ProjectSettings.globalize_path("res://../../FullDecomp/NwnRootInstall")))
	check(catalog.mount_install(install),"Original install mounts read-only")
	if not failures.is_empty():quit(2);return
	var table_bytes: PackedByteArray=catalog.get_resource("surfacemat",2017)
	var parser:=Table.new();var table: Dictionary=parser.parse(Binary.new(table_bytes).text(0,table_bytes.size()))
	check(not table_bytes.is_empty() and parser.failure.is_empty() and digest(table_bytes)==str(fixture.table_sha256),"Exact original surfacemat bytes")
	if not failures.is_empty():quit(2);return
	var sources: Array=[];var meshes: Dictionary={}
	for sample in fixture.sources:
		var name:=str(sample.name);var source_bytes: PackedByteArray=catalog.get_resource(name,2016)
		var decoder:=TileSurface.new();var mesh: Dictionary=decoder.parse_bytes(source_bytes)
		check(not source_bytes.is_empty() and decoder.failure.is_empty() and digest(source_bytes)==str(sample.sha256) and mesh.faces.size()==int(sample.faces),"Pinned original WOK "+name)
		if mesh.is_empty():continue
		var walkable:=0
		for material in mesh.materials:
			if TileSurface.walkable(table,int(material)):walkable+=1
		sources.append({"name":name,"faces":mesh.faces.size(),"walkable_faces":walkable,"sha256":digest(source_bytes)})
		meshes[name]=mesh
	check(sources.size()==fixture.sources.size(),"Full 74-source original WOK census")
	if not failures.is_empty():quit(2);return
	var ranked:=sources.duplicate();ranked.sort_custom(func(a: Dictionary,b: Dictionary)->bool:return int(a.faces)>int(b.faces) if int(a.faces)!=int(b.faces) else str(a.name)<str(b.name))
	var selected: Array=[]
	for i in [0,1,2,3,34,35,36,37]:selected.append(ranked[i])
	var pair:=make_pair();var cases: Array=[];var samples:=int(options.get("samples",16))
	check(samples>=8 and samples<=32,"Bounded original path samples")
	for sample in selected:cases.append(measure_asset(pair,str(sample.name),meshes[str(sample.name)],table,samples))
	for setup in pair:setup.world.free()
	await process_frame;await process_frame
	var report:={"success":failures.is_empty(),"checks":checks,"failures":failures,"fixture_sha256":FileAccess.get_sha256(str(options.fixture)),"table_sha256":digest(table_bytes),"sources":sources,"selected":cases,"order":"A-B-B-A per original WOK","scope":gate_scope()}
	var file:=FileAccess.open(str(options.report),FileAccess.WRITE);file.store_string(JSON.stringify(report,"  "));file.close()
	print(JSON.stringify({"success":report.success,"checks":checks,"failures":failures,"selected":cases.map(func(row):return {"name":row.name,"faces":row.faces})}));quit(0 if failures.is_empty() else 1)
