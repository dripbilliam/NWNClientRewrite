extends "res://tests/nwn63_floor_coverage_test.gd"
# Current accepted indexed owner versus a private walkable-face AABB candidate.
# Inherits crossing, edge, degenerate, elevation, blocker and path transcripts.
const Candidate=preload("res://.cache/nwn63/single-preview-broadphase-a/drive_collision_indexed.gd")

func pair()->Array:
	var result: Array=[]
	for candidate in [false,true]:
		var setup:=make_world(false);var world=setup.world
		var collision=Candidate.new() if candidate else Collision.new()
		world.add_child(collision);collision.world=world;collision.tables=tables();world.drive_collision=collision;collision.ensure_spatial_scope();collision.set_process(false)
		world.receive([creature(1,Vector2(1,1))],1)
		result.append(setup.merged({"collision":collision},true))
	return result

func face(a: Vector3,b: Vector3,c: Vector3,walk: bool=true)->Dictionary:
	var value: Dictionary=Candidate.triangle(a,b,c);value.walk=walk;return value

func actual_counts()->void:
	# The inherited route check names this step after its old profiler counter.
	# Keep this private parity gate count-only while another engine build runs.
	var worlds:=pair();var current=worlds[0].collision;var candidate=worlds[1].collision
	var geometry:=floor_faces(256);current.tiles[0]=geometry;candidate.tiles[0]=geometry
	var a:=Vector3(1,1,0);var b:=Vector3(3,1,0)
	check(current.query_preview(1,a,b,a).call(a,b)==candidate.query_preview(1,a,b,a).call(a,b),"512-face direct clear agrees")
	for setup in worlds:setup.world.free()
