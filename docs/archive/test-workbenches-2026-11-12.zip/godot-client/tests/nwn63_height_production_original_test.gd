extends "res://tests/nwn63_height_original_correctness_test.gd"
# Production source OFF/ON on the same 74-WOK corpus, no component timing.

func gate_scope()->String:
	return "Correctness only: production collision source flag OFF/ON, 74 SHA-pinned original WOK decodes, eight authored blocked 38-probe transcripts, four-rotation height parity, degenerate source and lifetime fallback. Decoded original face count selects the 90-face gate. No component or FPS timing."

func make_pair()->Array:
	var pair: Array=[]
	for enabled in [false,true]:
		var setup:=make_world(false);var collision=Collision.new()
		setup.world.add_child(collision);collision.world=setup.world;collision.tables=tables();setup.world.drive_collision=collision;collision.ensure_spatial_scope();collision.set_process(false)
		collision._preview_height_index_enabled=enabled
		var rows: Array=[creature(1,Vector2(1,1)),creature(4,Vector2(6,3)),object(2,Vector2(4,1)),object(3,Vector2(9,1),10)]
		collision.publish_model("chest:placeable",{"states":[footprint()]})
		collision.publish_model("gate:door",{"states":[footprint(),{"vertices":[],"faces":[]},footprint(2)]})
		for i in 340:
			var key:="cohort_"+str(i);var appearance: int=collision.tables.placeables.orderedRows.size()
			collision.tables.placeables.orderedRows.append({"ModelName":key})
			if i%17!=0:collision.publish_model(key+":placeable",{"states":[footprint(1+i%4)]})
			rows.append(object(100+i,Vector2(24+(i%12)*8,24+(i/12)*8),9,1,appearance))
		for extra in 549:
			var cohort:=extra%340
			var anchor:=Vector2(24+(cohort%12)*8,24+(cohort/12)*8)
			rows.append(object(1000+extra,anchor+Vector2(float(extra%3)*0.4,float(extra%5)*0.4),9,1,2+cohort))
		setup.world.receive(rows,1);setup.collision=collision;pair.append(setup)
		check(collision.static_groups.size()==342 and int(collision.snapshot().static_entries)==891,"Same 342-group/891-entry production publication")
	return pair

func measure_asset(pair: Array,name: String,mesh: Dictionary,table: Dictionary,samples: int)->Dictionary:
	var before: int=ProductionHeightIndex.total_builds
	var row: Dictionary=super.measure_asset(pair,name,mesh,table,samples)
	var built: int=ProductionHeightIndex.total_builds-before
	check((built>0)==(mesh.faces.size()>=ProductionHeightIndex.MIN_FACES),"Original "+name+" production face threshold engages exactly")
	row["production_index_builds"]=built
	return row
