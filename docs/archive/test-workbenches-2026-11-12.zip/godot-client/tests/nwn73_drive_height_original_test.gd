extends SceneTree
# Bounded read-only original-WOK parity and path census for the optional plan.
const Collision=preload("res://systems/native_render/drive_collision_indexed.gd")
const Terrain=preload("res://systems/native_render/terrain_surface.gd")
const Surface=preload("res://systems/native_data/tile_surface.gd")
const Table=preload("res://systems/native_data/two_da.gd")
const Binary=preload("res://systems/native_data/binary_data.gd")
const Catalog=preload("res://systems/native_data/resource_catalog.gd")
var checks:=0
var failures: Array=[]
func _initialize() -> void:call_deferred("run")
func check(ok: bool,label: String) -> void:
	checks+=1
	if not ok and failures.size()<30:failures.append(label)
func digest(bytes: PackedByteArray) -> String:
	var hash:=HashingContext.new();hash.start(HashingContext.HASH_SHA256);hash.update(bytes);return hash.finish().hex_encode()
func run() -> void:
	var args: Dictionary={}
	for arg in OS.get_cmdline_user_args():
		var pair:=arg.trim_prefix("--").split("=",true,1)
		if pair.size()==2:args[pair[0]]=pair[1]
	if not args.has("fixture") or not args.has("report") or FileAccess.file_exists(str(args.report)):quit(2);return
	var fixture: Variant=JSON.parse_string(FileAccess.get_file_as_string(str(args.fixture)))
	check(fixture is Dictionary and fixture.get("samples") is Array and fixture.get("install") is String,"original WOK descriptor")
	if not failures.is_empty():quit(2);return
	var catalog:=Catalog.new();check(catalog.mount_install(str(fixture.install)),"original resource install mounts read-only")
	if not failures.is_empty():quit(2);return
	var table_bytes: PackedByteArray=catalog.get_resource("surfacemat",2017)
	var parser:=Table.new();var table: Dictionary=parser.parse(Binary.new(table_bytes).text(0,table_bytes.size()))
	check(not table_bytes.is_empty() and parser.failure.is_empty() and digest(table_bytes)==str(fixture.tableSha256),"original surfacemat bytes and table parse")
	if not failures.is_empty():quit(2);return
	var meshes: Dictionary={};var sources: Array=[];var tiles: Array=[]
	for sample in fixture.samples:
		var name:=str(sample.name);var bytes: PackedByteArray=catalog.get_resource(name,2016)
		var decoder:=Surface.new();var mesh: Dictionary=decoder.parse_bytes(bytes)
		check(not bytes.is_empty() and decoder.failure.is_empty() and digest(bytes)==str(sample.sha256),"pinned original WOK "+name)
		if mesh.is_empty():continue
		sources.append({"name":name,"sha256":digest(bytes),"faces":mesh.faces.size(),"materials":mesh.materials.size()})
		if tiles.size()<8:
			meshes[name]=mesh
			var i:=tiles.size();tiles.append({"model":name,"orientation":i%4,"position":Vector3(i*10+5,0,0)})
	check(meshes.size()==8 and sources.size()==fixture.samples.size() and catalog.failure.is_empty(),"full original WOK census and eight parity models available")
	if not failures.is_empty():quit(2);return
	var surface:=Terrain.new();root.add_child(surface)
	surface.done=true;surface.table=table;surface.definition={"width":8,"height":1,"tiles":tiles};surface.meshes=meshes
	var collision:=Collision.new();root.add_child(collision)
	collision._prepare_height_plan(surface)
	var enabled:=OS.get_cmdline_user_args().has("--drive-height-plan=worker")
	if enabled:
		var deadline:=Time.get_ticks_msec()+1500
		while collision._height_plan.is_empty() and Time.get_ticks_msec()<deadline:
			await process_frame;collision._prepare_height_plan(surface)
		check(not collision._height_plan.is_empty(),"bounded worker publishes original WOK order plan")
	var answers: Array=[];var points: Array=[]
	for i in tiles.size():
		var xbase:=float(i*10)
		for local in [Vector2(0,0),Vector2(0,5),Vector2(5,0),Vector2(5,5),Vector2(9.9999,9.9999),Vector2(9.5,5.0),Vector2(0.001,0.001),Vector2(5.0,9.5),Vector2(10.0,5.0)]:
			var point:=Vector3(xbase+local.x,local.y,0)
			points.append(point)
			var original: float=surface.height(point,7.0)
			var planned: float=collision._drive_height(surface,point,7.0)
			check(original==planned,"exact original WOK height, tile "+str(i)+" at "+str(local))
			answers.append(planned)
	var timing: Array=[]
	for route: String in ["original","planned","planned","original"]:
		var began:=Time.get_ticks_usec();var checksum:=0.0
		for repeat in 10:
			for point: Vector3 in points:
				checksum+=surface.height(point,7.0) if route=="original" else collision._drive_height(surface,point,7.0)
		timing.append({"route":route,"ms":(Time.get_ticks_usec()-began)/1000.0,"checksum":checksum,"calls":points.size()*10})
	check(timing.all(func(row):return row.checksum==timing[0].checksum),"warmed original-WOK component paths preserve exact aggregate heights")
	var plan: Dictionary=collision._height_plan_stats.duplicate()
	collision.close();surface.close();collision.free();surface.free()
	var file:=FileAccess.open(str(args.report),FileAccess.WRITE)
	if file==null:quit(3);return
	file.store_string(JSON.stringify({"success":failures.is_empty(),"checks":checks,"failures":failures,"enabled":enabled,"sources":sources,"table_sha256":digest(table_bytes),"answers":answers,"timing":timing,"plan":plan,"scope":"Read-only original install census of all pinned WOKs and exact height parity at all quarter-turns and tile boundaries for eight models; short warmed component timing only, no FPS or server simulation."},"  "));file.close()
	quit(0 if failures.is_empty() else 1)
