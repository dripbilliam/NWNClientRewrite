extends "res://tests/nwn63_interval_edges_groups_benchmark.gd"
# ABBA CPU component timing at 342 groups/891 entries; no frame/FPS sampling.
func run()->void:
	var options: Dictionary={}
	for argument in OS.get_cmdline_user_args():
		var split:=argument.trim_prefix("--").split("=",true,1)
		if split.size()==2:options[split[0]]=split[1]
	var samples:=int(options.get("samples",96));check(samples>=32 and samples<=256,"Bounded explicit samples")
	var pair:=group_pair(340)
	var additions: Array=[]
	for extra in 549:
		var cohort:=extra%340
		var anchor:=Vector2(24+(cohort%12)*8,24+(cohort/12)*8)
		additions.append(object(1000+extra,anchor+Vector2(float(extra%3)*0.4,float(extra%5)*0.4),9,1,2+cohort))
	for setup in pair:
		setup.world.receive_delta(additions,[],1)
		check(int(setup.collision.snapshot().static_entries)==891,"Captured-density 342 groups/891 entries")
	var cases: Array=[]
	for spec in [
		["far_static","static_candidates",Vector3(1,7,0),Vector3(4,7,0)],
		["near_static","static_candidates",Vector3(24,24,0),Vector3(30,30,0)],
		["many_static","static_candidates",Vector3(24,24,0),Vector3(112,112,0)],
		["blocked_preview","preview",Vector3(2,1.5,0),Vector3(6,1.5,0)],
		["door_preview","preview",Vector3(8,1.5,0),Vector3(11,1.5,0)],
	]:
		var result: Dictionary=measure_groups(pair,samples,spec[1],spec[2],spec[3]);result.label=spec[0];cases.append(result)
	for setup in pair:setup.world.free()
	await process_frame;await process_frame
	var report:={"success":failures.is_empty(),"checks":checks,"failures":failures,"cases":cases,"order":"A-B-B-A","scope":"Exact before/current bounded ≤8-member flat group route at 342 model groups/891 static entries, same Core E process, identical query/path/probe results; no FPS or Arelith claim."}
	var file:=FileAccess.open(str(options.report),FileAccess.WRITE);file.store_string(JSON.stringify(report,"  "));file.close()
	print(JSON.stringify({"success":report.success,"checks":checks,"failures":failures,"cases":cases}));quit(0 if failures.is_empty() else 1)
