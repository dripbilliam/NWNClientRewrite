extends SceneTree
# One real recorded-catalog mount per process. This is a component and exit
# gate, not a gameplay loading or FPS benchmark.
const Recorded=preload("res://systems/native_data/recorded_catalog.gd")
func _initialize() -> void:call_deferred("run")
func run() -> void:
	var output:="";var directory:=""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.substr(9)
		elif arg.begins_with("--catalog="):directory=arg.substr(10)
	if output.is_empty() or directory.is_empty() or FileAccess.file_exists(output):quit(2);return
	var selected:=OS.get_cmdline_user_args().has("--recorded-catalog-overlap=packed")
	var catalog:=Recorded.new()
	var began:=Time.get_ticks_usec()
	var accepted:=catalog.mount(directory)
	var mount_us:=Time.get_ticks_usec()-began
	var payload_checks:=0;var payload_failures: Array=[]
	if accepted:
		for key in catalog.manifest.resources:
			var row: Dictionary=catalog.manifest.resources[key]
			if row.has("error") or not row.has("sha256") or int(row.get("bytes",0))>1024*1024:continue
			var pair:=str(key).rsplit(":",true,1)
			if pair.size()!=2:continue
			var actual: PackedByteArray=catalog.get_resource(pair[0],int(pair[1]))
			var packed: PackedByteArray=catalog.packed_catalog.get_resource(pair[0],int(pair[1]))
			payload_checks+=1
			if not catalog.failure.is_empty() or not catalog.packed_catalog.failure.is_empty() or actual!=packed or actual.size()!=int(row.bytes):payload_failures.append(key)
			if payload_checks>=3:break
	var bindings: int=catalog.packed_catalog.resolved.size() if accepted else 0
	var availability: int=catalog.manifest.availability.size() if accepted else 0
	var success: bool=accepted and bindings==availability and payload_checks==3 and payload_failures.is_empty() and catalog.cache_source_scope_v1()!=null and (not selected or bool(catalog.stats.get("overlap_thread_started",false)))
	var report:={"success":success,"selected":selected,"mount_ms":mount_us/1000.0,"availability":availability,"bindings":bindings,"payload_checks":payload_checks,"payload_failures":payload_failures,"failure":catalog.failure,"overlap":catalog.stats.duplicate(),"memory_static_bytes":Performance.get_monitor(Performance.MEMORY_STATIC),"scope":"One original-size recorded catalog mount, bindings and three payloads; process exit observed separately. Timings under user-game load are preliminary, not normal-client loading/FPS."}
	var file:=FileAccess.open(output,FileAccess.WRITE)
	if file==null:quit(3);return
	file.store_string(JSON.stringify(report,"  ")+"\n");file.close()
	quit(0 if success else 1)
