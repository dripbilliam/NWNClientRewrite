extends "res://tests/nwn63_model_groups_test.gd"
# Uninstrumented Core E component timing; no frame/FPS measurements.
func sample_stats(samples: Array)->Dictionary:
	var values:=samples.duplicate();values.sort();var total:=0.0
	for sample in values:total+=float(sample)
	return {"count":values.size(),"mean_us":total/values.size(),"median_us":values[values.size()/2],"p95_us":values[mini(values.size()-1,ceili(values.size()*0.95)-1)],"p99_us":values[mini(values.size()-1,ceili(values.size()*0.99)-1)],"max_us":values[-1]}
func measure_groups(pair: Array,samples: int,mode: String,a: Vector3,b: Vector3)->Dictionary:
	var result:={"mode":mode,"groups":pair[1].collision.static_groups.size(),"blocks":[]};var reference: PackedByteArray
	for index in [0,1,1,0]:
		var collision=pair[index].collision
		for warm in 24:
			if mode=="static_candidates":collision.static_candidates(a,b,0.3,1)
			else:Plan.path(a,b,a,collision.query_preview(1,a,b,a))
		var counts_before: Dictionary=collision.preview_stats.duplicate();var times: Array=[];var digest:=0
		for i in samples:
			var began:=Time.get_ticks_usec()
			var output: Dictionary=collision.static_candidates(a,b,0.3,1) if mode=="static_candidates" else Plan.path(a,b,a,collision.query_preview(1,a,b,a))
			times.append(Time.get_ticks_usec()-began)
			var bytes:=var_to_bytes(output)
			if reference.is_empty():reference=bytes
			check(bytes==reference,mode+": exact sampled result")
			digest=digest^hash(bytes)
		var counts: Dictionary={}
		for key in collision.preview_stats:counts[key]=int(collision.preview_stats[key])-int(counts_before[key])
		result.blocks.append({"owner":"before" if index==0 else "after","timing":sample_stats(times),"counts":counts,"digest":digest})
	for block in result.blocks:check(block.counts==result.blocks[0].counts,mode+": identical probes/collections")
	return result
func run()->void:
	var options: Dictionary={}
	for argument in OS.get_cmdline_user_args():
		var split:=argument.trim_prefix("--").split("=",true,1)
		if split.size()==2:options[split[0]]=split[1]
	var samples:=int(options.get("samples",96));check(samples>=32 and samples<=256,"Explicit bounded samples")
	var pair:=group_pair(340);var cold: Array=[]
	# Cold first query is reported separately; it is never substituted for warm
	# normal movement. Construction, cache proofs and shape preparation are live.
	for setup in pair:
		var began:=Time.get_ticks_usec();var output: Dictionary=setup.collision.static_candidates(Vector3(1,7,0),Vector3(4,7,0),0.3,1)
		cold.append({"time_us":Time.get_ticks_usec()-began,"result":output})
	check(cold[0].result==cold[1].result,"Cold preparation preserves candidates")
	var cases: Array=[]
	for spec in [["static_candidates",Vector3(1,7,0),Vector3(4,7,0)],["free_preview",Vector3(1,7,0),Vector3(4,7,0)],["blocked_preview",Vector3(2,1.5,0),Vector3(6,1.5,0)],["door_preview",Vector3(8,1.5,0),Vector3(11,1.5,0)]]:
		cases.append(measure_groups(pair,samples,spec[0],spec[1],spec[2]))
	var prepared_count:=0
	for group in pair[1].collision.static_groups.values():
		if group.has("query_preparation"):prepared_count+=1
	for setup in pair:setup.world.free()
	await process_frame;await process_frame
	var result:={"success":failures.is_empty(),"checks":checks,"failures":failures,"cases":cases,"prepared_groups":prepared_count,"cold_query_us":[cold[0].time_us,cold[1].time_us],"order":"A-B-B-A per case","scope":"Core E actual pre-change/current indexed static_candidates plus unchanged query_preview/Plan.path CPU,342 authored active model groups matching last captured group count. Original results/probe counts; data construction outside measured calls. No original-asset movement replay, frame/FPS or loading-latency claim."}
	var file:=FileAccess.open(str(options.report),FileAccess.WRITE);file.store_string(JSON.stringify(result,"  "));file.close()
	print(JSON.stringify({"success":result.success,"checks":checks,"failures":failures,"prepared_groups":prepared_count,"cases":cases}));quit(0 if failures.is_empty() else 1)
