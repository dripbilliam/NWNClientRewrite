extends "res://tests/nwn65_active_cost_breakdown_test.gd"
# Bounded headless component comparison only. No GPU/FPS inference.

func _sparse_sample(kind: String) -> Dictionary:
	var rows: Array=[]
	for index in 32:
		var row: Dictionary=Fixture.fixture(self,Rigs,false)
		row.entry.animated_models=[0,1]
		row.rigs.use_native_skin_publisher=kind=="native"
		row.rigs.use_identity_skin_setter=kind=="identity"
		row.rigs.use_skip_identity_skin_setter=kind=="skip"
		var skeleton:=Skeleton3D.new()
		row.host.add_child(skeleton)
		for bone in 65:skeleton.add_bone("bone_%d" % bone)
		var bones: Array[int]=[]
		for bone in 65:bones.append(bone if bone<3 else -1)
		row.entry.skins.append({"part":0,"bones":bones,"skeleton":skeleton})
		rows.append(row)
	var samples: Array[int]=[]
	for frame in 100:
		var began:=Time.get_ticks_usec()
		for row in rows:row.rigs._update(1.0/60.0)
		if frame>=20:samples.append(Time.get_ticks_usec()-began)
	samples.sort()
	var active_players:=0
	var native_completed:=0
	for row in rows:
		for model_index in [0,1]:
			if row.entry.models[model_index].player.is_playing():active_players+=1
		if kind=="native":native_completed+=int(row.rigs.native_skin_snapshot(1).get("completed",0))
	for row in rows:Fixture.dispose(row)
	return {"kind":kind,"owners":32,"players":active_players,"native_completed":native_completed,"median_us":samples[samples.size()/2],"p95_us":samples[int(ceil(samples.size()*0.95))-1],"max_us":samples[-1]}

func run() -> void:
	if output.is_empty() or FileAccess.file_exists(output):quit(2);return
	var legs: Array=[]
	for kind in ["native","scalar","identity","skip","skip","identity","scalar","native"]:
		var result:=_sparse_sample(kind)
		if result.players!=64 or kind=="native" and result.native_completed!=3200:failures.append("unexpected active/native count "+kind)
		legs.append(result)
	var report:={"ticket":"NWN-65","passed":failures.is_empty(),"failures":failures,"rig_sha256":FileAccess.get_sha256("res://systems/model_rigs.gd"),"legs":legs,"scope":"Headless ModelRigs._update component timing, 32 owners and 64 active AnimationPlayers, one synthetic 65-slot/3-active skin each, 80 sampled frames per leg. No GPU, FPS, live scene or original-asset inference."}
	var file:=FileAccess.open(output,FileAccess.WRITE)
	file.store_string(JSON.stringify(report,"\t"));file.close()
	quit(0 if failures.is_empty() else 1)
