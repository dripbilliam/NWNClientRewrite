extends "res://tests/nwn63_walkable_aabb_original_wok_test.gd"
# One instrumented path per original WOK after the existing exact ABBA gate.
# Phases are nested, overlapping wall spans and include profiler overhead.

func measure_asset(pair: Array,name: String,mesh: Dictionary,table: Dictionary,samples: int)->Dictionary:
	var row: Dictionary=super.measure_asset(pair,name,mesh,table,samples)
	var from:=Vector3(1,1,0);var target:=Vector3(3,1,0)
	var control=pair[0].collision
	var one: Dictionary=profile_path(control,"preview",from,target,true)
	check(one.transcript.size()==38,"Instrumented original "+name+" uses 38 probes")
	row["instrumented_control_phases"]=one.phases
	row["instrumented_control_counts"]=one.counts
	return row
