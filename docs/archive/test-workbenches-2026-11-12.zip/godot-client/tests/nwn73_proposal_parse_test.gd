extends SceneTree
const ProposedWorld=preload("res://.cache/nwn73/preview-worker-a/live_world-proposal.gd")
const ProposedEntry=preload("res://.cache/nwn73/preview-worker-a/native_live_world-proposal.gd")
func _initialize()->void:
	print(JSON.stringify({"success":ProposedWorld!=null and ProposedEntry!=null,"scope":"Parse only; no client or world launch"}))
	quit(0 if ProposedWorld!=null and ProposedEntry!=null else 1)
