extends "res://tests/nwn70_worker_parity_test.gd"
# Component throughput only. Coordinator supplies a quiet native timing lease.
var cycles:=6
var warm_jobs:=16
func percentile(values: Array,fraction: float) -> int:
	var ordered:=values.duplicate();ordered.sort();return int(ordered[mini(ordered.size()-1,maxi(0,int(ceil(ordered.size()*fraction))-1))]) if not ordered.is_empty() else 0
func summary(values: Array) -> Dictionary:
	var total:=0.0
	for value in values:total+=float(value)
	return {"samples":values.size(),"median_us":percentile(values,0.5),"p95_us":percentile(values,0.95),"p99_us":percentile(values,0.99),"mean_us":total/maxi(1,values.size())}
func batch(service,jobs: int) -> Dictionary:
	var delivered: Array=[]
	var callback: Callable=func(_id: int,result: Dictionary):
		# Match an ordinary bounded publication subscriber; decoded graphs are
		# not retained by this counter after the actual completed callback.
		delivered.append({"name":result.get("resource_name"),"error":result.get("error","missing"),"sha256":result.get("sha256",""),"worker_us":roundi(float(result.get("worker_ms",0))*1000),"memory_hit":result.get("memory_cache_hit",false)})
	service.completed.connect(callback)
	var before_calls:=int(service.completion_stats.delivered)
	var before_passes:=int(service.completion_stats.passes)
	var began:=Time.get_ticks_usec()
	for index in jobs:
		var sample: Dictionary=samples[index%samples.size()]
		check(service.request(str(sample.name),int(sample.type),str(sample.decoder))>0,"Actual bounded asset queue accepts throughput request")
	var deadline:=Time.get_ticks_msec()+30000
	while delivered.size()<jobs and Time.get_ticks_msec()<deadline:await process_frame
	var wall:=Time.get_ticks_usec()-began
	service.completed.disconnect(callback)
	check(delivered.size()==jobs and delivered.all(func(row):return str(row.error).is_empty() and str(row.sha256).length()==64),"All actual queued workers deliver verified original data")
	var worker: Array=delivered.map(func(row):return int(row.worker_us))
	return {"wall_us":wall,"worker_us":worker,"delivered":delivered.size(),"memory_hits":delivered.filter(func(row):return row.memory_hit).size(),"completion_calls":int(service.completion_stats.delivered)-before_calls,"completion_passes":int(service.completion_stats.passes)-before_passes,"max_pass_us":int(service.completion_stats.max_pass_us),"max_callback_us":int(service.completion_stats.max_callback_us)}
func measure(reference: bool) -> Dictionary:
	var cold_wall: Array=[];var warm_wall: Array=[];var cold_worker: Array=[];var warm_worker: Array=[]
	var pass_tails: Array=[];var callback_tails: Array=[];var records: Array=[]
	for cycle in cycles:
		var f:=fixture(reference);var service=f.service
		service.maximum_workers=4;service.maximum_pending=64;service.configure(f.catalog)
		var cold=await batch(service,4)
		var warm=await batch(service,warm_jobs)
		cold_wall.append(cold.wall_us);warm_wall.append(warm.wall_us);cold_worker.append_array(cold.worker_us);warm_worker.append_array(warm.worker_us)
		pass_tails.append(warm.max_pass_us);callback_tails.append(warm.max_callback_us)
		records.append({"cold":cold,"warm":warm})
		dispose(f);await process_frame
	return {"reference":reference,"cycles":cycles,"cold_queue_wall":summary(cold_wall),"memory_warm_queue_wall":summary(warm_wall),"cold_workers":summary(cold_worker),"memory_warm_workers":summary(warm_worker),"publication_pass_tails":summary(pass_tails),"publication_callback_tails":summary(callback_tails),"records":records}
func run() -> void:
	if not options.has_all(["report","install"]) or FileAccess.file_exists(options.report):quit(2);return
	cycles=int(options.get("cycles",6));warm_jobs=int(options.get("warm-jobs",16))
	if cycles<2 or cycles>12 or warm_jobs<4 or warm_jobs>64:quit(2);return
	check(OS.get_cmdline_user_args().has("--prepared-cache-write=disabled"),"Both throughput sides use identical explicitly disabled optional disk-write policy")
	var service_source:=FileAccess.get_sha256("res://systems/native_data/asset_service.gd");var prework_source:=FileAccess.get_sha256("res://systems/native_data/prework_store.gd")
	initialize_fixture()
	var a=await measure(true);var b=await measure(false);var c=await measure(false);var d=await measure(true)
	cleanup();await process_frame;await process_frame
	check(FileAccess.get_sha256("res://systems/native_data/asset_service.gd")==service_source and FileAccess.get_sha256("res://systems/native_data/prework_store.gd")==prework_source,"Actual source inputs stay unchanged for the matched throughput window")
	var out:={"success":failures.is_empty(),"checks":checks,"failures":failures,"order":"A-B-B-A","reference":[a,d],"optimized":[b,c],"cohort":samples,"source_sha256":FileAccess.get_sha256("res://systems/native_data/asset_service.gd"),"prework_sha256":FileAccess.get_sha256("res://systems/native_data/prework_store.gd"),"completion_policy":{"maximum_workers":4,"maximum_pending":64,"budget_us":1500,"maximum_per_pass":8},"scope":"Actual uninstrumented AssetService request/worker/completion pipeline with installed originals, independent catalog/prepared/decoded memory tiers each cycle, four-source cold cohort and memory-warm repeated cohort. OS file cache is warm; optional disk writes disabled identically. Completion drain/callback tails are observed, but no actual mesh/GUI scene publication, renderer/FPS, Arelith or cold-OS-disk loading acceptance."}
	var file:=FileAccess.open(options.report,FileAccess.WRITE);file.store_string(JSON.stringify(out,"\t"));file.close()
	print("NWN70_THROUGHPUT ",JSON.stringify({"success":out.success,"checks":checks,"reference":[a.cold_workers,a.memory_warm_workers,d.cold_workers,d.memory_warm_workers],"optimized":[b.cold_workers,b.memory_warm_workers,c.cold_workers,c.memory_warm_workers]}));quit(0 if out.success else 1)
