extends "res://tests/nwn63_support_world_part_box_test.gd"

func run() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="): output = arg.substr(9)
	if output.is_empty() or FileAccess.file_exists(output):
		quit(2)
		return
	var model := Fixtures.ModelStub.new()
	root.add_child(model)
	model.position.y = 11.0
	model.set_meta("native_scene_bounds", AABB(Vector3(-1, -2, -11), Vector3(113, 4, 22)))
	var data := Geometry.new()
	data.configure({"vertices": PackedFloat32Array([0,0,0,10,0,0,10,10,0,0,10,0]),
		"indices": PackedInt32Array([0,1,2,0,2,3]), "native_surface_types": PackedInt32Array([30,30])})
	part(model, data, facts())
	var second := part(model, data, facts())
	second.position.x = 0.25
	var distant := part(model, data, facts())
	distant.position.x = 100.0
	var start := Query.native(Vector3(5, 31, -5))
	var end := Query.native(Vector3(5, -9, -5))
	var trace := Trace.new()
	var hits := 0
	var samples: Array[int] = []
	for block in 5:
		var begun := Time.get_ticks_usec()
		for index in 5000:
			var result: Dictionary = trace.model_hit(model, start, end)
			if result.available and result.hit and absf(result.position[2] - 11.0) < 0.0001:
				hits += 1
		if block > 0: samples.append(Time.get_ticks_usec() - begun)
	samples.sort()
	var passed := hits == 25000
	var file := FileAccess.open(output, FileAccess.WRITE)
	file.store_string(JSON.stringify({"ticket": "NWN-63", "passed": passed,
		"enabled": OS.get_cmdline_user_args().has("--client-support-world-part-box"),
		"hits": hits, "rays": 25000, "median_5000_us": samples[1], "samples_us": samples,
		"stats": trace.snapshot(), "scope": "Headless direct model_hit cost; three ordinary Parts, one distant."}, "  "))
	file.close()
	model.free()
	quit(0 if passed else 1)
