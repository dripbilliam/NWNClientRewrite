extends "res://tests/nwn63_single_preview_breakdown_test.gd"
const Worker=preload("res://systems/native_render/drive_preview_worker.gd")
var cases: Array=[]

func ordinary_path(collision,from: Vector3,target: Vector3)->Dictionary:
	var transcript: Array=[]
	var clear: Callable=collision.query_preview(1,from,target,from)
	var recording:=func(a: Vector3,b: Vector3):
		var accepted: bool=clear.call(a,b)
		transcript.append([a,b,accepted,str(collision.stats.get("last_blocked",{}).get("reason","")) if not accepted else ""])
		return accepted
	return {"path":Plan.path(from,target,from,recording),"probes":transcript}

func compare_density(collision,world,density: int,threaded: bool)->void:
	if density>2:grid_mesh(world,24)
	collision.tiles.clear()
	var geometry: Array=collision.tile(0)
	var blocker: Dictionary=Collision.triangle(Vector3(0,0,0),Vector3(5,0,0),Vector3(0,5,0))
	blocker.walk=false;geometry.append(blocker)
	var from:=Vector3(1,1,0);var target:=Vector3(3,1,0)
	var baseline:=ordinary_path(collision,from,target)
	var snapshot: Dictionary=collision.prepare_worker_preview(1,from,target,from)
	check(snapshot.has("packet"),"Density "+str(density)+" sealed worker packet")
	if not snapshot.has("packet"):return
	check(snapshot.faces==density+1,"Density "+str(density)+" copied floor and blocker faces")
	var worker:=Worker.new();worker.packet=snapshot.packet
	var result: Dictionary={}
	if threaded:
		var job:=Thread.new();var error:=job.start(worker.run)
		check(error==OK,"Worker thread starts")
		if error==OK:result=job.wait_to_finish()
	else:result=worker.run()
	check(result.get("valid",false),"Density "+str(density)+" worker uses sealed data")
	check(var_to_bytes(result.get("path",{}))==var_to_bytes(baseline.path),"Density "+str(density)+" exact path/factor/fraction")
	check(result.get("probes",[])==baseline.probes,"Density "+str(density)+" exact ordered 38-probe decisions/reasons")
	check(baseline.probes.size()==38,"Density "+str(density)+" blocked 38-probe path")
	check(collision.worker_preview_current(snapshot),"Density "+str(density)+" unchanged snapshot admits")
	cases.append({"density":density,"probes":baseline.probes.size(),"tiles":snapshot.tiles,"faces":snapshot.faces,"threaded":threaded,"valid":result.get("valid",false)})

func mutation_gate(collision,world)->void:
	var from:=Vector3(1,1,0);var target:=Vector3(3,1,0)
	var snapshot: Dictionary=collision.prepare_worker_preview(1,from,target,from)
	check(snapshot.has("packet"),"Mutation packet exists")
	if snapshot.has("packet"):
		var old: float=world.surface.meshes.floor.vertices[0][0]
		world.surface.meshes.floor.vertices[0][0]=old+0.25
		check(not collision.worker_preview_current(snapshot),"In-place original WOK vertex mutation rejects stale worker result")
		world.surface.meshes.floor.vertices[0][0]=old
	var stale: Dictionary=collision.prepare_worker_preview(1,from,target,from)
	check(stale.has("packet"),"Door mutation packet exists")
	if stale.has("packet"):
		var door:=object(3,Vector2(9,1),10);door.replicated.doorOpenState=2
		world.receive_delta([door],[],1)
		check(not collision.worker_preview_current(stale),"Door state publication rejects stale worker result")
	var latest_serial:=2;var result_serial:=1
	check(result_serial!=latest_serial,"Superseded input serial is not admissible by proposed owner gate")

func special_blockers(collision,world)->void:
	var from:=Vector3(1,1,0);var target:=Vector3(3,1,0)
	var creature_row:=creature(4,Vector2(2,1));world.receive_delta([creature_row],[],1)
	var baseline:=ordinary_path(collision,from,target)
	check(not baseline.probes.is_empty() and baseline.probes[0][3]=="creature","Moving creature blocks first clearance")
	var packet: Dictionary=collision.prepare_worker_preview(1,from,target,from)
	check(packet.has("packet"),"Moving-creature worker packet")
	if packet.has("packet"):
		var worker:=Worker.new();worker.packet=packet.packet;var outcome: Dictionary=worker.run()
		check(outcome.get("valid",false) and var_to_bytes(outcome.path)==var_to_bytes(baseline.path) and outcome.probes==baseline.probes,"Moving-creature exact worker transcript")
		check(collision.worker_preview_current(packet),"Moving-creature source still current")
	world.receive_delta([creature(4,Vector2(6,3))],[],1)
	var door:=object(3,Vector2(2.5,1),10);door.replicated.doorOpenState=0;world.receive_delta([door],[],1)
	baseline=ordinary_path(collision,from,target)
	packet=collision.prepare_worker_preview(1,from,target,from)
	check(packet.has("packet") or packet.get("immediate",false),"Door worker or immediate packet")
	if packet.has("packet"):
		var worker:=Worker.new();worker.packet=packet.packet;var outcome: Dictionary=worker.run()
		check(outcome.get("valid",false) and var_to_bytes(outcome.path)==var_to_bytes(baseline.path) and outcome.probes==baseline.probes,"Closed-door exact worker transcript")
		check(collision.worker_preview_current(packet),"Closed-door source still current")
	elif packet.get("immediate",false):check(var_to_bytes(packet.path)==var_to_bytes(baseline.path),"Door immediate path exact")

func run()->void:
	var pair:=group_pair(340);var setup: Dictionary=pair[1];var collision=setup.collision
	check(collision.static_groups.size()==342,"Captured-scale model-group count")
	compare_density(collision,setup.world,2,false)
	compare_density(collision,setup.world,1152,true)
	mutation_gate(collision,setup.world)
	special_blockers(collision,setup.world)
	for owner in pair:owner.world.free()
	await process_frame;await process_frame
	var report:={"success":failures.is_empty(),"checks":checks,"failures":failures,"cases":cases,"scope":"Default-dormant NWN-73 sealed preview worker: exact blocked 38-probe paths with captured-scale model groups, 2/1152 face floors, actual Godot Thread, in-place WOK and door publication rejection. Input serial assertion is a proposed owner guard only; live-world integration and FPS are not claimed."}
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--report="):
			var file:=FileAccess.open(argument.trim_prefix("--report="),FileAccess.WRITE);file.store_string(JSON.stringify(report,"  "));file.close()
	print(JSON.stringify(report));quit(0 if failures.is_empty() else 1)
