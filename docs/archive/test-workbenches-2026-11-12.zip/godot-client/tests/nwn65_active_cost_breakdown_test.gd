extends SceneTree

const Rigs = preload("res://systems/model_rigs.gd")
const Fixture = preload("res://tests/nwn65_active_event_test.gd")

var output := ""
var failures: Array[String] = []
var sparse_skins:=false

func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):
			output = arg.trim_prefix("--report=")
	call_deferred("run")

func _sample(kind: String) -> Dictionary:
	var rows: Array = []
	for index in 32:
		var row: Dictionary = Fixture.fixture(self, Rigs, false)
		row.entry.animated_models = [0, 1]
		row.rigs.use_native_skin_publisher = kind == "skin_native"
		if kind == "animation":
			row.entry.attachments.clear()
		elif kind.begins_with("skin"):
			var skeleton := Skeleton3D.new()
			row.host.add_child(skeleton)
			for bone in 65:
				skeleton.add_bone("bone_%d" % bone)
			var bones: Array[int] = []
			for bone in 65:
				bones.append((bone if bone<3 else -1) if sparse_skins else bone%3)
			row.entry.skins.append({"part": 0, "bones": bones, "skeleton": skeleton})
		rows.append(row)
	var samples: Array[int] = []
	for frame in 100:
		var started := Time.get_ticks_usec()
		for row in rows:
			row.rigs._update(1.0 / 60.0)
		if frame >= 20:
			samples.append(Time.get_ticks_usec() - started)
	samples.sort()
	var active_players := 0
	var pose_frames := 0
	var native_completed := 0
	for row in rows:
		for model_index in [0, 1]:
			if row.entry.models[model_index].player.is_playing():
				active_players += 1
		pose_frames += int(row.rigs.stats.pose_frames)
		if kind == "skin_native":
			native_completed += int(row.rigs.native_skin_snapshot(1).get("completed", 0))
	for row in rows:
		Fixture.dispose(row)
	return {"kind": kind, "owners": 32, "players": active_players, "pose_frames": pose_frames,
		"native_completed": native_completed,
		"median_us": samples[samples.size() / 2], "p95_us": samples[int(ceil(samples.size() * 0.95)) - 1],
		"max_us": samples[-1]}

func run() -> void:
	if output.is_empty() or FileAccess.file_exists(output):
		quit(2)
		return
	var legs: Array = []
	for kind in ["animation", "attachment", "skin", "skin_native", "skin_native", "skin", "attachment", "animation"]:
		var result := _sample(kind)
		if result.players != 64 or result.pose_frames != 32 * 100:
			failures.append("unexpected active owner/player count: " + kind)
		if kind == "skin_native" and result.native_completed != 32 * 100:
			failures.append("native skin publisher did not complete each update")
		legs.append(result)
	var report := {"ticket": "NWN-65", "passed": failures.is_empty(), "failures": failures,
		"rig_sha256": FileAccess.get_sha256("res://systems/model_rigs.gd"), "legs": legs,
		"scope": "Manual headless ModelRigs._update component timings for 32 active owners and 64 authored AnimationPlayers. Synthetic attachment and 65-slot script/native skin; no live scene, GPU, FPS, or original-asset inference."}
	var file := FileAccess.open(output, FileAccess.WRITE)
	file.store_string(JSON.stringify(report, "\t"))
	file.close()
	quit(0 if failures.is_empty() else 1)
