extends "res://tests/nwn63_height_original_wok_test.gd"
# Original assets, exact 38-probe transcripts and direct height parity only.
# No timed ABBA samples in this gate.
const IndexedHeight=preload("res://.cache/nwn63/search-height-a/height_index.gd")

func gate_scope()->String:
	return "Correctness only: 74 SHA-pinned original WOK decodes and eight authored blocked 38-probe path transcripts; 2,592 exact original XY height comparisons over four rotations, original array replacement and degenerate-face fallback. No timed component or FPS claim."

func measure_asset(pair: Array,name: String,mesh: Dictionary,table: Dictionary,_samples: int)->Dictionary:
	for setup in pair:
		install_asset(setup,name,mesh,table)
		var collision=setup.collision
		var wall: Dictionary=Collision.triangle(Vector3(0,0,0),Vector3(5,0,0),Vector3(0,5,0))
		wall.walk=false;collision.tile(0).append(wall)
	var from:=Vector3(1,1,0);var target:=Vector3(3,1,0)
	var control: Dictionary=profile_path(pair[0].collision,"preview",from,target,false)
	var candidate: Dictionary=profile_path(pair[1].collision,"preview",from,target,false)
	check(var_to_bytes(candidate.path)==var_to_bytes(control.path) and candidate.transcript==control.transcript and candidate.transcript.size()==38,"Original "+name+" exact 38-probe path/transcript")
	check(int(candidate.counts.collections)==1 and int(candidate.counts.reused_clears)==37 and int(candidate.counts.fallback_clears)==0,"Original "+name+" contained search schedule")
	var surface=pair[1].world.surface;var index=IndexedHeight.new()
	check(index.configure(surface),"Original "+name+" height index configures")
	var points:=0
	for orientation in 4:
		var placed: Dictionary=surface.definition.tiles[0];placed.orientation=orientation;surface.definition.tiles[0]=placed
		for x in [0.0,0.0001,0.5,1.0,2.5,5.0,7.5,9.5,9.9999]:
			for y in [0.0,0.0001,0.5,1.0,2.5,5.0,7.5,9.5,9.9999]:
				var point:=Vector3(x,y,0)
				check(index.height(surface,point,7.0)==surface.height(point,7.0),"Original "+name+" height bits orientation "+str(orientation)+" point "+str(points))
				points+=1
	var prior_plan: Dictionary=index.plans.get(name,{})
	check(not prior_plan.is_empty() and index.built==1 and index.rejected_faces>0,"Original "+name+" prepared one reusable bounds plan")
	# Replacement arrays are treated as changed source, then sampled through the
	# unchanged TerrainSurface path. A separate degenerate mesh is checked below.
	var replaced: Dictionary=mesh.duplicate(true);surface.meshes[name]=replaced
	var previous: int=index.fallback
	check(index.height(surface,Vector3(3,3,0),7.0)==surface.height(Vector3(3,3,0),7.0) and index.fallback==previous+1,"Original "+name+" array replacement falls back")
	var degenerate: Dictionary=mesh.duplicate(true);var vertex_index: int=degenerate.vertices.size()
	degenerate.vertices.append([0.0,0.0,0.0]);degenerate.faces.insert(0,[vertex_index,vertex_index,vertex_index]);degenerate.materials.insert(0,0);degenerate.normals.insert(0,[0.0,0.0,0.0]);degenerate.constants.insert(0,0.0)
	surface.meshes[name]=degenerate
	var degenerate_index=IndexedHeight.new();check(degenerate_index.configure(surface),"Original "+name+" degenerate source configures")
	for point in [Vector3(0,0,0),Vector3(1,1,0),Vector3(9.9999,9.9999,0)]:
		check(degenerate_index.height(surface,point,7.0)==surface.height(point,7.0),"Original "+name+" degenerate leading face exact height")
	return {"name":name,"faces":mesh.faces.size(),"height_points":points,"path_probes":candidate.transcript.size(),"index_builds":index.built,"bounds_rejections":index.rejected_faces,"source_replacement_fallbacks":index.fallback,"degenerate_checks":3}
