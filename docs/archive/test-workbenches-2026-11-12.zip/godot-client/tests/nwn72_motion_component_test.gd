extends SceneTree
const Motion=preload("res://systems/network_motion.gd")
var output:=""
var fixture_path:=""
var preflight:=false
var failures: Array=[]
var checks:=0
func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.trim_prefix("--report=")
		if arg.begins_with("--fixture="):fixture_path=arg.trim_prefix("--fixture=")
		if arg=="--preflight":preflight=true
	call_deferred("run")
func check(value: bool,label: String) -> void:
	checks+=1
	if not value:failures.append(label);push_error(label)
func inputs(fixture: Dictionary,copies: int) -> Dictionary:
	var rows: Array=[];var sources: Dictionary={}
	for copy in copies:
		var offset:=int(copy)*0x100000000
		for id in fixture.sources:
			var source: Dictionary=fixture.sources[id].duplicate(true);source.id=int(id)+offset;sources[source.id]=source
		for id in fixture.motion:
			var state: Dictionary=fixture.motion[id].duplicate(true)
			var target:=int(state.get("facingTarget",0x7f000000))
			if target!=0x7f000000 and fixture.sources.has(target):state.facingTarget=target+offset
			rows.append({"id":int(id)+offset,"state":state})
	return {"rows":rows,"sources":sources,"area":int(fixture.area)}
func bind(motion,input: Dictionary) -> void:
	motion.facing_target_query=func(id):
		var source: Dictionary=input.sources.get(id,{})
		if int(source.get("areaId",-1))!=input.area or source.get("replicationRemoved",false):return null
		if motion.objects.has(id):return motion.objects[id].position
		var position: Variant=source.get("replicated",{}).get("position")
		return Motion.vector(position) if position is Array and position.size()>=3 else null
func statistics(values: Array) -> Dictionary:
	values.sort()
	return {"count":values.size(),"median_us":values[values.size()/2],"p95_us":values[mini(values.size()-1,int(ceil(values.size()*0.95))-1)],"max_us":values[-1]}
func digest(value: Variant) -> String:
	var hash:=HashingContext.new();hash.start(HashingContext.HASH_SHA256);hash.update(var_to_bytes(value));return hash.finish().hex_encode()
func leg(script,input: Dictionary,timed: bool) -> Dictionary:
	var motion=script.new();bind(motion,input)
	var samples: Array=[]
	for sample in (20 if timed else 1):
		motion.configure(input.rows)
		for frame in (32 if timed else 1):
			var began:=Time.get_ticks_usec();motion.update(0.016);var elapsed:=Time.get_ticks_usec()-began
			if timed:samples.append(elapsed)
			for id in motion.objects:motion.finish_frame(int(id))
	var result:={"state_sha256":digest(motion.objects),"rows":motion.objects.size(),"evaluation":motion.evaluation_snapshot() if motion.has_method("evaluation_snapshot") else {}}
	if timed:result.timing=statistics(samples)
	motion.facing_target_query=Callable()
	return result
func run() -> void:
	if output.is_empty() or fixture_path.is_empty() or FileAccess.file_exists(output):quit(2);return
	var original=load("res://.cache/nwn72/baseline/systems/network_motion.gd")
	var source_sha:=FileAccess.get_sha256("res://systems/network_motion.gd")
	var file:=FileAccess.open(fixture_path,FileAccess.READ);var fixture: Dictionary=file.get_var(false);file.close()
	var cases: Array=[]
	for copies in [1,16]:
		var input:=inputs(fixture,copies);var legs: Array=[]
		for mode in ["original","candidate","candidate","original"]:
			var result:=leg(original if mode=="original" else Motion,input,not preflight);result.mode=mode;legs.append(result)
		check(legs[0].rows==fixture.motion.size()*copies,"all intended captured/scaled creature rows admitted")
		for index in range(1,legs.size()):check(legs[index].state_sha256==legs[0].state_sha256,"ABBA final motion states bit-identical")
		cases.append({"copies":copies,"synthetic_scale":copies>1,"rows":input.rows.size(),"legs":legs})
	check(FileAccess.get_sha256("res://systems/network_motion.gd")==source_sha,"production motion source unchanged through execution")
	var report:={"checks":checks,"failures":failures,"passed":failures.is_empty(),"preflight":preflight,"motion_sha256":source_sha,"baseline_sha256":FileAccess.get_sha256("res://.cache/nwn72/baseline/systems/network_motion.gd"),"fixture_sha256":FileAccess.get_sha256(fixture_path),"cases":cases,"scope":"Actual Motion.update calls with captured13-creature peak-state input and explicit16x scale; finish_frame outside timed intervals. Fresh input restored every32updates. No assets, renderer, FPS or busy-live acceptance claim"}
	file=FileAccess.open(output,FileAccess.WRITE);file.store_string(JSON.stringify(report,"\t"));file.close();quit(0 if failures.is_empty() else 1)
