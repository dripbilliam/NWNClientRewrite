extends "res://tests/nwn73_asset_integration_test.gd"
class TimedPool:
	extends "res://systems/native_render/resource_pool.gd"
	var adopt_us:=0
	func accept_raster_upload_sidecar(sidecar: Dictionary) -> int:
		var began:=Time.get_ticks_usec()
		var accepted:=super.accept_raster_upload_sidecar(sidecar)
		adopt_us+=Time.get_ticks_usec()-began
		return accepted
var corpus_rows: Array=[]
func digest_bytes(bytes: PackedByteArray) -> String:
	var hash:=HashingContext.new();hash.start(HashingContext.HASH_SHA256)
	if not bytes.is_empty():hash.update(bytes)
	return hash.finish().hex_encode()
func extra_report() -> Dictionary:
	return {"corpus":corpus_rows,"corpus_scope":"Same-process diagnostic of actual AssetService requests/worker publication/completion and actual ResourcePool texture creation. Separate OFF/cold-ON/memo-ON contexts for13 pinned originals; per-leg byte/source keys, worker-only engagement, no added completion frame and full main drain/adoption/texture CPU. No matched loading/FPS claim; GPU submission timings are CPU time only."}
func diagnostic_leg(source: RefCounted,row: Dictionary,mode: String) -> Dictionary:
	var enabled:=mode!="off";ProjectSettings.set_setting("nwn/private/raster_upload_preparation",enabled)
	var pool:=TimedPool.new();var scope:=Node.new();scope.set_meta("native_publication_pool",pool);root.add_child(scope)
	var service:=Assets.new();scope.add_child(service);service.configure(source);service.set_process(false)
	var delivered: Array=[];var before:=Preparation.snapshot()
	var callback:=func(_id,result):
		var callback_began:=Time.get_ticks_usec()
		var texture_began:=Time.get_ticks_usec();var texture: Texture2D=null
		if str(result.get("error","")).is_empty() and result.get("value") is Dictionary:texture=pool.texture(result)
		var texture_us:=Time.get_ticks_usec()-texture_began
		delivered.append({"result":result,"texture":texture,"pool_texture_main_us":texture_us,"callback_thread":OS.get_thread_caller_id(),"callback_us":Time.get_ticks_usec()-callback_began})
	service.completed.connect(callback)
	var id:=service.request(str(row.name),int(row.type),"raster");service.set_process(false)
	check(id>0 and service.running.has(id),"Corpus request uses one original AssetService task")
	await wait_task(service,id)
	var frame:=Engine.get_process_frames();var began:=Time.get_ticks_usec();service._profile_process(0.0);var drain_us:=Time.get_ticks_usec()-began
	check(delivered.size()==1 and Engine.get_process_frames()==frame,"Corpus first completion drain has no extra task/poll/frame")
	var result: Dictionary={}
	if not delivered.is_empty():
		var packet: Dictionary=delivered[0];var original: Dictionary=packet.result;var texture: Texture2D=packet.texture
		check(str(original.get("error","")).is_empty() and original.get("value") is Dictionary,"Corpus actual worker succeeds before any texture consumer "+str(original.get("error","")))
		if not original.get("value") is Dictionary:
			service.close();scope.free();pool.clear()
			return {"name":row.name,"mode":mode,"error":original.get("error","Missing decoded source"),"decoded_digest":""}
		check(packet.callback_thread==OS.get_main_thread_id() and not original.has("_raster_upload_sidecar"),"Corpus completion remains main with no exposed sidecar "+str(row.name)+" "+mode)
		check(int(original.get("thread",0))!=OS.get_main_thread_id(),"Corpus original AssetService task executes off main")
		check(original.sha256==row.sha256,"Corpus original source SHA unchanged")
		check(texture!=null and texture.get_width()==int(row.width) and texture.get_height()==int(row.height),"Corpus original texture dimensions "+str(row.name))
		check(str(original.sha256) in pool.textures,"Corpus original source SHA is still the texture key")
		result={"name":row.name,"family":row.category,"width":row.width,"height":row.height,"mode":mode,"worker_ms":original.get("worker_ms",0.0),"worker_preparation":original.get("phases",{}).get("raster_upload_preparation",{}),"pool_texture_main_us":packet.pool_texture_main_us,"adoption_main_us":pool.adopt_us,"pool":pool.snapshot().raster_upload_preparation,"source_sha256":original.sha256,"decoded_digest":digest_bytes(var_to_bytes(original.value)),"callback_us":packet.callback_us,"main_completion_drain_us":drain_us}
		var eligible: bool=int(row.width)*int(row.height)>=Preparation.MIN_TRANSFORM_PIXELS
		check(int(result.pool.counts.consumed)==int(enabled and eligible),"Corpus eligibility is actually consumed or faithfully declined "+str(row.name)+" "+mode)
		if enabled:
			check(int(result.worker_preparation.get("prepared",0))==int(eligible),"Corpus worker preparation engagement matches E eligibility")
			check(int(result.worker_preparation.get("thread",0))!=OS.get_main_thread_id(),"Corpus worker Image work cannot run on main")
		else:check(Preparation.snapshot().requests==before.requests,"Corpus OFF does no sidecar/memo work")
	service.close();scope.free();pool.clear()
	return result
func run() -> void:
	var args: Dictionary={}
	for arg in OS.get_cmdline_user_args():
		var pair:=arg.trim_prefix("--").split("=",true,1)
		if pair.size()==2:args[pair[0]]=pair[1]
	if not args.has("report") or FileAccess.file_exists(args.report):quit(2);return
	check(Preparation.configured_enabled(),"Diagnostic starts from explicitly pinned private ON setting")
	Preparation.clear();var source:=LocalCatalog.new()
	var corpus: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://originals/corpus.json"))
	for row in corpus.records:
		var bytes:=FileAccess.get_file_as_bytes("res://originals/"+str(row.file));source.sources[str(row.name)+":"+str(int(row.type))]=bytes
		var modes: Array=[]
		for mode in ["off","cold","memo"]:
			var result:=await diagnostic_leg(source,row,mode);corpus_rows.append(result);modes.append(result)
		check(modes[0].decoded_digest==modes[1].decoded_digest and modes[1].decoded_digest==modes[2].decoded_digest,"Corpus decoded source bytes are exact across OFF/cold/memo "+str(row.name))
	var file:=FileAccess.open("res://original-tile.var",FileAccess.READ);var tile: Dictionary=file.get_var(false);file.close();var seen: Dictionary={}
	for name in tile.textures:
		var record: Dictionary=tile.textures[name]
		if seen.has(record.sha256):continue
		seen[record.sha256]=true
		check(not Preparation.worker_decline_reason(record).is_empty(),"Complete original DDS remains the faithful legacy upload path "+str(name))
	ProjectSettings.set_setting("nwn/private/raster_upload_preparation",true)
	await super.run()
