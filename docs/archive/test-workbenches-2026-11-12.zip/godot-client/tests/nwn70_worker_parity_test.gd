extends SceneTree
const Catalog=preload("res://systems/native_data/resource_catalog.gd")
const Store=preload("res://systems/native_data/preparation_store.gd")
const Cache=preload("res://systems/native_data/prepared_cache.gd")
const Assets=preload("res://systems/native_data/asset_service.gd")
var options: Dictionary={}
var checks:=0
var failures: Array=[]
var temp_root:=""
var control_script
var samples: Array=[{"name":"classes","type":2017,"decoder":"2da"},{"name":"c_dummy","type":2002,"decoder":"actor-model"},{"name":"pb_but_inv","type":2002,"decoder":"actor-model"},{"name":"tcn01_a01_01","type":2002,"decoder":"static-model"}]
func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		var pair:=arg.trim_prefix("--").split("=",true,1)
		if pair.size()==2:options[pair[0]]=pair[1]
	call_deferred("run")
func check(value: bool,label: String) -> void:
	checks+=1
	if not value:failures.append(label);print("FAIL ",label)
func fixture(reference: bool,installed: bool=true) -> Dictionary:
	var catalog:=Catalog.new();catalog.decoder_store=Store.new();catalog.decoder_store.maximum_bytes=256*1024*1024
	check(catalog.mount_install(str(options.install)) if installed else catalog.mount_directory(temp_root.path_join("base"),10),"Actual original/authored data catalog mounts")
	catalog.build_resource_index()
	var service=control_script.new() if reference else Assets.new();root.add_child(service);service.set_process(false)
	return {"catalog":catalog,"service":service,"serial":0}
func work(f: Dictionary,sample: Dictionary) -> Dictionary:
	f.serial+=1
	var catalog=f.catalog;var id:=int(f.serial);var store=catalog.preparation_cache()
	var job:={"id":id,"name":sample.name,"type":sample.type,"decoder":sample.decoder,"epoch":0,"catalog":catalog.fork(),"cache_directory":temp_root.path_join("cache"),"options":{},"memory_store":store,"decoder_store":catalog.decoded_cache(),"memory_epoch":store.generation(),"requested_us":Time.get_ticks_usec(),"dispatched_us":Time.get_ticks_usec(),"prework_write":false,"prework_read":true,"status_only":false,"prework_ticket":0}
	var task:=WorkerThreadPool.add_task(f.service._work.bind(job),false,"NWN70 worker parity")
	while not WorkerThreadPool.is_task_completed(task):await process_frame
	WorkerThreadPool.wait_for_task_completion(task)
	var result: Dictionary=f.service.results.get(id,{})
	f.service.results.erase(id)
	return result
func dispose(f: Dictionary) -> void:
	f.service.close();f.service.free();f.clear()
func semantic(result: Dictionary) -> Dictionary:
	var out: Dictionary={}
	for field in ["error","sha256","value","animation_sources","animation_view_identity","missing_textures","prework_inputs"]:
		if result.has(field):out[field]=result[field]
	for field in ["textures","emitter_textures"]:
		var textures: Dictionary={}
		for name in result.get(field,{}):
			var value: Dictionary=result[field][name].duplicate()
			for transient in ["timings","cache_hit","prepare_ms","palette_timings","palette_decodes","conversion"]:value.erase(transient)
			textures[name]=value
		out[field]=textures
	var dependencies: Array=[]
	for original in result.get("dependencies",[]):
		var row: Dictionary=original.duplicate()
		for transient in ["cache_hit","read_ms","timings"]:row.erase(transient)
		dependencies.append(row)
	out.dependencies=dependencies;return out
func compare_installed() -> Array:
	var a:=fixture(true);var b:=fixture(false);var records: Array=[]
	for sample in samples:
		for phase in ["first","memory-warm"]:
			var old=await work(a,sample);var current=await work(b,sample)
			check(str(old.get("error","missing")).is_empty() and str(current.get("error","missing")).is_empty(),"Original/candidate actual worker succeeds: "+str(sample.name)+"/"+phase)
			var expected:=semantic(old);var actual:=semantic(current)
			check(expected==actual,"Exact original/candidate decoded models, geometry, textures, source/dependency identity: "+str(sample.name)+"/"+phase)
			records.append({"name":sample.name,"decoder":sample.decoder,"phase":phase,"equal":expected==actual,"reference_digest":Cache.digest(var_to_bytes(expected)),"candidate_digest":Cache.digest(var_to_bytes(actual))})
	dispose(a);dispose(b);return records
func write(path: String,value: String) -> void:
	var file:=FileAccess.open(path,FileAccess.WRITE);file.store_buffer(value.to_ascii_buffer());file.close()
func compare_parents() -> void:
	var child:="newmodel child\nsetsupermodel child parent\nbeginmodelgeom child\nnode dummy root\nparent NULL\nendnode\nendmodelgeom child\n"
	var parent:="newmodel parent\nsetsupermodel parent NULL\nbeginmodelgeom parent\nnode dummy root\nparent NULL\nendnode\nendmodelgeom parent\n"
	write(temp_root.path_join("base/child.mdl"),child);write(temp_root.path_join("base/parent.mdl"),parent)
	var a:=fixture(true,false);var b:=fixture(false,false);var sample:={"name":"child","type":2002,"decoder":"actor-model"}
	var old=await work(a,sample);var current=await work(b,sample)
	check(str(old.get("error","missing")).is_empty() and str(current.get("error","missing")).is_empty() and semantic(old)==semantic(current),"Parent inheritance keeps exact original data and independently hashed sources")
	check(current.get("animation_sources",[]).size()==2 and current.animation_sources[0].sha256==Cache.digest(child.to_ascii_buffer()) and current.animation_sources[1].sha256==Cache.digest(parent.to_ascii_buffer()),"Root known_sha never leaks into a different parent source")
	var changed:=parent+"#same resource, new source revision\n";write(temp_root.path_join("override/parent.mdl"),changed)
	check(a.catalog.mount_directory(temp_root.path_join("override"),20) and b.catalog.mount_directory(temp_root.path_join("override"),20),"Both real catalogs admit higher-priority changed parent")
	old=await work(a,sample);current=await work(b,sample)
	check(str(current.get("error","missing")).is_empty() and semantic(old)==semantic(current) and current.animation_sources[1].sha256==Cache.digest(changed.to_ascii_buffer()),"Same root/new parent revision invalidates preparation and chooses its own current identity")
	var missing:={"name":"absent","type":2002,"decoder":"actor-model"};old=await work(a,missing);current=await work(b,missing)
	check(not str(old.get("error","")).is_empty() and semantic(old)==semantic(current),"Missing source preserves original error and cannot borrow an earlier known digest")
	dispose(a);dispose(b)
func initialize_fixture() -> void:
	control_script=load("res://.cache/nwn70/baseline/asset_service.gd")
	temp_root=OS.get_temp_dir().path_join("nwn70-worker-parity-"+str(OS.get_process_id())+"-"+str(Time.get_ticks_usec()))
	for child in ["base","override","cache"]:DirAccess.make_dir_recursive_absolute(temp_root.path_join(child))
func cleanup() -> void:
	for owned in ["base/child.mdl","base/parent.mdl","override/parent.mdl"]:
		var path:=temp_root.path_join(owned)
		if FileAccess.file_exists(path):DirAccess.remove_absolute(path)
	for owned in ["cache/saved-prework-v1","cache","base","override",""]:DirAccess.remove_absolute(temp_root.path_join(owned))
func run() -> void:
	if not options.has_all(["report","install"]) or FileAccess.file_exists(options.report):quit(2);return
	check(OS.get_cmdline_user_args().has("--prepared-cache-write=disabled"),"Parity fixture uses the same explicitly disabled optional disk-write policy for both sides")
	initialize_fixture();var records=await compare_installed();await compare_parents();cleanup();await process_frame;await process_frame
	var out:={"success":failures.is_empty(),"checks":checks,"failures":failures,"cases":records,"scope":"Actual uninstrumented original/candidate AssetService worker data on installed sources in independent catalog/prepared/decoded stores, first and memory-warm requests; exact geometry/texture/dependency identity plus changed parent precedence and missing-source errors. Timings and cache-hit flags normalized; no world/GUI/renderer/FPS or throughput acceptance."}
	var file:=FileAccess.open(options.report,FileAccess.WRITE);file.store_string(JSON.stringify(out,"\t"));file.close();print("NWN70_WORKER_PARITY ",checks," checks; ",failures.size()," failures");quit(0 if out.success else 1)
