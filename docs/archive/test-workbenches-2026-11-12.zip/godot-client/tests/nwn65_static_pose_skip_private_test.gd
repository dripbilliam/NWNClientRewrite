extends SceneTree

# Runs in two isolated private projects, each loading its own pinned native DLL.
class Probe:
	extends Node3D
	var notifications := 0
	func _notification(what: int) -> void:
		if what == NOTIFICATION_LOCAL_TRANSFORM_CHANGED:
			notifications += 1

var failures: Array[String] = []
var checks := 0

func check(value: bool, message: String) -> void:
	checks += 1
	if not value:
		failures.append(message)

func view(x: float) -> PackedByteArray:
	var bytes := PackedByteArray()
	bytes.resize(0x240)
	bytes.fill(0)
	bytes.encode_float(16, x)
	bytes.encode_float(20, 2.0)
	bytes.encode_float(24, 3.0)
	bytes.encode_float(28, 1.0)
	bytes.encode_float(44, 1.0)
	return bytes

func make_parts(count: int) -> Dictionary:
	var host := Node3D.new()
	root.add_child(host)
	var nodes: Array[Probe] = []
	var records: Array = []
	var sources: Array = []
	for index in count:
		var node := Probe.new()
		host.add_child(node)
		node.set_notify_local_transform(true)
		nodes.append(node)
		var source := {"type":"dummy", "children": []}
		var record := {"object":node, "id30":index, "dirty60":0, "field8c":0,
			"view":view(float(index)), "fields":{16:3, 28:4, 44:1},
			"materials":[], "source":source}
		records.append(record)
		sources.append(source)
	for index in range(1, count):
		sources[0].children.append(index)
	var children: Array = []
	for index in range(1, count):
		children.append({"id34":index, "flags98":0, "controllers78":[],
			"controllerCount80":0, "values88":PackedFloat32Array(),
			"children68":[], "childCount70":0})
	var tree := {"id34":0, "flags98":0,
		"controllers78":[{"rows4":2, "columnsA":3, "timeIndex6":0,
			"valueIndex8":2, "displacement0":16}], "controllerCount80":1,
		"values88":PackedFloat32Array([0,1,0,0,0,1,2,3]),
		"children68":children, "childCount70":children.size()}
	var plan: Dictionary = ClassDB.class_call_static("NwnParticleKernel", "model_prepare", tree)
	check(not plan.has("error"), "Prepared active root and controller-free child plan")
	var owner: RefCounted = ClassDB.instantiate("NwnModelPoseStorage")
	var binding: Array = []
	for index in count: binding.append(index)
	var result: Dictionary = owner.call("dispatch", 0, {"parts":records,
		"binding":binding, "root":0, "emitter_fields":{}})
	check(not result.has("error"), "Private native owner configured")
	return {"host":host, "nodes":nodes, "owner":owner, "plan":plan.get("plan",PackedByteArray())}

func step(row: Dictionary, t: float, profile: bool = false, manual: Dictionary = {}) -> Dictionary:
	return row.owner.call("dispatch", 1, {"plan":row.plan, "time":t,
		"weight":1.0, "scale":1.0, "manual":manual, "profile":profile,
		"scope":null})

func capture(row: Dictionary) -> Array:
	var output: Array = []
	for node: Probe in row.nodes:
		output.append([node.position, node.quaternion, node.scale,
			node.global_transform, node.notifications])
	return output

func semantics() -> Dictionary:
	var row := make_parts(4)
	var owner: RefCounted = row.owner
	var nodes: Array[Probe] = row.nodes
	var first: Dictionary = owner.call("dispatch", 2, {"manual":{}, "scope":null, "profile":false})
	check(not first.has("error"), "Publish before first apply succeeds")
	check(nodes[1].position == Vector3(1,3,-2), "First publication sets child pose")
	var initial: Dictionary = owner.call("dispatch", 7, {})
	check(int(initial.static_pose_checks) == 0, "First publication cannot use skip path")
	var frames: Array = [capture(row)]
	for index in 6:
		if index == 2:
			nodes[1].position = Vector3(91,92,93)
			nodes[2].quaternion = Quaternion(0,0,0,-1)
			nodes[3].scale = Vector3(2,3,4)
		if index == 4:
			nodes[1].position = Vector3(-7,-8,-9)
		var manual := {1:true} if index == 4 else {}
		var result := step(row, float(index) * 0.125, false, manual)
		check(not result.has("error"), "Active frame " + str(index) + " publishes")
		if index == 2:
			check(nodes[1].position == Vector3(1,3,-2), "External position edit corrected")
			check(nodes[2].quaternion == Quaternion.IDENTITY, "Signed quaternion edit corrected")
			check(nodes[3].scale == Vector3.ONE, "External scale edit corrected")
		if index == 4:
			check(nodes[1].position == Vector3(-7,-8,-9), "Manual child remains untouched")
		frames.append(capture(row))
	var stats: Dictionary = owner.call("dispatch", 7, {})
	owner.call("dispatch", 8, {})
	check(bool(owner.call("dispatch", 7, {}).closed), "Retired owner closes")
	row.host.free()
	return {"frames":frames, "stats":stats}

func timing() -> Dictionary:
	var row := make_parts(81)
	var warm := step(row, 0.0)
	check(not warm.has("error"), "Timing rig warmup")
	var samples: Array = []
	for index in 240:
		var result := step(row, float(index % 16) / 16.0, true)
		check(not result.has("error"), "Timing active rig frame " + str(index))
		samples.append(float(result.get("publish_ms",-1)))
	var stats: Dictionary = row.owner.call("dispatch", 7, {})
	row.owner.call("dispatch", 8, {})
	row.host.free()
	return {"publish_ms":samples, "stats":stats}

func run() -> void:
	var expected := OS.get_cmdline_user_args().has("--model-pose-static-skip=on")
	check(ClassDB.class_exists("NwnModelPoseStorage"), "Private native pose class loaded")
	var semantic := semantics()
	var component := timing()
	check(bool(semantic.stats.static_pose_skip_requested) == expected,
		"Private native flag matches selected mode")
	check(int(semantic.stats.static_pose_skips) > 0 if expected else int(semantic.stats.static_pose_skips) == 0,
		"Static child skip selected only in candidate")
	check(int(semantic.stats.static_pose_mismatches) >= 3 if expected else int(semantic.stats.static_pose_mismatches) == 0,
		"External pose edits fall back to original setters")
	var report := {"success":failures.is_empty(), "checks":checks,
		"failures":failures, "selected":expected,
		"semantic":semantic, "component":component,
		"scope":"Private active root with controller-free Parts, first publication, external pose edits, manual gate, retirement and 81-Part active publication timing. No original assets, GPU or whole-client FPS."}
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):
			var file := FileAccess.open(arg.substr(9), FileAccess.WRITE)
			if file != null: file.store_string(JSON.stringify(report) + "\n")
	print(JSON.stringify({"success":report.success,"checks":checks,"failures":failures,
		"selected":expected,"semantic_stats":semantic.stats,
		"component_stats":component.stats}))
	quit(0 if failures.is_empty() else 1)

func _initialize() -> void:
	call_deferred("run")
