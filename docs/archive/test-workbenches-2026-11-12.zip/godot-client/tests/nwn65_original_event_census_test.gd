extends SceneTree
# Three sealed original MDLs, one data-only worker at a time. No scene/model,
# texture, AnimationPlayer, extension or renderer admission occurs here.
const Recorded=preload("res://systems/native_data/recorded_catalog.gd")
const Assets=preload("res://systems/native_data/asset_service.gd")
const Cache=preload("res://systems/native_data/prepared_cache.gd")
var output:=""
var proposal_path:=""
var checks:=0
var failures: Array=[]
func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.trim_prefix("--report=")
		if arg.begins_with("--proposal="):proposal_path=arg.trim_prefix("--proposal=")
	call_deferred("run")
func check(value: bool,label: String) -> void:
	checks+=1
	if not value:failures.append(label);push_error(label)
func run() -> void:
	if output.is_empty() or proposal_path.is_empty() or FileAccess.file_exists(output):quit(2);return
	var proposal: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(proposal_path))
	check(proposal.resources.size()==3,"census is bounded to the three approved original models")
	var manifest_path:=ProjectSettings.globalize_path("res://"+str(proposal.catalog.file))
	check(FileAccess.get_sha256(manifest_path)==str(proposal.catalog.sha256),"exact sealed original catalog pin matches")
	var catalog:=Recorded.new();check(catalog.mount(manifest_path.get_base_dir()),"closed-world original catalog mounts read-only")
	if not catalog.failure.is_empty():quit(3);return
	var service:=Assets.new();var rows: Array=[]
	for resource in proposal.resources:
		var name:=str(resource.key).split(":")[0];var reader=catalog.fork();var bytes: PackedByteArray=reader.get_resource(name,2002)
		check(reader.failure.is_empty() and bytes.size()==int(resource.bytes) and Cache.digest(bytes)==str(resource.sha256),"exact original source bytes available: "+name)
		if not reader.failure.is_empty() or bytes.is_empty():continue
		var result: Array=[];var started:=Time.get_ticks_usec()
		var task:=WorkerThreadPool.add_task(func():result.append(service.actor_data(reader,name,bytes,"",[],{},str(resource.sha256))),false,"NWN65 original clip/event census")
		while not WorkerThreadPool.is_task_completed(task):await process_frame
		WorkerThreadPool.wait_for_task_completion(task)
		var decoded: Dictionary=result[0]
		check(str(decoded.get("error","missing")).is_empty(),"actual native original actor decoder succeeds: "+name+" "+str(decoded.get("error","")))
		if str(decoded.get("error","")).is_empty():
			var model: Dictionary=decoded.value;var clips: Array=[];var eventless:=0;var eventful:=0;var total_events:=0
			for clip in model.animations:
				var events: Array=clip.get("events",[])
				if events.is_empty():eventless+=1
				else:eventful+=1
				total_events+=events.size()
				clips.append({"name":str(clip.name),"length":clip.length,"transition":clip.get("transition",0.0),"events":events.duplicate(true),"tracks":clip.tracks.size()})
			var compact:={"resource":name,"sha256":resource.sha256,"nodes":model.nodes.size(),"clips":clips,"eventless_clips":eventless,"eventful_clips":eventful,"event_rows":total_events,"inherited_sources":decoded.get("animation_sources",[])}
			var fixture_path:=output.get_base_dir().path_join(name+"-original-events.json")
			check(not FileAccess.file_exists(fixture_path),"compact original event fixture is fresh: "+name)
			var fixture:=FileAccess.open(fixture_path,FileAccess.WRITE);fixture.store_string(JSON.stringify(compact));fixture.close()
			rows.append({"resource":name,"source_bytes":bytes.size(),"nodes":model.nodes.size(),"clips":clips.size(),"eventless":eventless,"eventful":eventful,"event_rows":total_events,"fixture":fixture_path,"fixture_sha256":FileAccess.get_sha256(fixture_path),"elapsed_ms":(Time.get_ticks_usec()-started)/1000.0})
		result.clear();decoded={};reader=null;bytes=PackedByteArray()
		catalog.prepared_store.clear();catalog.decoder_store.clear()
	service.free();catalog=null
	var file:=FileAccess.open(output,FileAccess.WRITE);file.store_string(JSON.stringify({"checks":checks,"failures":failures,"passed":failures.is_empty(),"resources":rows,"scope":"Three exact captured original humanoid/NPC/light-effect MDLs decoded by actual data workers, sequential; clip-library counts are not live playing-clip eligibility. No scene/texture/GPU/FPS/throughput claim."},"\t"));file.close();quit(0 if failures.is_empty() else 1)
