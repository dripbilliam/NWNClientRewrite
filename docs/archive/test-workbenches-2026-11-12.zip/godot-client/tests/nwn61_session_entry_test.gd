extends "res://native_session_world.gd"
# Real wire/backlog/session continuation, actual inherited World receiver and
# entity API; authored UI/area-open boundaries avoid graphics/asset work here.
const Fixture=preload("res://tests/nwn61_world_entry_test.gd")
const Authored=preload("res://tests/native_snapshot_preparation_session_test.gd")
const BaseAuthored=preload("res://tests/native_entity_api_session_test.gd")
const API=preload("res://systems/client_api/access.gd")
const ActualWorld=preload("res://systems/native_render/live_world_pending_appearances.gd")
var checks:=0
var failures: Array=[]
var output:=""
var trace: Array=[]
var sent: Array=[]
var serial:=0
var cancel_on_event:=false
class Loading extends Node:
	var epoch:=1
	var active:=true
	var milestones: Dictionary={}
class Ui extends BaseAuthored.RawUi:
	var events: Array=[]
	func set_gameplay_visible(_value: bool) -> void:pass
	func set_world(gen: int,area: int,controlled: int,rows: Array,inventory: Dictionary={},header: Dictionary={}) -> void:events.append("ui");super.set_world(gen,area,controlled,rows,inventory,header)
func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.trim_prefix("--report=")
	call_deferred("run")
func check(value: bool,label_text: String) -> void:
	checks+=1
	if not value:failures.append(label_text);push_error(label_text)
func _native_entry_snapshot_unit(state: Dictionary,deadline_usec: int) -> void:
	match str(state.phase):
		"capture":trace.append("capture");state.phase="retire"
		"retire":
			if is_instance_valid(world):world_retirement.retire(world)
			state.phase="open"
		"open":
			epoch=int(state.message.generation);acknowledged=-1
			world=ActualWorld.new();world.area_id=int(state.message.data.area.id);world.generation=epoch;world.combat=Fixture.Combat.new();world.set_process(false)
			state.new_world=world;state.previous_mode=world.process_mode;world.process_mode=Node.PROCESS_MODE_DISABLED;host.add_child(world)
			world.effects=Fixture.Effects.new();world.add_child(world.effects);world.effects.configure(world)
			state.phase="renderer_begin"
		"wind_voice":state.phase="targets"
		"targets":trace.append("targets");state.phase="combat"
		"combat":trace.append("combat");state.phase="finish"
		_:super._native_entry_snapshot_unit(state,deadline_usec)
func setup() -> void:
	gameplay_ui=Ui.new();gameplay_ui.events=trace;host.add_child(gameplay_ui);gameplay_ui.options_requested.connect(open_game_options)
	initialized=true;closing=false;cancelled_connection=-1
func feed(rows: Array,generation: int) -> void:
	serial+=1
	var messages: Array=[{"kind":"raw-world-begin","connection":1,"serial":serial,"generation":generation,"count":rows.size(),"data":{"bridgeMode":"full","area":{"id":7},"controlledId":1,"module":{}}}]
	for first in range(0,rows.size(),64):messages.append({"kind":"raw-world-chunk","connection":1,"serial":serial,"generation":generation,"objects":rows.slice(first,first+64)})
	messages.append({"kind":"raw-world-end","connection":1,"serial":serial,"generation":generation})
	var sizes:=PackedInt32Array();sizes.resize(messages.size());sizes.fill(100)
	dispatch_protocol_messages(messages,sizes)
func ack_count() -> int:return sent.filter(func(message):return message.kind=="raw-world-accepted").size()
func send(value: Dictionary) -> void:
	sent.append(value.duplicate(true))
	if value.kind=="raw-world-accepted":trace.append("ack")
func retain_world_diagnostics(_reason: String,_connection: int=0) -> void:pass
func shutdown() -> void:cancel_snapshot_preparation();closing=true
func run() -> void:
	if output.is_empty() or FileAccess.file_exists(output):quit(2);return
	host=Node3D.new();root.add_child(host);label=Label.new();host.add_child(label)
	render_settings=Authored.Settings.new();host.add_child(render_settings);render_menu=Authored.Menu.new();host.add_child(render_menu)
	world_retirement=WorldRetirement.new();host.add_child(world_retirement);session_connection=1;epoch=-1
	install_entity_api();setup();entry_snapshot_budget_us=50
	native_visibility_runtime=Authored.Visibility.new();native_visibility_runtime.events=trace
	var provider: RefCounted=API.entities
	provider.entity_added.connect(func(_event):
		trace.append("api")
		if cancel_on_event:cancel_on_event=false;reset_session())
	var rows: Array=[]
	for id in range(1,129):rows.append(Fixture.row(id,5))
	snapshot_preparation=Authored.HeldPreparation.new();snapshot_preparation_enabled=true
	feed(rows,1)
	check(not pending_prepared_snapshot.is_empty() and entry_snapshot_commit.is_empty(),"wire entry waits for held metadata without losing private wire admission")
	snapshot_preparation.released=true;poll_snapshot_preparation()
	check(not entry_snapshot_commit.is_empty() and ack_count()==0,"wire new-area end starts entry continuation before ACK")
	check(snapshot_transition_waiting() and keyboard_context().is_empty() and native_pointer_blocked(Vector2.ZERO),"new entry fences keyboard and pointer even after epoch changes")
	var queued:={"kind":"movement","connection":1,"generation":1,"areaId":7,"records":[{"id":1,"revision":1,"changes":{"position":[8,2,0]},"initial":{"position":[1,2,0]}}]}
	dispatch_protocol_messages([queued],PackedInt32Array([100]))
	check(snapshot_backlog.size()==1,"wire movement waits behind complete new-area publication")
	var limit:=0
	while not entry_snapshot_commit.is_empty() and limit<1000:
		poll_snapshot_preparation();limit+=1;await process_frame
	check(limit>1 and limit<1000 and ack_count()==1 and accepted_raw_serial==1,"cooperative entry finishes and ACKs exactly once")
	check(world.desired.size()==128 and gameplay_ui.text.objects.size()==128 and provider.list_references().size()==128,"entry publishes complete World, UI and API registries")
	check(trace.find("ui")<trace.find("visibility") and trace.find("visibility")<trace.find("api") and trace.find("api")<trace.find("ack"),"ordered core/UI→visibility→API→ACK preserved")
	check(snapshot_backlog.size()==0 and world.motion.objects[1].position==Vector3(8,2,0),"queued movement applies only after entry ACK")
	check(world.process_mode==Node.PROCESS_MODE_INHERIT and not snapshot_transition_waiting(),"new scene starts processing only after complete publication")
	check(report.entry_commit_entries.size()==1 and report.entry_commit_entries[0].budget_us==50,"bounded entry publishes scoped latency/budget receipt")
	loading_screen=Loading.new();host.add_child(loading_screen);world.set_meta("native_entry_loading",true)
	loading_screen.milestones={"terrain":true,"player":true,"camera":true}
	complete_native_entry_loading([])
	check(world.get_meta("native_entry_loading"),"active/early-dismissed loading does not release entry allowance")
	loading_screen.active=false;loading_screen.epoch=2;complete_native_entry_loading([])
	check(world.get_meta("native_entry_loading"),"stale loading generation does not release current entry allowance")
	loading_screen.epoch=1;loading_screen.milestones.camera=false;complete_native_entry_loading([])
	check(world.get_meta("native_entry_loading"),"camera readiness remains part of first-playable gate")
	loading_screen.milestones.camera=true;complete_native_entry_loading(["error"])
	check(world.get_meta("native_entry_loading"),"entry errors retain explicit loading state")
	complete_native_entry_loading([])
	check(not world.get_meta("native_entry_loading") and report.entry_commit_entries[0].has("first_playable_ms"),"exact completed loading milestone releases entry allowance and records first playable")
	loading_screen.queue_free();loading_screen=null
	snapshot_preparation_enabled=false
	var prior_ack:=ack_count();trace.clear();feed(rows,2)
	check(not entry_snapshot_commit.is_empty(),"second area entry queues cooperatively")
	dispatch_protocol_messages([{"kind":"session-reset","connection":1}],PackedInt32Array([100]))
	check(entry_snapshot_commit.is_empty() and world==null and ack_count()==prior_ack and snapshot_backlog.size()==0,"current reset cancels unfinished entry without stale ACK or retained backlog")
	setup();native_visibility_runtime=Authored.Visibility.new();native_visibility_runtime.events=trace
	feed(rows,3);cancel_on_event=true;limit=0
	check(not entry_snapshot_commit.is_empty(),"callback-reset fixture actually starts a staged entry")
	while not entry_snapshot_commit.is_empty() and limit<1000:
		poll_snapshot_preparation();limit+=1;await process_frame
	check(world==null and ack_count()==prior_ack and accepted_raw_serial==-1 and not cancel_on_event,"entity callback reset aborts staged publication and suppresses ACK")
	closing=false;reset_session();world_retirement.close();snapshot_preparation.close();host.free();host=null
	await process_frame
	var file:=FileAccess.open(output,FileAccess.WRITE);file.store_string(JSON.stringify({"checks":checks,"failures":failures,"passed":failures.is_empty(),"scope":"Actual wire/session/backlog/inherited World/API; authored area-open, UI and visibility; no GPU, original asset, FPS or loading-latency claim"},"\t"));file.close();quit(0 if failures.is_empty() else 1)
