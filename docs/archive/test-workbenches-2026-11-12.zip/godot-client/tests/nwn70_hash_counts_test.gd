extends SceneTree
# Count only; elapsed times are not an optimization or FPS measurement.
const Catalog=preload("res://systems/native_data/resource_catalog.gd")
const Cache=preload("res://systems/native_data/prepared_cache.gd")
const Probe=preload("res://tools/nwn70/hash_probe.gd")
var options: Dictionary={}
var checks:=0
var failures: Array=[]
var rows: Array=[]
func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		var pair:=arg.trim_prefix("--").split("=",true,1)
		if pair.size()==2:options[pair[0]]=pair[1]
	call_deferred("run")
func check(value: bool,label: String) -> void:
	checks+=1
	if not value:failures.append(label);print("FAIL ",label)
func run() -> void:
	if not options.has_all(["report","install","probe"]) or FileAccess.file_exists(options.report):quit(2);return
	check(OS.get_cmdline_user_args().has("--prepared-cache-write=disabled"),"Count fixture explicitly suppresses optional disk writes; validation code remains intact")
	var script=load(str(options.probe));var service=script.new();root.add_child(service);service.set_process(false)
	var catalog:=Catalog.new();check(catalog.mount_install(str(options.install)),"Installed original resource catalog mounts read-only");catalog.build_resource_index()
	var samples: Array=[{"name":"classes","type":2017,"decoder":"2da"},{"name":"c_dummy","type":2002,"decoder":"actor-model"},{"name":"pb_but_inv","type":2002,"decoder":"actor-model"}]
	for name in ["plc_barrel","plc_chest1","tcn01_a01_01"]:
		if catalog.has_resource(name,2002):samples.append({"name":name,"type":2002,"decoder":"static-model"});break
	var cache_root:=OS.get_temp_dir().path_join("nwn70-hash-counts-"+str(OS.get_process_id())+"-"+str(Time.get_ticks_usec()))
	DirAccess.make_dir_recursive_absolute(cache_root)
	var serial:=0
	for sample in samples:
		var bytes:=catalog.read_resource(str(sample.name),int(sample.type));check(catalog.failure.is_empty() and not bytes.is_empty(),"Original source bytes available: "+str(sample.name))
		if not catalog.failure.is_empty() or bytes.is_empty():continue
		var expected:=Cache.digest(bytes)
		for phase in ["first","memory-warm"]:
			serial+=1
			var reader=catalog.fork();var store=catalog.preparation_cache();var decoded=catalog.decoded_cache()
			var job:={"id":serial,"name":sample.name,"type":sample.type,"decoder":sample.decoder,"epoch":0,"catalog":reader,"cache_directory":cache_root,"options":{},"memory_store":store,"decoder_store":decoded,"memory_epoch":store.generation(),"requested_us":Time.get_ticks_usec(),"dispatched_us":Time.get_ticks_usec(),"prework_write":false,"prework_read":true,"status_only":false,"prework_ticket":0}
			var key: String=str(sample.name)+":"+str(sample.type)+":"+str(sample.decoder)+":"+str(phase)
			var metadata:={"name":sample.name,"type":sample.type,"decoder":sample.decoder,"source_sha256":expected,"source_bytes":bytes.size(),"phase":phase,"catalog_generation":store.generation(),"cache_revision":Cache.REVISION,"probe_source":options.probe}
			var task:=WorkerThreadPool.add_task(func():
				Probe.begin_scope(key,metadata);service._work(job);Probe.end_scope(),false,"NWN70 source digest counts")
			while not WorkerThreadPool.is_task_completed(task):await process_frame
			WorkerThreadPool.wait_for_task_completion(task)
			var result: Dictionary=service.results.get(serial,{})
			check(not result.is_empty() and str(result.get("error","missing")).is_empty(),"Actual data worker succeeds: "+key)
			var observed: Dictionary=Probe.snapshot().get(key,{})
			var root_row: Dictionary=observed.get("digests",{}).get(expected+":"+str(bytes.size()),{})
			check(not root_row.is_empty(),"Current root source identity was actually hashed: "+key)
			check(str(result.get("sha256",""))==expected,"Instrumentation returns the exact unmodified source SHA256: "+key)
			if sample.decoder=="static-model" and phase=="first" and options.has("bundle"):
				check(not FileAccess.file_exists(str(options.bundle)),"Owned original static-model bundle output is fresh")
				if not FileAccess.file_exists(str(options.bundle)):
					var bundle:=FileAccess.open(str(options.bundle),FileAccess.WRITE);bundle.store_var(result,false);bundle.close()
			rows.append({"key":key,"metadata":metadata,"root_digest":root_row,"digest_groups":observed.get("digests",{}).values(),"prework_inputs":result.get("prework_inputs",[]),"all_calls":observed.get("calls",0),"all_bytes_hashed":observed.get("bytes_hashed",0),"resource_io":result.get("phases",{}).get("resource_io",{}),"memory_cache_hit":result.get("memory_cache_hit",false),"memory_decode_hit":result.get("memory_decode_hit",false)})
			service.results.erase(serial)
	service.close();service.free();catalog=null
	var duplicate_jobs:=0;var duplicate_bytes:=0
	for row in rows:
		var calls:=int(row.root_digest.get("calls",0))
		if calls>1:duplicate_jobs+=1;duplicate_bytes+=(calls-1)*int(row.metadata.source_bytes)
	if options.get("candidate","false")=="true":check(duplicate_jobs==0 and rows.all(func(row):return int(row.root_digest.get("calls",0))==1),"Candidate hashes each actual job root exactly once")
	else:check(duplicate_jobs>0,"Measured actual worker jobs repeat SHA256 over identical root bytes/revision")
	var cleanup:={"prework_empty_removed":DirAccess.remove_absolute(cache_root.path_join("saved-prework-v1"))==OK,"root_empty_removed":DirAccess.remove_absolute(cache_root)==OK}
	var report:={"success":failures.is_empty(),"checks":checks,"failures":failures,"rows":rows,"duplicate_jobs":duplicate_jobs,"avoidable_root_bytes_hashed":duplicate_bytes,"cleanup":cleanup,"scope":"Untimed per-source/decoder/revision digest call and byte counts in exact private source snapshots of actual AssetService worker jobs using original installed data. Observer returns real SHA256. Optional disk writes disabled; no production code, payload checksum validation, rendering, GPU/FPS or loading-throughput acceptance is changed."}
	var file:=FileAccess.open(options.report,FileAccess.WRITE);file.store_string(JSON.stringify(report,"\t"));file.close();print("NWN70_HASH_COUNTS ",JSON.stringify({"success":report.success,"checks":checks,"duplicate_jobs":duplicate_jobs,"avoidable_bytes":duplicate_bytes,"jobs":rows.size()}));quit(0 if report.success else 1)
