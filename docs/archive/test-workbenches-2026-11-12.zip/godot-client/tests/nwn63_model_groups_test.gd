extends "res://tests/native_drive_spatial_adapter_test.gd"
# Exact current pre-change owner, including the independent NWN62 entry API.
const GroupBefore=preload("res://.cache/nwn63/model-groups-a/before/systems/native_render/drive_collision_indexed.gd")
var compared_queries:=0
var compared_paths:=0
var cache_reuses:=0
func group_pair(count: int=128)->Array:
	var pair: Array=[]
	for before in [true,false]:
		var setup:=make_world(false);var collision=GroupBefore.new() if before else Collision.new()
		setup.world.add_child(collision);collision.world=setup.world;collision.tables=tables();setup.world.drive_collision=collision;collision.ensure_spatial_scope();collision.set_process(false)
		var rows: Array=[creature(1,Vector2(1,1)),creature(4,Vector2(6,3)),object(2,Vector2(4,1)),object(3,Vector2(9,1),10)]
		collision.publish_model("chest:placeable",{"states":[footprint()]})
		collision.publish_model("gate:door",{"states":[footprint(),{"vertices":[],"faces":[]},footprint(2)]})
		for i in count:
			var key:="cohort_"+str(i);var appearance: int=collision.tables.placeables.orderedRows.size()
			collision.tables.placeables.orderedRows.append({"ModelName":key})
			if i%17!=0:collision.publish_model(key+":placeable",{"states":[footprint(1+i%4)]})
			var position:=Vector2(24+(i%12)*8,24+(i/12)*8)
			rows.append(object(100+i,position,9,1,appearance))
		setup.world.receive(rows,1);setup.collision=collision;pair.append(setup)
	return pair
func compare_groups(pair: Array,a: Vector3,b: Vector3,label: String)->void:
	for radius in [0.0,0.3,1.0/64,2.0,12.0]:
		var before: Dictionary=pair[0].collision.static_candidates(a,b,radius,1)
		var after: Dictionary=pair[1].collision.static_candidates(a,b,radius,1)
		check(var_to_bytes(before)==var_to_bytes(after),label+": exact candidate readiness/order/witnesses radius "+str(radius));compared_queries+=1
func compare_paths(pair: Array,a: Vector3,b: Vector3,label: String)->void:
	var transcripts: Array=[];var paths: Array=[]
	for setup in pair:
		var owner=setup.collision;var clear: Callable=owner.query_preview(1,a,b,a);var transcript: Array=[]
		var recorded:=func(from: Vector3,to: Vector3):
			var accepted: bool=clear.call(from,to)
			transcript.append([from,to,accepted,owner.stats.get("last_blocked",{}).get("reason","") if not accepted else ""]);return accepted
		paths.append(Plan.path(a,b,a,recorded));transcripts.append(transcript)
	check(var_to_bytes(paths[0])==var_to_bytes(paths[1]),label+": exact path/factor/fraction")
	check(transcripts[0]==transcripts[1],label+": original probes/endpoints/first blocker order");compared_paths+=1
func ordinary_and_seeded(pair: Array)->void:
	for line in [[Vector3(1,7,0),Vector3(4,7,0)],[Vector3(2,1.5,0),Vector3(6,1.5,0)],[Vector3(8,1.5,0),Vector3(11,1.5,0)],[Vector3(1,1,1000),Vector3(30,1,-1000)],[Vector3(1,1,0),Vector3(1,1,0)]]:
		compare_groups(pair,line[0],line[1],"ordinary/blocked/unknown-Z");compare_paths(pair,line[0],line[1],"ordinary path")
	var rng:=RandomNumberGenerator.new();rng.seed=0x63a7f930
	for i in 128:
		var a:=Vector3(rng.randf_range(-1,130),rng.randf_range(-1,130),rng.randf_range(-20,20));var b:=a+Vector3(rng.randf_range(-15,15),rng.randf_range(-15,15),0)
		compare_groups(pair,a,b,"seeded "+str(i))
	var group: Dictionary=pair[1].collision.static_groups["chest:placeable"]
	var prepared: Dictionary=group.query_preparation
	compare_groups(pair,Vector3(1,7,0),Vector3(4,7,0),"unchanged proof")
	check(is_same(prepared,group.query_preparation),"Unchanged model/group values reuse the derived preparation");cache_reuses+=1
func mutations(pair: Array)->void:
	var a:=Vector3(1,1,0);var b:=Vector3(6,1,0);var prior: Dictionary=pair[1].collision.static_groups["chest:placeable"].query_preparation
	for setup in pair:setup.collision.model_bounds["chest:placeable"][0].radius=90.0
	compare_groups(pair,a,b,"In-place radius mutation")
	check(not is_same(prior,pair[1].collision.static_groups["chest:placeable"].query_preparation),"Value proof rejects in-place radius mutation")
	for setup in pair:setup.collision.model_bounds["chest:placeable"][0].pending=true
	compare_groups(pair,Vector3(1000,1000,0),Vector3(1001,1000,0),"Pending state blocks even a distant group")
	for setup in pair:setup.collision.model_bounds["chest:placeable"][0].erase("pending")
	compare_groups(pair,a,b,"Pending restored")
	for setup in pair:setup.collision.static_groups["chest:placeable"].bounds.min_x=10000.0
	compare_groups(pair,a,b,"In-place root bound mutation")
	for setup in pair:
		setup.collision.dirty_groups["chest:placeable"]=true;setup.collision.flush_group_bounds()
	compare_groups(pair,a,b,"Root bounds republished")
	for setup in pair:setup.collision.models["chest:placeable"].error="received resource failure"
	compare_groups(pair,a,b,"Model error mutation uses original pending footprint")
	for setup in pair:setup.collision.models["chest:placeable"].erase("error")
	compare_groups(pair,a,b,"Model error removed")
	for setup in pair:setup.collision.model_bounds["chest:placeable"][0].custom="unknown schema"
	compare_groups(pair,a,b,"Unknown state fields preserve ordinary calculation")
	check(not pair[1].collision.static_groups["chest:placeable"].has("query_preparation"),"Unknown schema declines caching")
	for setup in pair:
		setup.collision.publish_model("chest:placeable",{"states":[footprint(5)]})
		setup.collision.publish_model("cohort_0:placeable",{"states":[footprint(30)]})
	compare_groups(pair,a,b,"Model replacement and pending arrival")
	compare_paths(pair,a,b,"Replacement path")
	for state in [1,2,0,-1,8]:
		for setup in pair:
			var door:=object(3,Vector2(9,1),10);door.replicated.doorOpenState=state;setup.world.receive_delta([door],[],1)
		compare_groups(pair,Vector3(8,1.5,0),Vector3(11,1.5,0),"Door state "+str(state));compare_paths(pair,Vector3(8,1.5,0),Vector3(11,1.5,0),"Door path "+str(state))
func lifecycle(pair: Array)->void:
	for setup in pair:
		var moved:=object(2,Vector2(30,30));moved.staticState.orientation.yaw=90;setup.world.receive_delta([moved],[100],1)
	compare_groups(pair,Vector3(29,30,0),Vector3(33,30,0),"Motion/rotation/removal membership")
	for setup in pair:
		check(setup.collision.begin_received_full(),"Entry begins in existing active scope")
		var count:=0
		while not setup.collision.received_full_step() and count<4096:count+=1
		check(count<4096 and setup.collision.ready(),"Incremental entry completes with current group bounds")
	compare_groups(pair,Vector3(1,1,0),Vector3(6,1,0),"Incremental full publication")
	var held: Array=[]
	for setup in pair:held.append(setup.collision.query(1));setup.world.receive_delta([creature(1,Vector2(1,1),2)],[],1)
	check(not held[0].call(Vector3(1,1,0),Vector3(2,1,0)) and not held[1].call(Vector3(1,1,0),Vector3(2,1,0)),"Cached group preparation cannot bypass controlled lifetime fences")
	for setup in pair:
		setup.world.generation+=1;setup.collision.sync_full()
	compare_groups(pair,Vector3(1,1,0),Vector3(6,1,0),"New area generation")
	for setup in pair:
		setup.collision.retire_index()
		check(setup.collision.static_groups.is_empty() and not setup.collision.query(1).is_valid(),"Retirement releases derived groups and query authority")
func run()->void:
	var pair:=group_pair();ordinary_and_seeded(pair);mutations(pair);lifecycle(pair)
	for setup in pair:setup.world.free()
	await process_frame;await process_frame
	var result:={"success":failures.is_empty(),"checks":checks,"failures":failures,"compared_queries":compared_queries,"compared_paths":compared_paths,"cache_reuses":cache_reuses,"scope":"Actual pre-change/current indexed owners: model-group preparation only; exact candidate order/readiness/witnesses and path/probe transcripts with value mutations, missing/error models, door states, bounds, entry publication, lifetimes, area generation and retirement. No timing or FPS claim."}
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--report="):
			var file:=FileAccess.open(argument.trim_prefix("--report="),FileAccess.WRITE);file.store_string(JSON.stringify(result,"  "));file.close()
	print(JSON.stringify(result));quit(0 if failures.is_empty() else 1)
