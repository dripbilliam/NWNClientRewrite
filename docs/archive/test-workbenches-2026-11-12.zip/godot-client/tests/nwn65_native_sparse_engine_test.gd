extends "res://tests/nwn65_rig_components_test.gd"
# Original scalar publisher oracle versus the private native sparse-slot
# candidate. The same script runs with the candidate flag off and on.
const Catalog=preload("res://systems/native_data/resource_catalog.gd")
const ActorModel=preload("res://systems/native_data/actor_model.gd")
var case_reports: Array=[]
func pose_bits(skeleton: Skeleton3D,slot: int) -> PackedByteArray:
	var p:=skeleton.get_bone_pose_position(slot)
	var q:=skeleton.get_bone_pose_rotation(slot)
	var s:=skeleton.get_bone_pose_scale(slot)
	return PackedFloat32Array([p.x,p.y,p.z,q.x,q.y,q.z,q.w,s.x,s.y,s.z]).to_byte_array()

func compare_sparse(label: String,part_count: int,slots: Array[int],expect_skip: bool) -> void:
	var original: Dictionary=create_case(part_count)
	var candidate: Dictionary=create_case(part_count)
	for row: Dictionary in [original,candidate]:
		for skin: Dictionary in row.skins:skin.bones.assign(slots)
	var original_forces: Array=[]
	var candidate_forces: Array=[]
	for skin_index in 2:
		original.skins[skin_index].skeleton.pose_updated.connect(func() -> void:
			original_forces.append(skin_index)
			if skin_index==0 and original_forces.size()==15:
				original.skins[1].skeleton.set_bone_pose_scale(20,Vector3(1.0,1.2,1.0)))
		candidate.skins[skin_index].skeleton.pose_updated.connect(func() -> void:
			candidate_forces.append(skin_index)
			if skin_index==0 and candidate_forces.size()==15:
				candidate.skins[1].skeleton.set_bone_pose_scale(20,Vector3(1.0,1.2,1.0)))
	var sparse:=0
	var negative_zero: float=PackedByteArray([0,0,0,128]).decode_float(0)
	var negative_zero_bits:=PackedByteArray([0,0,0,128])
	var canonical_bits:=PackedFloat32Array([0.0,0.0,0.0,0.0,0.0,0.0,1.0,1.0,1.0,1.0]).to_byte_array()
	for part in slots:
		if part<0:sparse+=1
	check(sparse>=16,label+": original or synthetic skin has sparse slots")
	for frame in 24:
		for row: Dictionary in [original,candidate]:
			row.nodes[3].position.y=frame*0.07
			row.nodes[7].quaternion=Quaternion.from_euler(Vector3(frame*0.031,frame*-0.017,frame*0.023))
			if frame==6:
				for skin: Dictionary in row.skins:
					skin.skeleton.set_bone_pose(20,Transform3D(Basis(Quaternion(Vector3.UP,0.3)).scaled(Vector3(1.7,0.6,2.3)),Vector3(0.4,-0.5,0.8)))
			if frame==11:
				for skin: Dictionary in row.skins:skin.skeleton.set_bone_pose_rotation(20,Quaternion(0.0,0.0,0.0,-1.0))
			if frame==17:
				for skin: Dictionary in row.skins:skin.skeleton.set_bone_pose_scale(20,Vector3(1.0,1.25,1.0))
			if frame==20:
				for skin: Dictionary in row.skins:
					skin.skeleton.set_bone_pose_position(20,Vector3(negative_zero,0.0,0.0))
					check(PackedFloat32Array([skin.skeleton.get_bone_pose_position(20).x]).to_byte_array()==negative_zero_bits,label+": signed-zero position injected")
			if frame==21:
				for skin: Dictionary in row.skins:
					skin.skeleton.set_bone_pose_rotation(20,Quaternion(negative_zero,0.0,0.0,1.0))
					check(PackedFloat32Array([skin.skeleton.get_bone_pose_rotation(20).x]).to_byte_array()==negative_zero_bits,label+": signed-zero quaternion injected")
			if frame==22:
				for skin: Dictionary in row.skins:skin.skeleton.set_bone_pose_scale(20,Vector3(1.0,negative_zero,1.0))
			if frame==9:row.skins[1].bones[21]=mini(7,part_count-1)
			if frame==14:row.skins[1].bones[21]=-1
		original_publish(original)
		check(int(candidate.publisher.call("publish"))==0,label+": native completes frame "+str(frame))
		check(capture(original)==capture(candidate),label+": exact local/global poses frame "+str(frame))
		if frame in [20,21,22]:
			for row: Dictionary in [original,candidate]:
				for skin: Dictionary in row.skins:
					var skeleton: Skeleton3D=skin.skeleton
					check(pose_bits(skeleton,20)==canonical_bits,label+": canonical identity restored frame "+str(frame))
	check(original_forces==candidate_forces and original_forces.size()==48,label+": exact force callback order/count")
	var state: Dictionary=candidate.publisher.call("inspect")
	check(bool(state.get("sparse_skip_enabled",false))==expect_skip,label+": candidate flag state")
	check(int(state.force_calls)==48,label+": every force boundary preserved")
	check(int(state.bone_writes)<24*2*slots.size()/2 if expect_skip else int(state.bone_writes)==24*2*slots.size(),label+": expected actual bone-write count")
	var weak: WeakRef=weakref(candidate.publisher)
	candidate.publisher=null
	check(weak.get_ref()==null,label+": candidate publisher releases on retirement")
	original.publisher=null
	case_reports.append({"label":label,"part_count":part_count,"sparse_slots":sparse,"state":state,"forces":candidate_forces.size()})

func original_sparse_cases(install: String,expect_skip: bool) -> void:
	var catalog:=Catalog.new()
	if not catalog.mount_install(install):check(false,"Original install catalog mounts");return
	var found:=0
	for name in ["pme0_robe038","c_goldem","pme2_robe030","pfe0_robe032"]:
		var bytes: PackedByteArray=catalog.read_resource(name,2002)
		if bytes.is_empty():continue
		var parser:=ActorModel.new();parser.packed_keys=true
		var model: Dictionary=parser.parse(bytes)
		if not parser.failure.is_empty():continue
		for node: Dictionary in model.nodes:
			if not node.has("skin"):continue
			var raw: PackedInt32Array=node.skin.boneConstantSlots
			var slots: Array[int]=[]
			var root_seen:=false;var stopped:=false
			for slot in 64:
				var part:=int(raw[slot]) if slot<raw.size() else -1
				if stopped:part=-1
				if part==0:
					if root_seen:part=-1;stopped=true
					else:root_seen=true
				slots.append(part if part>=0 and part<model.nodes.size() else -1)
			compare_sparse(name+":"+str(node.name),model.nodes.size(),slots,expect_skip)
			found+=1
			break
		if found>=3:break
	check(found>=2,"At least two original sparse skin families checked")

func check_child_fallback(expect_skip: bool,kind: String) -> void:
	var original: Dictionary=create_case()
	var candidate: Dictionary=create_case()
	for row: Dictionary in [original,candidate]:
		for skin: Dictionary in row.skins:
			for slot in 64:skin.bones[slot]=slot if slot<3 else -1
		var skeleton: Skeleton3D=row.skins[0].skeleton
		if kind=="simulating-physics":
			# Every in-tree skeleton owns this internal compatibility modifier.
			var simulator: PhysicalBoneSimulator3D=skeleton.get_child(0,true) as PhysicalBoneSimulator3D
			check(simulator!=null,"Internal compatibility simulator exists")
			if simulator!=null:
				simulator.physical_bones_start_simulation()
				check(simulator.is_simulating_physics(),"Compatibility simulator is now simulating")
		else:
			# A direct child, including another internal child, may observe the
			# unconditional legacy setters and must keep all 64 writes.
			var child:=Node3D.new()
			skeleton.add_child(child,false,Node.INTERNAL_MODE_BACK if kind=="extra-internal" else Node.INTERNAL_MODE_DISABLED)
	var first_skin:={"writes":[]}
	candidate.skins[0].skeleton.pose_updated.connect(func():first_skin.writes.append(int(candidate.publisher.call("inspect").bone_writes)))
	var ordinary_slot_before: PackedByteArray=pose_bits(candidate.skins[1].skeleton,3)
	var canonical_bits:=PackedFloat32Array([0.0,0.0,0.0,0.0,0.0,0.0,1.0,1.0,1.0,1.0]).to_byte_array()
	var ordinary_canonical_before:=0
	for slot in range(3,64):
		if pose_bits(candidate.skins[1].skeleton,slot)==canonical_bits:ordinary_canonical_before+=1
	check(ordinary_canonical_before==61,kind+": all ordinary sparse poses are bit-exact identity before first publication")
	original_publish(original)
	check(int(candidate.publisher.call("publish"))==0,kind+": guarded skeleton publication completes")
	check(capture(original)==capture(candidate),kind+": guarded skeleton exact pose parity")
	var first_state: Dictionary=candidate.publisher.call("inspect")
	check(first_skin.writes.size()==1 and int(first_skin.writes[0])==64,kind+": first skin explicitly retains all 64 writes on first publication")
	check(int(first_state.bone_writes)>=67 and int(first_state.bone_writes)<=128,kind+": first ordinary skin may conservatively use legacy writes during setup")
	original_publish(original)
	check(int(candidate.publisher.call("publish"))==0,kind+": warmed publication completes")
	check(capture(original)==capture(candidate),kind+": warmed exact pose parity")
	var state: Dictionary=candidate.publisher.call("inspect")
	var second_writes:=int(state.bone_writes)-int(first_state.bone_writes)
	check(first_skin.writes.size()==2 and int(first_skin.writes[1])-int(first_state.bone_writes)==64,kind+": first skin explicitly retains all 64 writes on warmed publication")
	check(second_writes==(67 if expect_skip else 128),kind+": ordinary second skin follows selected route after warmup")
	original.publisher=null;candidate.publisher=null
	case_reports.append({"label":kind+"-fallback","ordinary_slot_before_bits":ordinary_slot_before.hex_encode(),"ordinary_canonical_before":ordinary_canonical_before,"first_writes":first_state.bone_writes,"second_writes":second_writes,"first_skin_cumulative_writes":first_skin.writes,"state":state})

func check_empty_skin_fallback(expect_skip: bool) -> void:
	var original: Dictionary=create_case()
	var candidate: Dictionary=create_case()
	for row: Dictionary in [original,candidate]:
		for skin: Dictionary in row.skins:
			for slot in 64:skin.bones[slot]=-1
	original_publish(original)
	check(int(candidate.publisher.call("publish"))==0,"All-empty skin publication completes")
	check(capture(original)==capture(candidate),"All-empty skin exact pose parity")
	var state: Dictionary=candidate.publisher.call("inspect")
	check(int(state.bone_writes)==128,"All-empty skin retains writes and deferred observer notification")
	original.publisher=null;candidate.publisher=null
	case_reports.append({"label":"all-empty-fallback","state":state,"skip_enabled":expect_skip})

func check_deferred_observers(expect_skip: bool) -> void:
	var original: Dictionary=create_case()
	var candidate: Dictionary=create_case()
	for row: Dictionary in [original,candidate]:
		for skin: Dictionary in row.skins:
			for slot in 64:skin.bones[slot]=slot if slot<3 else -1
	var old_pose: Array=[];var new_pose: Array=[]
	var old_deferred: Array=[];var new_deferred: Array=[]
	for skin_index in 2:
		original.skins[skin_index].skeleton.pose_updated.connect(func():old_pose.append(skin_index))
		candidate.skins[skin_index].skeleton.pose_updated.connect(func():new_pose.append(skin_index))
		original.skins[skin_index].skeleton.skeleton_updated.connect(func():old_deferred.append(skin_index))
		candidate.skins[skin_index].skeleton.skeleton_updated.connect(func():new_deferred.append(skin_index))
	# Drain construction notifications so only publication is counted.
	await process_frame
	await process_frame
	old_pose.clear();new_pose.clear();old_deferred.clear();new_deferred.clear()
	for frame in 3:
		original_publish(original)
		check(int(candidate.publisher.call("publish"))==0,"Observed publication completes frame "+str(frame))
		check(old_pose==new_pose and old_pose.size()==(frame+1)*2,"Synchronous pose_updated count/order preserved frame "+str(frame))
		await process_frame
		await process_frame
		check(old_deferred==new_deferred and old_deferred.size()==(frame+1)*2,"Deferred skeleton_updated count/order preserved frame "+str(frame))
	original.publisher=null;candidate.publisher=null
	case_reports.append({"label":"signal-observers","pose_count":old_pose.size(),"deferred_count":old_deferred.size(),"skip_enabled":expect_skip})

func run() -> void:
	if not options.has("report") or FileAccess.file_exists(options.report):quit(2);return
	if not ClassDB.class_exists("NwnRigSkinPublisher"):check(false,"Native publisher exists");finish({});return
	var expect_skip: bool=options.get("expect-skip","off")=="on"
	var slots: Array[int]=[]
	for slot in 64:slots.append(slot if slot<3 else -1)
	compare_sparse("synthetic-3-of-64",24,slots,expect_skip)
	for kind in ["plain-child","extra-internal","simulating-physics"]:check_child_fallback(expect_skip,kind)
	check_empty_skin_fallback(expect_skip)
	await check_deferred_observers(expect_skip)
	if options.has("install"):original_sparse_cases(str(options.install),expect_skip)
	else:check(false,"Original install path supplied for sparse asset coverage")
	finish({"cases":case_reports,"expected_skip":expect_skip,"scope":"Original scalar oracle versus private native sparse candidate over 24 animated frames per case; live external pose edits, -identity quaternion, between-skin callback mutation, exact force order and retirement. No GPU/FPS timing."})
