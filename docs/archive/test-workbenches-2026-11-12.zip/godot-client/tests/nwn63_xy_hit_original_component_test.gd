extends SceneTree
# Component-only trial: reuse the cached XY points after an original WOK face
# misses the interior test. The production collision owner is unchanged.
const HitCandidate=preload("res://systems/native_render/drive_collision_indexed.gd")
const Collision=preload("res://.cache/nwn63/xy-hit-a/drive_collision_before.gd")
const TileSurface=preload("res://systems/native_data/tile_surface.gd")
const Table=preload("res://systems/native_data/two_da.gd")
const Binary=preload("res://systems/native_data/binary_data.gd")
const Catalog=preload("res://systems/native_data/resource_catalog.gd")
var checks:=0
var failures: Array=[]

func _initialize()->void:call_deferred("run")
func check(value: bool,label: String)->void:
	checks+=1
	if not value:failures.append(label)
func digest(bytes: PackedByteArray)->String:
	var hash:=HashingContext.new();hash.start(HashingContext.HASH_SHA256);hash.update(bytes);return hash.finish().hex_encode()

func run()->void:
	var options:={}
	for argument in OS.get_cmdline_user_args():
		var split:=argument.trim_prefix("--").split("=",true,1)
		if split.size()==2:options[split[0]]=split[1]
	if not options.has("fixture") or not options.has("report"):quit(2);return
	var fixture: Variant=JSON.parse_string(FileAccess.get_file_as_string(str(options.fixture)))
	check(fixture is Dictionary and fixture.get("sources") is Array and fixture.get("table_sha256") is String,"Pinned original WOK corpus")
	if not failures.is_empty():quit(2);return
	var catalog:=Catalog.new()
	var install:=str(options.get("install",ProjectSettings.globalize_path("res://../../FullDecomp/NwnRootInstall")))
	check(catalog.mount_install(install),"Original install mounts read-only")
	if not failures.is_empty():quit(2);return
	var table_bytes: PackedByteArray=catalog.get_resource("surfacemat",2017)
	var parser:=Table.new();var table: Dictionary=parser.parse(Binary.new(table_bytes).text(0,table_bytes.size()))
	check(digest(table_bytes)==str(fixture.table_sha256) and parser.failure.is_empty(),"Exact original surfacemat bytes")
	var ranked: Array=fixture.sources.duplicate()
	ranked.sort_custom(func(a: Dictionary,b: Dictionary)->bool:return int(a.faces)>int(b.faces) if int(a.faces)!=int(b.faces) else str(a.name)<str(b.name))
	var selected: Array=[]
	if str(options.get("all","off"))=="on":selected=ranked
	else:
		for i in [0,1,2,3,34,35,36,37]:selected.append(ranked[i])
	var queries: Array=[];var source_rows: Array=[]
	for sample in selected:
		var bytes: PackedByteArray=catalog.get_resource(str(sample.name),2016)
		var decoder:=TileSurface.new();var mesh: Dictionary=decoder.parse_bytes(bytes)
		check(not bytes.is_empty() and decoder.failure.is_empty() and digest(bytes)==str(sample.sha256) and mesh.faces.size()==int(sample.faces),"Exact original WOK "+str(sample.name))
		var before:=queries.size()
		for face_index in mesh.faces.size():
			if TileSurface.walkable(table,int(mesh.materials[face_index])):continue
			var face: Array=mesh.faces[face_index]
			var va: Array=mesh.vertices[int(face[0])];var vb: Array=mesh.vertices[int(face[1])];var vc: Array=mesh.vertices[int(face[2])]
			var tri: Dictionary=Collision.triangle(Vector3(float(va[0]),float(va[1]),float(va[2])),Vector3(float(vb[0]),float(vb[1]),float(vb[2])),Vector3(float(vc[0]),float(vc[1]),float(vc[2])))
			var a: Vector2=tri.xy_points[0];var b: Vector2=tri.xy_points[1];var c: Vector2=tri.xy_points[2]
			var edge:=b-a
			if edge.length_squared()<0.00001:continue
			var outward:=Vector2(-edge.y,edge.x).normalized()
			if (c-a).dot(outward)>0:outward=-outward
			var center: Vector2=(a+b)*0.5+outward*0.05
			var from:=center;var to:=center+edge.normalized()*0.05
			if Collision.interval(from,to,tri).x<=Collision.interval(from,to,tri).y:continue
			for radius in [0.0,0.05,0.2,1.0]:
				var low: float=float(tri.min.z)-0.1;var high: float=float(tri.max.z)+0.1
				var control: bool=Collision.hits(from,to,tri,radius,low,high)
				var candidate: bool=HitCandidate.hits(from,to,tri,radius,low,high)
				check(control==candidate,"Exact original face hit "+str(sample.name)+"/"+str(face_index)+"/"+str(radius))
				queries.append([from,to,tri,radius,low,high])
		source_rows.append({"name":sample.name,"faces":mesh.faces.size(),"tested_queries":queries.size()-before})
	check(queries.size()>=40,"Original nonwalkable edge-query sample")
	var legacy_triangle: Dictionary=Collision.triangle(Vector3(0,0,0),Vector3(2,0,0),Vector3(0,2,0))
	legacy_triangle.erase("xy_points")
	for from in [Vector2(-0.1,0.2),Vector2(0.5,0.5),Vector2(3,3)]:
		for radius in [0.0,0.2,1.0]:
			check(Collision.hits(from,from+Vector2(0.1,0),legacy_triangle,radius,-1,1)==HitCandidate.hits(from,from+Vector2(0.1,0),legacy_triangle,radius,-1,1),"Uncached external triangle fallback")
	var blocks: Array=[];var iterations:=maxi(1,mini(200,int(options.get("iterations",80))))
	for candidate in [false,true,true,false]:
		var began:=Time.get_ticks_usec();var hit_count:=0
		for repetition in iterations:
			for query in queries:
				if HitCandidate.hits(query[0],query[1],query[2],float(query[3]),float(query[4]),float(query[5])) if candidate else Collision.hits(query[0],query[1],query[2],float(query[3]),float(query[4]),float(query[5])):hit_count+=1
		blocks.append({"candidate":candidate,"elapsed_us":Time.get_ticks_usec()-began,"calls":iterations*queries.size(),"hits":hit_count})
	check(blocks[0].hits==blocks[1].hits and blocks[1].hits==blocks[2].hits and blocks[2].hits==blocks[3].hits,"Identical hit totals")
	var report:={"success":failures.is_empty(),"checks":checks,"failures":failures,"fixture_sha256":FileAccess.get_sha256(str(options.fixture)),"sources":source_rows,"query_count":queries.size(),"blocks":blocks,"scope":"Original SHA-pinned WOK nonwalkable face geometry; authored near-edge static hits component only. No whole preview, movement, frame/FPS or Arelith claim."}
	var file:=FileAccess.open(str(options.report),FileAccess.WRITE);file.store_string(JSON.stringify(report,"  "));file.close()
	print(JSON.stringify({"success":report.success,"checks":checks,"query_count":queries.size(),"blocks":blocks}));quit(0 if failures.is_empty() else 1)
