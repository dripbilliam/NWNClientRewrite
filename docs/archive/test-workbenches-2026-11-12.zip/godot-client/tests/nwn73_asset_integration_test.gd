extends SceneTree
const Assets=preload("res://systems/native_data/asset_service.gd")
const Pool=preload("res://systems/native_render/resource_pool.gd")
const Preparation=preload("res://systems/native_data/raster_upload_preparation.gd")
const Store=preload("res://systems/native_data/preparation_store.gd")
var checks:=0
var failures: Array=[]
class LocalCatalog:
	extends RefCounted
	var failure:=""
	var sources: Dictionary={}
	var prepared:=Store.new()
	var decoded:=Store.new()
	func fork() -> RefCounted:
		var value:=LocalCatalog.new();value.sources=sources;value.prepared=prepared;value.decoded=decoded;return value
	func preparation_cache():return prepared
	func decoded_cache():return decoded
	func get_resource(name: String,type: int) -> PackedByteArray:
		failure="";var key:=name+":"+str(type)
		if not sources.has(key):failure="Fixture source unavailable";return PackedByteArray()
		return sources[key]
	func has_resource(name: String,type: int) -> bool:return sources.has(name+":"+str(type))
	func raster_location(name: String) -> Dictionary:return {"name":name,"type":3} if has_resource(name,3) else {}
func _initialize() -> void:call_deferred("run")
func check(ok: bool,label: String) -> void:
	checks+=1
	if not ok:failures.append(label);print("FAIL: ",label)
func wait_task(service: Node,id: int) -> void:
	while service.running.has(id) and not WorkerThreadPool.is_task_completed(int(service.running[id])):await process_frame
func context(source: RefCounted) -> Dictionary:
	var pool:=Pool.new();var scope:=Node.new();scope.set_meta("native_publication_pool",pool);root.add_child(scope)
	var service:=Assets.new();scope.add_child(service);service.configure(source);service.set_process(false)
	return {"pool":pool,"scope":scope,"service":service}
func close_context(value: Dictionary) -> void:
	value.service.close();value.scope.free();value.pool.clear()
func extra_report() -> Dictionary:return {}
func request_once(value: Dictionary,name: String,type: int,decoder: String,mutate: bool=false) -> Dictionary:
	var delivered: Array=[];var source: Node=value.service;var pool: RefCounted=value.pool
	var callback:=func(_id,result):
		check(OS.get_thread_caller_id()==OS.get_main_thread_id(),"Actual completion signal stays on main")
		check(not result.has("_raster_upload_sidecar"),"Sidecar erased before ANY completion listener")
		check(int(result.get("thread",0))!=OS.get_main_thread_id(),"Actual AssetService job runs off main")
		var raster: Dictionary=result if decoder=="raster" else result.textures.c_amethyst
		var before: int=raster.value.mips[0].data[0]
		if mutate:raster.value.mips[0].data[0]=before^255
		var texture: Texture2D=pool.texture(raster)
		check(texture!=null and texture.get_width()==512 and texture.get_height()==512,"Actual pool texture consumes complete original dimensions")
		if mutate:raster.value.mips[0].data[0]=before
		delivered.append({"result":result,"texture":texture,"pool":pool.snapshot()})
	source.completed.connect(callback)
	var id: int=source.request(name,type,decoder);source.set_process(false);check(id>0 and source.running.has(id),"One existing asset job enqueued")
	await wait_task(source,id)
	check(WorkerThreadPool.is_task_completed(int(source.running[id])),"Original job includes ready CPU work before completion")
	var frame:=Engine.get_process_frames();source._profile_process(0.0)
	check(delivered.size()==1 and not source.running.has(id),"First normal completion drain delivers prepared result")
	check(Engine.get_process_frames()==frame,"No extra task/poll/frame barrier added")
	source.completed.disconnect(callback)
	return delivered[0] if not delivered.is_empty() else {}
func run() -> void:
	var args: Dictionary={}
	for arg in OS.get_cmdline_user_args():
		var pair:=arg.trim_prefix("--").split("=",true,1)
		if pair.size()==2:args[pair[0]]=pair[1]
	if not args.has("report") or FileAccess.file_exists(args.report):quit(2);return
	var setting: bool=Preparation.configured_enabled();Preparation.clear()
	var corpus: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://originals/corpus.json"));var original: Dictionary={}
	for row in corpus.records:
		if row.name=="c_amethyst":original=row;break
	var bytes:=FileAccess.get_file_as_bytes("res://originals/"+str(original.file))
	check(FileAccess.get_sha256("res://originals/"+str(original.file))==str(original.sha256),"Actual recorded original raster source is pinned")
	var source:=LocalCatalog.new();source.sources={"c_amethyst:3":bytes,"raster73:2002":("newmodel raster73\nclassification tile\nbeginmodelgeom raster73\nnode dummy root\nparent NULL\nendnode\nnode trimesh body\nparent root\nbitmap c_amethyst\nrender 1\nshadow 1\nverts 3\n0 0 0\n1 0 0\n0 1 0\nfaces 1\n0 1 2 1 0 0 0 0\nendnode\nendmodelgeom raster73\ndonemodel raster73\n").to_ascii_buffer()}
	var value:=context(source);check(value.pool.raster_upload_preparation_active()==setting,"Private setting and actual pool capability match")
	var direct:=await request_once(value,"c_amethyst",3,"raster")
	var first:=await request_once(value,"raster73",2002,"static-model")
	var warm:=await request_once(value,"raster73",2002,"static-model")
	check(bool(warm.result.get("memory_cache_hit",false)),"Actual model bundle memory-hit path exercised")
	check(Pool.Template.identity(first.result,value.pool)==Pool.Template.identity(warm.result,value.pool),"Actual template key bytes ignore sidecar/runtime preparation")
	check(str(direct.result.sha256) in value.pool.textures,"Original source SHA remains exact texture key")
	var counts: Dictionary=value.pool.snapshot().raster_upload_preparation.counts
	if setting:
		check(int(counts.worker_jobs)>=3 and int(counts.consumed)==1 and int(counts.fallbacks)==0,"Actual cold+warm worker preparation and one main upload engaged")
		check(value.pool.ready_raster_bytes==0,"Material/texture cache hits retain no unused ready pixels here")
	else:check(int(counts.worker_jobs)==0 and int(counts.consumed)==0 and Preparation.snapshot().requests==0,"Absent/private-false setting retains original path")
	var snapshot: Dictionary=value.pool.snapshot().raster_upload_preparation
	close_context(value)
	if setting:
		# Completion listeners may legally edit pixels without changing the SHA.
		var changed:=context(source);await request_once(changed,"c_amethyst",3,"raster",true)
		check(changed.pool.raster_upload_counts.consumed==0 and changed.pool.raster_upload_counts.fallbacks==1,"Actual listener pixel mutation uses faithful unprepared upload")
		close_context(changed)
		var cancelled:=context(source);var emitted: Array=[];cancelled.service.completed.connect(func(_id,_result):emitted.append(true))
		var id: int=cancelled.service.request("c_amethyst",3,"raster");cancelled.service.set_process(false);cancelled.service.retire_scope();cancelled.service.set_process(false)
		await wait_task(cancelled.service,id);cancelled.service._profile_process(0.0)
		check(emitted.is_empty() and cancelled.pool.raster_upload_counts.worker_jobs==0 and cancelled.pool.ready_raster_bytes==0,"Cancelled epoch never adopts ready pixels or delivers an old result")
		close_context(cancelled)
		var main_guard:=Assets.new();var before: int=Preparation.snapshot().requests
		main_guard.publish_result({"id":999,"status_only":false,"decoder":"raster","raster_upload_preparation":true},{"value":direct.result.value,"sha256":direct.result.sha256,"error":"","worker_ms":0.0})
		check(Preparation.snapshot().requests==before and not main_guard.results[999].has("_raster_upload_sidecar"),"Even a direct main-thread fast publish cannot perform Image preparation")
		main_guard.close();main_guard.free()
	Preparation.clear();check(Preparation.snapshot().retained_bytes==0 and Preparation.snapshot().inflight==0,"All helper-retained bytes and producer flights release")
	var report:={"issue":"NWN-73","success":failures.is_empty(),"checks":checks,"failures":failures,"enabled":setting,"actual_pool":snapshot,"scope":"Actual AssetService request/task/publish/completion and actual ResourcePool adapter using pinned original Arelith pixels plus a separately authored one-mesh binding. Cold/direct/model-memory-hit paths, source/template keys, listener mutation, cancelled epoch, main-fast-publish guard and no additional completion frame. Headless correctness, no FPS/loading/performance claim."}
	report.merge(extra_report())
	var file:=FileAccess.open(args.report,FileAccess.WRITE);file.store_string(JSON.stringify(report,"\t"));file.close();print("NWN73_ASSET_INTEGRATION ",checks," checks; ",failures.size()," failures");quit(0 if failures.is_empty() else 1)
