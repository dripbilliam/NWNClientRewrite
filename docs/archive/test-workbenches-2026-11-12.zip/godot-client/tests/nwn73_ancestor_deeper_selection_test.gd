extends SceneTree
const Ancestors=preload("res://systems/native_data/ancestor_preparation.gd")

class Reader:
	extends RefCounted
	var entries: Dictionary={}
	var failure: String=""
	func fork() -> RefCounted:return self
	func get_resource(name: String,_type: int) -> PackedByteArray:
		if entries.has(name):failure="";return entries[name]
		failure="Missing test ancestor";return PackedByteArray()
	func decoded_cache():return null

class Decoder:
	extends RefCounted
	var fail:=false
	func decode(_bytes: PackedByteArray,_type: int,_format: String,_cache: String,_store) -> Dictionary:
		return {"error":"Speculative decoder failure" if fail else "","timings":{}}

var checks:=0
var failures: Array[String]=[]
func _initialize() -> void:call_deferred("run")
func check(ok: bool,label: String) -> void:
	checks+=1
	if not ok:failures.append(label)
func model(name: String,parent: String,size: int) -> PackedByteArray:
	var header:="newmodel "+name+"\n"+("setsupermodel "+name+" "+parent+"\n" if not parent.is_empty() else "")+"beginmodelgeom "+name+"\n"
	var result:=header.to_ascii_buffer()
	result.resize(maxi(size,result.size()))
	return result
func selected(reader: Reader,name: String,raw: PackedByteArray,decoder: Decoder) -> Dictionary:
	var state:=Ancestors.start(reader,name,raw,"",decoder.decode)
	var names: Array=[]
	for job in state.jobs:names.append(str(job.name))
	var metrics:=Ancestors.finish(state)
	return {"names":names,"metrics":metrics}
func run() -> void:
	var report:=""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):report=arg.trim_prefix("--report=")
	if report.is_empty() or FileAccess.file_exists(report):quit(2);return
	var deeper:=Ancestors.configured_deeper_prefetch()
	var reader:=Reader.new();var decoder:=Decoder.new()
	reader.entries={"near":model("near","mid",1000),"mid":model("mid","far",900),"far":model("far","",950)}
	var chain:=selected(reader,"root",model("root","near",100),decoder)
	check(chain.names==(["far"] if deeper else ["near"]),"Multi-parent selection chooses the largest deeper source")
	check(chain.metrics.jobs_started==1 and chain.metrics.sources.size()==1 and Ancestors.snapshot().active==0,"Multi-parent helper joins and releases its one credit")
	reader.entries={"only":model("only","",100)}
	var one:=selected(reader,"root",model("root","only",100),decoder)
	check(one.names==["only"] and Ancestors.snapshot().active==0,"One-parent chain retains its only helper")
	reader.entries={"near":model("near","mid",1000),"mid":model("mid","far",900),"far":model("far","",900)}
	var tie:=selected(reader,"root",model("root","near",100),decoder)
	check(tie.names==(["mid"] if deeper else ["near"]),"Equal deeper sizes preserve nearest source depth")
	var malformed:=selected(reader,"root",model("root","../escape",100),decoder)
	check(malformed.names.is_empty() and Ancestors.snapshot().active==0,"Malformed parent hint starts no helper")
	decoder.fail=true
	var failed:=selected(reader,"root",model("root","near",100),decoder)
	check(failed.metrics.sources.size()==1 and failed.metrics.sources[0].error=="Speculative decoder failure" and Ancestors.snapshot().active==0,"Failed speculative task joins without leaked credit")
	var file:=FileAccess.open(report,FileAccess.WRITE)
	file.store_string(JSON.stringify({"success":failures.is_empty(),"checks":checks,"failures":failures,"deeper":deeper,"selected_chain":chain.names,"selected_one":one.names,"selected_tie":tie.names,"selected_failed":failed.names,"scope":"Pure source-selection, bounded helpers, malformed hints and failed task cleanup; no performance or original asset claim."},"\t"))
	file.close();quit(0 if failures.is_empty() else 1)
