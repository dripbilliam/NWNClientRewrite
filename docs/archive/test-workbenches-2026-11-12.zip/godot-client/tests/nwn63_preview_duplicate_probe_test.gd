extends "res://tests/nwn63_single_preview_breakdown_test.gd"
# Count exact repeated clearance endpoints in the full blocked 38-probe path.
# This is authored geometry at captured group scale, not a live input trace.
func run()->void:
	var options: Dictionary={}
	for argument in OS.get_cmdline_user_args():
		var parts:=argument.trim_prefix("--").split("=",true,1)
		if parts.size()==2:options[parts[0]]=parts[1]
	var pair:=group_pair(340)
	var setup: Dictionary=pair[1];var collision=setup.collision
	var from:=Vector3(1,1,0);var target:=Vector3(3,1,0)
	var cases: Array=[]
	for density in [2,1152]:
		if density==1152:grid_mesh(setup.world,24)
		collision.tiles.clear()
		var geometry: Array=collision.tile(0)
		var blocker: Dictionary=Collision.triangle(Vector3(0,0,0),Vector3(5,0,0),Vector3(0,5,0))
		blocker.walk=false;geometry.append(blocker)
		var path: Dictionary=profile_path(collision,"preview",from,target,false)
		var first_by_probe: Dictionary={};var repeats: Array=[]
		for index in path.transcript.size():
			var row: Array=path.transcript[index]
			var key:=var_to_bytes([row[0],row[1]]).hex_encode()
			if first_by_probe.has(key):repeats.append([first_by_probe[key],index])
			else:first_by_probe[key]=index
		check(path.transcript.size()==38,"Full blocked search uses 38 calls at density "+str(density))
		cases.append({"floor_faces":density,"probes":path.transcript.size(),"unique_exact_endpoints":first_by_probe.size(),"repeat_indices":repeats})
	for owner in pair:owner.world.free()
	await process_frame;await process_frame
	var report:={"success":failures.is_empty(),"checks":checks,"failures":failures,"cases":cases,"scope":"Authored 342-group blocked 38-probe path; exact float32 endpoint byte identity only, no live-server equivalence, timings or FPS."}
	if options.has("report"):
		var file:=FileAccess.open(str(options.report),FileAccess.WRITE);file.store_string(JSON.stringify(report,"  "));file.close()
	print(JSON.stringify(report));quit(0 if failures.is_empty() else 1)
