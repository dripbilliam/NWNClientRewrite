extends SceneTree

const Candidate=preload("res://systems/native_data/actor_model.gd")
const Baseline=preload("res://.cache/nwn73/binary-clips-next-a/actor_model-baseline.gd")
var checks:=0
var failures: Array[String]=[]

func _initialize() -> void: call_deferred("run")
func check(ok: bool,label: String) -> void:
	checks+=1
	if not ok:failures.append(label)
func same(a: Variant,b: Variant) -> bool:return var_to_bytes(a)==var_to_bytes(b)
func corrupt_clip(bytes: PackedByteArray,index: int) -> PackedByteArray:
	var changed:=bytes.duplicate()
	var table:=12+changed.decode_u32(12+120)
	changed.encode_u32(table+index*4,changed.decode_u32(4))
	return changed
func same_failure(bytes: PackedByteArray,label: String,expected_reason: String="") -> void:
	var original:=Baseline.new();var current:=Candidate.new()
	var old_result: Dictionary=original.parse(bytes)
	var new_result: Dictionary=current.parse(bytes)
	check(old_result.is_empty() and new_result.is_empty() and original.failure==current.failure and not original.failure.is_empty() and (expected_reason.is_empty() or original.failure==expected_reason),label)
func check_source(name: String,bytes: PackedByteArray) -> void:
	var original:=Baseline.new();var current:=Candidate.new()
	var expected: Dictionary=original.parse(bytes)
	var actual: Dictionary=current.parse(bytes)
	check(original.failure.is_empty() and current.failure.is_empty(),name+" valid parses succeed")
	check(expected.get("nodes",[]).size()==actual.get("nodes",[]).size(),name+" physical node count")
	check(expected.get("animations",[]).size()==actual.get("animations",[]).size(),name+" clip count and order")
	for key in ["name","supermodel","animation_scale","behavior_version","classification_flags"]:
		check(same(expected.get(key),actual.get(key)),name+" model field "+key)
	for index in mini(expected.get("nodes",[]).size(),actual.get("nodes",[]).size()):
		check(same(expected.nodes[index],actual.nodes[index]),name+" physical node "+str(index))
	for index in mini(expected.get("animations",[]).size(),actual.get("animations",[]).size()):
		check(same(expected.animations[index],actual.animations[index]),name+" clip "+str(index))
	var clip_count:=int(bytes.decode_u32(12+124))
	for index in [0,int(clip_count/2),clip_count-1]:
		same_failure(corrupt_clip(bytes,index),name+" corrupt clip "+str(index)+" retains earliest error")
	var mixed:=corrupt_clip(bytes,clip_count-1)
	var table:=12+mixed.decode_u32(12+120)
	var first_at:=12+mixed.decode_u32(table)
	mixed.encode_u32(first_at+188,100001)
	same_failure(mixed,name+" first event-count error wins over later clip pointer","Original animation events are invalid")
	var header_table:=bytes.duplicate();header_table.encode_u32(12+120,0)
	same_failure(header_table,name+" header-overlapping table keeps original error")
	if name=="a_dfa":
		var inflated:=bytes.duplicate();inflated.resize(8*1024*1024+1)
		var started_before:=int(Candidate.binary_clip_helper_snapshot().started)
		current=Candidate.new()
		var capped: Dictionary=current.parse(inflated)
		check(current.failure.is_empty() and capped.get("animations",[]).size()==expected.animations.size() and int(Candidate.binary_clip_helper_snapshot().started)==started_before,name+" over-cap source keeps serial path")
	check(Candidate.binary_clip_helper_snapshot().active==0,name+" helper joined after valid and invalid parses")

func run() -> void:
	var output:=""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.trim_prefix("--report=")
	if output.is_empty() or FileAccess.file_exists(output):quit(2);return
	var archive_path:=ProjectSettings.globalize_path("res://.cache/loading-benchmark-worlds/arelith-archive-shaders-v1/catalog-1/resources.erf")
	var archive:=FileAccess.open(archive_path,FileAccess.READ)
	if archive==null or archive.get_length()!=289956979:quit(3);return
	for source in [{"name":"a_ba","offset":20148484,"bytes":5990990},{"name":"a_dfa","offset":36825551,"bytes":1694488}]:
		archive.seek(int(source.offset))
		var bytes: PackedByteArray=archive.get_buffer(int(source.bytes))
		check(bytes.size()==int(source.bytes) and bytes.decode_u32(0)==0,str(source.name)+" exact saved binary payload")
		check_source(str(source.name),bytes)
	archive.close()
	var snapshot: Dictionary=Candidate.binary_clip_helper_snapshot()
	var selected:=OS.get_cmdline_user_args().has("--binary-clips=parallel")
	var inline:=OS.get_cmdline_user_args().has("--binary-clips=inline")
	if selected:check(int(snapshot.started)>=2 and int(snapshot.active)==0,"Parallel mode started and joined bounded helpers")
	if inline:check(int(snapshot.started)==0 and int(snapshot.start_fallbacks)>=2 and int(snapshot.active)==0,"Inline mode exercised thread-start fallback")
	var report:={"passed":failures.is_empty(),"checks":checks,"failures":failures,"parallel":selected,"inline_fallback":inline,"helpers":snapshot,
		"scope":"Exact saved a_ba/a_dfa binary source node/clip bytes and ordered malformed-clip errors versus pre-change script; no loading/FPS claim."}
	var file:=FileAccess.open(output,FileAccess.WRITE);file.store_string(JSON.stringify(report,"\t"));file.close()
	quit(0 if failures.is_empty() else 1)
