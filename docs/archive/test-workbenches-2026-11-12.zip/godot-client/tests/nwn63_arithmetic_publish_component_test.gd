extends SceneTree
# Exact counter/publication oracle against the frozen pre-edit source, then
# bounded headless component timing. No client, original scene, or FPS claim.
const Profile=preload("res://systems/native_render/frame_profile.gd")
var checks:=0
var failures: Array=[]
func check(value: bool,label: String)->void:
	checks+=1
	if not value:failures.append(label)
func observation(owner)->Dictionary:
	return {"ledger":owner._ledger.duplicate(true),"published":owner._published.duplicate(),"profile":Profile.phases.duplicate(true)}
func stats(values: Array)->Dictionary:
	var ordered:=values.duplicate();ordered.sort()
	return {"samples":values,"median_usec":ordered[ordered.size()/2],"minimum_usec":ordered[0],"maximum_usec":ordered[-1]}
func _initialize()->void:
	var options: Dictionary={}
	for argument in OS.get_cmdline_user_args():
		var parts:=argument.trim_prefix("--").split("=",true,1)
		if parts.size()==2:options[parts[0]]=parts[1]
	var script=load(str(options.get("source","res://systems/native_render/drive_preview_arithmetic.gd")))
	if script==null:print("Arithmetic source unavailable");quit(1);return
	var owner=script.new();owner._ledger={"arithmetic_peak_bytes":-7};owner.bytes=42
	Profile.enabled=true;Profile.phase_frame=-1;Profile.collected_frame=-1;Profile.phases={}
	var observed: Array=[]
	owner.counts.term_prepares=3;owner.counts.term_reuses=2;owner.counts.height_hits=1
	owner.publish();observed.append(observation(owner))
	check(owner._ledger=={"arithmetic_peak_bytes":42,"from_terms_prepared":3,"from_terms_reused":2,"height_memo_hits":1},"First publication values and peak")
	owner.publish();observed.append(observation(owner))
	check(observed[0]==observed[1],"No-change publication remains exact")
	owner._ledger.from_terms_prepared=100;owner._ledger.arithmetic_peak_bytes=75;owner.bytes=10
	owner.counts.term_prepares=1;owner.counts.term_reuses=5;owner.counts.budget_fallbacks=4
	owner.publish();observed.append(observation(owner))
	check(int(owner._ledger.from_terms_prepared)==98 and int(owner._ledger.from_terms_reused)==5 and int(owner._ledger.arithmetic_budget_fallbacks)==4 and int(owner._ledger.arithmetic_peak_bytes)==75,"Negative delta and external ledger edits")
	owner._ledger.erase("height_memo_hits");owner.counts.height_hits=2;owner.publish();observed.append(observation(owner))
	check(int(owner._ledger.height_memo_hits)==1,"Missing externally removed counter uses zero base")
	check(int(Profile.phases.get("count_drive_from_terms_prepared",0))==1 and int(Profile.phases.get("count_drive_from_terms_reused",0))==5 and int(Profile.phases.get("count_drive_height_memo_hits",0))==2 and int(Profile.phases.get("count_drive_arithmetic_budget_fallbacks",0))==4,"Profiler deltas retain exact totals")
	Profile.enabled=false;Profile.phases={}
	var times: Array=[]
	for batch in 4:
		var work=script.new();work._ledger={};work.bytes=12000
		for warm in 200:
			work.counts.term_prepares+=1;work.counts.term_reuses+=1;work.counts.height_hits+=1;work.publish()
		var began:=Time.get_ticks_usec()
		for index in 10000:
			work.counts.term_prepares+=1
			work.counts.term_reuses+=1
			work.counts.height_hits+=1
			if index%64==0:work.counts.budget_fallbacks+=1
			work.publish()
		times.append(Time.get_ticks_usec()-began)
		check(int(work._ledger.from_terms_prepared)==10200 and int(work._ledger.from_terms_reused)==10200 and int(work._ledger.height_memo_hits)==10200 and int(work._ledger.arithmetic_budget_fallbacks)==157,"Batch "+str(batch)+" complete exact counters")
	var report:={"success":failures.is_empty(),"checks":checks,"failures":failures,"observed":observed,"component":stats(times),"scope":"Frozen-source control versus current-source identical fixture; 10,000 publications/batch and exact ledger/profiler checks, headless only. Does not establish whole-preview/FPS gain."}
	if options.has("report"):
		var file:=FileAccess.open(str(options.report),FileAccess.WRITE)
		if file==null:failures.append("Report unavailable")
		else:file.store_string(JSON.stringify(report,"  "));file.close()
	print(JSON.stringify({"success":failures.is_empty(),"checks":checks,"component":report.component,"failures":failures}))
	quit(0 if failures.is_empty() else 1)
