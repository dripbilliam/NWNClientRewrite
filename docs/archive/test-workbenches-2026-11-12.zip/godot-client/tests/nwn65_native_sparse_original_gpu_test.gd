extends "res://tests/nwn65_rig_components_test.gd"
# Graphical correctness only. The model bytes, mesh vertices, weights, bind
# transforms and 64-slot skin all come from the installed original resources.
# Run the same private engine separately with sparse OFF and ON; no FPS sampling.
const Catalog=preload("res://systems/native_data/resource_catalog.gd")
const ActorModel=preload("res://systems/native_data/actor_model.gd")
const ActorInstance=preload("res://systems/native_render/actor_instance.gd")
const Rigs=preload("res://systems/model_rigs.gd")

const FAMILIES=[
	{"resource":"pme0_robe038","node":"apron"},
	{"resource":"c_goldem","node":"RWING"},
	{"resource":"pme2_robe030","node":"loincloth_B"},
]
var cases: Array=[]
var maximum_vertex_error:=0.0
var compared_vertices:=0
var bright_pixel_samples:=0

func sha256_bytes(bytes: PackedByteArray) -> String:
	var digest:=HashingContext.new()
	digest.start(HashingContext.HASH_SHA256)
	digest.update(bytes)
	return digest.finish().hex_encode()

func original_case(model: Dictionary,parser,index: int,native: bool) -> Dictionary:
	var host:=Node3D.new();root.add_child(host);roots.append(host)
	var rigs: Node=Rigs.new();host.add_child(rigs);rigs.set_process(false)
	var defaults: Array=parser.rig_asset(model).defaults
	var nodes: Array=[];var parents: Array=[]
	for part_index in model.nodes.size():
		var part: Dictionary=model.nodes[part_index]
		var parent:=int(part.parent)
		check(parent<part_index and parent>=-1,"Original physical node order "+str(part_index))
		if parent>=part_index or parent< -1:return {}
		var node:=Node3D.new();(host if parent<0 else nodes[parent]).add_child(node)
		var value: Dictionary=defaults[part_index]
		var p: Array=value.position;var q: Array=value.quaternion;var s: Array=value.scale
		node.position=Vector3(float(p[0]),float(p[1]),float(p[2]))
		node.quaternion=Quaternion(float(q[0]),float(q[1]),float(q[2]),float(q[3]))
		node.scale=Vector3(float(s[0]),float(s[1]),float(s[2]))
		nodes.append(node);parents.append(parent)
	var original: Dictionary=model.nodes[index]
	var actor:=ActorInstance.new()
	actor.use_prepared_skins=false
	var source: Dictionary=actor.skin_source(original,0,index)
	actor.free()
	check(not source.is_empty() and source.position.size()>0,"Original skin mesh vertices decoded")
	if source.is_empty() or source.position.is_empty():return {}
	var mesh:=MeshInstance3D.new();nodes[index].add_child(mesh)
	var parts: Array=[]
	for part_index in nodes.size():parts.append(part_index)
	var skin: Dictionary=rigs._skin(mesh,source,parts)
	check(not skin.is_empty() and skin.mesh.mesh!=null,"Original weighted skin installs")
	if skin.is_empty():return {}
	# The original mesh, weights and bind poses remain untouched. Its fixture
	# material only makes the actual deformed silhouette legible in a PNG.
	var display:=StandardMaterial3D.new()
	display.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
	display.cull_mode=BaseMaterial3D.CULL_DISABLED
	display.albedo_color=Color(1.0,0.72,0.35) if native else Color(0.45,0.85,1.0)
	mesh.material_override=display
	var entry:={"nodes":nodes,"parents":parents,"skins":[skin]}
	if native:
		rigs.entities[1]=entry
		rigs._refresh_processing();rigs.set_process(false)
	return {"host":host,"rigs":rigs,"nodes":nodes,"parents":parents,"skins":[skin],"entry":entry,"native":native}

func arrange_pair(old: Dictionary,candidate: Dictionary,row_number: int) -> Dictionary:
	# Frame each original piece from its actual mesh bounds. A uniform host
	# display transform does not change local skin poses or baked vertices.
	var mesh: MeshInstance3D=old.skins[0].mesh
	var local: AABB=mesh.mesh.get_aabb()
	var transform: Transform3D=mesh.global_transform
	var bounds:=AABB(transform*local.get_endpoint(0),Vector3.ZERO)
	for corner in range(1,8):bounds=bounds.expand(transform*local.get_endpoint(corner))
	var major:=maxf(bounds.size.x,maxf(bounds.size.y,bounds.size.z))
	check(is_finite(major) and major>0.0001,"Original mesh has finite visual bounds")
	var factor:=clampf(2.4/maxf(major,0.0001),0.0001,1000.0)
	var center:=bounds.get_center()
	for row in [old,candidate]:
		row.host.scale=Vector3.ONE*factor
		row.host.position=Vector3(-2.5 if not row.native else 2.5,float(row_number)*3.0,0.0)-center*factor
	return {"mesh_aabb_position":[local.position.x,local.position.y,local.position.z],"mesh_aabb_size":[local.size.x,local.size.y,local.size.z],"display_scale":factor}

func baked_error(old_mesh: MeshInstance3D,new_mesh: MeshInstance3D,label: String) -> void:
	var old: ArrayMesh=old_mesh.bake_mesh_from_current_skeleton_pose()
	var current: ArrayMesh=new_mesh.bake_mesh_from_current_skeleton_pose()
	check(old!=null and current!=null,label+": both original meshes bake")
	if old==null or current==null:return
	check(old.get_surface_count()==current.get_surface_count(),label+": surface counts")
	if old.get_surface_count()!=current.get_surface_count():return
	for surface in old.get_surface_count():
		var a: PackedVector3Array=old.surface_get_arrays(surface)[Mesh.ARRAY_VERTEX]
		var b: PackedVector3Array=current.surface_get_arrays(surface)[Mesh.ARRAY_VERTEX]
		check(a.size()==b.size() and a.size()>0,label+": real vertex counts")
		if a.size()!=b.size():continue
		for vertex in a.size():maximum_vertex_error=maxf(maximum_vertex_error,a[vertex].distance_to(b[vertex]))
		compared_vertices+=a.size()
		check(maximum_vertex_error<0.0004,label+": skinned vertex parity")

func run() -> void:
	if not options.has("report") or not options.has("install") or FileAccess.file_exists(options.report):quit(2);return
	if DisplayServer.get_name()=="headless":check(false,"Graphical renderer required");finish({});return
	if not ClassDB.class_exists("NwnRigSkinPublisher") or not Rigs.configured_native_skin_publisher():
		check(false,"Selected native ModelRigs publisher required");finish({});return
	var expect_skip: bool=options.get("expect-skip","off")=="on"
	check(OS.get_cmdline_user_args().has("--rig-native-sparse-skip=on")==expect_skip,"Sparse command line agrees with expected route")
	var catalog:=Catalog.new()
	if not catalog.mount_install(str(options.install)):check(false,"Original install mounts");finish({});return
	var environment:=WorldEnvironment.new();environment.environment=Environment.new()
	environment.environment.background_mode=Environment.BG_COLOR
	environment.environment.background_color=Color(0.07,0.09,0.13)
	root.add_child(environment)
	var light:=DirectionalLight3D.new();root.add_child(light);light.rotation_degrees=Vector3(-35,-25,0);light.light_energy=1.5
	var camera:=Camera3D.new();root.add_child(camera);camera.projection=Camera3D.PROJECTION_ORTHOGONAL;camera.size=10.0;camera.position=Vector3(5,4,18);camera.look_at(Vector3(0,3,0));camera.current=true
	for family in FAMILIES:
		var name: String=family.resource
		var bytes: PackedByteArray=catalog.read_resource(name,2002)
		check(not bytes.is_empty(),name+": installed original bytes")
		if bytes.is_empty():continue
		var parser:=ActorModel.new();parser.packed_keys=true
		var model: Dictionary=parser.parse(bytes)
		check(parser.failure.is_empty() and not model.is_empty(),name+": original decoder")
		if not parser.failure.is_empty() or model.is_empty():continue
		var index: int=-1
		for part_index in model.nodes.size():
			if str(model.nodes[part_index].name).to_lower()==str(family.node).to_lower() and model.nodes[part_index].has("skin"):
				index=part_index;break
		check(index>=0,name+": named original skin node")
		if index<0:continue
		var row_number: int=cases.size()
		var old: Dictionary=original_case(model,parser,index,false)
		var candidate: Dictionary=original_case(model,parser,index,true)
		if old.is_empty() or candidate.is_empty():continue
		var slots: Array=candidate.skins[0].bones
		var active:=0
		for slot in slots:
			if int(slot)>=0:active+=1
		check(slots.size()==64 and active>0 and active<64,name+": original sparse 64-slot map")
		var framing: Dictionary=arrange_pair(old,candidate,row_number)
		cases.append({"resource":name,"node":str(family.node),"resource_sha256":sha256_bytes(bytes),"source_bytes":bytes.size(),"vertices":int(old.skins[0].source.position.size()/3),"active_slots":active,"framing":framing,"old":old,"candidate":candidate,"warmup_writes":0})
	check(cases.size()==FAMILIES.size(),"All three original skin families installed")
	for frame in 24:
		for item in cases:
			var old: Dictionary=item.old;var candidate: Dictionary=item.candidate
			for row in [old,candidate]:
				var slot: int=-1
				for bone in row.skins[0].bones:
					if int(bone)>0:slot=int(bone);break
				if slot<0:
					for bone in row.skins[0].bones:
						if int(bone)>=0:slot=int(bone);break
				check(slot>=0,str(item.resource)+": valid animated original part")
				if slot<0:continue
				row.nodes[slot].position.y+=0.005*float(frame+1)
				row.nodes[slot].quaternion=Quaternion.from_euler(Vector3(frame*0.013,frame*0.021,frame*-0.009))
				if frame==11:
					for sparse_slot in row.skins[0].bones.size():
						if int(row.skins[0].bones[sparse_slot])<0:
							row.skins[0].skeleton.set_bone_pose_scale(sparse_slot,Vector3(1.0,1.3,1.0));break
			original_publish(old)
			check(int(candidate.rigs._publish_skin_native(1,candidate.entry))==0,str(item.resource)+": selected native publisher frame "+str(frame))
			check(capture(old)==capture(candidate),str(item.resource)+": exact original local/global bone bytes frame "+str(frame))
		await process_frame
		await RenderingServer.frame_post_draw
		for item in cases:baked_error(item.old.skins[0].mesh,item.candidate.skins[0].mesh,str(item.resource)+" frame "+str(frame))
		if frame==1:
			for item in cases:item.warmup_writes=int(item.candidate.rigs.native_skin_snapshot(1).bone_writes)
	for item in cases:
		var route: Dictionary=item.candidate.rigs.native_skin_snapshot(1)
		check(bool(route.get("sparse_skip_enabled",false))==expect_skip,str(item.resource)+": exact engine switch state")
		check(int(route.completed)==24 and int(route.fallbacks)==0 and int(route.partial_failures)==0,str(item.resource)+": native route completes without fallback")
		check(int(route.force_calls)==24,str(item.resource)+": one final force per original skin frame")
		var after_warmup:=int(route.bone_writes)-int(item.warmup_writes)
		check(after_warmup<22*64 and after_warmup>0 if expect_skip else after_warmup==22*64,str(item.resource)+": sparse write reduction after warmup")
		item.erase("old");item.erase("candidate")
		item["route"]=route;item["writes_after_warmup"]=after_warmup
	if options.has("image"):
		check(not FileAccess.file_exists(str(options.image)),"Graphical screenshot path is fresh")
		if not FileAccess.file_exists(str(options.image)):
			var screenshot: Image=root.get_texture().get_image()
			for y in range(0,screenshot.get_height(),4):
				for x in range(0,screenshot.get_width(),4):
					var pixel: Color=screenshot.get_pixel(x,y)
					if maxf(pixel.r,maxf(pixel.g,pixel.b))>0.3:bright_pixel_samples+=1
			check(bright_pixel_samples>=50,"Original skin silhouettes are visible in rendered screenshot")
			check(screenshot.save_png(str(options.image))==OK,"Graphical original-skin screenshot saved")
	for host in roots:host.free()
	roots.clear();camera.free();light.free();environment.free()
	finish({"families":cases,"expected_skip":expect_skip,"maximum_vertex_error":maximum_vertex_error,"compared_vertices":compared_vertices,"bright_pixel_samples":bright_pixel_samples,"renderer":DisplayServer.get_name(),"scope":"Original installed mesh/weights/bind/skin graphical bake and visible diagnostic material, exact native route and sparse write engagement; no FPS or Arelith material claim."})

func finish(extra: Dictionary) -> void:
	for host in roots:host.free()
	roots.clear()
	await process_frame
	var report:={"issue":"NWN-65","success":failures.is_empty(),"checks":checks,"failures":failures}
	report.merge(extra)
	var file:=FileAccess.open(options.report,FileAccess.WRITE)
	if file==null:push_error("Cannot write NWN-65 original-skin report");quit(2);return
	file.store_string(JSON.stringify(report,"\t")+"\n")
	file.close()
	print("NWN65_ORIGINAL_GPU ",checks," checks; ",failures.size()," failures")
	quit(0 if failures.is_empty() else 1)
