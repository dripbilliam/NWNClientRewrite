extends SceneTree
const Recorded=preload("res://systems/native_data/recorded_catalog.gd")
const Catalog=preload("res://systems/native_data/resource_catalog.gd")
func _initialize() -> void:call_deferred("run")
func run() -> void:
	var output:="";var path:=""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.substr(9)
		elif arg.begins_with("--catalog="):path=arg.substr(10)
	if output.is_empty() or path.is_empty() or FileAccess.file_exists(output):quit(2);return
	var phases:={};var began:=Time.get_ticks_usec()
	var file:=FileAccess.open(path.path_join("manifest.json"),FileAccess.READ)
	if file==null:quit(2);return
	var raw:=file.get_as_text();file.close()
	phases.read_ms=(Time.get_ticks_usec()-began)/1000.0;began=Time.get_ticks_usec()
	var value: Variant=JSON.parse_string(raw)
	phases.parse_ms=(Time.get_ticks_usec()-began)/1000.0;began=Time.get_ticks_usec()
	var invalid:=0
	for key in value.availability:
		var split:=str(key).rsplit(":",true,1)
		if split.size()!=2 or not str(split[1]).is_valid_int() or int(split[1])<0 or int(split[1])>65535 or str(split[0]).is_empty() or str(split[0]).length()>32 or "/" in key or "\\" in key or str(key).count(":")!=1 or int(value.availability[key]) not in [1,2,3,5]:invalid+=1
	phases.validate_availability_ms=(Time.get_ticks_usec()-began)/1000.0;began=Time.get_ticks_usec()
	var packed:=Catalog.new();var mounted:=packed.mount_erf(path.path_join("resources.erf"))
	phases.packed_mount_ms=(Time.get_ticks_usec()-began)/1000.0;began=Time.get_ticks_usec()
	var index:=packed.build_resource_index() if mounted else {}
	phases.packed_bindings_ms=(Time.get_ticks_usec()-began)/1000.0;began=Time.get_ticks_usec()
	var recorded:=Recorded.new()
	var sealed:=recorded._seal_graph([value,[{"kind":"recorded","entries":value.availability}]])
	phases.seal_ms=(Time.get_ticks_usec()-began)/1000.0;began=Time.get_ticks_usec()
	var full:=Recorded.new();var success:=full.mount(path)
	phases.full_mount_warm_ms=(Time.get_ticks_usec()-began)/1000.0
	var payload_checks:=0;var payload_failures: Array=[]
	if success:
		for key in value.resources:
			var row: Dictionary=value.resources[key]
			if row.has("error") or not row.has("sha256") or int(row.get("bytes",0))>1024*1024:continue
			var pair:=str(key).rsplit(":",true,1)
			if pair.size()!=2:continue
			var actual: PackedByteArray=full.get_resource(pair[0],int(pair[1]))
			var original: PackedByteArray=full.packed_catalog.get_resource(pair[0],int(pair[1]))
			payload_checks+=1
			if not full.failure.is_empty() or not full.packed_catalog.failure.is_empty() or actual!=original or actual.size()!=int(row.bytes):payload_failures.append(key)
			if payload_checks>=3:break
	var source_scope=full.cache_source_scope_v1() if success else null
	var report:={"success":success and invalid==0 and mounted and source_scope!=null and full.packed_catalog.resolved.size()==value.availability.size() and payload_checks==3 and payload_failures.is_empty(),"failure":full.failure,"invalid":invalid,"availability":value.availability.size(),"resources":value.resources.size(),"sealed_containers":sealed,"packed_entries":index.get("resolved_entries",0),"full_stats":full.stats,"full_layers":full.layers.size(),"full_bindings":full.packed_catalog.resolved.size() if success else 0,"payload_checks":payload_checks,"payload_failures":payload_failures,"phases":phases,"scope":"Read-only phase decomposition plus one warm-cache RecordedCatalog.mount on the existing original-entry recording. No FPS, gameplay or matched loading claim."}
	var output_file:=FileAccess.open(output,FileAccess.WRITE);output_file.store_string(JSON.stringify(report,"  ")+"\n");output_file.close();quit(0 if report.success else 1)
