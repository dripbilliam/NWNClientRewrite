extends "res://tests/nwn63_model_scalars_test.gd"
# Exact current source snapshot, including all earlier accepted scalar work.
const ExactBefore=preload("res://.cache/nwn63/interval-edges-a/before/systems/native_render/drive_collision_indexed.gd")

func group_pair(count: int=128)->Array:
	var pair: Array=[]
	for before in [true,false]:
		var setup:=make_world(false);var collision=ExactBefore.new() if before else Collision.new()
		setup.world.add_child(collision);collision.world=setup.world;collision.tables=tables();setup.world.drive_collision=collision;collision.ensure_spatial_scope();collision.set_process(false)
		var rows: Array=[creature(1,Vector2(1,1)),creature(4,Vector2(6,3)),object(2,Vector2(4,1)),object(3,Vector2(9,1),10)]
		collision.publish_model("chest:placeable",{"states":[footprint()]})
		collision.publish_model("gate:door",{"states":[footprint(),{"vertices":[],"faces":[]},footprint(2)]})
		for i in count:
			var key:="cohort_"+str(i);var appearance: int=collision.tables.placeables.orderedRows.size()
			collision.tables.placeables.orderedRows.append({"ModelName":key})
			if i%17!=0:collision.publish_model(key+":placeable",{"states":[footprint(1+i%4)]})
			var position:=Vector2(24+(i%12)*8,24+(i/12)*8)
			rows.append(object(100+i,position,9,1,appearance))
		setup.world.receive(rows,1);setup.collision=collision;pair.append(setup)
	return pair
