extends SceneTree
const Current=preload("res://systems/model_rigs.gd")
const Fixture=preload("res://tests/nwn65_active_event_test.gd")
var output:=""
var preflight:=false
var checks:=0
var failures: Array=[]
func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.trim_prefix("--report=")
		if arg=="--preflight":preflight=true
	call_deferred("run")
func check(value: bool,label: String) -> void:
	checks+=1
	if not value:failures.append(label);push_error(label)
func digest(value: Variant) -> String:
	var hash:=HashingContext.new();hash.start(HashingContext.HASH_SHA256);hash.update(var_to_bytes(value));return hash.finish().hex_encode()
func statistics(values: Array) -> Dictionary:
	values.sort()
	return {"count":values.size(),"median_us":values[values.size()/2],"p95_us":values[mini(values.size()-1,int(ceil(values.size()*0.95))-1)],"max_us":values[-1]}
func leg(script,eventful: bool) -> Dictionary:
	var rows: Array=[]
	for index in 80:
		var row:=Fixture.fixture(self,script,eventful)
		# This component case measures the ordinary AnimationPlayer path only.
		# The semantic test separately covers authored native-owner events.
		row.entry.animated_models=[0,1]
		rows.append(row)
	var samples: Array=[];var warm:=0 if preflight else 20;var frames:=32 if preflight else 120
	for frame in warm+frames:
		var began:=Time.get_ticks_usec()
		for row in rows:row.rigs._update(1.0/60.0)
		if frame>=warm and not preflight:samples.append(Time.get_ticks_usec()-began)
	var snapshots: Array=[];var events:=0;var calls:=0;var running:=0
	var counts:={"allocated":0,"reused":0,"rows":0,"empty_models":0,"interval_models":0,"retained_batches":0}
	for row in rows:
		snapshots.append(Fixture.capture(row));events+=row.log.size();calls+=int(row.rigs.stats.pose_frames)
		for model_index in [0,1]:
			if row.entry.models[model_index].player.is_playing():running+=1
		if row.rigs.has_method("event_batch_snapshot"):
			var info: Dictionary=row.rigs.event_batch_snapshot()
			for key in counts:counts[key]+=int(info[key])
	var result:={"owners":rows.size(),"animation_players":rows.size()*2,"running_players":running,"event_records":events,"update_calls":calls,"state_sha256":digest(snapshots),"work_counts":counts}
	if not preflight:result.timing=statistics(samples)
	for row in rows:Fixture.dispose(row)
	return result
func run() -> void:
	if output.is_empty() or FileAccess.file_exists(output):quit(2);return
	var original=load("res://.cache/nwn65/active-baseline-a/systems/model_rigs.gd")
	var source_sha:=FileAccess.get_sha256("res://systems/model_rigs.gd");var cases: Array=[]
	for eventful in [false,true]:
		var legs: Array=[]
		for mode in ["original","candidate","candidate","original"]:
			var result:=leg(original if mode=="original" else Current,eventful);result.mode=mode;legs.append(result)
		for index in legs.size():
			check(legs[index].owners==80 and legs[index].animation_players==160,"all intended active owners/players admitted")
			check(legs[index].running_players==160,"all measured players actually retain active clocks")
			check(legs[index].event_records>0 if eventful else legs[index].event_records==0,"eventful/empty scenarios exercise the intended event population")
			check(legs[index].state_sha256==legs[0].state_sha256,"ABBA active clocks/poses/events/attachments remain bit-identical")
		cases.append({"eventful":eventful,"legs":legs})
	check(FileAccess.get_sha256("res://systems/model_rigs.gd")==source_sha,"rig source unchanged through execution")
	var file:=FileAccess.open(output,FileAccess.WRITE);file.store_string(JSON.stringify({"checks":checks,"failures":failures,"passed":failures.is_empty(),"preflight":preflight,"rig_sha256":source_sha,"baseline_sha256":FileAccess.get_sha256("res://.cache/nwn65/active-baseline-a/systems/model_rigs.gd"),"cases":cases,"scope":"Actual ModelRigs._update with80active owners/160AnimationPlayers, deterministic authored property clips and attachment/event consumers. Manual callback invocation; no assets/skins, SceneTree callback reduction, FPS or live eligibility claim"},"\t"));file.close();quit(0 if failures.is_empty() else 1)
