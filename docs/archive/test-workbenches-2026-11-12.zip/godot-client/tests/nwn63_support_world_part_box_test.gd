extends SceneTree
# Paired off/on fixture for the optional ordinary Part world-box rejection.
const Trace=preload("res://systems/native_render/native_support_part_trace_box.gd")
const Fixtures=preload("res://tests/native_parity_client_support_scene_test.gd")
const Geometry=preload("res://systems/native_render/scene_geometry.gd")
const Query=preload("res://systems/native_render/projectile_scene.gd")
const Gate=preload("res://systems/native_data/native_support_authored_box.gd")
const NormalScene=preload("res://systems/native_render/native_client_support_scene_box.gd")
const LiveWorld=preload("res://systems/native_render/live_world_support.gd")
var output:=""
var checks:=0
var failures: Array=[]
var answers: Array=[]

func _initialize() -> void:call_deferred("run")

func check(ok: bool,description: String) -> void:
	checks+=1
	if not ok:failures.append(description)

func facts(low: Array=[0.0,0.0,-1.0],high: Array=[10.0,10.0,1.0]) -> Dictionary:
	return {"node_is_aabb":false,"native_tilefade_available":true,"native_tilefade":0,"native_bounds_available":true,"native_bounds_valid":true,"native_bounds":{"min":low,"max":high}}

func part(model: Node3D,data: Resource,source: Dictionary) -> Node3D:
	var node:=Node3D.new();model.add_child(node)
	var mesh:=ArrayMesh.new();mesh.set_meta("native_scene_geometry",data)
	node.set_meta("native_pick_geometry",mesh);node.set_meta("native_mesh_source",source)
	model.pick_surfaces.append(node)
	return node

func ray(trace: RefCounted,model: Node3D,local: Vector3,label: String) -> Dictionary:
	var center: Vector3=model.global_transform*local
	var a: Array=Query.native(center+Vector3.UP*20.0)
	var b: Array=Query.native(center-Vector3.UP*20.0)
	var result: Dictionary=trace.model_hit(model,a,b)
	answers.append({"label":label,"result":result})
	return result

func run() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.substr(9)
	if output.is_empty() or FileAccess.file_exists(output):quit(2);return
	var enabled:=OS.get_cmdline_user_args().has("--client-support-world-part-box")
	var normal_scene:=NormalScene.new()
	check(LiveWorld.SupportScene==NormalScene and normal_scene._part_trace is Trace and normal_scene._part_trace._world_part_box==enabled,"Selected live-world support route owns the same flag-controlled Part trace")
	var model:=Fixtures.ModelStub.new();root.add_child(model);model.position.y=11.0
	# Keep the model broadphase open for both the near and distant Parts.
	model.set_meta("native_scene_bounds",AABB(Vector3(-1,-2,-11),Vector3(113,4,22)))
	var data:=Geometry.new()
	data.configure({"vertices":PackedFloat32Array([0,0,0,10,0,0,10,10,0,0,10,0]),"indices":PackedInt32Array([0,1,2,0,2,3]),"native_surface_types":PackedInt32Array([30,30])})
	var near:=part(model,data,facts())
	var far:=part(model,data,facts());far.position.x=100.0
	var trace:=Trace.new()
	var hit:=ray(trace,model,Vector3(5,0,-5),"base")
	check(hit.available and hit.hit and absf(hit.position[2]-11.0)<0.0001 and hit.normal==[0.0,0.0,0.0],"ordinary near hit keeps native zero normal")
	var first: Dictionary=trace.snapshot()
	check((int(first.world_box_misses)>0 and int(first.inverse_builds)==1) if enabled else (int(first.world_box_misses)==0 and int(first.inverse_builds)==2),"distant Part changes only optional prefilter work")
	hit=ray(trace,model,Vector3(5,0,-5),"repeat")
	check(hit.available and hit.hit and absf(hit.position[2]-11.0)<0.0001,"same-pose result unchanged")
	if enabled:check(int(trace.snapshot().world_box_reuses)>0,"same-pose authored world box reused")
	# Parent rotation and nonuniform scale change the current world box.
	model.position=Vector3(10,11,4);model.rotation.y=PI/2;model.scale=Vector3(1.25,0.8,1.5)
	hit=ray(trace,model,Vector3(5,0,-5),"parent-rotated-scaled")
	check(hit.available and hit.hit and absf(hit.position[2]-11.0)<0.0001,"rotated scaled parent still hits")
	near.position.y=0.5;near.scale=Vector3(0.8,1.3,1.1)
	hit=ray(trace,model,Vector3(4,0,-5.5),"part-posed-scaled")
	check(hit.available and hit.hit,"Part-local pose and scale retain hit")
	# A source mutation at an unchanged pose must rebuild the box. An excluded
	# source must still pass through exact authored admission and produce a miss.
	near.set_meta("native_mesh_source",facts([0.0,0.0,-1.0],[1.0,1.0,1.0]))
	hit=ray(trace,model,Vector3(4,0,-5.5),"bounds-narrowed")
	check(hit.available and not hit.hit,"narrowed authored bounds reject old hit")
	near.set_meta("native_mesh_source",facts())
	hit=ray(trace,model,Vector3(4,0,-5.5),"bounds-restored")
	check(hit.available and hit.hit,"restored authored bounds restore hit")
	var editable:=facts();near.set_meta("native_mesh_source",editable)
	hit=ray(trace,model,Vector3(4,0,-5.5),"in-place-bounds-prime")
	check(hit.available and hit.hit,"source bound cache primes from a mutable authored array")
	var before_edit_builds:=int(trace.snapshot().world_box_builds)
	editable.native_bounds.max[0]=1.0
	hit=ray(trace,model,Vector3(4,0,-5.5),"in-place-bounds-narrowed")
	check(hit.available and not hit.hit and (int(trace.snapshot().world_box_builds)>before_edit_builds if enabled else true),"in-place authored bound edit invalidates cached world box")
	editable.native_bounds.max[0]=10.0
	hit=ray(trace,model,Vector3(4,0,-5.5),"in-place-bounds-restored")
	check(hit.available and hit.hit,"in-place authored bound restoration returns the same support hit")
	model.scale.x=-1.25
	hit=ray(trace,model,Vector3(4,0,-5.5),"parent-reflected")
	check(hit.available and hit.hit,"reflected parent still hits")
	model.scale.x=1.25
	# Boundary touch gets conservative admission to the original local path.
	hit=ray(trace,model,Vector3(0,0,-5),"boundary")
	check(hit.available,"segment on authored boundary remains decidable")
	# An infinite line can cross the box after the segment ends, but the
	# original shared-outcode check does not admit that finite segment.
	check(not Gate.admit(facts(),[5.0,5.0,20.0],[5.0,5.0,10.0]).admit,"original box rejects extension beyond the segment")
	near.set_meta("native_mesh_source",facts([0.0,0.0,0.0],[10.0,10.0,0.0]))
	hit=ray(trace,model,Vector3(4,0,-5.5),"zero-thickness-fallback")
	check(hit.available and hit.hit,"zero-thickness authored box takes exact local path")
	var invalid_flag:=facts();invalid_flag.native_bounds_valid=false
	var inverted:=facts([10.0,0.0,-1.0],[0.0,10.0,1.0])
	var malformed:=facts();malformed.native_bounds={"min":[0.0,0.0,-1.0],"max":[INF,10.0,1.0]}
	for source: Dictionary in [{"node_is_aabb":false},invalid_flag,inverted,malformed]:
		near.set_meta("native_mesh_source",source)
		hit=ray(trace,model,Vector3(4,0,-5.5),"unavailable-%s" % answers.size())
		check(not hit.available,"missing or invalid source remains unavailable")
	var excluded:=facts();excluded.native_tilefade=2;near.set_meta("native_mesh_source",excluded)
	hit=ray(trace,model,Vector3(4,0,-5.5),"tilefade-excluded")
	check(hit.available and not hit.hit,"tilefade provenance retains exact exclusion")
	var aabb:=facts();aabb.node_is_aabb=true;near.set_meta("native_mesh_source",aabb)
	hit=ray(trace,model,Vector3(4,0,-5.5),"aabb-material-policy")
	check(hit.available and not hit.hit,"AABB material mask remains separate from ordinary box")
	near.set_meta("native_mesh_source",facts())
	var saved_planes: PackedFloat32Array=data.planes;data.planes=PackedFloat32Array()
	hit=ray(trace,model,Vector3(4,0,-5.5),"malformed-geometry")
	check(not hit.available,"malformed geometry fails open to existing unavailable path")
	data.planes=saved_planes
	# A degenerate transform cannot prove a safe rejection.
	check(trace._ordinary_world_box({"node":near,"data":data},facts(),Transform3D(Basis.from_scale(Vector3(0,1,1)),Vector3.ZERO))==null,"degenerate transform fails open")
	var after: Dictionary=trace.snapshot()
	check((int(after.world_box_builds)>int(first.world_box_builds) and int(after.world_box_fallbacks)>0) if enabled else (int(after.world_box_builds)==0 and int(after.world_box_fallbacks)==0),"source and pose changes follow opt-in policy")
	model.free()
	var file:=FileAccess.open(output,FileAccess.WRITE)
	if file==null:quit(3);return
	file.store_string(JSON.stringify({"success":failures.is_empty(),"checks":checks,"failures":failures,"enabled":enabled,"answers":answers,"first":first,"stats":after},"  "));file.close()
	quit(0 if failures.is_empty() else 1)
