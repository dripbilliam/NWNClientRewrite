extends SceneTree
const Support=preload("res://tests/native_popup_scene_support.gd")
const Gameplay=preload("res://systems/native_gameplay_ui.gd")
const Hud=preload("res://systems/native_hud.gd")
const Registry=preload("res://systems/native_overhead_popup_registry.gd")
const Fonts=preload("res://systems/native_popup_fonts.gd")
const Resources=preload("res://systems/native_nameplate_resources.gd")
const Art=preload("res://systems/native_ui_art.gd")
const Catalog=preload("res://systems/native_data/resource_catalog.gd")
const Table=preload("res://systems/native_data/two_da.gd")
const PortraitChoices=preload("res://systems/native_data/portrait_choices.gd")
var options: Dictionary={}
var ui
var camera: Camera3D
var ids: Array=[]
var stage: Control
var samples:=60
var actors:=48
var preflight_failures: Array=[]
func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		var pair:=arg.trim_prefix("--").split("=",true,1)
		if pair.size()==2:options[pair[0]]=pair[1]
	call_deferred("run")
func anchor(id: int,_witness: Array,_scope: Array) -> Dictionary:
	return {"ready":true,"screen":Vector2(100+((id-1000)%8)*120,100+((id-1000)/8)*70)}
func fixture(reference: bool):
	var script=load("res://.cache/nwn68/baseline/native_hud_control.gd") if reference else Hud
	var hud=script.new();root.add_child(hud);hud.camera=camera;hud.registry=Support.VisualRows.new();hud.root=stage
	hud.nameplate_root=Control.new();stage.add_child(hud.nameplate_root)
	for id in ids:hud.registry.entities[id]={"eligible":true,"type":5}
	print("NWN68_FIXTURE ",JSON.stringify({"ids":ids.size(),"eligible":preload("res://systems/native_data/nameplate_state.gd").visible_ids(ids,hud.registry.entities).size(),"ui_closed":ui.closed,"ui_present":ui.presentation_enabled,"context":ui.overhead_context(),"first_object":ui.text.objects.get(ids[0]),"first_anchor":ui.overhead_anchor(ids[0],[],[])}))
	hud.bind_gameplay(ui);hud.labels(ids)
	var until:=Time.get_ticks_msec()+20000
	while not hud.nameplates.values().all(func(p):return Support.raster_ready(p)) and Time.get_ticks_msec()<until:await process_frame
	return hud
func dispose(hud) -> void:
	var overlay=hud.nameplate_root;hud.clear_nameplates();hud.release_nameplate_source();hud.free();overlay.queue_free();await process_frame
func summary(values: Array) -> Dictionary:
	var ordered:=values.duplicate();ordered.sort();var total:=0
	for value in values:total+=int(value)
	return {"median_us":ordered[values.size()/2],"mean_us":float(total)/values.size(),"p95_us":ordered[mini(values.size()-1,int(ceil(values.size()*0.95))-1)],"p99_us":ordered[mini(values.size()-1,int(ceil(values.size()*0.99))-1)],"samples":values.size()}
func measure(reference: bool) -> Dictionary:
	var hud=await fixture(reference)
	for warm in 10:ui.text.mark_changed();hud.labels(ids)
	var before: Dictionary={}
	for id in ids:
		var plate=hud.nameplates.get(id)
		if not is_instance_valid(plate):preflight_failures.append(["missing",reference,id]);continue
		var fit: Variant=plate.get("layouts");var paint: Variant=plate.get("display_refreshes")
		if not fit is int or not paint is int or fit<0 or fit>100000 or paint<0 or paint>100000:preflight_failures.append(["bad-counter",reference,id,fit,paint])
		before[id]=Vector2i(int(fit),int(paint))
		if not plate.visible or not Support.raster_ready(plate) or not plate.caption.get_parsed_text().contains("Native Actor "+str(id-1000)):preflight_failures.append(["not-admitted",reference,id,plate.visible,plate.caption.get_parsed_text(),plate.layout_ready])
	print("NWN68_ADMISSION ",JSON.stringify({"reference":reference,"count":hud.nameplates.size(),"first":before.get(ids[0]),"failures":preflight_failures.slice(0,8)}))
	if not preflight_failures.is_empty() or options.get("preflight","false")=="true":
		var result:={"preflight":true,"count":hud.nameplates.size(),"reference":reference,"state":[]};await dispose(hud);return result
	var times: Array=[]
	for sample in samples:
		ui.text.mark_changed() # Unrelated native token/table publication: output may stay equal.
		var began:=Time.get_ticks_usec();hud.labels(ids);times.append(Time.get_ticks_usec()-began)
	var counts:=Vector2i.ZERO
	var state: Array=[]
	for id in ids:
		var plate=hud.nameplates[id]
		var after:=Vector2i(int(plate.get("layouts")),int(plate.get("display_refreshes")))
		var delta: Vector2i=after-before[id]
		if delta.x<0 or delta.y<0 or delta.x>samples*3 or delta.y>samples*3:preflight_failures.append(["bad-delta",reference,id,before[id],after])
		counts+=delta
		state.append({"id":id,"visible":plate.visible,"caption":plate.caption.get_parsed_text(),"position":plate.position,"size":plate.size,"caption_position":plate.caption.position,"caption_size":plate.caption.size,"displayed":plate.displayed_rich.duplicate(true)})
	var result:=summary(times);result.layouts=counts.x;result.display_refreshes=counts.y;result.state=state;result.plates=hud.nameplates.size()
	await dispose(hud);return result
func run() -> void:
	if not options.has_all(["report","install"]) or FileAccess.file_exists(options.report):quit(2);return
	samples=int(options.get("samples",60));actors=int(options.get("actors",48))
	if samples<20 or samples>300 or actors<2 or actors>128:quit(2);return
	root.size=Vector2i(1280,720);stage=Control.new();root.add_child(stage);stage.size=Vector2(1280,720)
	var catalog:=Catalog.new()
	if not catalog.mount_install(str(options.install)):quit(2);return
	var table: Dictionary=Table.new().parse(catalog.get_resource("portraits",2017).get_string_from_ascii())
	var portraits: Array=PortraitChoices.ordered(table.get("orderedRows",[]),0,0,catalog.has_resource,[],false)
	if portraits.is_empty():quit(2);return
	var cache:=str(options.report).get_base_dir();var fonts:=Fonts.new();root.add_child(fonts);fonts.configure(catalog,cache.path_join("timing-fonts"))
	var art:=Art.new();root.add_child(art);art.configure(catalog,cache.path_join("timing-art"))
	var resources:=Resources.new();root.add_child(resources);resources.configure(catalog,cache.path_join("timing-models"))
	ui=Gameplay.new();root.add_child(ui);ui.set_process(false);ui.set_process_unhandled_key_input(false);ui.catalog=catalog;ui.popup_fonts=fonts;ui.overhead_popup_source=resources;ui.generation=7;ui.area_id=91;ui.controlled_id=1000;ui.presentation_enabled=true
	ui.native_connection_query=func():return 3
	ui.overhead_anchor_query=anchor
	ui.text.base.open_file(str(options.install).path_join("lang/en/data/dialog.tlk"));ui.text.publish_table("damagelevels",Table.new().parse(catalog.get_resource("damagelevels",2017).get_string_from_ascii()))
	for index in actors:
		var id:=1000+index;ids.append(id);ui.text.objects[id]=Support.row(id,"Native Actor "+str(index),index+8,index+13);ui.text.objects[id].replicated.portraitRef=str(portraits[0])
	var desktop:=Support.Desktop.new();ui.add_child(desktop);desktop.art=art;ui.desktop=desktop
	var registry:=Registry.new();ui.add_child(registry);registry.automatic=false;registry.configure(ui.overhead_context,ui.overhead_source,ui.popup_settings);ui.overhead_popup_registry=registry
	camera=Camera3D.new();root.add_child(camera);camera.current=true
	var a=await measure(true);var b=await measure(false);var c=await measure(false);var d=await measure(true)
	var equal: bool=a.state==b.state and a.state==c.state and a.state==d.state
	for result in [a,b,c,d]:result.erase("state")
	var clean: bool=fonts.failed.is_empty() and resources.failures.is_empty() and art.failed.is_empty()
	var out:={"success":equal and clean and preflight_failures.is_empty(),"preflight_failures":preflight_failures,"order":"A-B-B-A","actors":actors,"reference":[a,d],"optimized":[b,c],"state_equal":equal,"assets_clean":clean,"scope":"Actual NativeHud.labels, canonical popup registry and native nameplate Controls with installed original fonts/model/raster owners. An unrelated text revision republishes unchanged resolved names; preserve all writes/clocks/callback order. Fixed-step repeated component calls only; no FPS, GPU, live server or loading-latency measurement."}
	registry.close();ui.text.close();ui.free();fonts.close();fonts.free();resources.close();resources.free();art.close();art.free();stage.free();camera.free();await process_frame;await process_frame
	var file:=FileAccess.open(options.report,FileAccess.WRITE);file.store_string(JSON.stringify(out,"\t"));file.close();print("NWN68_NAMEPLATE_TIMING ",JSON.stringify(out));quit(0 if out.success else 1)
