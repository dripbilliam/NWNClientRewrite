extends "res://native_live_world.gd"
# This overrides startup and outer providers only. The actual adapted inherited
# _profile_tick, bridge decoder, keyboard and protocol queue/flush execute.
var fixture_checks:=0
var fixture_failures: Array=[]
var fixture_order: Array=[]
var fixture_state:={"position":Vector3(2,3,0),"render":Vector3(2,3,0),"orientation":Vector3.RIGHT,"lifetime":11}
var fixture_identity:="connection/3/1/11"
var fixture_transition:=false
var fixture_server:=TCPServer.new()
var fixture_remote: StreamPeerTCP
var fixture_surface: SubViewport
var fixture_library: Resource
func _initialize()->void:call_deferred("run_fixture")
func fixture_check(ok: bool,text: String)->void:
	fixture_checks+=1
	if not ok:fixture_failures.append(text)
func native_clock_prefix()->void:fixture_order.append("prefix")
func native_clock_post_receive()->void:fixture_order.append("post_receive")
func creation_runtime_phase(_stage: String)->void:pass
func keyboard_context()->Dictionary:
	return {} if fixture_transition else {"id":1,"identity":fixture_identity,"state":fixture_state}
func dispatch_protocol_messages(messages: Array,_wire_sizes: PackedInt32Array)->void:
	for message in messages:
		fixture_order.append("dispatch")
		match str(message.get("kind","")):
			"fixture-pose":fixture_state.position=Vector3(9,8,0);fixture_state.render=fixture_state.position
			"fixture-transition":fixture_transition=true
			"fixture-lifetime":fixture_identity="connection/4/1/12";fixture_state.lifetime=12
func player_command(value: Dictionary)->void:
	fixture_order.append("request");value.generation=3;value.areaId=91;send(value)
func _send_profiled(value: Dictionary)->void:
	fixture_order.append("enqueue");super._send_profiled(value)
func flush_protocol_output()->void:
	fixture_order.append("flush");super.flush_protocol_output()
func fail(reason: String)->void:
	fixture_failures.append(reason);closing=true
func fixture_push()->void:
	var event:=InputEventKey.new();event.physical_keycode=KEY_W;event.keycode=KEY_W;event.pressed=true
	fixture_surface.push_input(event,true)
func fixture_receive(kind: String)->void:
	var error:=fixture_remote.put_data((JSON.stringify({"kind":kind})+"\n").to_utf8_buffer())
	fixture_check(error==OK,"Local fixture payload writes completely")
	for attempt in 128:
		peer.poll()
		if peer.get_available_bytes()>0:return
		await process_frame
	fixture_check(false,"Local fixture payload becomes available before manual tick")
func fixture_wire()->Array:
	for attempt in 128:
		fixture_remote.poll()
		if fixture_remote.get_available_bytes()>0:break
		await process_frame
	var result: Array=[]
	var text:=fixture_remote.get_utf8_string(fixture_remote.get_available_bytes())
	for line in text.split("\n",false):result.append(JSON.parse_string(line))
	return result
func run_fixture()->void:
	var destination:=""
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--report="):destination=argument.trim_prefix("--report=")
	if destination.is_empty() or FileAccess.file_exists(destination):quit(2);return
	var expected: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://accepted-runtime.json"))
	fixture_library=load("res://native/particle_kernel.gdextension")
	fixture_check(FileAccess.get_sha256(OS.get_executable_path())==expected.engineSha256,"Exact accepted Core E engine")
	fixture_check(FileAccess.get_sha256("res://.cache/native-kernel/nwn-particle-kernel.dll")==expected.nativeKernelSha256 and fixture_library!=null and ClassDB.class_exists("NwnParticleKernel"),"Exact accepted485 kernel is loaded")
	for flag in expected.fullFunctionalFlags:fixture_check(flag in OS.get_cmdline_user_args(),"Accepted functional flag "+str(flag))
	var enabled: bool=bool(ProjectSettings.get_setting("nwn/private/keyboard_frame_admission",false))
	fixture_check(fixture_server.listen(0,"127.0.0.1")==OK,"Isolated local protocol fixture listens")
	fixture_check(peer.connect_to_host("127.0.0.1",fixture_server.get_local_port())==OK,"Actual NativeLive peer connects only to fixture loopback")
	for attempt in 128:
		peer.poll()
		if fixture_server.is_connection_available():fixture_remote=fixture_server.take_connection()
		if fixture_remote!=null and peer.get_status()==StreamPeerTCP.STATUS_CONNECTED:break
		await process_frame
	if fixture_remote==null or peer.get_status()!=StreamPeerTCP.STATUS_CONNECTED:
		fixture_failures.append("Isolated peer did not connect");finish_fixture(destination,enabled,{});return
	authenticated=true
	fixture_surface=SubViewport.new();fixture_surface.size=Vector2i(640,480);root.add_child(fixture_surface)
	keyboard=Keyboard.new();fixture_surface.add_child(keyboard);keyboard.require_focus=false
	keyboard.context_query=keyboard_context;keyboard.transmit=player_command
	keyboard.predict=func(_id,_flags,_heading):fixture_order.append("predict");return {"target":Vector3(10,8,0)}
	keyboard.set_frame_input_admission(enabled);keyboard.set_process(false)
	fixture_push()
	fixture_check(fixture_order.is_empty() if enabled else fixture_order==["request","enqueue","predict"],"Actual OS event route has the privately selected scheduling")
	await fixture_receive("fixture-pose")
	# Invoke the inherited function containing the actual adapter, not a copy.
	_profile_tick()
	var first_order:=fixture_order.duplicate()
	var expected_order: Array=["prefix","dispatch","request","enqueue","predict","flush","post_receive"] if enabled else ["request","enqueue","predict","prefix","dispatch","flush","post_receive"]
	fixture_check(first_order==expected_order,"Actual adapted root tick applies receive then candidate enqueue then existing flush, with no extra frame")
	var wire:=await fixture_wire()
	fixture_check(wire.size()==1 and wire[0].kind=="drive" and wire[0].operation=="drive","Existing protocol queue really writes one keyboard drive to the local peer")
	if wire.size()==1:fixture_check(wire[0].position==([9.0,8.0] if enabled else [2.0,3.0]),"Candidate reads post-dispatch pose; OFF retains original pre-dispatch wire shape")
	fixture_check(int(protocol_output.snapshot().get("queued_bytes",-1))==0,"Request was flushed in this same root tick")
	var first_frame:=Engine.get_process_frames()
	keyboard.stop(false);fixture_order.clear()
	for attempt in 8:
		await process_frame
		if Engine.get_process_frames()!=first_frame:break
	var next_frame:=Engine.get_process_frames()
	fixture_check(next_frame!=first_frame,"Next protocol cycle genuinely advances the Engine process frame")
	fixture_push();await fixture_receive("fixture-pose");_profile_tick()
	var next_order:=fixture_order.duplicate();var next_wire:=await fixture_wire()
	fixture_check(next_order==expected_order and next_wire.size()==1,"A genuine next-frame cycle still enqueues and flushes one request in the inherited root tick")
	keyboard.stop(false);fixture_order.clear();await process_frame
	fixture_push();await fixture_receive("fixture-transition");_profile_tick()
	var transition_order:=fixture_order.duplicate()
	fixture_check(not keyboard.moving and keyboard.held.is_empty() if enabled else keyboard.moving,"Snapshot-transition context cancels pending candidate input at the actual flush seam")
	fixture_check(not fixture_order.has("request") if enabled else fixture_order.has("request"),"A transition received before the candidate flush emits no stale drive")
	if not enabled:await fixture_wire()
	keyboard.stop(false);fixture_transition=false;fixture_order.clear();await process_frame
	fixture_push();await fixture_receive("fixture-lifetime");_profile_tick()
	fixture_check(not fixture_order.has("request") and keyboard.held.is_empty() if enabled else fixture_order.has("request"),"A replacement lifetime cannot inherit admitted candidate input")
	if not enabled:await fixture_wire()
	finish_fixture(destination,enabled,{"first_order":first_order,"next_order":next_order,"first_frame":first_frame,"next_frame":next_frame,"transition_order":transition_order,"lifetime_order":fixture_order.duplicate(),"wire":wire,"admission_stats":keyboard.stats.duplicate()})
func finish_fixture(destination: String,enabled: bool,observed: Dictionary)->void:
	if is_instance_valid(keyboard):
		keyboard.context_query=Callable();keyboard.transmit=Callable();keyboard.predict=Callable();keyboard.end_prediction=Callable()
	if is_instance_valid(fixture_surface):fixture_surface.free()
	peer.disconnect_from_host()
	if fixture_remote!=null:fixture_remote.disconnect_from_host()
	fixture_server.stop()
	var result:={"success":fixture_failures.is_empty(),"checks":fixture_checks,"failures":fixture_failures,"frame_input_admission":enabled,"observed":observed,"user_data_dir":OS.get_user_data_dir(),"scope":"Actual inherited private NativeLive._profile_tick, BridgeFrames decoder, NativeKeyboard OS route, current pose/transition/lifetime and real protocol queue/loopback flush. Startup overridden; no game server, assets, GUI, FPS or benchmark."}
	var file:=FileAccess.open(destination,FileAccess.WRITE);file.store_string(JSON.stringify(result,"  "));file.close()
	print(JSON.stringify({"success":result.success,"checks":result.checks,"failures":result.failures}));quit(0 if result.success else 1)
