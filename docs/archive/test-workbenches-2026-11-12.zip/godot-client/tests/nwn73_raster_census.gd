extends SceneTree
func _initialize() -> void:call_deferred("run")
func run() -> void:
	var args: Dictionary={}
	for arg in OS.get_cmdline_user_args():
		var pair:=arg.trim_prefix("--").split("=",true,1)
		if pair.size()==2:args[pair[0]]=pair[1]
	if not args.has("bundle") or not args.has("report") or FileAccess.file_exists(args.report):quit(2);return
	var file:=FileAccess.open(args.bundle,FileAccess.READ)
	if file==null:quit(2);return
	var bundle: Dictionary=file.get_var(false);file.close();var rows: Array=[];var seen: Dictionary={}
	for field in ["textures","emitter_textures"]:
		for name in bundle.get(field,{}):
			var record: Dictionary=bundle[field][name]
			if not record.get("value") is Dictionary or seen.has(str(record.get("sha256",""))):continue
			seen[str(record.get("sha256",""))]=true
			var value: Dictionary=record.value;var bytes:=0
			for mip in value.get("mips",[]):bytes+=mip.data.size()
			rows.append({"name":name,"sha256":record.get("sha256"),"width":value.get("width"),"height":value.get("height"),"format":value.get("format"),"mips":value.get("mips",[]).size(),"generate_mips":value.get("generate_mips",false),"source_bytes":bytes})
	var report:={"source":args.bundle,"source_sha256":FileAccess.get_sha256(args.bundle),"textures":rows,"scope":"Read-only metadata census of frozen original decoded model bundle; no decode, image/GPU creation or timing."}
	file=FileAccess.open(args.report,FileAccess.WRITE);file.store_string(JSON.stringify(report,"\t"));file.close();print(JSON.stringify(report));quit()
