extends SceneTree
const Session=preload("res://native_session_world.gd")
var checks:=0
var failures: Array=[]
func _initialize() -> void:call_deferred("run")
func check(ok: bool,label: String) -> void:
	checks+=1
	if not ok:failures.append(label)
func run() -> void:
	var report:=""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):report=arg.trim_prefix("--report=")
	if report.is_empty() or FileAccess.file_exists(report):quit(2);return
	var odd:=PackedFloat64Array()
	for i in 121:odd.append(float(i+1))
	var a: Dictionary=Session.movement_window_intervals(odd)
	check(a.count==121 and a.median_ms==61.0 and a.p95_ms==115.0 and a.p99_ms==120.0 and a.worst_ms==121.0,"odd-size exact median and upper percentiles")
	check(a.over_50ms==71 and a.average_ms==61.0,"full retained interval count and mean")
	var even:=PackedFloat64Array()
	for i in 120:even.append(float(i+1))
	var b: Dictionary=Session.movement_window_intervals(even)
	check(b.count==120 and b.median_ms==60.5 and b.p95_ms==114.0 and b.p99_ms==119.0,"even-size exact median and upper percentiles")
	check(Session.movement_window_intervals(PackedFloat64Array([1.0,2.0])).is_empty(),"less than 120 samples rejects")
	var malformed:=odd.duplicate();malformed[0]=NAN
	check(Session.movement_window_intervals(malformed).is_empty(),"nonfinite interval rejects")
	var too_many:=PackedFloat64Array();too_many.resize(20001)
	check(Session.movement_window_intervals(too_many).is_empty(),"sample bound rejects before sorting")
	var file:=FileAccess.open(report,FileAccess.WRITE)
	if file==null:quit(3);return
	file.store_string(JSON.stringify({"success":failures.is_empty(),"checks":checks,"failures":failures,"odd":a,"even":b,"scope":"Pure bounded movement-window interval summary; no gameplay, renderer or FPS measurement."},"  "));file.close()
	quit(0 if failures.is_empty() else 1)
