extends "res://tests/native_visual_setup_test.gd"
const NativeEffects=preload("res://systems/native_render/effect_world.gd")
const EffectModel=preload("res://systems/native_render/effect_model.gd")
const PrivateHosts=preload("res://systems/native_render/client_dummies.gd")
const Presentation=preload("res://systems/native_data/entity_presentation_lifetime.gd")
var native_cases:=0
var attachment_cases:=0
class ObservedDummies extends PrivateHosts:
	var hook: Callable
	func has(id: int,token: int) -> bool:
		if hook.is_valid():hook.call()
		return super.has(id,token)
func native_fixture(reuse: bool) -> Dictionary:
	var log:=Log.new();var w:=NativeEffects.new();w.client=w;w.controlled_id=123;w.reuse_selection_inputs=reuse;w.reused_selection_setup=reuse
	w.world={"desired":{123:{"object":{"nativeLifetime":4,"clientKnownLifetime":6}},456:{"object":{"nativeLifetime":5}}},"instances":{},"installed":{}}
	w.client_dummies=PrivateHosts.new();w.client_dummies.entries[123]={"token":9,"area":false,"model":null}
	var f:={"world":w,"log":log,"states":[]}
	for index in 8:
		var actor:=123 if index<7 else 456;var token:=9 if index in [4,5] else 0
		w.receive({"kind":"visual-reserve","effectId":index+1,"actorId":actor,"privateToken":token,"visualId":456,"transient":false,"areaVisual":index==6})
		var s:=state({"scope":index%3,"type":index%2,"attached":index%2})
		var runtime:=Runtime.new();runtime.configure(s,index+1,log);w.entries[index+1].runtime=runtime;f.states.append(s)
		w.records[index+1]={"area":false,"lifetime":4 if actor==123 else 5}
		if token==0:w.records[index+1].presentation_lifetime=Presentation.token(w.world.desired[actor].object)
	return f
func native_dispose(f: Dictionary) -> void:
	f.log.enabled=false
	for entry in f.world.entries.values():
		if entry.runtime!=null:entry.runtime.attach_hook=Callable()
	f.world.client_dummies.entries.clear();f.world.close();f.world.client_dummies.free();f.world.free();f.clear()
func selection_result(reuse: bool,kind: String) -> Dictionary:
	var f:=native_fixture(reuse);var w=f.world;var selected: Array=[]
	if kind=="disclosure-replacement":w.world.desired[123].object.clientKnownLifetime=7
	elif kind=="native-replacement":w.world.desired[123].object.nativeLifetime=9
	elif kind=="legacy-disclosure":w.world.desired[123].object.erase("clientKnownLifetime");w.world.desired[123].object.disclosureLifetime=6
	elif kind=="canonical-disclosure-missing":w.world.desired[123].object.clientKnownLifetime=null;w.world.desired[123].object.disclosureLifetime=6
	elif kind=="private-replacement":w.client_dummies.entries[123].token=10
	elif kind=="private-closed":w.client_dummies.closed=true
	elif kind=="owner-removed":w.world.desired.erase(123)
	elif kind=="missing-record":w.records.erase(2)
	elif kind=="pending":w.entries[2].runtime=null
	elif kind=="no-presentation-token":w.records[2].erase("presentation_lifetime")
	elif kind=="nested-revoke":
		var once:={"done":false}
		w.entries[1].runtime.attach_hook=func():
			if once.done:return
			once.done=true;f.log.put("nested-enter");w.select_actor(456);w.world.desired[123].object.clientKnownLifetime=8;f.log.put("nested-exit")
	elif kind=="custom-private-bound-callback":
		var old=w.client_dummies;var observed:=ObservedDummies.new();observed.entries=old.entries.duplicate(true);w.client_dummies=observed;old.entries.clear();old.free()
		var once:={"done":false}
		observed.hook=func():
			f.log.put("private-bound")
			if not once.done:once.done=true;w.entries[6].actor=456
		# Current-owner values are re-read after each custom bound callback.
		w.detach_competing(w.entries[6]);observed.hook=Callable()
	for token in [0,9,10]:
		var members: Array=w._selection_entries(123,token);selected.append(members.map(func(entry):return int(entry.id)))
		w.select_actor(123,token)
	w.detach_competing(w.entries[3]);w.select_actor(123)
	# A later invocation must re-read the owner, not reuse the previous verdict.
	if w.world.desired.has(123):w.world.desired[123].object={"nativeLifetime":4,"clientKnownLifetime":6}
	w.client_dummies.closed=false;w.client_dummies.entries[123].token=9;w.select_actor(123);w.select_actor(123,9)
	check(w.selection_contexts.is_empty(),"Native contexts released: "+kind)
	if reuse:check(w.selection_owner_projections>0,"Canonical owner projection exercised: "+kind)
	var out:={"selected":selected,"calls":f.log.events.duplicate(true),"states":f.states.duplicate(true)}
	native_dispose(f);native_cases+=1;return out
func attachment_reuse() -> void:
	var container:=Node3D.new();root.add_child(container)
	var parent:=Node3D.new();container.add_child(parent)
	var anchor:=Node3D.new();parent.add_child(anchor)
	var other:=Node3D.new();container.add_child(other)
	var control_script=load("res://.cache/nwn67/baseline/systems/native_render/effect_model.gd")
	var a=control_script.new();var b:=EffectModel.new();a.installed=true;b.installed=true;container.add_child(a);container.add_child(b)
	check(not b.is_processing(),"Unbound effect model has no idle attachment callback")
	for flags in [0,3]:
		for inherit in [false,true]:
			a.scale=Vector3(0.75,1.25,0.9);b.scale=a.scale
			check(a.attach_to(anchor,flags,inherit) and b.attach_to(anchor,flags,inherit),"Both binding owners attach")
			check(b.is_processing(),"Attachment wakes its callback")
			for step in 16:
				match step:
					1:pass
					2:anchor.position=Vector3(2,3,4)
					3:parent.rotation=Vector3(0.1,0.2,0.3)
					4:parent.scale=Vector3(1.2,0.8,1.4)
					5:a.position+=Vector3(1,0,0);b.position+=Vector3(1,0,0)
					6:a.rotation=Vector3(0.2,0.5,0.1);b.rotation=a.rotation
					7:anchor.reparent(other,true)
					8:a.anchor_scale=Vector3(1.4,0.7,0.9);b.anchor_scale=a.anchor_scale
					9:a.anchor_inherit_scale=not inherit;b.anchor_inherit_scale=not inherit
					10:anchor.position+=Vector3(0.25,0.5,0.75)
					11:container.position+=Vector3(0.25,0.5,0.75)
					12:other.visible=false;anchor.position+=Vector3(0.5,0,0)
					13:a.set_process(false);b.set_process(false);anchor.position+=Vector3(0,0.5,0);a.set_process(true);b.set_process(true)
					14:a.reparent(other,true);b.reparent(other,true)
					15:other.rotation+=Vector3(0.2,0.1,0.25);other.visible=true
				a._process(0.016);b._process(0.016)
				check(a.global_transform.is_equal_approx(b.global_transform),"Original attachment transform mode/scale/step "+str([flags,inherit,step]));attachment_cases+=1
			a.detach();b.detach();check(not b.is_processing() and b.anchor_node==null,"Detach sleeps and releases anchor")
			check(not b.has_meta("native_light_anchor"),"Detach releases lighting anchor metadata")
	# Direct flags edits must not reuse the previous rotation mode's result.
	a.attach_to(anchor,3);b.attach_to(anchor,3);a._process(0.016);b._process(0.016);a.anchor_flags=0;b.anchor_flags=0;a._process(0.016);b._process(0.016)
	check(a.global_transform.is_equal_approx(b.global_transform),"Rotation mode change invalidates cached input")
	b._process(0.016);check(b.binding_reused>0,"Unchanged canonical binding skips redundant transform evaluation/publication")
	anchor.free();b._process(0.016);check(not b.is_processing(),"Freed attachment stops the obsolete callback")
	container.free()
func extra_evidence() -> Dictionary:
	var result:=super.extra_evidence()
	for kind in ["steady","disclosure-replacement","native-replacement","legacy-disclosure","canonical-disclosure-missing","private-replacement","private-closed","owner-removed","missing-record","pending","no-presentation-token","nested-revoke","custom-private-bound-callback"]:
		check(equal(selection_result(false,kind),selection_result(true,kind)),"Canonical selection trace matches imperative reference: "+kind)
	attachment_reuse()
	result.native_input_cases=native_cases;result.attachment_cases=attachment_cases
	result.nwn67_scope="Invocation-local canonical lifetime/presentation projection and immutable callback plumbing; original selection/competing corpus and reentry traces, private identity replacement, disclosure changes, attachment parent/mode/scale edits, detach and freed anchors. No live FPS claim."
	return result
