extends "res://tests/native_nameplate_test.gd"
const PopupState=preload("res://systems/native_data/popup_caption_state.gd")
const Rich=preload("res://systems/native_data/rich_text.gd")
var reuse_cases:=0
func view_state(view) -> Dictionary:
	return {"caption":view.caption.get_parsed_text(),"displayed":view.displayed_rich.duplicate(true),"size":view.size,"caption_position":view.caption.position,"caption_size":view.caption.size,"indent":view.text_indent,"bubble":view.bubble_resource,"portrait":view.portrait_key,"portrait_visible":view.portrait_frame.visible,"layout_ready":view.layout_ready,"active":view.presentation_active,"mode":view.presentation_mode}
func source_checks(plate,catalog) -> void:
	super.source_checks(plate,catalog)
	var baseline=load("res://.cache/nwn68/baseline/systems/native_nameplate.gd")
	var control=baseline.new();plate.get_parent().add_child(control);control.configure(plate.art,plate.fonts,plate.source,plate.font_resource)
	var original: Dictionary=plate.data.duplicate(true)
	var value: Dictionary=original.duplicate(true)
	for mode in [2,1,0,2]:
		control.set_popup_preferences(mode,plate.font_resource);plate.set_popup_preferences(mode,plate.font_resource)
		for variant in ["original","same","caption","same-caption","color","no-portrait","portrait","long","same-long","original-again"]:
			match variant:
				"original","original-again":value=original.duplicate(true)
				"caption":value.caption=Rich.parse("[b]literal[/b]\nChanged native caption")
				"color":value.caption_color=Color(0.3,0.7,0.9,1)
				"no-portrait":value.portrait=""
				"portrait":value.portrait=original.portrait
				"long":value.caption=Rich.parse("Long native caption wraps across several lines. ".repeat(8))
			control.set_content(value);plate.set_content(value)
			check(view_state(control)==view_state(plate),"Reuse matches original immutable display state "+str([mode,variant]));reuse_cases+=1
		# Data is borrowed from its owner. In-place edits cannot alias the cache.
		value.caption=Rich.parse("In-place source update");control.set_content(value);plate.set_content(value)
		check(view_state(control)==view_state(plate),"In-place caption mutation invalidates immutable cached render inputs")
	control.set_popup_preferences(2,plate.font_resource);plate.set_popup_preferences(2,plate.font_resource)
	control.set_content(original);plate.set_content(original)
	var refreshes: int=plate.display_refreshes;var layouts: int=plate.layouts;var old_refreshes: int=control.display_refreshes;var old_layouts: int=control.layouts
	for iteration in 120:control.set_content(original);plate.set_content(original)
	check(plate.display_refreshes==refreshes and plate.layouts==layouts and plate.display_reuses>=120,"Repeated current content avoids fitting and RichTextLabel rebuilds")
	check(control.display_refreshes-old_refreshes==120 and control.layouts-old_layouts==120,"Original control actually rebuilds each repeated write")
	control.size=Vector2(1,1);plate.size=Vector2(1,1);control.caption.clear();plate.caption.clear()
	control.set_content(original);plate.set_content(original)
	check(view_state(control)==view_state(plate),"Current SetText restores externally cleared plain caption and size rather than masking them")
	var record:=PopupState.create(2,false)
	PopupState.write(record,original.caption.nativeRawBytes,original.caption,"hover",str(original.portrait),4,0,true,1)
	for step in ["write","unchanged-notification","hide","show","unavailable","restore"]:
		if step=="hide":record.hidden=true
		elif step=="show":record.hidden=false
		elif step=="unavailable":record.currentRawKnown=false
		elif step=="restore":record.currentRawKnown=true
		control.apply_popup_state(record,true,false);plate.apply_popup_state(record,true,false)
		check(view_state(control)==view_state(plate),"Popup notification and unknown-text transition match original "+step);reuse_cases+=1
	# Hook publication adjusts placement without trusting old rich-text caches.
	if plate.source.plans.has("but_popup_prtrt"):
		var hooks: Dictionary=plate.source.plans.but_popup_prtrt.hooks;var prior: Variant=hooks.get("textindent")
		hooks.textindent=Vector2(23,4);control.source_loaded("but_popup_prtrt");plate.source_loaded("but_popup_prtrt")
		check(view_state(control)==view_state(plate),"Late original-model hook publication invalidates caption placement")
		hooks.textindent=prior;control.source_loaded("but_popup_prtrt");plate.source_loaded("but_popup_prtrt")
	control.font_loaded(plate.font_resource);plate.font_loaded(plate.font_resource)
	check(view_state(control)==view_state(plate),"Actual font delivery forces display refresh without changing wrapped lines/bubble")
	var font: Font=plate.caption.get_theme_font("normal_font");var font_size: int=plate.caption.get_theme_font_size("normal_font_size")
	if font is FontFile and font.has_char("W".unicode_at(0)):
		var glyph: int=font.get_glyph_index(font_size,"W".unicode_at(0),0)
		var advance: Vector2=font.get_glyph_advance(0,font_size,glyph)
		var metric_value: Dictionary=original.duplicate(true);metric_value.caption=Rich.parse("W ".repeat(60))
		control.set_content(metric_value);plate.set_content(metric_value)
		var original_size: Vector2=plate.size;var old_fit: int=control.layouts;var new_fit: int=plate.layouts
		font.set_glyph_advance(0,font_size,glyph,Vector2(advance.x*3.0,advance.y))
		control.font_loaded(plate.font_resource);plate.font_loaded(plate.font_resource)
		check(control.layouts==old_fit and plate.layouts==new_fit and plate.size==original_size and view_state(control)==view_state(plate),"Same-Font metric publication updates display without immediate rewrap/bubble choice")
		control.set_content(metric_value);plate.set_content(metric_value)
		check(control.layouts==old_fit+1 and plate.layouts==new_fit+1 and view_state(control)==view_state(plate),"Next SetText refits after metrics mutate in the same Font object")
		font.set_glyph_advance(0,font_size,glyph,advance);control.font_loaded(plate.font_resource);plate.font_loaded(plate.font_resource)
	else:check(false,"Installed original test font supports the same-Font glyph metric mutation fixture")
	control.caption.set_meta("native_text_color",Color(0.6,0.4,0.2,1));plate.caption.set_meta("native_text_color",Color(0.6,0.4,0.2,1))
	control.set_content(original);plate.set_content(original)
	check(view_state(control)==view_state(plate),"Native text color metadata remains an effective paint input")
	var before_color: int=plate.display_refreshes
	control.caption.set_meta("native_text_color",Color(0.2,0.4,0.6,1));plate.caption.set_meta("native_text_color",Color(0.2,0.4,0.6,1))
	control.set_content(original);plate.set_content(original)
	check(plate.display_refreshes==before_color+1 and view_state(control)==view_state(plate),"Changing only native text color metadata invalidates cached paint")
	control.caption.remove_meta("native_text_color");plate.caption.remove_meta("native_text_color")
	var unavailable: Dictionary=original.duplicate(true);unavailable.available=false
	control.set_content(unavailable);plate.set_content(unavailable);control.set_content(original);plate.set_content(original)
	check(view_state(control)==view_state(plate),"Unavailable content and re-admission cannot reuse cleared text")
	control.close();control.queue_free();plate.set_content(original)
