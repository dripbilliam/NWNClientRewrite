extends SceneTree

# Read-only private Node3D representation and notification diagnostic.
class Probe:
	extends Node3D
	var local_notes := 0
	var global_notes := 0
	func _notification(what: int) -> void:
		if what == NOTIFICATION_LOCAL_TRANSFORM_CHANGED: local_notes += 1
		if what == NOTIFICATION_TRANSFORM_CHANGED: global_notes += 1

func bits(value: float) -> String:
	var bytes := PackedByteArray()
	bytes.resize(4)
	bytes.encode_float(0, value)
	return bytes.hex_encode()

func tuple(value: Variant) -> Array:
	if value is Vector3: return [bits(value.x),bits(value.y),bits(value.z)]
	return [bits(value.x),bits(value.y),bits(value.z),bits(value.w)]

func run() -> void:
	var parent := Probe.new()
	root.add_child(parent)
	var child := Probe.new()
	parent.add_child(child)
	parent.set_notify_local_transform(true)
	child.set_notify_transform(true)
	var expected_position := Vector3(1,3,-2)
	var expected_quaternion := Quaternion(0.0,0.0,-0.0,1.0)
	var expected_scale := Vector3.ONE
	var observations: Array = []
	for index in 3:
		parent.position=expected_position
		parent.quaternion=expected_quaternion
		parent.scale=expected_scale
		await process_frame
		observations.append({"step":index,
			"position":{"expected":tuple(expected_position),"live":tuple(parent.position)},
			"quaternion":{"expected":tuple(expected_quaternion),"live":tuple(parent.quaternion)},
			"scale":{"expected":tuple(expected_scale),"live":tuple(parent.scale)},
			"local_notes":parent.local_notes,"child_global_notes":child.global_notes})
	var report := {"observations":observations,
		"local_enabled":parent.is_local_transform_notification_enabled(),
		"child_global_enabled":child.is_transform_notification_enabled()}
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):
			var file := FileAccess.open(arg.substr(9),FileAccess.WRITE)
			if file != null: file.store_string(JSON.stringify(report)+"\n")
	print(JSON.stringify(report))
	parent.free()
	quit()

func _initialize() -> void:
	call_deferred("run")
