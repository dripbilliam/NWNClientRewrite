extends RefCounted
class EventLog extends RefCounted:
	static var items: Array=[]
class Painter extends RefCounted:
	var tag:=""
	func _init(value: String=""):tag=value
class Assets extends RefCounted:
	var running: Dictionary={}
	var retirements:=0
	func retire_scope() -> void:retirements+=1
	func close() -> void:
		for task in running.values():WorkerThreadPool.wait_for_task_completion(int(task))
		running.clear()
class Frame extends Control:
	signal prepared
	signal artwork_ready
	signal action_requested(tag: String)
	signal title_input(event: InputEvent)
	var assets:=Assets.new()
	var definition:={"size":Vector2(320,200)}
	var stage: Control
	var buttons: Dictionary={}
	var confirmation: Control
	var held: Dictionary={}
	var scope: Array=[]
	var closed:=false
	func _ready() -> void:stage=Control.new();add_child(stage);hide()
	func configure(_frame,_text,_catalog,_cache) -> void:EventLog.items.append("frame.configure")
	func set_modal_order(_order,_surfaces=null,_canvas=null,_admission: Callable=Callable()) -> void:EventLog.items.append("frame.modal")
	func start() -> void:EventLog.items.append("frame.start")
	func close() -> void:
		if closed:return
		closed=true;EventLog.items.append("frame.close");assets.close()
	func dismiss() -> void:hide()
	func art_ready() -> bool:return false
	func set_context(value: Array,_availability: Dictionary) -> void:scope=value.duplicate()
	func release_button(_button) -> void:pass
class Video extends Control:
	signal prepared
	signal finished
	var assets:=Assets.new()
	var layout_ready:=true
	var failure:=""
	var closed:=false
	func configure(_frame,_text,_catalog,_cache,_settings,_path) -> void:EventLog.items.append("video.configure");hide()
	func set_modal_order(_order,_surfaces=null,_canvas=null) -> void:EventLog.items.append("video.modal")
	func close() -> void:
		if closed:return
		closed=true;EventLog.items.append("video.close");assets.close()
	func retire_scope() -> void:hide()
class Keys extends Control:
	signal prepared
	signal finished
	var assets:=Assets.new()
	var layout_ready:=true
	var failure:=""
	var closed:=false
	func configure(_frame,_text,_catalog,_cache,_bindings,_path) -> void:EventLog.items.append("keys.configure");hide()
	func set_modal_order(_order,_surfaces=null,_canvas=null) -> void:EventLog.items.append("keys.modal")
	func close() -> void:
		if closed:return
		closed=true;EventLog.items.append("keys.close");assets.close()
	func retire_scope() -> void:hide()
class Style extends Node:
	signal changed(value: Theme)
	var tag:="prior"
	var entry_publication_active:=false
	var publication_steps:=0
	var pending_theme: Theme
	func begin_entry_publication() -> void:entry_publication_active=true;publication_steps=0
	func configure(painter) -> void:
		tag=painter.tag;EventLog.items.append("style.configure:"+tag)
		var value:=Theme.new();value.set_meta("painter",tag)
		if entry_publication_active:pending_theme=value
		else:changed.emit(value)
	func entry_publication_step() -> Dictionary:
		publication_steps+=1
		if publication_steps<3:return {"done":false}
		entry_publication_active=false;changed.emit(pending_theme)
		return {"done":true,"accepted":true}
	func close() -> void:entry_publication_active=false;EventLog.items.append("style.close:"+tag)
class Pregame extends Control:
	var painter: RefCounted
	func dismiss() -> void:EventLog.items.append("pregame.dismiss");hide()
	func close() -> void:pass
	func snapshot() -> Dictionary:return {}
class Bindings extends RefCounted:
	signal changed
	var bindings_ready:=true
