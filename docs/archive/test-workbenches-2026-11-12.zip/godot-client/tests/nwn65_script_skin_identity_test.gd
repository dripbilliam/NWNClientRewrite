extends "res://tests/nwn65_script_skin_setter_test.gd"
# Exact scalar-versus-identity-slot setter parity, with and without the
# independent combined nonempty-slot route. No timing or GPU readback.

func compare_identity(combined: bool) -> void:
	var original: Dictionary=setup(false,false,false)
	var candidate: Dictionary=setup(false,false,false)
	candidate.rigs.use_identity_skin_setter=true
	candidate.rigs.use_combined_skin_setter=combined
	check(not original.rigs.use_identity_skin_setter and candidate.rigs.use_identity_skin_setter,"Identity-slot route explicitly selected")
	var sparse_slots:=0
	for skin: Dictionary in original.entry.skins:
		for part in skin.bones:
			if int(part)<0:sparse_slots+=1
	check(sparse_slots>100,"Both authored skins exercise many sparse identity slots")
	for row: Dictionary in [original,candidate]:
		for skin: Dictionary in row.entry.skins:
			var skeleton: Skeleton3D=skin.skeleton
			skeleton.set_bone_parent(1,0)
			skeleton.set_bone_parent(2,1)
			skeleton.set_bone_rest(0,Transform3D(Basis(Quaternion(Vector3.UP,0.23)),Vector3(0.2,-0.3,0.4)))
			skeleton.set_bone_rest(1,Transform3D(Basis(Quaternion(Vector3.RIGHT,-0.17)),Vector3(-0.1,0.5,0.3)))
	for frame: int in 24:
		for row: Dictionary in [original,candidate]:
			if frame in [0,4,11,19]:
				for skin: Dictionary in row.entry.skins:
					# Sparse slot 12 is externally mutated before publication; the
					# candidate must restore all three original components.
					skin.skeleton.set_bone_pose(12,Transform3D(Basis(Quaternion.from_euler(Vector3(0.3,-0.2,0.7))).scaled(Vector3(1.7,0.6,2.3)),Vector3(0.4,-0.5,0.8)))
			if frame==5:row.rigs.set_manual_pose(1,row.entry.nodes[1],Vector3(0.2,-0.7,0.3),Quaternion(Vector3.RIGHT,0.17))
			if frame==8:row.entry.attachments[0].flags=0
			if frame==12:row.entry.attachments[0].flags=3
			if frame==13:row.rigs._play(row.entry.models[0],"turn",true,-0.5,0.4,true)
			if frame==17:row.entry.parents=[-1,0,0,2,3]
			row.rigs._update(0.0625)
		check(var_to_bytes(capture(original))==var_to_bytes(capture(candidate)),"Exact node/local/global bone, event, force and clock output frame "+str(frame)+" combined="+str(combined))
		check(var_to_bytes(skin_matrices(original))==var_to_bytes(skin_matrices(candidate)),"Exact CPU skin matrices frame "+str(frame)+" combined="+str(combined))
		for row: Dictionary in [original,candidate]:
			for skin: Dictionary in row.entry.skins:
				var skeleton: Skeleton3D=skin.skeleton
				check(skeleton.get_bone_pose(12)==Transform3D.IDENTITY,"Sparse slot external pose reset frame "+str(frame))
	check(original.forces==candidate.forces and not original.forces.is_empty(),"Force notification order/count preserved")
	for row: Dictionary in [original,candidate]:
		row.rigs.forget_entity(1)
		check(row.rigs.entities.is_empty(),"Appearance entity retired")
		row.host.free()
		row.clear()
	coverage.append("24 animated frames with sparse prior nonidentity/nonunit slot, rest/parent changes, manual/reverse/attachment changes, exact local/global poses, CPU skin matrices, event/force order and retirement; combined="+str(combined))

func run() -> void:
	compare_identity(false)
	compare_identity(true)
	finish()
