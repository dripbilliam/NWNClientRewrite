extends SceneTree
const Entities=preload("res://systems/client_api/entities.gd")
const NativeBinding=preload("res://systems/client_api/native_binding.gd")
var output:=""
var checks:=0
var failures: Array=[]

func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.trim_prefix("--report=")
	call_deferred("run")

func check(value: bool,label: String) -> void:
	checks+=1
	if not value:failures.append(label)

func row(id: int,area: int) -> Dictionary:
	return {"id":id,"areaId":area,"objectType":5,"nativeLifetime":id+1,"clientKnownLifetime":id+1,"replicated":{"name":"actor-"+str(id)}}

func normalize(value: Variant) -> Variant:
	if value is Dictionary:
		var result: Dictionary={}
		for key in value:
			if key!="api_instance":result[key]=normalize(value[key])
		return result
	if value is Array:
		var result: Array=[]
		for item in value:result.append(normalize(item))
		return result
	return value

func setup(log: Array,cancel_on_add: bool=false) -> Dictionary:
	var api=Entities.new()
	api._bind_sources(func(_id):return null,func(_id):return null)
	api.scope_changed.connect(func(event):log.append(["scope",event]))
	api.entity_removed.connect(func(event):log.append(["remove",event]))
	api.entity_added.connect(func(event):
		log.append(["add",event])
		if cancel_on_add:api._cancel_entry_boundary())
	api.controlled_entity_changed.connect(func(event):log.append(["control",event]))
	check(api._apply_boundary(1,1,100,7,[row(7,100),row(9,100)],[],true),"initial scope")
	log.clear()
	var binding=NativeBinding.new(api)
	return {"api":api,"binding":binding}

func run_case(batch: int,cancel_on_add: bool=false) -> Dictionary:
	var log: Array=[]
	var pair:=setup(log,cancel_on_add)
	var api=pair.api
	var binding=pair.binding
	var objects: Array=[]
	for i in 256:objects.append(row(i+20,200))
	objects.append(row(21,200))
	check(binding.begin_entry_commit(1,2,200,{"bridgeMode":"full","objects":objects,"removedObjectIds":[],"controlledId":20}),"entry admitted "+str(batch))
	var calls:=0
	var units:=0
	var result: Dictionary={}
	while calls<2048:
		result=binding.entry_commit_step() if batch==1 else binding.entry_commit_steps(Time.get_ticks_usec()+1000000,batch)
		calls+=1
		units+=int(result.get("steps",1))
		if result.get("done",false):break
	return {"result":result,"calls":calls,"units":units,"scope":api.get_scope(),"known":api._known.duplicate(true),"diagnostics":api.diagnostics(),"log":log}

func run() -> void:
	if output.is_empty() or FileAccess.file_exists(output):quit(2);return
	var single:=run_case(1)
	check(single.result.get("accepted",false),"single-step control completes")
	var batch_calls: Dictionary={}
	for batch in [7,64]:
		var candidate:=run_case(batch)
		batch_calls[batch]=candidate.calls
		check(candidate.result.get("accepted",false),"batch completes "+str(batch))
		check(candidate.units==single.units,"same state-machine unit count "+str(batch))
		check(candidate.calls<single.calls,"fewer binding round trips "+str(batch))
		check(candidate.scope==single.scope and candidate.known==single.known,"scope and lifetimes identical "+str(batch))
		check(candidate.diagnostics==single.diagnostics,"metrics identical "+str(batch))
		check(normalize(candidate.log)==normalize(single.log),"ordered observer events identical "+str(batch))
	var stopped:=run_case(64,true)
	check(stopped.result.get("done",false) and not stopped.result.get("accepted",true),"callback cancellation stops batch")
	check(stopped.log.filter(func(entry):return entry[0]=="add").size()==1,"no observer event after cancellation")
	var immediate_log: Array=[]
	var immediate:=setup(immediate_log)
	check(immediate.binding.begin_entry_commit(1,2,200,{"bridgeMode":"full","objects":[row(20,200)],"removedObjectIds":[],"controlledId":20}),"deadline fixture admitted")
	var first: Dictionary=immediate.binding.entry_commit_steps(0,64)
	check(first.get("steps",0)==1 and not first.get("done",false),"expired deadline admits at most one row")
	var file:=FileAccess.open(output,FileAccess.WRITE)
	file.store_string(JSON.stringify({"checks":checks,"failures":failures,"passed":failures.is_empty(),"single_calls":single.calls,"batch_7_calls":batch_calls[7],"batch_64_calls":batch_calls[64]},"\t"));file.close()
	quit(0 if failures.is_empty() else 1)
