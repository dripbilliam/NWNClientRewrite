extends SceneTree

const Rigs=preload("res://systems/model_rigs.gd")
var failures: Array[String]=[]
var checks:=0

func check(value: bool,message: String)->void:
	checks+=1
	if not value and failures.size()<30:failures.append(message)

func clip(name: String,part: int,property: String,values: Array,events: Array=[])->Dictionary:
	return {"name":name,"length":0.5,"transition":0.15,"events":events,
		"tracks":[{"part":part,"property":property,"sourceInterpolation":"linear",
			"keys":[{"time":0.0,"value":values[0]},{"time":0.5,"value":values[1]}]}]}

func setup(sparse: bool)->Dictionary:
	var host:=Node3D.new();root.add_child(host)
	var rigs:=Rigs.new();host.add_child(rigs);rigs.set_process(false)
	rigs.use_sparse_default_tracks=sparse;rigs.use_native_skin_publisher=false
	var nodes: Array[Node3D]=[]
	for index in 3:
		var node:=Node3D.new();(host if index==0 else nodes[0]).add_child(node)
		node.position=Vector3(index*0.3,index*0.2,-index*0.1)
		nodes.append(node)
	var defaults: Array=[]
	for index in 3:
		defaults.append({"position":[index*0.3,index*0.2,-index*0.1],
			"quaternion":[1,0,0,0],"scale":[1,1,1]})
	var a:=clip("a",0,"position",[[0,0,0],[1,2,3]],[{"time":0.125,"name":"a_event"}])
	var b:=clip("b",1,"position",[[0.3,0.2,-0.1],[2,1,-3]],[{"time":0.25,"name":"b_event"}])
	var c:=clip("c",2,"quaternion",[[1,0,0,0],[0.9,0.1,0.2,0.3]])
	var asset:={"defaults":defaults,"unsupported":[],"clips":[a,b,c],"lazyClips":true,
		"clipIndex":{"a":0,"b":1,"c":2},"controlled":{
			"0:position":{"part":0,"property":"position","bezier":false},
			"1:position":{"part":1,"property":"position","bezier":false},
			"2:quaternion":{"part":2,"property":"quaternion","bezier":false}}}
	var source:={"parts":[0,1,2],"defaults":defaults,"follow":true,"clip":"a","loop":true,"speed":1.0,"time":0.0}
	var model: Dictionary=rigs._model(host,nodes,source,asset);model.asset_source=asset;model.part_source=source;model.event_source=true
	var skeleton:=Skeleton3D.new();host.add_child(skeleton)
	for index in 3:skeleton.add_bone("bone_"+str(index))
	var entry:={"root":host,"nodes":nodes,"parents":[-1,0,0],"models":[model],
		"animated_models":[0],"manual_poses":{},"attachments":[{"node":2,"anchor":0,"scale":[1,1,1],"flags":0}],
		"skins":[{"part":0,"bones":[0,1,2],"skeleton":skeleton}],"counts":{}}
	rigs.entities[1]=entry
	var log: Array=[]
	rigs.model_event.connect(func(id,index,name,serial):log.append(["model",id,index,name,serial]))
	rigs.animation_event.connect(func(id,name,serial):log.append(["animation",id,name,serial]))
	return {"host":host,"rigs":rigs,"entry":entry,"nodes":nodes,"skeleton":skeleton,"log":log}

func capture(row: Dictionary)->Dictionary:
	var model: Dictionary=row.entry.models[0]
	var bones: Array=[]
	for index in row.skeleton.get_bone_count():
		bones.append([row.skeleton.get_bone_pose_position(index),
			row.skeleton.get_bone_pose_rotation(index),row.skeleton.get_bone_pose_scale(index),
			row.skeleton.get_bone_global_pose(index)])
	return {"nodes":row.nodes.map(func(node):return [node.position,node.quaternion,node.scale,node.global_transform]),
		"bones":bones,"events":row.log.duplicate(true),"clip":model.clip,"time":model.last_time,
		"serial":model.play_serial,"playing":model.player.is_playing(),
		"player_clip":model.player.current_animation,"player_time":model.player.current_animation_position}

func dispose(row: Dictionary)->void:
	row.rigs.forget_entity(1);row.host.free()

func run()->void:
	var output:=""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.substr(9)
	if output.is_empty() or FileAccess.file_exists(output):quit(2);return
	var ordinary:=setup(false)
	var sparse:=setup(true)
	check(not ordinary.entry.models[0].player.deterministic and sparse.entry.models[0].player.deterministic,"Explicit mode selection")
	check(sparse.entry.models[0].player.has_animation("RESET"),"Sparse model includes RESET defaults")
	check(ordinary.entry.models[0].player.get_animation("clip_0").get_track_count()==3,"Original active clip includes all defaults")
	check(sparse.entry.models[0].player.get_animation("clip_0").get_track_count()==1,"Sparse active clip retains only authored track")
	var compared:=0
	var mismatch_rows: Array=[]
	for frame in 60:
		for row in [ordinary,sparse]:
			var model: Dictionary=row.entry.models[0]
			if frame==8:row.rigs._play(model,"b",true,1.0,0.0,true)
			if frame==17:row.rigs._play(model,"c",true,1.0,0.0,true)
			if frame==25:row.rigs._play(model,"a",true,-0.5,0.4,true)
			if frame==34:row.rigs._play(model,"b",false,1.0,0.0,true)
			if frame==42:row.entry.manual_poses[1]={"position":Vector3(4,5,6),"quaternion":Quaternion.IDENTITY,"scale":Vector3.ONE}
			if frame==45:row.entry.manual_poses.clear()
			if frame==48:row.entry.attachments[0].flags=3
			if frame==53:row.entry.attachments[0].flags=0
			row.rigs._update(0.0625)
		var a:=capture(ordinary);var b:=capture(sparse)
		if var_to_bytes(a)!=var_to_bytes(b) and mismatch_rows.size()<5:
			mismatch_rows.append({"frame":frame,"ordinary":a,"sparse":b})
		check(var_to_bytes(a)==var_to_bytes(b),"Exact pose/skin/clock/event/missing-track parity frame "+str(frame))
		compared+=1
	var report:={"passed":failures.is_empty(),"checks":checks,"failures":failures,
		"frames":compared,"mismatch_rows":mismatch_rows,"sourceSha256":FileAccess.get_sha256("res://systems/model_rigs.gd"),
		"scope":"Actual AnimationPlayers with three disjoint controlled channels, RESET defaults, missing-track transitions, reverse/nonloop playback, manual pose, attachments, skin and ordered events. Synthetic clip fixture; original assets and FPS separate."}
	dispose(ordinary);dispose(sparse)
	var file:=FileAccess.open(output,FileAccess.WRITE)
	if file!=null:file.store_string(JSON.stringify(report,"\t")+"\n")
	print(JSON.stringify(report));quit(0 if failures.is_empty() else 1)

func _initialize()->void:call_deferred("run")
