extends "res://tests/nwn63_frame_input_admission_test.gd"

func deferred_fixture()->Dictionary:
	var f:=input_fixture()
	var tokens: Array=[]
	f.input.predict=func(_id,flags,_heading):tokens.append(f.input.preview_token(flags));return {"deferred":true}
	f.tokens=tokens
	push_key(f,KEY_W);f.input.flush_input_frame(1,1000)
	check(f.sent.size()==1 and f.tokens.size()==1 and f.input.stats.previews==0 and f.input.last_sent==1000,"Deferred result preserves ordered wire send and waits to count preview")
	return f

func valid_completion()->void:
	var f:=deferred_fixture();var result:={"target":Vector3(3,3,0),"factor":1.0,"resendFraction":0.5}
	check(f.input.complete_async_preview(f.tokens[0],result),"Current worker result admits")
	check(f.input.last_sent==750 and f.input.stats.previews==1,"Late fraction uses original 1000 ms request time")
	check(not f.input.complete_async_preview(f.tokens[0],result) and f.input.stats.previews==1,"Worker result cannot be consumed twice")
	dispose_input(f)

func stale_completions()->void:
	var result:={"target":Vector3(3,3,0),"factor":1.0,"resendFraction":0.5}
	var f:=deferred_fixture();var first: Dictionary=f.tokens[0].duplicate(true)
	f.input.flush_input_frame(2,1250)
	check(f.input.request_serial==2 and not f.input.complete_async_preview(first,result),"New preview request supersedes prior fraction")
	dispose_input(f)
	f=deferred_fixture();first=f.tokens[0].duplicate(true);f.input.stop(false)
	check(not f.input.complete_async_preview(first,result),"Stop generation rejects worker completion")
	dispose_input(f)
	f=deferred_fixture();first=f.tokens[0].duplicate(true);f.input.last_flags=999
	check(not f.input.complete_async_preview(first,result),"Input flag change rejects worker completion")
	dispose_input(f)
	f=deferred_fixture();first=f.tokens[0].duplicate(true);f.input.owner_identity="new-owner"
	check(not f.input.complete_async_preview(first,result),"Owner identity change rejects worker completion")
	dispose_input(f)
	f=deferred_fixture();first=f.tokens[0].duplicate(true);f.state.lifetime=12
	check(not f.input.complete_async_preview(first,result),"Lifetime change rejects worker completion")
	dispose_input(f)
	f=deferred_fixture();first=f.tokens[0].duplicate(true)
	check(not f.input.complete_async_preview(first,{"deferred":true}),"Deferred placeholder cannot complete itself")
	dispose_input(f)

func run()->void:
	valid_completion();stale_completions()
	await process_frame;await process_frame
	var report:={"success":failures.is_empty(),"checks":checks,"failures":failures,"scope":"NWN-73 async keyboard completion token guard. Ordered wire request remains synchronous; fraction uses original request time. Serial, stop generation, input flags, identity and lifetime reject stale results. World adapter must still enforce once-only consumption and collision/pose authority."}
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--report="):
			var file:=FileAccess.open(argument.trim_prefix("--report="),FileAccess.WRITE);file.store_string(JSON.stringify(report,"  "));file.close()
	print(JSON.stringify(report));quit(0 if failures.is_empty() else 1)
