extends SceneTree
const Collision=preload("res://systems/native_render/drive_collision_indexed.gd")
const Terrain=preload("res://systems/native_render/terrain_surface.gd")
const Motion=preload("res://systems/network_motion.gd")
var checks:=0
var failures: Array=[]
var report:=""

class World:
	extends Node
	var generation:=1
	var area_id:=73
	var surface
	var desired: Dictionary={}
	var motion:=Motion.new()

func _initialize() -> void:call_deferred("run")
func check(ok: bool,label: String) -> void:
	checks+=1
	if not ok:failures.append(label)

func grid_mesh() -> Dictionary:
	var vertices: Array=[];var faces: Array=[];var materials: Array=[];var normals: Array=[];var constants: Array=[]
	for y in 10:
		for x in 10:
			var at:=vertices.size()
			for p in [Vector2(x,y),Vector2(x+1,y),Vector2(x+1,y+1),Vector2(x,y+1)]:vertices.append([float(p.x),float(p.y),1.0])
			for face in [[0,1,2],[0,2,3]]:
				faces.append([at+face[0],at+face[1],at+face[2]])
				materials.append(1 if (x+y)%11==0 else 0)
				normals.append([0.0,0.0,1.0]);constants.append(-1.0)
	return {"vertices":vertices,"faces":faces,"materials":materials,"normals":normals,"constants":constants}

func run() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):report=arg.trim_prefix("--report=")
	if report.is_empty() or FileAccess.file_exists(report):quit(2);return
	var enabled:=OS.get_cmdline_user_args().has("--drive-height-plan=worker")
	var world:=World.new();root.add_child(world)
	var surface:=Terrain.new();world.add_child(surface);world.surface=surface
	surface.done=true;surface.table={"orderedRows":[{"Walk":"1"},{"Walk":"0"}]}
	var tiles: Array=[]
	for i in 4:tiles.append({"model":"floor","orientation":i,"position":Vector3(5+i*10,2,-5)})
	surface.definition={"width":4,"height":1,"tiles":tiles};surface.meshes={"floor":grid_mesh()}
	var collision:=Collision.new();world.add_child(collision);collision.world=world
	check(collision._height_plan_enabled==enabled,"only exact worker option enables WOK plan")
	collision.tables={"appearance":{"orderedRows":[{"PERSPACE":"0.3","HEIGHT":"1.8"}]},"placeables":{"orderedRows":[]},"genericdoors":{"orderedRows":[]},"doortypes":{}}
	world.desired[1]={"object":{"id":1,"objectType":5,"appearance":{"appearance":0}}};world.motion.ensure(1,{"position":[1,1,0]})
	collision.sync_full();check(collision.ready(),"configured collision and terrain ready")
	if enabled:
		var deadline:=Time.get_ticks_msec()+1000
		while collision._height_plan.is_empty() and Time.get_ticks_msec()<deadline:
			await process_frame
			collision.ready()
		check(not collision._height_plan.is_empty() and collision._height_plan_stats.ready==1,"bounded worker published immutable material-order plan")
	var points: Array=[Vector3(-0.01,2,0),Vector3(0,0,0),Vector3(1,1,0),Vector3(9.9999,5,0),Vector3(10,5,0),Vector3(19.9999,5,0),Vector3(20,5,0),Vector3(30,5,0),Vector3(39.9999,9.9999,0),Vector3(40,5,0)]
	for i in 240:points.append(Vector3(float((i*17)%3999)/100.0,float((i*13)%999)/100.0,0))
	var answers: Array=[]
	for point: Vector3 in points:
		var original: float=surface.height(point,7.0)
		var planned: float=collision._drive_height(surface,point,7.0)
		check(original==planned,"exact height at "+str(point))
		answers.append(planned)
	# Short warmed component comparison on the same exact points. These are
	# elapsed CPU samples, never an FPS or whole movement-path claim.
	var timing: Array=[]
	for route: String in ["original","planned","planned","original"]:
		var began:=Time.get_ticks_usec();var checksum:=0.0
		for repeat in 6:
			for point: Vector3 in points:
				checksum+=surface.height(point,7.0) if route=="original" else collision._drive_height(surface,point,7.0)
		timing.append({"route":route,"ms":(Time.get_ticks_usec()-began)/1000.0,"checksum":checksum,"calls":points.size()*6})
	check(timing.all(func(row):return row.checksum==timing[0].checksum),"component timing paths preserve aggregate exact heights")
	var clear:=collision.query(1);var decisions: Array=[]
	for path: Array in [[Vector3(1,1,0),Vector3(3,1,0)],[Vector3(9.5,5,0),Vector3(10.5,5,0)],[Vector3(19.5,5,0),Vector3(20.5,5,0)],[Vector3(29.5,5,0),Vector3(30.5,5,0)],[Vector3(39.5,5,0),Vector3(40.5,5,0)],[Vector3(1,1,0),Vector3(1,1,0)]]:
		decisions.append(bool(clear.call(path[0],path[1])))
	# Changed source identity and malformed face count must take the original path.
	var original_table: Dictionary=surface.table;surface.table={"orderedRows":[{"Walk":"0"},{"Walk":"0"}]}
	var changed: float=surface.height(Vector3(1,1,0),7.0)
	check(collision._drive_height(surface,Vector3(1,1,0),7.0)==changed,"changed material table falls back")
	surface.table=original_table
	var original_rows: Array=surface.table.orderedRows
	surface.table.orderedRows=[{"Walk":"0"},{"Walk":"0"}]
	changed=surface.height(Vector3(1,1,0),7.0)
	check(collision._drive_height(surface,Vector3(1,1,0),7.0)==changed,"replaced table rows within same dictionary fall back")
	surface.table.orderedRows=original_rows
	var mesh: Dictionary=surface.meshes.floor;var old_faces: Array=mesh.faces;mesh.faces=[]
	var degenerate: float=surface.height(Vector3(1,1,0),7.0)
	check(collision._drive_height(surface,Vector3(1,1,0),7.0)==degenerate,"changed or degenerate face count falls back")
	mesh.faces=old_faces
	var old_materials: Array=mesh.materials;mesh.materials=old_materials.duplicate()
	mesh.materials.fill(1)
	changed=surface.height(Vector3(1,1,0),7.0)
	check(collision._drive_height(surface,Vector3(1,1,0),7.0)==changed,"same-size material array replacement falls back")
	mesh.materials=old_materials
	var plan_stats: Dictionary=collision._height_plan_stats.duplicate()
	collision.close();check(collision._height_plan_worker==null and collision._height_plan.is_empty(),"close joins worker and retires plan")
	world.free()
	if enabled:
		var retired_surface:=Terrain.new();root.add_child(retired_surface)
		retired_surface.done=true;retired_surface.table={"orderedRows":[{"Walk":"1"},{"Walk":"0"}]}
		retired_surface.definition={"width":1,"height":1,"tiles":[{"model":"floor","orientation":0,"position":Vector3.ZERO}]}
		retired_surface.meshes={"floor":grid_mesh()}
		var retired_collision:=Collision.new();root.add_child(retired_collision)
		retired_collision._prepare_height_plan(retired_surface)
		check(retired_collision._height_plan_stats.starts==1,"retirement case starts private worker")
		retired_surface.close()
		check(retired_collision._drive_height(retired_surface,Vector3(1,1,0),7.0)==7.0,"closed WOK source takes original previous-height route")
		retired_collision.close()
		check(retired_collision._height_plan_worker==null and retired_collision._height_plan.is_empty(),"in-flight close joins without publishing stale plan")
		retired_collision.free();retired_surface.free()
	var file:=FileAccess.open(report,FileAccess.WRITE)
	if file==null:quit(3);return
	file.store_string(JSON.stringify({"success":failures.is_empty(),"checks":checks,"failures":failures,"enabled":enabled,"answers":answers,"decisions":decisions,"plan":plan_stats,"timing":timing,"scope":"Exact synchronous WOK height and drive-clear answers with optional worker-built face order; synthetic 200-face rotated tiles, boundary and mutation fallbacks. Short warmed component elapsed timings only, no FPS or original-asset claim."},"  "));file.close()
	quit(0 if failures.is_empty() else 1)
