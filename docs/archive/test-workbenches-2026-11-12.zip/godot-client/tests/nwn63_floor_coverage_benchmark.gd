extends "res://tests/nwn63_floor_coverage_test.gd"
# Scripted CPU component timing only; no frame loop, viewport or FPS sampling.
func stats_for(samples: Array)->Dictionary:
	var ordered:=samples.duplicate();ordered.sort();var sum:=0.0
	for value in samples:sum+=float(value)
	return {"samples":samples.size(),"mean_us":sum/samples.size(),"median_us":ordered[ordered.size()/2],"p95_us":ordered[mini(ordered.size()-1,ceili(ordered.size()*0.95)-1)],"p99_us":ordered[mini(ordered.size()-1,ceili(ordered.size()*0.99)-1)]}
func dense_mesh(world,repetitions: int)->void:
	var mesh: Dictionary=world.surface.meshes.floor.duplicate(true);var faces: Array=mesh.faces.duplicate(true);var materials: Array=mesh.materials.duplicate();var normals: Array=mesh.normals.duplicate(true);var constants: Array=mesh.constants.duplicate()
	for repeat in repetitions-1:mesh.faces.append_array(faces);mesh.materials.append_array(materials);mesh.normals.append_array(normals);mesh.constants.append_array(constants)
	world.surface.meshes.floor=mesh
func grid_mesh(world,divisions: int)->void:
	var mesh:={"vertices":[],"faces":[],"materials":[],"normals":[],"constants":[]}
	for y in divisions+1:
		for x in divisions+1:mesh.vertices.append([10.0*x/divisions,10.0*y/divisions,0.0])
	for y in divisions:
		for x in divisions:
			var a:=y*(divisions+1)+x;var b:=a+1;var c:=a+divisions+1;var d:=c+1
			mesh.faces.append([a,b,d]);mesh.faces.append([a,d,c]);mesh.materials.append(0);mesh.materials.append(0);mesh.normals.append([0,0,1]);mesh.normals.append([0,0,1]);mesh.constants.append(0);mesh.constants.append(0)
	world.surface.meshes.floor=mesh
func sample_case(spec: Dictionary,samples: int)->Dictionary:
	var worlds:=pair()
	for setup in worlds:
		if spec.get("grid",false):grid_mesh(setup.world,24)
		elif int(spec.faces)>2:dense_mesh(setup.world,int(spec.faces)/2)
		var geometry: Array=setup.collision.tile(0)
		if spec.blocked:geometry.append(face(Vector3(2.2,0,0),Vector3(2.2,4,0),Vector3(2.2,4,3),false))
		setup.collision.tiles[0]=geometry
	var a: Vector3=spec.from;var b: Vector3=spec.to;var report:={"case":spec.name,"floor_faces":spec.faces,"blocks":[],"observations_equal":true}
	var expected: Dictionary={};var expected_ready:=false
	for index in [0,1,1,0]:
		var collision=worlds[index].collision
		for warm in 8:Plan.path(a,b,a,collision.query_preview(1,a,b,a))
		var counts_before: Dictionary=collision.preview_stats.duplicate();var timings: Array=[]
		for sample in samples:
			var began:=Time.get_ticks_usec()
			var result: Dictionary=Plan.path(a,b,a,collision.query_preview(1,a,b,a))
			timings.append(Time.get_ticks_usec()-began)
			if not expected_ready:expected=result;expected_ready=true
			if var_to_bytes(expected)!=var_to_bytes(result):report.observations_equal=false
		var counters: Dictionary={}
		for key in ["probes","initial_clears","reused_clears","fallback_clears","collections"]:counters[key]=int(collision.preview_stats[key])-int(counts_before[key])
		report.blocks.append({"engine":"reference" if index==0 else "optimized","timing":stats_for(timings),"counts":counters})
	check(report.observations_equal,str(spec.name)+": sampled results remain bit-exact")
	check(report.blocks[0].counts==report.blocks[1].counts and report.blocks[0].counts==report.blocks[2].counts and report.blocks[0].counts==report.blocks[3].counts,str(spec.name)+": A-B-B-A preserves probe and collection counts")
	for setup in worlds:setup.world.free()
	return report
func run()->void:
	var options: Dictionary={}
	for argument in OS.get_cmdline_user_args():
		var pair:=argument.trim_prefix("--").split("=",true,1)
		if pair.size()==2:options[pair[0]]=pair[1]
	var samples:=int(options.get("samples",48));check(samples>=16 and samples<=256,"Bounded explicit timing samples")
	var cases: Array=[]
	for spec in [
		{"name":"sparse-free","faces":2,"blocked":false,"from":Vector3(1,1,0),"to":Vector3(3,1,0)},
		{"name":"sparse-blocked","faces":2,"blocked":true,"from":Vector3(1,1,0),"to":Vector3(3,1,0)},
		{"name":"dense-free","faces":512,"blocked":false,"from":Vector3(1,1,0),"to":Vector3(3,1,0)},
		{"name":"dense-blocked","faces":512,"blocked":true,"from":Vector3(1,1,0),"to":Vector3(3,1,0)},
		{"name":"dense-crossing-triangles","faces":512,"blocked":false,"from":Vector3(2,1,0),"to":Vector3(1,2,0)},
		{"name":"dense-crossing-tiles","faces":512,"blocked":false,"from":Vector3(9,1,0),"to":Vector3(11,1,0)},
		{"name":"grid-free","faces":1152,"grid":true,"blocked":false,"from":Vector3(1,1,0),"to":Vector3(3,1,0)},
		{"name":"grid-blocked","faces":1152,"grid":true,"blocked":true,"from":Vector3(1,1,0),"to":Vector3(3,1,0)},
		{"name":"grid-crossing-tiles","faces":1152,"grid":true,"blocked":false,"from":Vector3(9,1,0),"to":Vector3(11,1,0)}
	]:cases.append(sample_case(spec,samples))
	var result:={"success":failures.is_empty(),"checks":checks,"failures":failures,"cases":cases,"order":"A-B-B-A","scope":"Authored immutable WOK-backed normal uninstrumented-engine query_preview plus unchanged Plan.path CPU time. Same process; scene construction outside timing. Dense cases use 512 overlapping walkable faces; grid cases use 1152 tessellated faces. No frame-time/FPS, live Arelith or loading-latency claim."}
	var output:=FileAccess.open(str(options.report),FileAccess.WRITE);output.store_string(JSON.stringify(result,"  "));output.close()
	print(JSON.stringify({"success":result.success,"checks":checks,"cases":cases}));quit(0 if failures.is_empty() else 1)
