extends SceneTree

# Data-only gate for an optional ordinary-rig NativeAnimation route.
const Recorded=preload("res://systems/native_data/recorded_catalog.gd")
const Assets=preload("res://systems/native_data/asset_service.gd")
const Cache=preload("res://systems/native_data/prepared_cache.gd")

var failures: Array[String]=[]
var checks:=0

func check(value: bool,message: String)->void:
	checks+=1
	if not value:failures.append(message)

func run()->void:
	var report_path:=""
	var proposal_path:=""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):report_path=arg.substr(9)
		if arg.begins_with("--proposal="):proposal_path=arg.substr(11)
	if report_path.is_empty() or proposal_path.is_empty() or FileAccess.file_exists(report_path):quit(2);return
	var proposal: Dictionary=JSON.parse_string(FileAccess.get_file_as_string(proposal_path))
	check(proposal.resources.size()==3,"Three pinned original models")
	var manifest:=ProjectSettings.globalize_path("res://"+str(proposal.catalog.file))
	check(FileAccess.get_sha256(manifest)==str(proposal.catalog.sha256),"Pinned original catalog")
	var catalog:=Recorded.new()
	check(catalog.mount(manifest.get_base_dir()),"Original catalog mounts read-only")
	var service:=Assets.new()
	var rows: Array=[]
	for resource in proposal.resources:
		var name:=str(resource.key).split(":")[0]
		var reader=catalog.fork()
		var bytes: PackedByteArray=reader.get_resource(name,2002)
		check(reader.failure.is_empty() and bytes.size()==int(resource.bytes) and Cache.digest(bytes)==str(resource.sha256),"Exact original model bytes "+name)
		if not reader.failure.is_empty() or bytes.is_empty():continue
		var result: Array=[]
		var task:=WorkerThreadPool.add_task(func():result.append(service.actor_data(reader,name,bytes,"",[],{},str(resource.sha256))),false,"NWN65 native coverage")
		while not WorkerThreadPool.is_task_completed(task):await process_frame
		WorkerThreadPool.wait_for_task_completion(task)
		var decoded: Dictionary=result[0]
		check(str(decoded.get("error","missing")).is_empty(),"Original actor decodes "+name)
		if not str(decoded.get("error","missing")).is_empty():continue
		var model: Dictionary=decoded.value
		var asset: Dictionary=service.rig_data(model,decoded.get("animation_sources",[]),"")
		var native: Dictionary=asset.get("nativeAnimation",{})
		var available: Array=[]
		var unavailable: Array=[]
		var requested: Dictionary={}
		var selected_tracks: Array=[]
		var controlled_count: int=int(asset.get("controlled",{}).size())
		var active_total:=0
		var default_total:=0
		for clip in asset.clips:
			var key:=str(clip.name)
			if key in ["walk","run","2hreadyr","gustandf","attack","castout","pause1"]:requested[key]=""
			if native.get("clips",{}).get(key,{}).has("root"):available.append(key)
			else:unavailable.append(key)
			var active: Dictionary={}
			for channel in clip.tracks:active[str(int(channel.part))+":"+str(channel.property)]=true
			active_total+=active.size()
			default_total+=controlled_count-active.size()
			if key in ["walk","run","2hreadyr","gustandf","attack","castout","pause1"]:
				selected_tracks.append({"name":key,"active":active.size(),"default":controlled_count-active.size()})
		for key in requested:requested[key]=native.get("clips",{}).get(key,{}).has("root")
		var leaves:=0
		var child_counts: Array=[]
		child_counts.resize(model.nodes.size());child_counts.fill(0)
		for node in model.nodes:
			var parent:=int(node.parent)
			if parent>=0:child_counts[parent]=int(child_counts[parent])+1
		for count in child_counts:
			if int(count)==0:leaves+=1
		rows.append({"resource":name,"sha256":resource.sha256,"nodes":model.nodes.size(),
			"clips":asset.clips.size(),"native_available":available.size(),
			"native_unavailable":unavailable.size(),"native_source":native.get("source","binary"),
			"native_root":native.get("root",-1),"requested":requested,
			"physical_leaves":leaves,"example_unavailable":unavailable.slice(0,12),
			"controlled_channels":controlled_count,"selected_tracks":selected_tracks,
			"mean_active_tracks":float(active_total)/maxi(1,asset.clips.size()),
			"mean_default_tracks":float(default_total)/maxi(1,asset.clips.size())})
		reader=null;bytes=PackedByteArray();result.clear();decoded={}
		catalog.prepared_store.clear();catalog.decoder_store.clear()
	service.free()
	var report:={"success":failures.is_empty(),"checks":checks,"failures":failures,
		"rows":rows,"scope":"Three exact pinned original MDLs, actual decoder and rig_asset native clip coverage. Data-only; no ModelRigs selection, visual parity, timing or FPS."}
	var file:=FileAccess.open(report_path,FileAccess.WRITE)
	if file!=null:file.store_string(JSON.stringify(report,"\t")+"\n")
	print(JSON.stringify(report))
	quit(0 if failures.is_empty() else 1)

func _initialize()->void:
	call_deferred("run")
