extends SceneTree
const Style=preload("res://systems/native_client_menu_style.gd")
const WindowScript=preload("res://systems/draggable_panel.gd")
class Art extends Node:
	signal loaded(key: String,texture: Texture2D,bounds: Dictionary)
	var textures: Dictionary={}
	func request_model(name: String,clip: String="up") -> String:return name+":"+clip
class Fonts extends Node:
	signal loaded(name: String)
	var fonts: Dictionary={}
	var metrics: Dictionary={}
	func request(_name: String) -> void:pass
class Painter extends Node:
	var art:=Art.new()
	var fonts:=Fonts.new()
	func _init() -> void:add_child(art);add_child(fonts)
var checks:=0
var failures: Array=[]
var output:=""
func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.trim_prefix("--report=")
	call_deferred("run")
func check(value: bool,label: String) -> void:
	checks+=1
	if not value:failures.append(label);push_error(label)
func run() -> void:
	if output.is_empty() or FileAccess.file_exists(output):quit(2);return
	var windows: Array=[]
	for index in 24:
		var window=WindowScript.new();root.add_child(window)
		window.configure("Original window "+str(index),"window"+str(index),Vector2.ZERO,"")
		windows.append(window)
	var hidden_parent:=Control.new();root.add_child(hidden_parent)
	var inherited_window=WindowScript.new();hidden_parent.add_child(inherited_window)
	inherited_window.configure("Inherited hidden window","inherited-hidden",Vector2.ZERO,"")
	windows.append(inherited_window);hidden_parent.hide()
	var painter=Painter.new();root.add_child(painter)
	var original=Style.new();root.add_child(original)
	var original_changes: Array=[];original.changed.connect(func(value: Theme):original_changes.append(value))
	var began:=Time.get_ticks_usec();original.configure(painter);var original_us:=Time.get_ticks_usec()-began
	check(original_changes.size()==1 and original.current!=null,"synchronous style publishes once")
	check(windows.all(func(window):return window.theme==original.current),"synchronous style applies to all real client windows")
	var staged=Style.new();root.add_child(staged)
	var staged_changes: Array=[];staged.changed.connect(func(value: Theme):staged_changes.append(value))
	staged.begin_entry_publication();began=Time.get_ticks_usec();staged.configure(painter)
	var begin_us:=Time.get_ticks_usec()-began
	check(staged_changes.is_empty() and staged.current==null,"entry configure defers theme publication")
	check(windows.all(func(window):return window.theme==original.current),"entry configure keeps old theme until publication")
	var steps:=0;var maximum_step_us:=0;var dirty_restart:=false;var result: Dictionary={}
	var phase_maximum_us: Dictionary={};var phase_total_us: Dictionary={};var phase_counts: Dictionary={}
	while steps<80:
		var phase: String="refresh" if staged.entry_publication_dirty else "window" if staged.entry_publication_index<staged.entry_publication_windows.size() else "finish"
		began=Time.get_ticks_usec();result=staged.entry_publication_step();var elapsed:=Time.get_ticks_usec()-began
		maximum_step_us=maxi(maximum_step_us,elapsed);steps+=1
		phase_maximum_us[phase]=maxi(int(phase_maximum_us.get(phase,0)),elapsed)
		phase_total_us[phase]=int(phase_total_us.get(phase,0))+elapsed
		phase_counts[phase]=int(phase_counts.get(phase,0))+1
		if steps==3:
			var key: String=str(staged.keys.find_key("button:up"))
			var image:=Image.create_empty(2,2,false,Image.FORMAT_RGBA8)
			staged.art_loaded(key,ImageTexture.create_from_image(image),{})
			dirty_restart=true
		if result.get("done",false):break
	check(result.get("accepted",false) and dirty_restart and steps>26,"staged style restarts for a late original asset and completes")
	check(staged_changes.size()==1 and staged_changes[0]==staged.current,"staged theme notifies exactly once after all windows")
	check(windows.slice(0,24).all(func(window):return window.theme==staged.current) and inherited_window.theme==original.current and inherited_window.pending_native_theme==staged.current,"entry theme defers hidden inherited window without changing visible windows")
	var publication_receipt:=staged.entry_publication_receipt()
	check(publication_receipt.hidden_deferrals>=1 and publication_receipt.visible_applies>=24 and publication_receipt.pending_hidden==1,"entry receipt counts visible and deferred windows")
	hidden_parent.show()
	check(windows.all(func(window):return window.theme==staged.current) and inherited_window.pending_native_theme==null,"hidden window receives final theme synchronously when its ancestor shows")
	check(get_meta("native_client_menu_theme",null)==staged.current,"tree theme is published after staged windows")
	check(staged.current.default_font_size==original.current.default_font_size and staged.current.get_color("font_color","Button")==original.current.get_color("font_color","Button"),"base theme values match synchronous path")
	hidden_parent.hide()
	var cancelled=Style.new();root.add_child(cancelled)
	var cancelled_changes: Array=[];cancelled.changed.connect(func(value: Theme):cancelled_changes.append(value))
	cancelled.begin_entry_publication();cancelled.configure(painter);cancelled.entry_publication_step()
	for index in 32:
		if inherited_window.pending_native_theme==cancelled.current:break
		cancelled.entry_publication_step()
	check(inherited_window.pending_native_theme==cancelled.current,"cancelled entry stages a hidden theme")
	cancelled.close();hidden_parent.show()
	check(cancelled_changes.is_empty() and not cancelled.entry_publication_active and get_meta("native_client_menu_theme",null)==staged.current,"cancelled publication cannot notify or replace final theme")
	check(inherited_window.theme==staged.current and inherited_window.pending_native_theme==null,"cancelled hidden theme cannot appear later")
	hidden_parent.hide()
	var completed=Style.new();root.add_child(completed)
	completed.begin_entry_publication();completed.configure(painter)
	var completed_result: Dictionary={}
	for index in 80:
		completed_result=completed.entry_publication_step()
		if completed_result.get("done",false):break
	check(completed_result.get("accepted",false) and inherited_window.pending_native_theme==completed.current,"completed publication retains hidden update until visible")
	completed.close();hidden_parent.show()
	check(inherited_window.pending_native_theme==null and inherited_window.theme==staged.current,"closing completed publisher clears its pending hidden update")
	hidden_parent.hide()
	var repeated=Style.new();root.add_child(repeated)
	repeated.begin_entry_publication();repeated.configure(painter)
	var repeated_result: Dictionary={}
	for index in 80:
		repeated_result=repeated.entry_publication_step()
		if repeated_result.get("done",false):break
	check(repeated_result.get("accepted",false) and inherited_window.pending_native_theme==repeated.current,"first repeated publication leaves a hidden update")
	repeated.begin_entry_publication()
	check(inherited_window.pending_native_theme==null,"repeated begin clears prior completed hidden update")
	for index in 32:
		if inherited_window.pending_native_theme==repeated.current:break
		repeated.entry_publication_step()
	check(inherited_window.pending_native_theme==repeated.current,"active repeated publication stages hidden update")
	repeated.begin_entry_publication()
	check(inherited_window.pending_native_theme==null,"repeated begin clears prior active hidden update")
	for index in 80:
		repeated_result=repeated.entry_publication_step()
		if repeated_result.get("done",false):break
	hidden_parent.show()
	check(repeated_result.get("accepted",false) and inherited_window.theme==repeated.current and inherited_window.pending_native_theme==null,"latest repeated publication is the only theme revealed")
	var file:=FileAccess.open(output,FileAccess.WRITE)
	file.store_string(JSON.stringify({"passed":failures.is_empty(),"checks":checks,"failures":failures,"windows":windows.size(),"original_us":original_us,"begin_us":begin_us,"staged_maximum_step_us":maximum_step_us,"staged_steps":steps,"phase_maximum_us":phase_maximum_us,"phase_total_us":phase_total_us,"phase_counts":phase_counts,"scope":"Headless real NativeClientMenuStyle and DraggablePanel theme publication with authored painter API stub. No original assets, GPU, full client or FPS."},"\t"));file.close()
	for window in windows:window.free()
	for owner in [repeated,completed,cancelled,staged,original,painter,hidden_parent]:owner.free()
	quit(0 if failures.is_empty() else 1)
