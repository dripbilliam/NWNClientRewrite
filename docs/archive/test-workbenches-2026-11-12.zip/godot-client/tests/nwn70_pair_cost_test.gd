extends SceneTree
const Catalog=preload("res://systems/native_data/resource_catalog.gd")
const Store=preload("res://systems/native_data/prework_store.gd")
const Cache=preload("res://systems/native_data/prepared_cache.gd")
class Source extends RefCounted:
	var bytes:=PackedByteArray()
	var failure:=""
	func get_resource(_name: String,_type: int) -> PackedByteArray:return bytes
var options: Dictionary={}
var failed:=false
func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		var pair:=arg.trim_prefix("--").split("=",true,1)
		if pair.size()==2:options[pair[0]]=pair[1]
	call_deferred("run")
func summarize(values: Array) -> Dictionary:
	var sorted:=values.duplicate();sorted.sort();var total:=0.0
	for value in values:total+=float(value)
	return {"samples":values.size(),"median_us":sorted[values.size()/2],"p95_us":sorted[mini(values.size()-1,int(ceil(values.size()*0.95))-1)],"p99_us":sorted[mini(values.size()-1,int(ceil(values.size()*0.99))-1)],"mean_us":total/values.size()}
func measure(bytes: PackedByteArray,name: String,type: int,reference: bool,count: int) -> Dictionary:
	var before=load("res://.cache/nwn70/baseline/prework_store.gd")
	var source:=Source.new();source.bytes=bytes
	var inputs=before.Inputs.new(source) if reference else Store.Inputs.new(source)
	var expected:=Cache.digest(bytes);var times: Array=[]
	for index in count+40:
		var digest: String
		var began:=Time.get_ticks_usec()
		if reference:
			var raw: PackedByteArray=inputs.get_resource(name,type)
			digest=Cache.digest(raw) # The immediately following decoder's identity read.
			raw=PackedByteArray()
		else:
			var packet: Dictionary=inputs.get_resource_with_digest(name,type)
			digest=str(packet.sha256)
			packet.clear() # Include release of the private copied byte owner.
		var elapsed:=Time.get_ticks_usec()-began
		if digest!=expected:failed=true
		if index>=40:times.append(elapsed)
	var result:=summarize(times);result.source_sha256=expected;result.source_bytes=bytes.size();result.dependency=inputs.snapshot();return result
func run() -> void:
	if not options.has_all(["report","install"]) or FileAccess.file_exists(options.report):quit(2);return
	var source_sha:=FileAccess.get_sha256("res://systems/native_data/prework_store.gd")
	var catalog:=Catalog.new()
	if not catalog.mount_install(str(options.install)):quit(2);return
	var rows: Array=[];var samples:=int(options.get("samples",600))
	if samples<100 or samples>2000:quit(2);return
	for definition in [{"name":"pnl_party_bar","type":3},{"name":"tcn01_splotch02","type":2033}]:
		var bytes:=catalog.get_resource(str(definition.name),int(definition.type))
		if not catalog.failure.is_empty() or bytes.is_empty():failed=true;continue
		var a:=measure(bytes,str(definition.name),int(definition.type),true,samples)
		var b:=measure(bytes,str(definition.name),int(definition.type),false,samples)
		var c:=measure(bytes,str(definition.name),int(definition.type),false,samples)
		var d:=measure(bytes,str(definition.name),int(definition.type),true,samples)
		if a.dependency!=b.dependency or a.dependency!=c.dependency or a.dependency!=d.dependency:failed=true
		rows.append({"name":definition.name,"type":definition.type,"source_bytes":bytes.size(),"reference":[a,d],"paired":[b,c]})
	if source_sha!=FileAccess.get_sha256("res://systems/native_data/prework_store.gd"):failed=true
	var report:={"success":not failed,"order":"A-B-B-A","rows":rows,"prework_sha256":source_sha,"scope":"Actual original get_resource+dependency record+decoder SHA versus current owned paired read+copy+oneSHA+record, including private buffer release, on two original installed raster buffers. Immutable in-memory reader isolates helper cost. No decoder, source IO, queue throughput, GUI/renderer or FPS claim."}
	var file:=FileAccess.open(options.report,FileAccess.WRITE);file.store_string(JSON.stringify(report,"\t"));file.close();print("NWN70_PAIR_COST ",JSON.stringify(report));quit(0 if report.success else 1)
