extends "res://tests/nwn63_interval_edges_groups_benchmark.gd"
# Source-only route probe: identical current owners, existing BVH versus
# existing flat-control group query. Only direct static_candidates is timed.
func run()->void:
	var options: Dictionary={}
	for argument in OS.get_cmdline_user_args():
		var split:=argument.trim_prefix("--").split("=",true,1)
		if split.size()==2:options[split[0]]=split[1]
	var samples:=int(options.get("samples",96))
	check(samples>=32 and samples<=256,"Explicit bounded samples")
	var pair:=group_pair(340)
	# The saved live owner had 324 model groups and 891 static entries. Keep
	# this fixture's 342 groups, then add 549 members to match that density.
	var additions: Array=[]
	for extra in 549:
		var cohort:=extra%340
		var anchor:=Vector2(24+(cohort%12)*8,24+(cohort/12)*8)
		additions.append(object(1000+extra,anchor+Vector2(float(extra%3)*0.4,float(extra%5)*0.4),9,1,2+cohort))
	for setup in pair:
		setup.world.receive_delta(additions,[],1)
		check(int(setup.collision.snapshot().static_entries)==891,"Live-density 342-group/891-entry publication")
	pair[1].collision.retained_flat_control=true
	var cases: Array=[]
	for spec in [
		["far",Vector3(1,7,0),Vector3(4,7,0)],
		["near",Vector3(24,24,0),Vector3(30,30,0)],
		["many",Vector3(24,24,0),Vector3(112,112,0)],
	]:
		var result: Dictionary=measure_groups(pair,samples,"static_candidates",spec[1],spec[2])
		result.label=spec[0];cases.append(result)
	for setup in pair:setup.world.free()
	await process_frame;await process_frame
	var report:={"success":failures.is_empty(),"checks":checks,"failures":failures,"cases":cases,"scope":"Same-source live-density 342 model groups/891 static entries direct static_candidates ABBA, existing BVH vs existing flat-control group query. No source mutation, path/FPS or original Arelith claim."}
	var file:=FileAccess.open(str(options.report),FileAccess.WRITE);file.store_string(JSON.stringify(report,"  "));file.close()
	print(JSON.stringify({"success":report.success,"checks":checks,"failures":failures,"cases":cases}));quit(0 if failures.is_empty() else 1)
