extends "res://tests/nwn63_walkable_aabb_original_wok_test.gd"
const Worker=preload("res://systems/native_render/drive_preview_worker.gd")

func transcript(collision,from: Vector3,target: Vector3)->Dictionary:
	var probes: Array=[];var query: Callable=collision.query_preview(1,from,target,from)
	var clear:=func(a: Vector3,b: Vector3):
		var accepted: bool=query.call(a,b)
		probes.append([a,b,accepted,str(collision.stats.get("last_blocked",{}).get("reason","")) if not accepted else ""])
		return accepted
	return {"path":Plan.path(from,target,from,clear),"probes":probes}

func run()->void:
	var options: Dictionary={}
	for argument in OS.get_cmdline_user_args():
		var split:=argument.trim_prefix("--").split("=",true,1)
		if split.size()==2:options[split[0]]=split[1]
	if not options.has("fixture") or not options.has("report"):quit(2);return
	var fixture: Variant=JSON.parse_string(FileAccess.get_file_as_string(str(options.fixture)))
	check(fixture is Dictionary and fixture.get("sources") is Array and fixture.sources.size()==74,"Pinned 74-original-WOK corpus")
	if not failures.is_empty():quit(2);return
	var catalog:=Catalog.new();var install:=str(options.get("install",ProjectSettings.globalize_path("res://../../FullDecomp/NwnRootInstall")))
	check(catalog.mount_install(install),"Original install mounts read-only")
	if not failures.is_empty():quit(2);return
	var table_bytes: PackedByteArray=catalog.get_resource("surfacemat",2017)
	var parser:=Table.new();var table: Dictionary=parser.parse(Binary.new(table_bytes).text(0,table_bytes.size()))
	check(not table_bytes.is_empty() and parser.failure.is_empty() and digest(table_bytes)==str(fixture.table_sha256),"Exact original surfacemat bytes")
	if not failures.is_empty():quit(2);return
	var pair:=group_pair(340);var setup: Dictionary=pair[1];var collision=setup.collision
	var from:=Vector3(1,1,0);var target:=Vector3(3,1,0);var rows: Array=[]
	for source in fixture.sources:
		var name:=str(source.name);var bytes: PackedByteArray=catalog.get_resource(name,2016)
		var decoder:=TileSurface.new();var mesh: Dictionary=decoder.parse_bytes(bytes)
		check(not bytes.is_empty() and decoder.failure.is_empty() and digest(bytes)==str(source.sha256) and mesh.faces.size()==int(source.faces),"Pinned original WOK "+name)
		if mesh.is_empty():continue
		install_asset(setup,name,mesh,table)
		var blocker:=Collision.triangle(Vector3(0,0,0),Vector3(5,0,0),Vector3(0,5,0));blocker.walk=false;collision.tile(0).append(blocker)
		var reference: Dictionary=transcript(collision,from,target)
		var snapshot: Dictionary=collision.prepare_worker_preview(1,from,target,from)
		check(snapshot.has("packet"),"Original "+name+" sealed packet")
		if not snapshot.has("packet"):continue
		var worker:=Worker.new();worker.packet=snapshot.packet
		var outcome: Dictionary=worker.run()
		check(outcome.get("valid",false) and var_to_bytes(outcome.get("path",{}))==var_to_bytes(reference.path) and outcome.get("probes",[])==reference.probes,"Original "+name+" exact search transcript")
		check(collision.worker_preview_current(snapshot),"Original "+name+" unchanged source admits")
		rows.append({"name":name,"faces":mesh.faces.size(),"probes":reference.probes.size(),"tiles":snapshot.tiles,"snapshot_faces":snapshot.faces})
	check(rows.size()==74,"All 74 pinned original WOKs pass through worker route")
	for owner in pair:owner.world.free()
	await process_frame;await process_frame
	var report:={"success":failures.is_empty(),"checks":checks,"failures":failures,"sources":rows,"table_sha256":digest(table_bytes),"scope":"Read-only 74 original WOK hashes and surfacemat, one authored blocked local path per mesh under 342 model groups. Exact worker/main path bytes and ordered probes/reasons, deep source admission. No recorded Arelith tile layout, normal-client integration, timing or FPS claim."}
	var file:=FileAccess.open(str(options.report),FileAccess.WRITE);file.store_string(JSON.stringify(report,"  "));file.close()
	print(JSON.stringify({"success":report.success,"checks":checks,"failures":failures,"sources":rows.size()}));quit(0 if failures.is_empty() else 1)
