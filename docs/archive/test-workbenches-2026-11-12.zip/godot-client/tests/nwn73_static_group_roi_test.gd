extends "res://tests/nwn63_model_groups_test.gd"

# Bound the maximum possible gain before adding a static-group worker.
# This measures the complete current static query, the exact root gate, and
# copying only scalar group metadata into a prospective immutable view.
func root_gate(collision,from: Vector3,to: Vector3,radius: float) -> Dictionary:
	var selected:=0;var visited:=0;var pending:=0
	var min_x:=minf(from.x,to.x);var max_x:=maxf(from.x,to.x)
	var min_y:=minf(from.y,to.y);var max_y:=maxf(from.y,to.y)
	for model_key in collision.static_groups:
		var group: Dictionary=collision.static_groups[model_key]
		var bounds: Dictionary=group.bounds
		if bounds.is_empty():continue
		visited+=1
		var unknown: bool=not collision.models.has(model_key)
		if not unknown:
			var model: Dictionary=collision.models[model_key]
			unknown=model.is_empty() or model.has("error")
		var states: Array=collision.model_bounds.get(model_key,[])
		var footprint:=12.0 if unknown else 0.0
		if not unknown:
			for state in states:
				if state.get("pending",false):return {"ready":false}
				footprint=maxf(footprint,float(state.get("radius",0)))
		var expansion:=footprint+(0.0 if unknown else radius)
		if not unknown:
			var magnitude:=maxf(1.0,footprint)
			var group_min_x:=float(bounds.min_x);var group_min_y:=float(bounds.min_y)
			var group_max_x:=float(bounds.max_x);var group_max_y:=float(bounds.max_y)
			magnitude=maxf(magnitude,absf(group_min_x));magnitude=maxf(magnitude,absf(group_min_y))
			magnitude=maxf(magnitude,absf(group_max_x));magnitude=maxf(magnitude,absf(group_max_y))
			expansion+=magnitude*0.000003814697265625
			if group_min_x>max_x+expansion or group_max_x<min_x-expansion or group_min_y>max_y+expansion or group_max_y<min_y-expansion:continue
		elif float(bounds.min_x)>max_x+expansion or float(bounds.max_x)<min_x-expansion or float(bounds.min_y)>max_y+expansion or float(bounds.max_y)<min_y-expansion:continue
		selected+=1
		if unknown:pending+=1
	return {"ready":true,"visited":visited,"selected":selected,"pending":pending}

func snapshot(collision) -> Array:
	var rows: Array=[]
	for key in collision.static_groups:
		var group: Dictionary=collision.static_groups[key]
		var bounds: Dictionary=group.bounds
		if bounds.is_empty():continue
		var unknown: bool=not collision.models.has(key)
		if not unknown:
			var model: Dictionary=collision.models[key]
			unknown=model.is_empty() or model.has("error")
		var footprint:=12.0 if unknown else 0.0
		if not unknown:
			for state in collision.model_bounds.get(key,[]):
				if state.get("pending",false):return []
				footprint=maxf(footprint,float(state.get("radius",0)))
		rows.append([str(key),float(bounds.min_x),float(bounds.min_y),float(bounds.max_x),float(bounds.max_y),footprint,unknown])
	return rows

func stats(samples: Array) -> Dictionary:
	samples.sort()
	return {"median_us":samples[samples.size()/2],"p95_us":samples[ceili(samples.size()*0.95)-1],"count":samples.size()}

func run() -> void:
	var pair:=group_pair(340)
	var owner=pair[1].collision
	var queries: Array=[
		[Vector3(1,7,0),Vector3(4,7,0)],
		[Vector3(2,1.5,0),Vector3(6,1.5,0)],
		[Vector3(80,80,0),Vector3(93,81,0)]]
	var output: Array=[]
	for query in queries:
		var a: Vector3=query[0];var b: Vector3=query[1]
		var gate:=root_gate(owner,a,b,0.3)
		check(gate.ready,"No pending states in ROI gate")
		for warm in 20:owner.static_candidates(a,b,0.3,1);root_gate(owner,a,b,0.3);snapshot(owner)
		var measures: Dictionary={"full":[],"gate":[],"snapshot":[]}
		for mode in ["full","gate","snapshot","snapshot","gate","full"]:
			for trial in 80:
				var started:=Time.get_ticks_usec()
				match mode:
					"full":owner.static_candidates(a,b,0.3,1)
					"gate":root_gate(owner,a,b,0.3)
					"snapshot":snapshot(owner)
				measures[mode].append(Time.get_ticks_usec()-started)
		output.append({"from":a,"to":b,"gate":gate,"full":stats(measures.full),"root_gate":stats(measures.gate),"snapshot":stats(measures.snapshot)})
	for setup in pair:setup.world.free()
	await process_frame;await process_frame
	var result:={"passed":failures.is_empty(),"checks":checks,"failures":failures,"groups":342,"queries":output,"scope":"Headless 342-model-group component ROI only, no worker/default/FPS"}
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):
			var file:=FileAccess.open(arg.substr(9),FileAccess.WRITE);file.store_string(JSON.stringify(result,"\t"));file.close()
	print(JSON.stringify(result));quit(0 if failures.is_empty() else 1)
