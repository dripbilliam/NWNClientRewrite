'use strict';
const assert = require('node:assert/strict');
const path = require('node:path');
const flags = require('../tools/native-client-flags.cjs');

const project = path.resolve(__dirname, '..');
const rows = flags.catalogue(project).features.filter(row => row.name === 'drive-preview-worker');
assert.equal(rows.length, 1);
assert.deepEqual(rows[0].choices, ['off', 'on']);
assert.equal(rows[0].default, 'off');
assert.equal(rows[0].target, 'native');
assert.equal(rows[0].forwarder, 'performance');
assert.deepEqual(rows[0].requires, {'drive-collision': 'indexed'});

for (const argv of [[], ['--performance-runtime=verified-native']]) {
 const resolved = flags.resolvePerformanceOptions(argv);
 assert.deepEqual(resolved.requested['drive-preview-worker'], {value: 'off', explicit: false});
 assert(!resolved.nativeArguments.some(value => value.startsWith('--drive-preview-worker=')));
}
for (const choice of ['off', 'on']) {
 const token = '--drive-preview-worker=' + choice;
 const parsed = flags.validateHostOptions([token]);
 assert.equal(parsed.values['drive-preview-worker'], choice);
 const resolved = flags.resolvePerformanceOptions([token]);
 assert.deepEqual(resolved.requested['drive-preview-worker'], {value: choice, explicit: true});
 assert.deepEqual(resolved.nativeArguments.filter(value => value.startsWith('--drive-preview-worker=')), [token]);
}
for (const argv of [
 ['--drive-preview-worker'],
 ['--drive-preview-worker=parallel'],
 ['--drive-preview-worker=on', '--drive-preview-worker=off'],
 ['--drive-preview-worker=on', '--drive-collision=legacy']
]) assert.throws(() => flags.validateHostOptions(argv));

console.log(JSON.stringify({passed: true, checks: 21, scope: 'Default-off explicit movement preview worker selection and host forwarding only; no Godot launch or FPS.'}));
