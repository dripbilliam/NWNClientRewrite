extends "res://tests/nwn65_active_cost_breakdown_test.gd"

func run() -> void:
	if output.is_empty() or FileAccess.file_exists(output):
		quit(2)
		return
	sparse_skins = true
	var result := _sample("skin")
	var passed: bool = result.players == 64 and result.pose_frames == 32 * 100
	var report := {"ticket": "NWN-65", "passed": passed,
		"rig_sha256": FileAccess.get_sha256("res://systems/model_rigs.gd"),
		"sample": result, "scope": "32 active owners, 65 skin slots with only 3 authored slots, 100 frames; headless script publisher component timing."}
	var file := FileAccess.open(output, FileAccess.WRITE)
	file.store_string(JSON.stringify(report, "\t"))
	file.close()
	quit(0 if passed else 1)
