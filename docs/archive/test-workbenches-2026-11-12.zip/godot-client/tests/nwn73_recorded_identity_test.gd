extends SceneTree
const Recorded=preload("res://systems/native_data/recorded_catalog.gd")
func _initialize() -> void:call_deferred("run")
func original(key: String,storage: Variant) -> bool:
	var split:=str(key).rsplit(":",true,1)
	return not (split.size()!=2 or not str(split[1]).is_valid_int() or int(split[1])<0 or int(split[1])>65535 or str(split[0]).is_empty() or str(split[0]).length()>32 or "/" in key or "\\" in key or str(key).count(":")!=1 or int(storage) not in [1,2,3,5])
func run() -> void:
	var output:=""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):output=arg.substr(9)
	if output.is_empty() or FileAccess.file_exists(output):quit(2);return
	var keys: Array[String]=["",":0","a:","a:0","a:+0","a:-0","a:00001","a:65535","a:65536","a:-1","a:3.0","a:1e2","a: 3","a:3 ","a:3:4","a/b:3","a\\b:3","é:3","x".repeat(32)+":5","x".repeat(33)+":5"]
	for index in 128:
		keys.append("res"+str(index)+":"+str(index%65537))
		keys.append("n".repeat(index%35)+":"+str(index*511))
	var storages: Array=[-1,0,1,2,3,4,5,"3",3.9]
	var checks:=0;var mismatches: Array=[]
	for key in keys:
		for storage in storages:
			checks+=1
			if Recorded._valid_identity_fast(key,storage)!=original(key,storage):mismatches.append({"key":key,"storage":storage})
	var report:={"success":mismatches.is_empty(),"checks":checks,"mismatches":mismatches,"scope":"Fast recorded identity predicate versus frozen original for boundary and generated JSON String keys/storage values; no entry or FPS timing."}
	var file:=FileAccess.open(output,FileAccess.WRITE)
	if file==null:quit(3);return
	file.store_string(JSON.stringify(report,"  ")+"\n");file.close();quit(0 if mismatches.is_empty() else 1)
